#!/usr/bin/env python3
"""LANTERN clean-ink mechanisms. Fresh untouched illustration masters + editable
world-space assembly and clipping meshes. Never regenerates animation frames.
This authored art source is separate from the preserved original mechanism pack.
"""
from pathlib import Path
from font_support import get_font
import math,json,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageChops
ROOT=Path(__file__).resolve().parents[1]
W=H=1536; PPM=440.; ROOTPX=np.array([768.,1220.]); ELEV=math.radians(35.2643897)
INK='#231d19'; STONE='#4b4035'; RAW='#c19b66'
CACHE={}; LAYERS={}; MASKS={}
def p(v):
 x,y,z=v
 return tuple(ROOTPX+PPM*np.array([(x-z)/math.sqrt(2),(x+z)*math.sin(ELEV)/math.sqrt(2)-y*math.cos(ELEV)]))
def ry(a):
 a=math.radians(a);return np.array([[math.cos(a),0,-math.sin(a)],[0,1,0],[math.sin(a),0,math.cos(a)]])
def rx(a):
 a=math.radians(a);return np.array([[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]])
def rz(a):
 a=math.radians(a);return np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]])
def master(id):
 if id not in CACHE:CACHE[id]=Image.open(ROOT/'source/masters'/f'{id}.png').convert('RGBA')
 return CACHE[id]
def layer(id,name,bbox):
 key=id+'_'+name
 if key not in LAYERS:
  im=master(id).crop(bbox);LAYERS[key]=im;im.save(ROOT/'layers'/f'{key}.png')
 return LAYERS[key]
def cut(img,pts,id,invert=False):
 """Editable source clipping mesh, preserving all master pixels and alpha."""
 MASKS[id]={'polygon_px':pts,'subtract':invert}
 m=Image.new('L',img.size,255 if invert else 0);ImageDraw.Draw(m).polygon(pts,fill=0 if invert else 255)
 out=img.copy();out.putalpha(ImageChops.multiply(img.getchannel('A'),m));return out
class Art:
 def __init__(self):self.im=Image.new('RGBA',(W,H))
 def poly(self,points,col,stroke=INK,sw=2):
  d=ImageDraw.Draw(self.im);q=[p(v) for v in points];d.polygon(q,fill=col)
  if stroke:d.line(q+[q[0]],fill=stroke,width=sw,joint='curve')
 def line(self,pts,col,sw):ImageDraw.Draw(self.im).line([p(v) for v in pts],fill=col,width=sw,joint='curve')
 def texture(self,img,o,u,v,R=None,pivot=None):
  o=np.array(o,float);u=np.array(u,float);v=np.array(v,float)
  if R is not None:
   pivot=np.array(pivot if pivot is not None else [0,0,0]);o=R@(o-pivot)+pivot;u=R@u;v=R@v
  dst=np.array([p(o),p(o+u*img.width),p(o+v*img.height)]);src=np.array([[0,0],[img.width,0],[0,img.height]],float)
  if abs(np.linalg.det(np.column_stack([dst,np.ones(3)])))<1e-5:return
  M=np.linalg.solve(np.column_stack([dst,np.ones(3)]),src).T
  transformed=img.transform((W,H),Image.Transform.AFFINE,tuple(M.flatten()),Image.Resampling.BICUBIC)
  self.im.alpha_composite(transformed)
 def sprite(self,img,source_anchor,world_anchor,metres_per_pixel,R=None,pivot=None):
  # Already-isometric painted volumes stay in the fixed camera basis.
  right=np.array([1/math.sqrt(2),0,-1/math.sqrt(2)])
  down=np.array([math.sin(ELEV)/math.sqrt(2),-math.cos(ELEV),math.sin(ELEV)/math.sqrt(2)])
  u=right*metres_per_pixel;v=down*metres_per_pixel;o=np.array(world_anchor)-u*source_anchor[0]-v*source_anchor[1]
  self.texture(img,o,u,v,R,pivot)
 def triangle(self,img,uv,verts):
  dst=np.array([p(q) for q in verts]);src=np.array(uv,float)
  lo=np.floor(dst.min(axis=0)).astype(int)-2;hi=np.ceil(dst.max(axis=0)).astype(int)+2
  lo=np.maximum(lo,0);hi=np.minimum(hi,[W,H]);size=tuple(hi-lo)
  if min(size)<=0:return
  dst=dst-lo
  M0=np.column_stack([dst,np.ones(3)])
  if abs(np.linalg.det(M0))<1e-5:return
  M=np.linalg.solve(M0,src).T;tile=img.transform(size,Image.Transform.AFFINE,tuple(M.flatten()),Image.Resampling.BICUBIC)
  mask=Image.new('L',size);ImageDraw.Draw(mask).polygon([tuple(q) for q in dst],fill=255)
  tile.putalpha(ImageChops.multiply(tile.getchannel('A'),mask));self.im.alpha_composite(tile,tuple(lo))
 def revolved(self,img,profile,center=(0,0,0),R=None,pivot=None,axis='y'):
  # Each profile row: source v, source center-u, source radius-u, world axis coordinate, world radius.
  # One painted front master is wrapped onto an actual surface of revolution.
  center=np.array(center);pivot=np.array(pivot if pivot is not None else center)
  theta=np.linspace(-math.pi/4,3*math.pi/4,19)
  quads=[]
  def pt(row,t):
   vv,cu,ru,yy,r=row
   local=np.array([r*math.sin(t),yy,r*math.cos(t)]) if axis=='y' else np.array([yy,r*math.sin(t),r*math.cos(t)])
   world=local+center
   if R is not None:world=R@(world-pivot)+pivot
   return (cu+ru*math.sin(t),vv),world
  for row0,row1 in zip(profile,profile[1:]):
   for t0,t1 in zip(theta,theta[1:]):
    q=[pt(row0,t0),pt(row0,t1),pt(row1,t1),pt(row1,t0)]
    depth=sum(sum(v[1]) for v in q);quads.append((depth,q))
  for _,q in sorted(quads,key=lambda z:z[0]):
   for ids in [(0,1,2),(0,2,3)]:self.triangle(img,[q[i][0] for i in ids],[q[i][1] for i in ids])
 def disc(self,center,r,plane='xz',fill='#58442e',n=32,R=None,pivot=None):
  pts=[];center=np.array(center);pivot=np.array(pivot if pivot is not None else center)
  for i in range(n):
   t=i*math.tau/n;v=np.array([r*math.cos(t),0,r*math.sin(t)]) if plane=='xz' else np.array([0,r*math.cos(t),r*math.sin(t)])
   q=center+v
   if R is not None:q=R@(q-pivot)+pivot
   pts.append(q)
  self.poly(pts,fill,INK,3)
 def front(self,img,x,y,z,w,h,R=None,pivot=None):
  self.texture(img,(x,y+h,z),(w/img.width,0,0),(0,-h/img.height,0),R,pivot)
 def top(self,img,x,y,z,w,depth,R=None,pivot=None):
  self.texture(img,(x,y,z),(w/img.width,0,0),(0,0,depth/img.height),R,pivot)
 def contour_depth(self,contours,x,y,z,w,h,depth,colors=('#40382f','#675947')):
  for outline in contours:
   for a,b in zip(outline,outline[1:]+outline[:1]):
    a=np.array([x+a[0]*w,y+(1-a[1])*h,z]);b=np.array([x+b[0]*w,y+(1-b[1])*h,z]);off=np.array([0,0,-depth])
    color=colors[1] if abs(b[0]-a[0])>abs(b[1]-a[1])*.8 else colors[0]
    self.poly([a,b,b+off,a+off],color,INK,2)
 def pad(self,r=.5,y=.04,depth=.10,n=8):
  pts=[(r*math.cos(math.tau*i/n+math.pi/8),y,r*math.sin(math.tau*i/n+math.pi/8)) for i in range(n)]
  for i in range(n):
   a,b=pts[i],pts[(i+1)%n];self.poly([a,b,(b[0],y-depth,b[2]),(a[0],y-depth,a[2])], '#4e4336' if i%3 else '#6a5840',INK,2)
  self.poly(pts,'#635344',INK,2)

# All contour coordinates below are source registration annotations, not substitute front art.
DOOR_OUT=[(.01,1),(.026,.877),(.053,.837),(.075,.596),(.075,.472),(.043,.432),(.043,.413),(.084,.411),(.121,.340),(.182,.262),(.265,.192),(.28,.156),(.38,.109),(.429,.052),(.531,.001),(.631,.047),(.64,.056),(.721,.096),(.794,.153),(.835,.201),(.876,.26),(.909,.318),(.95,.405),(.987,.408),(.987,.428),(.953,.46),(.96,.588),(.976,.827),(1,1)]
DOOR_IN=[(.275,1),(.276,.468),(.278,.415),(.295,.344),(.332,.284),(.389,.224),(.465,.179),(.529,.151),(.594,.182),(.669,.23),(.718,.291),(.753,.352),(.769,.424),(.77,.982)]
def door(state='closed',t=None):
 a=Art();id='gothic_oak_door';f=layer(id,'frame',(100,10,866,1002));l=layer(id,'leaf',(949,149,1381,994));h=2.46;w=766/992*h;x=-w/2;y=.015;z=.0
 a.contour_depth([DOOR_OUT,DOOR_IN],x,y,z,w,h,.20);a.front(f,x,y,z,w,h)
 lx=(303-490)*h/992;lw=(677-303)*h/992;lh=844*h/992;pivot=[lx,.0,.023];ang=100*((0 if state=='closed' else 1 if state=='open' else .07) if t is None else t)
 if state=='broken':
  hole=[(122,436),(135,454),(130,501),(161,480),(166,551),(191,530),(186,619),(205,609),(205,850),(91,850),(100,721),(83,742),(91,627),(110,639),(108,535)]
  frag=cut(l,hole,'door_splinter_fragment');l=cut(l,hole,'door_missing_boards',True)
  a.top(frag,-.30,.043,.28,.53,.87,R=ry(22))
  # Freshly authored raw oak fracture lip; never stretched texture edges.
  a.poly([(-.224,.63,.030),(-.194,.80,.030),(-.17,.70,.030),(-.151,.96,.030),(-.128,.84,.030),(-.145,.61,.030)],RAW,INK,2)
 # Same original source across every door frame, with a small genuine side thickness.
 for off in [-.025,0]:a.front(l,lx-14/432*lw,.025,.023+off,lw*432/414,lh,R=ry(ang),pivot=pivot)
 return a.im

def portcullis(state='closed',t=None):
 a=Art();id='iron_portcullis';f=layer(id,'frame',(30,24,922,982));g=layer(id,'gate',(956,66,1484,960))
 x=-.96;w=1.92;h=2.25;y=.025;z=0
 outer=[(0,1),(.036,.854),(.065,.813),(.066,.165),(.048,.14),(.048,.016),(.406,.016),(.406,0),(.597,0),(.597,.016),(.951,.016),(.951,.14),(.934,.165),(.934,.813),(.965,.854),(1,1)]
 inner=[(.267,1),(.267,.172),(.743,.172),(.743,1)]
 a.contour_depth([outer,inner],x,y,z,w,h,.25)
 v=(0 if state=='closed' else 1 if state=='open' else .05) if t is None else t;travel=2.08*v
 gate=g
 if state=='broken':
  hole=[(143,338),(183,330),(194,397),(220,369),(259,414),(282,393),(315,460),(331,449),(354,601),(328,633),(337,896),(144,896)]
  shard=cut(g,hole,'portcullis_bent_piece');gate=cut(g,hole,'portcullis_missing_middle',True)
  a.top(shard,-.15,.043,.26,.58,.84,R=ry(-27))
 # Gate source is geometrically occluded inside its shaft above world y=2.08.
 gh=2.08;gy=.07+travel;visible_h=max(0,min(gh,2.08-gy))
 if visible_h>0:
  sy=int(gate.height*(1-visible_h/gh));visible=gate.crop((0,sy,gate.width,gate.height))
  a.front(visible,-.475,gy,.018,.95,visible_h)
 a.front(f,x,y,z+.032,w,h)
 return a.im

def lever(state='idle',t=None):
 a=Art();id='yoke_lever';base=master('yoke_lever_isobase');l=layer(id,'handle',(674,12,836,980))
 anchor=(654,845);scale=.00070;pivot=np.array([.07,.52,0])
 a.sprite(base,anchor,[0,0,0],scale)
 angle=-36+70*((0 if state=='idle' else 1 if state=='engaged' else .56) if t is None else t)
 if state=='broken':
  split=[(0,505),(35,493),(46,529),(70,476),(99,523),(122,490),(162,518),(162,968),(0,968)]
  stub=cut(l,split,'lever_broken_stub');grip=cut(l,split,'lever_fallen_grip',True)
  a.top(grip,.11,.055,.25,.16,.62,R=ry(38));l=stub
 # An axial billboard represents the round grip/shaft, keeping its diameter through the swing.
 axis=rx(angle)@np.array([0,1,0]);view=np.array([1,1,1])/math.sqrt(3)
 u=np.cross(view,axis);u=u/np.linalg.norm(u)*(.154/l.width)
 if u[0]<0:u=-u
 v=-axis*(.91/l.height);origin=pivot-u*80-v*886
 a.texture(l,origin,u,v)
 # Foreground cheek remains in front of the lever's true center bearing.
 front=cut(base,[(787,145),(887,184),(915,399),(990,534),(1062,615),(942,688),(711,830),(526,788),(489,756),(631,640),(675,333),(682,239)],'lever_front_cheek')
 a.sprite(front,anchor,[0,0,0],scale)
 return a.im

def pressure_plate(state='idle',t=None):
 a=Art();id='octagonal_pressure_plate';rim=layer(id,'rim',(10,0,884,858));plate=layer(id,'plate',(936,36,1745,826));v=(0 if state=='idle' else 1) if t is None else t;y=.205-.08*v
 a.pad(.58,.092,.085)
 a.top(rim,-.56,.108,-.56,1.12,1.12)
 if state=='broken':
  crack=[(0,0),(436,0),(430,210),(405,282),(454,353),(401,426),(433,473),(402,540),(431,790),(0,790)]
  left=cut(plate,crack,'plate_left');right=cut(plate,crack,'plate_right',True)
  a.top(left,-.386,.142,-.386,.772,.772);a.top(right,-.356,.115,-.364,.772,.772,R=ry(-5),pivot=[0,.115,0])
  a.line([(.019,.15,-.35),(-.004,.15,-.15),(.043,.15,-.035),(-.014,.15,.063),(.03,.15,.18)],'#d0ad70',3)
 else:a.top(plate,-.386,y,-.386,.772,.772)
 return a.im

def valve(state='idle',t=None):
 a=Art();id='brass_stop_valve';body=master('brass_stop_valve_isobody');wheel=layer(id,'wheel',(828,248,1515,912))
 a.sprite(body,(572,1040),[0,0,0],.00078)
 center=np.array([-.059,.647,.40]);dia=.64
 ang=63*((0 if state=='idle' else 1 if state=='engaged' else .35) if t is None else t)
 if state=='broken':
  hole=[(346,0),(700,0),(700,353),(618,376),(536,315),(502,220),(414,169)]
  fallen=cut(wheel,hole,'valve_rim_fragment');wheel=cut(wheel,hole,'valve_missing_rim',True)
  a.top(fallen,.18,.05,.22,.43,.43,R=ry(19))
 a.front(wheel,center[0]-dia/2,center[1]-dia/2,center[2],dia,dia,R=rz(ang),pivot=center)
 return a.im

def winch(state='idle',t=None):
 a=Art();id='oak_rope_winch';frame=layer(id,'frame',(25,78,867,687));drum=layer(id,'drum',(845,218,1548,676));crank=layer(id,'crank',(1554,145,2017,576))
 frame=cut(frame,[(0,609),(0,518),(60,437),(61,160),(67,22),(112,0),(207,0),(213,158),(207,291),(329,421),(510,421),(638,291),(631,149),(639,0),(761,0),(762,417),(792,466),(842,518),(842,609)],'winch_frame_atlas_isolation')
 drum=cut(drum,[(5,124),(110,124),(124,11),(160,0),(555,0),(586,15),(600,121),(694,122),(702,152),(694,179),(599,179),(582,292),(538,300),(384,300),(384,444),(366,458),(335,449),(331,300),(160,300),(126,292),(110,182),(5,181)],'winch_drum_atlas_isolation')
 # Pair of long source-matched timber shoes provides true ground depth.
 for xx in [-.50,.40]:
  a.poly([(xx,.035,-.33),(xx+.13,.035,-.33),(xx+.13,.12,.37),(xx,.12,.37)],'#644027',INK,3)
  a.poly([(xx,.12,-.33),(xx+.13,.12,-.33),(xx+.13,.12,.37),(xx,.12,.37)],'#ad7845',INK,3)
  a.line([(xx+.04,.124,-.28),(xx+.052,.124,.10),(xx+.032,.124,.31)],'#543821',3)
  a.poly([(xx+.13,.035,-.33),(xx+.13,.12,-.33),(xx+.13,.12,.37),(xx+.13,.035,.37)],'#563b26',INK,2)
  a.poly([(xx,.035,.37),(xx+.13,.035,.37),(xx+.13,.12,.37),(xx,.12,.37)],'#785133',INK,2)
 a.front(frame,-.59,.04,-.20,1.18,.79)
 if state=='broken':
  cutpoly=[(350,0),(703,0),(703,460),(392,460),(376,311),(407,280),(376,214),(394,152),(359,106)]
  chunk=cut(drum,cutpoly,'winch_split_drum');drum=cut(drum,cutpoly,'winch_drum_remaining',True);a.top(chunk,.01,.054,.32,.75,.49,R=ry(24))
 # Rope-covered barrel: piecewise curved texture surface, matching its real X-axis.
 def drum_point(u,v):
  xx=(u/703-.5)*.96;theta=math.asin(max(-1,min(1,(155-v)/148)))
  return np.array([xx,.585+.19*math.sin(theta),.19*math.cos(theta)])
 for v0,v1 in reversed(list(zip(np.linspace(9,298,20)[:-1],np.linspace(9,298,20)[1:]))):
  uv=[(0,v0),(703,v0),(703,v1),(0,v1)];verts=[drum_point(*q) for q in uv]
  for ids in [(0,1,2),(0,2,3)]:a.triangle(drum,[uv[i] for i in ids],[verts[i] for i in ids])
 a.disc((.40,.585,0),.187,'yz','#302b24');a.disc((.405,.585,0),.151,'yz','#84603d');a.disc((.409,.585,0),.065,'yz','#4d4941')
 # Source-authored rope tail hangs under the symmetric rotating barrel.
 tail=drum.crop((325,294,382,458));a.front(tail,-.039,.17,.18,.078,.225)
 a.front(frame,-.59,.04,.145,1.18,.79)
 # Crank lies in the YZ plane and turns about the barrel's horizontal X axle.
 v=(0 if state=='idle' else 1 if state=='engaged' else .17) if t is None else t;ang=90*v
 center=np.array([.50,.585,.033]);scale=.43/463
 o=center-np.array([0,(576-518)*scale,(1622-1554)*scale]);u=np.array([0,0,scale]);vv=np.array([0,-scale,0]);o=o-vv*crank.height
 a.texture(crank,o,u,vv,R=rx(ang),pivot=center)
 return a.im

def bell(state='idle',t=None):
 a=Art();id='watch_bell';frame=layer(id,'gantry',(12,12,856,960));body=master('watch_bell_isobody');clapper=layer(id,'clapper',(1329,528,1433,927));rope=layer(id,'rope',(1441,408,1525,955))
 # Outer timber silhouettes are extruded consistently; front art remains untouched.
 out=[(.03,1),(.02,.92),(.07,.84),(.083,.20),(.033,.19),(.023,.16),(.023,.09),(.085,.08),(.10,.005),(.18,.005),(.196,.08),(.80,.08),(.814,.005),(.889,.005),(.913,.08),(.973,.084),(.99,.11),(.974,.19),(.91,.20),(.929,.84),(.99,.92),(1,1)]
 inner=[(.22,.95),(.22,.34),(.32,.2),(.68,.2),(.79,.34),(.79,.95)]
 a.contour_depth([out,inner],-.63,.04,0,1.26,1.65,.16,('#3a2b21','#785033'))
 a.front(frame,-.63,.04,.02,1.26,1.65)
 pivot=np.array([0,1.47,.105]);v=(0 if state=='idle' else .55 if state=='engaged' else .28) if t is None else t;angle=16*math.sin(v*math.pi)
 if state!='broken':
  a.front(clapper,-.053,.615,.105,.106,.38,R=rx(angle+9*math.sin(v*math.pi)),pivot=pivot)
  a.front(rope,.39,.22,.09,.077,1.28)
 else:
  # A long jagged fracture removes a cast-bronze mouth section, leaving dark interior.
  crack=[(350,650),(420,690),(490,660),(570,755),(520,822),(680,950),(665,1199),(80,1199),(80,630)]
  piece=cut(body,crack,'bell_cast_fragment');body=cut(body,crack,'bell_open_fracture',True)
  a.top(piece,.10,.053,.25,.57,.56,R=ry(22));a.top(clapper,-.23,.053,.36,.10,.36,R=ry(-30))
 a.sprite(body,(645,106),pivot,.00059,R=rx(angle),pivot=pivot)
 return a.im

def seal(state='closed',t=None):
 a=Art();id='crypt_sliding_seal';f=layer(id,'frame',(52,12,935,1002));slab=layer(id,'slab',(985,72,1478,996));x=-.77;w=1.54;h=1.86;y=.026
 outer=[(0,1),(.013,.847),(.045,.812),(.059,.744),(.058,.15),(.032,.10),(.079,.082),(.11,.002),(.889,.002),(.932,.08),(.96,.10),(.941,.15),(.945,.75),(.975,.847),(1,1)]
 inner=[(.30,.881),(.299,.135),(.708,.135),(.713,.881)]
 a.contour_depth([outer,inner],x,y,0,w,h,.26)
 v=(0 if state=='closed' else 1 if state=='open' else .18) if t is None else t;sy=.18-1.27*v;sh=1.52
 if state=='broken':
  poly=[(0,0),(259,0),(243,188),(276,321),(237,453),(261,562),(231,700),(199,775),(229,924),(0,924)]
  left=cut(slab,poly,'seal_cracked_left');right=cut(slab,poly,'seal_cracked_right',True)
  a.front(left,-.40,.18,.024,.8,sh);a.front(right,-.35,.13,.045,.8,sh,R=rz(-3),pivot=[0,.18,.03])
 else:
  visible_h=max(0,min(sh,sy+sh-.16));ey=int(slab.height*visible_h/sh)
  if ey>0:a.front(slab.crop((0,0,slab.width,ey)),-.40,.16,.018,.8,visible_h)
 a.front(f,x,y,.053,w,h)
 return a.im

ASSETS={'gothic_oak_door':(door,['closed','open','broken']),'iron_portcullis':(portcullis,['closed','open','broken']),'yoke_lever':(lever,['idle','engaged','broken']),'octagonal_pressure_plate':(pressure_plate,['idle','engaged','broken']),'brass_stop_valve':(valve,['idle','engaged','broken']),'oak_rope_winch':(winch,['idle','engaged','broken']),'watch_bell':(bell,['idle','engaged','broken']),'crypt_sliding_seal':(seal,['closed','open','broken'])}
def font(n):return get_font(n)
def composite(im,bg='#dcd5c7'):
 b=Image.new('RGBA',im.size,bg);b.alpha_composite(im);return b.convert('RGB')
def main():
 records=[];sheet=Image.new('RGB',(1560,144+440*len(ASSETS)),'#ddd6c9');d=ImageDraw.Draw(sheet)
 d.text((34,28),'LANTERN / MECHANISMS 02 / CLEAN INK',font=font(34),fill='#34291f');d.text((34,84),'Eight fresh illustration masters / three registered states each / fixed orthographic camera',font=font(21),fill='#73604d')
 for row,(id,(fn,states)) in enumerate(ASSETS.items()):
  rec={'id':id,'master':f'source/masters/{id}.png','states':{},'notes':'source illustration retained unchanged; editable world-space assembly'}
  for col,state in enumerate(states):
   im=fn(state);path=ROOT/'png'/f'{id}_{state}.png';im.save(path);box=im.getbbox()
   rec['states'][state]={'png':str(path.relative_to(ROOT)),'alpha_bounds_px':box,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'canvas_px':[W,H],'ground_pivot_px':ROOTPX.tolist()}
   thumb=im.crop(box);thumb.thumbnail((466,333),Image.Resampling.LANCZOS);x=col*520;y=144+row*440
   d.rectangle((x+10,y+5,x+510,y+430),fill='#d0c5b3' if (row+col)%2 else '#d7cdbd')
   sheet.paste(composite(thumb,'#d0c5b3' if (row+col)%2 else '#d7cdbd'),(x+(520-thumb.width)//2,y+20+(333-thumb.height)//2))
   d.text((x+25,y+367),id.replace('_',' ').title(),font=font(22),fill='#34291f');d.text((x+25,y+403),state.upper(),font=font(15),fill='#7a634c')
  records.append(rec);print('Stills:',id,flush=True)
 sheet.save(ROOT/'proof/All_Mechanism_States.png')
 manifest={'version':'2.0-clean-ink-candidate','content_status':'fresh_art_pending_independent_audit','camera':{'projection':'orthographic','elevation_degrees':35.2643897,'azimuth_degrees':45,'world':'right-handed XZ ground / Y up'},'canvas':[W,H],'source_density_px_per_m':PPM,'ground_pivot_px':ROOTPX.tolist(),'assets':records,'limitations':['Hand-painted 2.5D parts with world-space assembly; source-baked lighting follows rotating surfaces.','Door reverse shares the front illustration; separate reverse artwork recommended for view-dependent lighting.','Art extents changed; colliders and gameplay bounds require engine-side review.']}
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2));(ROOT/'source/clipping_meshes.json').write_text(json.dumps(MASKS,indent=2))
 if '--stills-only' in sys.argv:return
 clips=[]
 for id in ['gothic_oak_door','iron_portcullis','yoke_lever','octagonal_pressure_plate']:
  outdir=ROOT/'animation'/id;outdir.mkdir(exist_ok=True);fn,states=ASSETS[id];frames=[];recs=[]
  for i in range(24):
   t=i/23;t=t*t*(3-2*t);im=fn(states[0],t=t);path=outdir/f'activate_{i:03}.png';im.save(path);frames.append(composite(im).resize((640,640),Image.Resampling.LANCZOS));recs.append({'file':str(path.relative_to(ROOT)),'normalized_progress':t,'duration_ms':1000/24,'root':ROOTPX.tolist(),'bounds':im.getbbox(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
  gif=[frames[0]]*8+frames+[frames[-1]]*10+list(reversed(frames));gif[0].save(outdir/'review.gif',save_all=True,append_images=gif[1:],duration=60,loop=0,optimize=False)
  clips.append({'id':id+'_activate','asset':id,'fps':24,'duration_seconds':1,'loop':False,'frame_count':24,'source':'source/build_mechanisms.py','frames':recs});print('Clip:',id,flush=True)
 (ROOT/'animation/clips.json').write_text(json.dumps(clips,indent=2))
if __name__=='__main__':main()
