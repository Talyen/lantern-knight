from pathlib import Path
from font_support import get_font
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,subprocess
R=Path(__file__).resolve().parents[1];old=R/'source/historical_before';m=json.load(open(R/'manifest.json'))
def font(n):return get_font(n)
def paste_fit(sheet,path,rect,bg):
 im=Image.open(path).convert('RGBA');box=im.getbbox();im=im.crop(box);im.thumbnail((rect[2]-rect[0],rect[3]-rect[1]),Image.Resampling.LANCZOS)
 x=rect[0]+(rect[2]-rect[0]-im.width)//2;y=rect[1]+(rect[3]-rect[1]-im.height)//2
 sheet.paste(im,(x,y),im)
# review overview at gameplay-ish sizes, before/after pairing.
sheet=Image.new('RGB',(1600,1850),'#ddd6c8');d=ImageDraw.Draw(sheet)
d.text((35,28),'LANTERN / EIGHT MECHANISM REDRAWS',font=font(35),fill='#34291e')
d.text((35,80),'Original blockout → new clean-ink art. Same fixed camera and registered source layers.',font=font(21),fill='#6f5c48')
for i,a in enumerate(m['assets']):
 col=i%2;row=i//2;x=col*800;y=145+row*415
 d.rectangle((x+15,y,x+785,y+396),fill='#d2c7b5')
 state=next(iter(a['states']));name=a['id']
 paste_fit(sheet,old/f'{name}_{state}.png',(x+28,y+20,x+303,y+320),'#d2c7b5')
 paste_fit(sheet,R/'png'/f'{name}_{state}.png',(x+360,y+20,x+760,y+320),'#d2c7b5')
 d.text((x+34,y+332),'BEFORE',font=font(16),fill='#78634c');d.text((x+366,y+332),'AFTER',font=font(16),fill='#78634c')
 d.text((x+34,y+363),name.replace('_',' ').title(),font=font(24),fill='#34291e')
sheet.save(R/'proof/Before_After_All_Eight.png')
# Film and 4-up GIF of original animation deliverables, using fixed full canvases.
clips=json.load(open(R/'animation/clips.json'));rows=[]
for c in clips:
 gif=R/'animation'/c['asset']/'review.gif';mp4=gif.with_suffix('.mp4');subprocess.run(['ffmpeg','-y','-i',str(gif),'-movflags','+faststart','-pix_fmt','yuv420p',str(mp4)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
seq=[]
for i in list(range(24))+[23]*6+list(reversed(range(24)))+[0]*6:
 page=Image.new('RGB',(1280,1330),'#ddd6c8');draw=ImageDraw.Draw(page)
 for j,c in enumerate(clips):
  im=Image.open(R/c['frames'][i]['file']).convert('RGBA');im.thumbnail((640,640),Image.Resampling.LANCZOS)
  page.paste(im,((j%2)*640,(j//2)*665),im);draw.text(((j%2)*640+22,(j//2)*665+632),c['asset'].replace('_',' ').title(),font=font(21),fill='#443528')
 seq.append(page)
seq[0].save(R/'proof/Four_Activation_Clips.gif',save_all=True,append_images=seq[1:],duration=65,loop=0,optimize=False)
subprocess.run(['ffmpeg','-y','-i',str(R/'proof/Four_Activation_Clips.gif'),'-movflags','+faststart','-pix_fmt','yuv420p',str(R/'proof/Four_Activation_Clips.mp4')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
checks=[]
for a in m['assets']:
 for state,r in a['states'].items():
  im=Image.open(R/r['png']);b=im.getbbox();checks.append({'asset':a['id'],'state':state,'rgba':im.mode=='RGBA','canvas':im.size,'alpha_edge_contact': b[0]==0 or b[1]==0 or b[2]==im.width or b[3]==im.height,'bounds':b})
endpoints=[]
for c in clips:
 a=next(a for a in m['assets'] if a['id']==c['asset']);states=list(a['states']);result={}
 for state,idx in [(states[0],0),(states[1],23)]:
  result[state]=Image.open(R/a['states'][state]['png']).tobytes()==Image.open(R/c['frames'][idx]['file']).tobytes()
 endpoints.append({'asset':c['asset'],'endpoint_exact_matches':result,'frame_count':len(c['frames'])})
qa={'stills':checks,'clips':endpoints,'untouched_generated_master_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'source/masters').glob('*.png')},'evaluation':'Automated integrity checks only; independent art/motion audit pending.'}
(R/'proof/QA_integrity.json').write_text(json.dumps(qa,indent=2));print('Proofs and QA ready')
