#!/usr/bin/env python3
from pathlib import Path
import json,zipfile,hashlib,math
from PIL import Image
import build_scenic_illustrated as s
ROOT=s.ROOT
CURRENT_MASTERS=[v+'_components_v01.png' for v in s.COMPONENTS]+['tower_bell_components_v03.png']
CURRENT_LAYERS=[name+'_'+part+'.png' for name,parts in s.COMPONENTS.items() for part in parts]+['bell_v03_wall_corbel.png','bell_v03_body.png','bell_v03_clapper.png']

def packparts():
 root=ROOT/'part_atlases';root.mkdir(exist_ok=True)
 for old in root.glob('*.png'):old.unlink()
 pages=[];page=Image.new('RGBA',(2048,2048));x=y=6;rowh=0;meta=[];pageno=0
 for name in sorted(CURRENT_LAYERS):
  im=Image.open(ROOT/'layers'/name).convert('RGBA');w,h=im.size
  if x+w+6>2048:x=6;y+=rowh+12;rowh=0
  if y+h+6>2048:page.save(root/f'{pageno:02}.png',optimize=True);pages.append(f'{pageno:02}.png');pageno+=1;page=Image.new('RGBA',(2048,2048));x=y=6;rowh=0
  page.paste(im,(x,y));page.paste(im.crop((0,0,w,1)).resize((w,2)),(x,y-2));page.paste(im.crop((0,h-1,w,h)).resize((w,2)),(x,y+h));page.paste(im.crop((0,0,1,h)).resize((2,h)),(x-2,y));page.paste(im.crop((w-1,0,w,h)).resize((2,h)),(x+w,y));entry={'id':name[:-4],'source':'layers/'+name,'atlas':f'part_atlases/{pageno:02}.png','rect':[x,y,w,h],'full_original_alpha_preserved':True,'default_centre_pivot_px':[w/2,h/2]}
  if name=='waterwheel_spoke.png':entry.update(used_source_region=[0,0,w,h-110],pivot_px=[w/2,h-110],note='Repeated spoke artwork excludes its individual collar; a single fixed illustrated axle cap supplies the common hub.')
  if name=='bell_v03_body.png':entry.update(pivot_px=[325,30],pivot_role='registered top bearing anchor in unscaled cropped master')
  if name=='pulley_chain_sway_block.png':entry.update(pivot_px=[183,19],pivot_role='top moving clevis anchor')
  if name=='pulley_chain_sway_wheel.png':entry.update(pivot_px=[79,204],pivot_role='visible axle centre in grooved wheel master')
  meta.append(entry);x+=w+12;rowh=max(rowh,h)
 page.save(root/f'{pageno:02}.png',optimize=True);pages.append(f'{pageno:02}.png');(ROOT/'PART_SPRITES.json').write_text(json.dumps({'parts':meta,'pages':pages,'atlas_padding':{'total':6,'extrusion':2,'clear_gutter':4},'assembly_registration':'source/build_scenic_illustrated.py holds exact affine planes, image-space anchors and shared world pivots. Default centre pivots are descriptive; use explicitly registered assembly pivots for animation.','alpha':'straight','mipmaps':'disable or generate per sprite','source_originals':'masters/; part isolation is a component mask/crop preserving source RGBA values'},indent=2))

if __name__=='__main__':packparts()
