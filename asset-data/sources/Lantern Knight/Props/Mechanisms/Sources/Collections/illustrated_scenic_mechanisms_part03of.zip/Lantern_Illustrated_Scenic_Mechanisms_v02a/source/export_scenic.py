#!/usr/bin/env python3
from pathlib import Path
import math,json,hashlib,subprocess,time
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import build_scenic_illustrated as s
ROOT=s.ROOT
FPS=30;SIZE=(640,640);PIVOT=[320,531.25];FT=lambda n:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',n)
MOTION={
'exposed_gear_pair':{'kind':'continuous meshed pair','duration_seconds':8,'large_angle_degrees':'90 * seconds','small_angle_degrees':'-135 * seconds','completed_turns_per_loop':[2,-3],'tooth_ratio':'12:8 nominal decorative cast outline; rotation ratio exact -3:2','angular_speed_change':'6x prior 15/-22.5 deg per second; compact complete painted-orientation cycle','camera_class':'exact_projected_flat_part_planes; painted thickness is illustrative'},
'waterwheel':{'kind':'continuous fixed +X axle','duration_seconds':8,'angle_degrees':'45 * seconds','completed_turns_per_loop':1,'paddles':8,'paddle_thickness_metres':0.040,'paddle_edges':'source-textured thin silhouette extrusion; original illustrated faces retained','angular_speed_change':'2x prior 22.5 deg per second; full painted-orientation cycle','camera_class':'exact_projected_flat_part_planes; illustrated rim/spoke/paddle planes with fixed front and rear supports'},
'astrolabe':{'kind':'linked gimbal rings','duration_seconds':4,'middle_Y_degrees':'90 * seconds','inner_carried_X_degrees':'-90 * seconds','angular_speed_change':'unchanged; extended cycle to preserve painted-source orientation','camera_class':'exact_projected_ring_planes plus approximate illustrated elevated-view pedestal'},
'pulley_chain_sway':{'kind':'pendular fixture; wheel does not operate','duration_seconds':2,'swing_degrees':'4 * sin(2*pi*seconds/2)','anchor_px_at_1024':[419.64,445.88],'camera_class':'approximate_illustrated_elevated_view; rigid 2D whole-assembly swing','fixed':'timber wall mount; moving block, wheel and closed chain share one hinge'},
'tower_bell':{'kind':'pendular bell','duration_seconds':2,'swing_degrees':'5.5 * sin(2*pi*seconds/2)','anchor_px_at_1024':[488,403],'camera_class':'approximate_illustrated_elevated_view; rigid 2D bell-layer sway','fixed':'stone corbel and bearing cover; clapper hidden behind body from elevated rest viewpoint','clapper_relative_swing_degrees':'8 * sin(2*pi*seconds/2 - 0.5)' },
'bubble_chamber':{'kind':'contained three-bubble rise','duration_seconds':2,'bubble_phase':'(seconds/2 + index/3) modulo 1','camera_class':'approximate_illustrated_elevated_view; static physical fixture','fixed':'vessel, cap, steady liquid level; only bubbles move'}}

def normalize(im):
 im=im.resize(SIZE,Image.Resampling.LANCZOS);arr=np.array(im);arr[arr[:,:,3]==0,:3]=0;return Image.fromarray(arr)

def export(names=None):
 qa=[]
 for name,(fn,n) in s.SPECS.items():
  if names and name not in names:continue
  print('render',name,n,flush=True);folder=ROOT/'clips'/name;(folder/'frames').mkdir(parents=True,exist_ok=True);(ROOT/'review').mkdir(exist_ok=True);ims=[]
  for f in range(n):
   im=normalize(fn(f/n));im.save(folder/'frames'/f'{f:03}.png',optimize=True);ims.append(im)
  bounds=[im.getbbox() for im in ims];box=(min(b[0] for b in bounds),min(b[1] for b in bounds),max(b[2] for b in bounds),max(b[3] for b in bounds));w=box[2]-box[0];h=box[3]-box[1];tw=w+12;th=h+12;cols=2048//tw;rows=2048//th;cap=cols*rows;(folder/'atlases').mkdir(exist_ok=True);frameinfo=[]
  for page in range(math.ceil(n/cap)):
   count=min(cap,n-page*cap);atlas=Image.new('RGBA',(min(cols,count)*tw,math.ceil(count/cols)*th))
   for local in range(count):
    f=page*cap+local;crop=ims[f].crop(box);x=local%cols*tw+6;y=local//cols*th+6;atlas.paste(crop,(x,y));atlas.paste(crop.crop((0,0,w,1)).resize((w,2)),(x,y-2));atlas.paste(crop.crop((0,h-1,w,h)).resize((w,2)),(x,y+h));atlas.paste(crop.crop((0,0,1,h)).resize((2,h)),(x-2,y));atlas.paste(crop.crop((w-1,0,w,h)).resize((2,h)),(x+w,y));frameinfo.append({'frame':f,'atlas':f'atlases/{page:02}.png','rect':[x,y,w,h],'source_rect':list(box),'pivot_in_rect':[PIVOT[0]-box[0],PIVOT[1]-box[1]],'duration_seconds':1/FPS})
   atlas.save(folder/'atlases'/f'{page:02}.png',optimize=True)
  meta={'id':name,'loop':True,'source_fps':FPS,'preview_fps':60,'frame_count':n,'duration_seconds':n/FPS,'source_canvas':list(SIZE),'pivot':PIVOT,'render_density_px_per_m':187.5,'rig_authored_canvas':[1024,1024],'rig_authored_density_px_per_m':300,'requested_camera':{'elevation':35.264389682754654,'azimuth':45,'projection':'orthographic'},'camera_class':MOTION[name]['camera_class'],'motion':MOTION[name],'source':'unaltered fresh illustration masters; isolated original-alpha parts; editable assembly source','atlas_padding':{'total':6,'edge_extrusion':2,'transparent_gutter':4,'mipmaps':'off or per-sprite generated'},'frames':frameinfo}
  (folder/'manifest.json').write_text(json.dumps(meta,indent=2))
  endpoint=normalize(fn(1));first=np.array(ims[0]);end=np.array(endpoint);replays=[]
  for f in [0,n//3,n-1]:replays.append({'frame':f,'match':bool(np.array_equal(np.array(normalize(fn(f/n))),np.array(ims[f])))})
  row={'id':name,'frames':n,'bounds':box,'margin_clear':box[0]>0 and box[1]>0 and box[2]<SIZE[0] and box[3]<SIZE[1],'source_replays':replays,'loop_endpoint_max_channel_delta':int(np.max(np.abs(first.astype(int)-end.astype(int)))),'loop_endpoint_fraction_changed':float(np.mean(np.any(first!=end,axis=2))),'seam_mean_rgba_delta':float(np.abs(first.astype(int)-np.array(ims[-1]).astype(int)).mean()),'first_step_mean_rgba_delta':float(np.abs(first.astype(int)-np.array(ims[1]).astype(int)).mean()),'unique_rgba_images':len({hashlib.sha256(im.tobytes()).hexdigest() for im in ims})};qa.append(row)
  # Review and extremes at stable registration, not per-frame recentering.
  keys=[0,n//8,n//4,n//2,3*n//4,n-1];board=Image.new('RGB',(1800,780),'#d8d5c8');d=ImageDraw.Draw(board);d.text((20,12),name.replace('_',' ').upper(),font=FT(25),fill='#253034');d.text((20,48),f'{n} drawings / 30 fps / {n/30:g}s full loop / 60 Hz held-frame preview',font=FT(19),fill='#59615d')
  for j,k in enumerate(keys):
   im=ims[k].crop(box);im.thumbnail((285,620),Image.Resampling.LANCZOS);board.paste(im,(j*300+(300-im.width)//2,120),im);d.text((j*300+14,84),f'frame {k} / {k/30:.3f}s',font=FT(17),fill='#253034')
  board.save(ROOT/'review'/f'{name}_phases.jpg',quality=95)
  tmp=folder/'_preview';tmp.mkdir(exist_ok=True)
  for f,im in enumerate(ims):
   bg=Image.new('RGB',(1280,700),'#d8d5c8');d=ImageDraw.Draw(bg);d.rectangle((640,0,1280,700),fill='#263035');bg.paste(im,(0,40),im);bg.paste(im,(640,40),im);d.text((18,10),name.replace('_',' ')+f' / {f:03}',font=FT(18),fill='#263035');d.text((657,10),'30 fps source / 60 Hz held-frame preview',font=FT(18),fill='#d8d5c8');bg.save(tmp/f'{f:03}.jpg',quality=93)
  subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-i',str(tmp/'%03d.jpg'),'-vf','fps=60','-c:v','libx264','-crf','18','-pix_fmt','yuv420p',str(ROOT/'review'/f'{name}_60hz.mp4')],check=True)
  for p in tmp.glob('*'):p.unlink()
  tmp.rmdir();print('done',name,row,flush=True)
 prior=json.loads((ROOT/'QA_SOURCE_LOOPS_BOUNDS.json').read_text()) if (ROOT/'QA_SOURCE_LOOPS_BOUNDS.json').exists() else []
 byid={q['id']:q for q in prior}
 for q in qa:byid[q['id']]=q
 (ROOT/'QA_SOURCE_LOOPS_BOUNDS.json').write_text(json.dumps(list(byid.values()),indent=2))
 (ROOT/'ANALYTIC_MOTION.json').write_text(json.dumps({'source_fps':30,'part_source':'layers/','assembly_source':'source/build_scenic_illustrated.py','motions':MOTION,'runtime_note':'The part-sprite rig is the compact editable source. Full 30fps baked loops are optional authoring/runtime convenience; no Unity integration is claimed. Speeds may be configured while retaining ratios and shared pivots.'},indent=2))
if __name__=='__main__':
 import sys;export(sys.argv[1:] or None)
