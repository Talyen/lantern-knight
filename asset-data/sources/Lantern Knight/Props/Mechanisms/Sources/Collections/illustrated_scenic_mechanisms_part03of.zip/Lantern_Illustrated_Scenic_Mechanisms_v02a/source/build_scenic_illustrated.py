#!/usr/bin/env python3
"""Fresh illustrated master assembly. Unlit source texture on registered smooth surfaces.
No procedural material painting, regenerated animation frames, or baked light changes.
"""
from pathlib import Path
import math,json
import numpy as np
from PIL import Image,ImageDraw,ImageChops
import illustrated_renderer as r
ROOT=Path(__file__).resolve().parents[1];LAYERS=ROOT/'layers';LAYERS.mkdir(exist_ok=True)
r.ROOT=ROOT
CACHE={}
def source(name):
 if name not in CACHE:CACHE[name]=Image.open(ROOT/'masters'/name).convert('RGBA')
 return CACHE[name]
def piece(name,part,box,polygon=None):
 key=name+'|'+part
 if key not in CACHE:
  original=source(name)
  from scipy.ndimage import label,binary_dilation
  arr=np.array(original);labels,count=label(arr[:,:,3]>25);x0,y0,x1,y1=box;ids,counts=np.unique(labels[y0:y1,x0:x1],return_counts=True);valid=ids!=0;idx=ids[valid][int(np.argmax(counts[valid]))];mask=binary_dilation(labels==idx,iterations=3);arr[:,:,3]=np.where(mask,arr[:,:,3],0);im=Image.fromarray(arr).crop(box)
  if polygon:
   m=Image.new('L',im.size);ImageDraw.Draw(m).polygon(polygon,fill=255);im.putalpha(ImageChops.multiply(im.getchannel('A'),m))
  CACHE[key]=im;im.save(LAYERS/(part+'.png'))
 return CACHE[key]

def tower_bell_drawn(t=0):
 t=t%1
 """Art-preserving rigid-layer pendular approximation from elevated-view master.
 Camera is illustrated approximate, NOT a mathematically exact rendered volume.
 """
 name='tower_bell_components_v03.png';a=r.Art()
 bracket=piece(name,'bell_v03_wall_corbel',(0,0,775,860));bell=piece(name,'bell_v03_body',(760,70,1460,870))
 bs=.50;ss=.58;bx,by=140,190;hinge=(bx+696*bs,by+426*bs)
 bracket=bracket.resize((round(bracket.width*bs),round(bracket.height*bs)),Image.Resampling.LANCZOS)
 bell=bell.resize((round(bell.width*ss),round(bell.height*ss)),Image.Resampling.LANCZOS)
 origin=(round(hinge[0]-(1085-760)*ss),round(hinge[1]-(100-70)*ss))
 body=Image.new('RGBA',(1024,1024));body.alpha_composite(bell,origin)
 body=body.rotate(5.5*math.sin(t*math.tau),Image.Resampling.BICUBIC,center=hinge)
 clapper=piece(name,'bell_v03_clapper',(1559,289,1755,751));clapper=clapper.resize((74,175),Image.Resampling.LANCZOS);inside=Image.new('RGBA',(1024,1024));inside.alpha_composite(clapper,(round(hinge[0]-37),round(hinge[1]+35)));inside=inside.rotate(5.5*math.sin(t*math.tau)+8*math.sin(t*math.tau-.5),Image.Resampling.BICUBIC,center=hinge)
 # The interior clapper is occluded by the opaque bell from this elevated six-degree view. Its source and analytic relative motion remain available in the rig.
 a.im.alpha_composite(body);a.im.alpha_composite(bracket,(bx,by))
 return a.im

COMPONENTS={
 'exposed_gear_pair':{'back':(27,19,660,673),'large':(686,19,1353,682),'small':(1393,148,1892,645),'cap':(1929,358,2163,598)},
 'pulley_chain_sway':{'mount':(41,29,772,766),'block':(790,108,1169,832),'wheel':(1203,336,1495,725),'link_front':(1545,88,1736,439),'link_edge':(1596,474,1677,832)},
 'waterwheel':{'rim':(4,16,810,811),'support':(1197,124,1772,798),'paddle':(965,145,1195,741),'spoke':(795,48,942,794)},
 'bubble_chamber':{'vessel':(62,46,601,950),'lid':(637,165,1148,549),'meniscus':(831,639,1404,841),'bubble':(1211,236,1519,539)},
 'astrolabe':{'base':(20,108,615,692),'outer':(670,4,1225,692),'middle':(1293,120,1971,612),'shaft':(2039,7,2158,695)}}

def component(name,part):
 """Isolate a disconnected original master part without changing retained pixels.
 The 3-pixel mask expansion preserves original antialiasing. Master remains untouched.
 """
 key=name+'|'+part
 if key in CACHE:return CACHE[key]
 from scipy.ndimage import label,binary_dilation
 im=source(name+'_components_v01.png');arr=np.array(im);labs,n=label(arr[:,:,3]>25);x0,y0,x1,y1=COMPONENTS[name][part]
 ids,count=np.unique(labs[y0:y1,x0:x1],return_counts=True);ids=ids[ids!=0];counts=[np.sum(labs[y0:y1,x0:x1]==i) for i in ids];idx=ids[int(np.argmax(counts))]
 mask=binary_dilation(labs==idx,iterations=3)
 arr[:,:,3]=np.where(mask,arr[:,:,3],0)
 if name=='waterwheel' and part=='rim':
  # The neighboring strip is already alpha-zero after component isolation.
  # Remove hidden RGB payload only; all visible original rim RGBA remains exact.
  # This prevents misleading raw-RGB previews and unsafe straight-alpha sampling.
  arr[arr[:,:,3]==0,:3]=0
 bbox=(max(0,x0-3),max(0,y0-3),min(im.width,x1+3),min(im.height,y1+3));out=Image.fromarray(arr).crop(bbox);CACHE[key]=out;out.save(LAYERS/(name+'_'+part+'.png'))
 return out

def paste_scaled(canvas,img,xy,scale):
 im=img.resize((max(1,round(img.width*scale)),max(1,round(img.height*scale))),Image.Resampling.LANCZOS);canvas.alpha_composite(im,(round(xy[0]),round(xy[1])));return im.size

def gear_pair(t=0):
 t=t%1
 a=r.Art();back=component('exposed_gear_pair','back');big=component('exposed_gear_pair','large');small=component('exposed_gear_pair','small');cap=component('exposed_gear_pair','cap')
 # World anchors derived from painted bearing centres on the original board.
 w=1.8;h=w*back.height/back.width;x=-.9;y=.05;z=0
 a.front(back,x,y,z,w,h)
 units=w/back.width;centres=[(x+(253-24)*units,y+h-(355-16)*units,.045),(x+(443-24)*units,y+h-(355-16)*units,.045)]
 distance=centres[1][0]-centres[0][0];radii=[distance*.60,distance*.40]
 # Two and three full revolutions provide true texture closure at a manageable eight seconds.
 for j,(im,c,rr,deg) in enumerate([(big,centres[0],radii[0],720*t),(small,centres[1],radii[1],-1080*t)]):
  R=r.rz(deg);diam=2*rr;a.front(im,c[0]-rr,c[1]-rr,c[2],diam,diam,R=R,pivot=c)
  # Retainer caps are stationary on the fixed shafts, hiding no unconnected gear centres.
  a.front(cap,c[0]-.063,c[1]-.063,c[2]+.016,.126,.126)
 return a.im

def face_yz(a,img,x,y,z,w,h,R=None,pivot=None):
 a.texture(img,(x,y+h,z-w/2),(0,0,w/img.width),(0,-h/img.height,0),R,pivot)

def paddle_outline(image):
 """Source silhouette for thin side geometry, not an alpha-filtered sprite.
 Radial contour samples preserve chipped ends; the original face is never altered.
 """
 key='waterwheel_paddle_outline'
 if key in CACHE:return CACHE[key]
 alpha=np.array(image)[:,:,3];h,w=alpha.shape;cx,cy=w/2,h/2;out=[]
 for i in range(128):
  a=math.tau*i/128;dx,dy=math.cos(a),math.sin(a);last=None
  for rr in range(1,int(math.hypot(w,h))):
   x=round(cx+rr*dx);y=round(cy+rr*dy)
   if x<0 or y<0 or x>=w or y>=h:break
   if alpha[y,x]>=128:last=(x,y)
  if last is not None and (not out or out[-1]!=last):out.append(last)
 # Remove nearly straight samples only, retaining the hand-drawn corner changes.
 changed=True
 while changed and len(out)>12:
  changed=False;new=[]
  for i,b in enumerate(out):
   a=np.array(out[i-1],float);c=np.array(out[(i+1)%len(out)],float);bb=np.array(b,float);den=np.linalg.norm(c-a)
   dist=abs(np.cross(c-a,bb-a))/max(den,.001)
   if dist<1.2 and i%2==0:changed=True
   else:new.append(b)
  out=new
 CACHE[key]=out
 return out

def wheel_illustrated(t=0):
 t=t%1
 a=r.Art();rim=component('waterwheel','rim');spoke=component('waterwheel','spoke');paddle=component('waterwheel','paddle').transpose(Image.Transpose.ROTATE_90);support=component('waterwheel','support');cap=component('exposed_gear_pair','cap')
 # The single illustrated spoke hub collar is excluded from repeated spoke planes; the fixed axle cap supplies the shared hub.
 spoke=spoke.crop((0,0,spoke.width,spoke.height-110))
 centre=np.array([0,.94,0]);theta=360*t;R=r.rx(theta)
 # Each whole source part retains its own alpha and artwork. No replacement primitive materials.
 face_yz(a,support,-.43,0,0,.90,1.055)
 for xx in [-.26,.26]:
  for k in range(8):face_yz(a,spoke,xx,.94,0,.11,.78,R=r.rx(theta+k*45),pivot=centre)
  face_yz(a,rim,xx,.94-.80,0,1.60,1.60,R=R,pivot=centre)
 # True 40 mm timber thickness, with edge artwork sampled from the original
 # paddle boundary. Broad original illustrated faces remain unchanged.
 faces=[]
 outline=paddle_outline(paddle)
 for k in range(8):
  q=math.radians(theta+k*45);radial=np.array([0,math.cos(q),math.sin(q)]);tv=np.array([0,-math.sin(q),math.cos(q)]);c=np.array([0,.94+.82*math.cos(q),.82*math.sin(q)])
  def world(uv,depth):return c+np.array([-.34+.68*uv[0]/paddle.width,0,0])+tv*(-.125+.25*uv[1]/paddle.height)+radial*depth
  # The camera-facing face is preserved pixel-for-pixel under its affine projection.
  depth=.020 if sum(radial)>=0 else -.020
  o=world((0,0),depth);faces.append((sum(c+radial*depth),('face',o,tv)))
  centre_uv=np.array([paddle.width/2,paddle.height/2])
  for uv0,uv1 in zip(outline,outline[1:]+outline[:1]):
   uv0=np.array(uv0);uv1=np.array(uv1);v=[world(uv0,-.020),world(uv1,-.020),world(uv1,.020),world(uv0,.020)]
   near0=uv0*.995+centre_uv*.005;near1=uv1*.995+centre_uv*.005;inside0=uv0*.94+centre_uv*.06;inside1=uv1*.94+centre_uv*.06
   faces.append((sum(sum(p) for p in v)/4,('edge',v,[near0,near1,inside1,inside0])))
 for _,item in sorted(faces,key=lambda pair:pair[0]):
  if item[0]=='face':a.texture(paddle,item[1],(.68/paddle.width,0,0),item[2]*.25/paddle.height)
  else:
   _,v,uv=item
   for ids in [(0,1,2),(0,2,3)]:a.triangle(paddle,[uv[j] for j in ids],[v[j] for j in ids])
 # Foreground bearing trestle is deliberately drawn after the wheel: axle support is visible.
 face_yz(a,support,.43,0,0,.90,1.055)
 face_yz(a,cap,.46,.94-.08,0,.16,.16)
 return a.im

def pulley_illustrated(t=0):
 t=t%1
 mount=component('pulley_chain_sway','mount');block=component('pulley_chain_sway','block');wheel=component('pulley_chain_sway','wheel');lf=component('pulley_chain_sway','link_front');le=component('pulley_chain_sway','link_edge')
 a=r.Art();moving=Image.new('RGBA',(1024,1024));mx,my=130,150;ms=.52
 hinge=(mx+(595-38)*ms,my+(595-26)*ms);bs=.43;ox=hinge[0]-(970-787)*bs;oy=hinge[1]-(124-105)*bs
 # Continuous closed stadium chain path behind the wheel and cheek frame.
 cx=ox+(969-787)*bs;top=oy+(552-105)*bs;bottom=top+161;rad=38;straight=bottom-top;length=2*straight+2*math.pi*rad
 def capsule(q):
  d=q*length
  if d<straight:return (cx+rad,top+d),(0,1)
  d-=straight
  if d<math.pi*rad:
   v=d/rad;return (cx+rad*math.cos(v),bottom+rad*math.sin(v)),(-math.sin(v),math.cos(v))
  d-=math.pi*rad
  if d<straight:return (cx-rad,bottom-d),(0,-1)
  d-=straight;v=math.pi+d/rad;return (cx+rad*math.cos(v),top+rad*math.sin(v)),(-math.sin(v),math.cos(v))
 for j in range(24):
  (xx,yy),(tx,ty)=capsule(j/24);im=lf if j%2==0 else le;sc=35/im.height;im=im.resize((max(2,round(im.width*sc)),35),Image.Resampling.LANCZOS);im=im.rotate(math.degrees(math.atan2(tx,ty)),Image.Resampling.BICUBIC,expand=True);moving.alpha_composite(im,(round(xx-im.width/2),round(yy-im.height/2)))
 # Bronze wheel seated behind the open cheek and chain-return mouths.
 wscale=.31;wx=cx-(1279-1200)*wscale;wy=top-(537-333)*wscale;paste_scaled(moving,wheel,(wx,wy),wscale)
 paste_scaled(moving,block,(ox,oy),bs)
 moving=moving.rotate(4*math.sin(math.tau*t),Image.Resampling.BICUBIC,center=hinge)
 a.im.alpha_composite(moving);paste_scaled(a.im,mount,(mx,my),ms)
 return a.im

def chamber_illustrated(t=0):
 t=t%1
 a=r.Art();vessel=component('bubble_chamber','vessel');lid=component('bubble_chamber','lid');meniscus=component('bubble_chamber','meniscus');bubble=component('bubble_chamber','bubble');scale=.60;bx,by=350,254
 # A flat quiet liquid interior is native geometry; all vessel hardware and meniscus are original illustration.
 front=Image.new('RGBA',(1024,1024));d=ImageDraw.Draw(front);d.rectangle((402,504,621,726),fill='#78947a');d.ellipse((402,691,621,751),fill='#78947a');paste_scaled(front,meniscus,(391,466),.42)
 for j,(dx,size) in enumerate([(-49,22),(29,29),(0,17)]):
  q=(t+j/3)%1;g=math.sin(math.pi*q)**.5;side=max(1,round(size*g));im=bubble.resize((side,side),Image.Resampling.LANCZOS);front.alpha_composite(im,(round(510+dx+math.sin(q*math.pi*1.5+j)*7-side/2),round(715-q*177-side/2)))
 a.im.alpha_composite(front);paste_scaled(a.im,vessel,(bx,by),scale);paste_scaled(a.im,lid,(356,120),.60)
 return a.im

def astrolabe_illustrated(t=0):
 t=t%1
 a=r.Art();base=component('astrolabe','base');outer=component('astrolabe','outer');middle=component('astrolabe','middle');shaft=component('astrolabe','shaft');centre=np.array([0,1.05,0]);Ry=r.ry(360*t);R=Ry@r.rx(-360*t)
 # Illustrated pedestal stays fixed in its authored elevated view. Registered ring planes carry actual 3D pivots.
 paste_scaled(a.im,base,(422,749),.302)
 a.front(outer,-.65,1.05-.806,0,1.30,1.612)
 a.front(middle.transpose(Image.Transpose.ROTATE_90),-.48,1.05-.661,.015,.96,1.322,R=Ry,pivot=centre)
 a.front(outer.transpose(Image.Transpose.ROTATE_90),-.477,1.05-.385,.032,.954,.77,R=R,pivot=centre)
 a.front(shaft,-.067,1.05-.385,.040,.134,.77,R=R,pivot=centre)
 return a.im

SPECS={'exposed_gear_pair':(gear_pair,240),'pulley_chain_sway':(pulley_illustrated,60),'waterwheel':(wheel_illustrated,240),'tower_bell':(tower_bell_drawn,60),'bubble_chamber':(chamber_illustrated,60),'astrolabe':(astrolabe_illustrated,120)}

def proof():
 from PIL import ImageFont
 board=Image.new('RGB',(1800,1600),'#d8d5c8');d=ImageDraw.Draw(board);ft=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',23)
 for j,(name,(fn,n)) in enumerate(SPECS.items()):
  im=fn(.125);im.save(ROOT/(name+'_rest_proof.png'));box=im.getbbox();im=im.crop(box);im.thumbnail((560,680),Image.Resampling.LANCZOS);xx=j%3*600;yy=j//3*800;board.paste(im,(xx+(600-im.width)//2,yy+70),im);d.text((xx+18,yy+18),name,font=ft,fill='#263035')
 board.save(ROOT/'six_scenic_assembled_gate.jpg',quality=95)

if __name__=="__main__":proof()
