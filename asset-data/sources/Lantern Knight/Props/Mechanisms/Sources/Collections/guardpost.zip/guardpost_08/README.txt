LANTERN REVISION 02 / guardpost_08
Eight world-prop masters, one PNG per named object or purposeful assembly.
Fresh generations use canonical C/RUST as a style reference only; no generated-prop edit cascades. Retained originals are byte-identical and explicitly marked. The canonical hero is unchanged.
Native RGBA masters are preserved without pixel processing. Proofs are layout-only composites/resizes and are NOT replacement masters.
Camera is approximate 35.2643897 degree elevation / 45 degree azimuth. It is not calibrated, nor registered to the 13 m camera span. Ground pivots, physical scale, colliders, wall mounts and runtime materials require engine integration.
Check alpha on both light and dark proof sheets. Hidden RGB in transparent texels may look noisy in raw viewers. Native partial alpha remains unchanged; validate straight/premultiplied alpha, atlas extrusion and filtering in engine.
Game-size sheets show 96 px object-fit and 160 px full-canvas proxies, not runtime rendering.
All old sources remain preserved. manifest.json contains IDs, exact prompts, source mapping, hashes and alpha bounds.

ART REVIEW
All eight redrawn, including initially keep-rated drum and shield pair for overall style coherence. Rack shafts are seated on lower beam and held by upper rail; target has feet, crossbar and rear support; case rests on upper stand supports with X hinges and connecting crossbar. Horn strap contacts both body loops, cuffs connect through chains to bracket. Bracket is a wall-mounted prop requiring wall placement. Collapsed stake bundle is now upright rather than the original diagonal lying pose; ID/role retained but pivot/orientation must be re-authored. Drum rests on shell; shield pair leans together. Target wood wear is deliberately more detailed than quiet cloth props, without procedural grain.

ALPHA AND FORM LIMITATIONS
Some exports have faint native alpha=1 pixels at outer edges. No alpha>=128 silhouette touches a canvas edge; all are fully framed. Native pixel data is not cleaned or thresholded. Most masters are 1254 square; star chart is 1536x1024. Requested 65% framing is not exact; consult manifest core bounds and set atlas gutters.
