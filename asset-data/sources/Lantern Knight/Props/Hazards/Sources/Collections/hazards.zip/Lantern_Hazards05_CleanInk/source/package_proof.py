from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,subprocess,sys,math,tempfile,numpy as np
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'));import build_hazards as b
old=R/'source/reference_before';m=json.load(open(R/'manifest.json'))
def font(n):
 try:return ImageFont.truetype(str(R/'source/fonts/DejaVuSans.ttf'),n)
 except OSError:return ImageFont.load_default()
def fit(sheet,path,rect):
 im=Image.open(path).convert('RGBA');im=im.crop(im.getbbox());im.thumbnail((rect[2]-rect[0],rect[3]-rect[1]),Image.Resampling.LANCZOS);sheet.paste(im,(rect[0]+(rect[2]-rect[0]-im.width)//2,rect[1]+(rect[3]-rect[1]-im.height)//2),im)
sheet=Image.new('RGB',(1600,1430),'#ddd4c3');d=ImageDraw.Draw(sheet);d.text((35,28),'LANTERN / SIX HAZARD REDRAWS',font=font(35),fill='#382b20');d.text((35,80),'New illustrated materials with original mechanical pivots, travel and clip semantics.',font=font(21),fill='#735e46');featured=['engaged','closed','active','active','lowered','raised']
for i,a in enumerate(m['assets']):
 x=(i%2)*800;y=145+(i//2)*415;d.rectangle((x+15,y,x+785,y+396),fill='#d0c3ae');id=a['id'];state=featured[i];fit(sheet,old/'png'/f'{id}_{state}.png',(x+28,y+20,x+303,y+320));fit(sheet,R/'png'/f'{id}_{state}.png',(x+360,y+20,x+760,y+320));d.text((x+34,y+332),'BEFORE',font=font(16),fill='#806b4f');d.text((x+366,y+332),'AFTER',font=font(16),fill='#806b4f');d.text((x+34,y+363),id.replace('_',' ').title(),font=font(23),fill='#382b20')
sheet.save(R/'proof/Before_After_All_Six.png')
clips=json.load(open(R/'animation/clips.json'));temp=Path(tempfile.mkdtemp(prefix='hazard_review_'));pages=[]
for c in clips:
 folder=temp/c['asset'];folder.mkdir()
 for i,f in enumerate(c['frames']):b.comp(Image.open(R/f['file'])).resize((640,640),Image.Resampling.LANCZOS).save(folder/f'{i:03}.png')
 subprocess.run(['ffmpeg','-y','-framerate',str(c['fps']),'-i',str(folder/'%03d.png'),'-frames:v','24','-movflags','+faststart','-pix_fmt','yuv420p',str(R/'animation'/c['asset']/'review.mp4')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
for i in range(48):
 page=Image.new('RGB',(1536,560),'#ddd4c3');draw=ImageDraw.Draw(page)
 for j,c in enumerate(clips):
  idx=i//2 if c['loop'] else i if i<24 else 47-i
  im=Image.open(R/c['frames'][idx]['file']).convert('RGBA').resize((512,512),Image.Resampling.LANCZOS);page.paste(im,(j*512,0),im);draw.text((j*512+20,522),c['asset'].replace('_',' ').title(),font=font(19),fill='#493726')
 page.save(temp/f'combined_{i:03}.png');pages.append(page)
pages[0].save(R/'proof/Three_Hazard_Clips.gif',save_all=True,append_images=pages[1:],duration=[40,40,40,40,40,50]*8,loop=0,optimize=False)
subprocess.run(['ffmpeg','-y','-framerate','24','-i',str(temp/'combined_%03d.png'),'-frames:v','48','-movflags','+faststart','-pix_fmt','yuv420p',str(R/'proof/Three_Hazard_Clips.mp4')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
checks=[]
for a in m['assets']:
 for state,r in a['states'].items():
  im=Image.open(R/r['png']);box=im.getbbox();checks.append({'asset':a['id'],'state':state,'canvas':im.size,'root':r['ground_pivot_px'],'rgba':im.mode=='RGBA','edge_contact':box[0]==0 or box[1]==0 or box[2]==im.width or box[3]==im.height,'bounds':box})
endpoints=[]
for c in clips:
 if c['loop']:
  endpoints.append({'asset':c['asset'],'phase0_equals_idle_still':Image.open(R/c['frames'][0]['file']).tobytes()==Image.open(R/'png'/f"{c['asset']}_idle.png").tobytes(),'quarter_phase_equals_active_still':Image.open(R/c['frames'][6]['file']).tobytes()==Image.open(R/'png'/f"{c['asset']}_active.png").tobytes(),'phase0_equals_phase1':b.render(c['asset'],t=0).tobytes()==b.render(c['asset'],t=1).tobytes()})
 else:
  states=b.ASSETS[c['asset']];endpoints.append({'asset':c['asset'],'start_matches_still':Image.open(R/c['frames'][0]['file']).tobytes()==Image.open(R/'png'/f"{c['asset']}_{states[0]}.png").tobytes(),'end_matches_still':Image.open(R/c['frames'][-1]['file']).tobytes()==Image.open(R/'png'/f"{c['asset']}_{states[1]}.png").tobytes()})
# Mechanical numerical checks independent of the cropped visible art.
maxradius=0.;maxerror=0.;orig=np.array(b.IRIS_RAW);D=np.linalg.norm(orig[:,None,:]-orig[None,:,:],axis=2)
for t in np.linspace(0,1,101):
 for j in range(8):
  q=j*math.tau/8;piv=np.array([.98,0]);ra=np.array([[math.cos(-1.21*t),-math.sin(-1.21*t)],[math.sin(-1.21*t),math.cos(-1.21*t)]]);rq=np.array([[math.cos(q),-math.sin(q)],[math.sin(q),math.cos(q)]]);pts=(rq@(ra@(orig-piv).T+piv[:,None])).T;maxradius=max(maxradius,float(np.linalg.norm(pts,axis=1).max()));maxerror=max(maxerror,float(abs(np.linalg.norm(pts[:,None,:]-pts[None,:,:],axis=2)-D).max()))
mechanics={'iris_fixed_pivot_rigid_shape_distance_error_max':maxerror,'iris_vertex_envelope_radius_max_m':maxradius,'iris_required_hidden_chamber_radius_m':1.85,'iris_envelope_within_required_chamber':maxradius<=1.85,'spikes_rigid_vertical_travel_m':.50,'spikes_clipped_by_fixed_deck_y':.181,'pendulum_fixed_pivot':[0,2.38,.03],'bridge_fixed_hinge':[0,.225,-.86],'steam_fixed_outlet':[0,.218,0],'crusher_head_clearance_m':{'raised':1.86,'lowered':.23},'crusher_chain_link_scale':'Fractional UV clip from a fixed1.9m master; links do not stretch when exposed.'}
qa={'stills':checks,'clips':endpoints,'mechanics':mechanics,'untouched_master_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (R/'source/masters').glob('*.png')}};(R/'proof/QA_integrity.json').write_text(json.dumps(qa,indent=2));print('Hazard proofs and mechanics QA ready')
from context_proofs import main as context_proofs
context_proofs()
