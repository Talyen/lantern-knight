#!/usr/bin/env python3
"""Illustrated hazard source rigs. New material masters; exact retained mechanism math.
No gameplay/damage/safety/collision timing is defined by these presentation clips."""
from illustration_engine import *
import illustration_engine as eng
from PIL import ImageDraw
ASSETS={'retracting_spike_trap':['idle','engaged','broken'],'bronze_iris_gate':['closed','open','jammed'],'ceiling_pendulum_blade':['idle','active','jammed'],'pressure_steam_vent':['idle','active','broken'],'hinged_bridge_panel':['lowered','raised','jammed'],'guided_stone_crusher':['raised','lowered','jammed']}
RIGHT=np.array([1/math.sqrt(2),0,-1/math.sqrt(2)]);DOWN=np.array([math.sin(ELEV)/math.sqrt(2),-math.cos(ELEV),math.sin(ELEV)/math.sqrt(2)])

def clipped_surface(a,tex,uv,verts,ymin):
 pairs=list(zip(uv,[np.array(v)for v in verts]));out=[]
 for (u,p0),(v,p1) in zip(pairs,pairs[1:]+pairs[:1]):
  i=p0[1]>=ymin;j=p1[1]>=ymin
  if i:out.append((np.array(u),p0))
  if i!=j:
   t=(ymin-p0[1])/(p1[1]-p0[1]);out.append((np.array(u)+(np.array(v)-u)*t,p0+(p1-p0)*t))
 for k in range(1,len(out)-1):a.triangle(tex,[out[i][0]for i in [0,k,k+1]],[out[i][1]for i in [0,k,k+1]])

def spikes(state='idle',t=None):
 a=Art();id='retracting_spike_trap';plate=layer(id,'deck',(34,52,1112,968));spike=layer(id,'spike',(1230,104,1480,947));v=(0 if state=='idle' else 1 if state=='engaged' else .55)if t is None else t
 rim=[(-.65,-.55),(.55,-.55),(.66,-.42),(.66,.44),(.54,.55),(-.56,.55),(-.66,.43),(-.66,-.43)]
 for j in range(len(rim)):
  p0,p1=rim[j],rim[(j+1)%len(rim)];a.poly([(p0[0],.03,p0[1]),(p1[0],.03,p1[1]),(p1[0],.17,p1[1]),(p0[0],.17,p0[1])],'#514739'if j%3 else'#75634c',INK,3)
 a.top(plate,-.66,.17,-.55,1.32,1.1)
 for x,z in sorted([(x,z)for x in [-.32,0,.32]for z in [-.26,0,.26]],key=lambda q:sum(q)):
  a.poly([(x-.073,.178,z-.067),(x+.073,.178,z-.067),(x+.073,.178,z+.067),(x-.073,.178,z+.067)],'#171716',INK,2)
  if state=='broken' and x==0:continue
  travel=-.50*(1-v);tip=(x+.015,.68+travel,z-.01);r=.058;bottom=.18+travel
  faces=[([(126,0),(10,832),(132,832)],[(x-r,bottom,z-r),(x+r,bottom,z-r),tip]),([(126,0),(132,784),(240,832)],[(x+r,bottom,z-r),(x+r,bottom,z+r),tip]),([(126,0),(22,830),(132,784)],[(x+r,bottom,z+r),(x-r,bottom,z+r),tip])]
  # Tip UV is first in each source triangle; world order follows it, preserving facet artwork.
  for uv,pts in faces:clipped_surface(a,spike,uv,[pts[2],pts[0],pts[1]],.181)
 if state=='broken':a.top(spike,-.26,.186,.36,.12,.43,R=ry(32))
 return a.im

IRIS_RAW=[(1.01,0),(1.12*math.cos(-.22),1.12*math.sin(-.22)),(1.15*math.cos(.86),1.15*math.sin(.86)),(.23*math.cos(.59),.23*math.sin(.59)),(-.03,0),(.23*math.cos(-.23),.23*math.sin(-.23))]
IRIS_ENVELOPES=[]
def iris(state='closed',t=None,unclipped=False):
 global IRIS_ENVELOPES
 a=Art();id='bronze_iris_gate';frame=layer(id,'casing',(10,0,897,878));field=layer(id,'bronze_field',(953,37,1738,831));cy=1.15;v=(0 if state=='closed' else 1 if state=='open' else .26)if t is None else t
 # Controlled native casing depth; the illustrated annulus is UV-mapped over its face.
 for j in range(64):
  t0=j*math.tau/64;t1=(j+1)*math.tau/64
  for r in [1.05,.75]:a.poly([(r*math.cos(t0),cy+r*math.sin(t0),-.16),(r*math.cos(t1),cy+r*math.sin(t1),-.16),(r*math.cos(t1),cy+r*math.sin(t1),.08),(r*math.cos(t0),cy+r*math.sin(t0),.08)],'#40382e',None)
 tex=field.crop((480,540,730,735)).resize((785,794),Image.Resampling.BICUBIC);mask=Image.new('L',tex.size);dr=ImageDraw.Draw(mask)
 def uv(q):return ((q[0]+.05)/1.22*tex.width,(.92-q[1])/1.20*tex.height)
 poly=[uv(q)for q in IRIS_RAW];dr.polygon(poly,fill=255);tex.putalpha(ImageChops.multiply(tex.getchannel('A'),mask));ink=ImageDraw.Draw(tex);ink.line(poly+[poly[0]],fill='#302315',width=7,joint='curve');ink.line([uv(IRIS_RAW[2]),uv(IRIS_RAW[3])],fill='#c0a46a',width=9,joint='curve')
 blades=Art();IRIS_ENVELOPES=[]
 for j in range(8):
  q=j*math.tau/8;ang=-1.21 if state=='jammed'and j==2 else -v*1.21;Rq=rz(math.degrees(q));Ra=rz(math.degrees(ang));center=np.array([0,cy,.096]);pivot=np.array([.98,cy,.096])
  def tr(p0):return Rq@(Ra@(np.array(p0)-pivot)+pivot-center)+center
  o=tr([-.05,cy+.92,.096]);u=Rq@Ra@np.array([1.22/tex.width,0,0]);vv=Rq@Ra@np.array([0,-1.2/tex.height,0]);blades.texture(tex,o,u,vv)
  envelope=[tr([x,cy+y,.096]).tolist()for x,y in IRIS_RAW];IRIS_ENVELOPES.append({'blade':j,'pivot':[.98*math.cos(q),cy+.98*math.sin(q),.096],'angle':ang,'vertices':envelope})
 if not unclipped:
  m=Art();m.poly([(.745*math.cos(i*math.tau/128),cy+.745*math.sin(i*math.tau/128),.094)for i in range(128)],'white',None);blades.im.putalpha(ImageChops.multiply(blades.im.getchannel('A'),m.im.getchannel('A')))
 a.im.alpha_composite(blades.im)
 # Two anchoring feet are illustrated source components, not a freestanding chassis claim.
 left=frame.crop((4,668,223,878));right=frame.crop((669,668,887,878));a.front(left,-.96,.025,.12,.42,.405);a.front(right,.54,.025,.12,.42,.405)
 # Polar registration maps the newly authored stone/brass to the exact .75/1.05m aperture/casing.
 for j in range(64):
  t0=j*math.tau/64;t1=(j+1)*math.tau/64
  for r0,r1 in zip([.75,.85,.95],[.85,.95,1.05]):
   def src(r,t):rr=273+(r-.75)/.30*(421-273);return (440+rr*math.cos(t),434-rr*math.sin(t))
   def dst(r,t):return (r*math.cos(t),cy+r*math.sin(t),.114)
   uu=[src(r0,t0),src(r1,t0),src(r1,t1),src(r0,t1)];pp=[dst(r0,t0),dst(r1,t0),dst(r1,t1),dst(r0,t1)]
   for ix in [(0,1,2),(0,2,3)]:a.triangle(frame,[uu[i]for i in ix],[pp[i]for i in ix])
 return a.im

def pendulum(state='idle',t=None):
 a=Art();id='ceiling_pendulum_blade';src=master(id);bearing=layer(id,'bearing',(25,52,538,496));moving=cut(src,[(582,0),(712,0),(712,980),(1024,980),(1024,1536),(257,1536),(257,980),(582,980)],'pendulum_connected_assembly')
 pivot=np.array([0,2.38,.03]);angle=-.27 if state=='jammed'else .60 if state=='active'and t is None else .60*math.sin(math.tau*(t%1))if t is not None else 0
 a.sprite(bearing,(402-25,282-52),pivot,.00088)
 if state=='jammed':
  chip=[(587,1467),(625,1450),(644,1492),(683,1468),(715,1536),(560,1536)];moving=cut(moving,chip,'pendulum_chipped_edge',True)
 a.texture(moving,(-645*.00158,2.38+58*.00152,.055),(.00158,0,0),(0,-.00152,0),rz(math.degrees(angle)),pivot)
 pin=cut(bearing,[(314,171),(372,149),(423,174),(451,230),(425,286),(373,303),(320,267)],'pendulum_fixed_pin')
 a.sprite(pin,(402-25,282-52),pivot,.00088)
 return a.im

def steam(state='idle',t=None):
 a=Art();id='pressure_steam_vent';body=layer(id,'vent_body',(20,22,1178,852));wheel=layer(id,'handwheel',(1182,224,1764,810));outlet=np.array([0,.218,0]);sourceanchor=(477-20,365-22);scale=.00082
 if state=='broken':
  poly=[(360,196),(398,204),(460,271),(485,317),(461,335),(423,303),(385,238),(345,220)];piece=cut(body,poly,'vent_broken_bar');body=cut(body,poly,'vent_bar_gap',True);a.top(piece,-.30,.04,.24,.44,.35,R=ry(-23))
 a.sprite(body,sourceanchor,outlet,scale)
 # The new source's spindle rises vertically; its handwheel lies on the XZ plane.
 wheelcenter=outlet+RIGHT*((1035-477)*scale)+DOWN*((68-365)*scale)
 angle=51.566 if state=='active'else 20 if state=='broken'else 0
 a.top(wheel,wheelcenter[0]-.20,wheelcenter[1],wheelcenter[2]-.20,.40,.40,R=ry(angle),pivot=wheelcenter)
 if state!='idle':
  plume=master('steam_plume_clean');phase=0 if t is None else t;h=.96 if state=='active'else .42;w=.57 if state=='active'else .26
  # One new steam painting, coherent deterministic deformation around the fixed outlet.
  for v0,v1 in zip(np.linspace(0,1,20)[:-1],np.linspace(0,1,20)[1:]):
   def pt(u,v):lift=1-v;return outlet+RIGHT*((u-.5)*w+.09*w*math.sin(math.tau*phase+v*5)*lift)+DOWN*(-h*lift)
   uv=[(0,v0*plume.height),(plume.width,v0*plume.height),(plume.width,v1*plume.height),(0,v1*plume.height)];vv=[pt(0,v0),pt(1,v0),pt(1,v1),pt(0,v1)]
   for ix in [(0,1,2),(0,2,3)]:a.triangle(plume,[uv[i]for i in ix],[vv[i]for i in ix])
 return a.im

def bridge(state='lowered',t=None):
 a=Art();id='hinged_bridge_panel';deck=layer(id,'deck',(46,11,541,984));back=layer(id,'underside',(610,14,1106,984));block=layer(id,'hinge_block',(1141,62,1528,509));pivot=np.array([0,.225,-.86]);v=(0 if state=='lowered'else 1 if state=='raised'else .46)if t is None else t;R=rx(math.degrees(-1.38*v));w=1.15;depth=1.80;z0=-.86-41/973*depth
 for x in [-.51,.51]:a.sprite(block,(273,133),[x,.225,-.86],.00085)
 if state=='jammed':
  poly=[(138,393),(178,409),(181,469),(215,447),(208,517),(247,495),(255,577),(311,604),(322,463),(310,396)];deck=cut(deck,poly,'bridge_splintered_board',True)
 a.top(back,-w/2,.167,z0,w,depth,R,pivot)
 if np.dot(R@np.array([0,1,0]),np.array([1,1,1]))>0:a.top(deck,-w/2,.225,z0,w,depth,R,pivot)
 for x in [-w/2,w/2]:
  pts=[(x,.167,z0),(x,.167,z0+depth),(x,.225,z0+depth),(x,.225,z0)];a.poly([R@(np.array(q)-pivot)+pivot for q in pts],'#553922',INK,3)
 return a.im

def registered3(a,img,uv,world):
 dst=np.array([p(q)for q in world]);src=np.array(uv,float);M=np.linalg.solve(np.column_stack([dst,np.ones(3)]),src).T
 a.im.alpha_composite(img.transform((eng.W,eng.H),Image.Transform.AFFINE,tuple(M.flatten()),Image.Resampling.BICUBIC))

def crusher(state='raised',t=None):
 a=Art();id='guided_stone_crusher';frame=layer('guided_stone_crusher_isovolumes','gantry',(82,3,843,1011));head=layer('guided_stone_crusher_isovolumes','head',(882,436,1468,957));chain=layer(id,'chain',(1381,7,1498,1018));v=(0 if state=='raised' else 1 if state=='lowered' else .52)if t is None else t;bottom=1.86-1.63*v;top=bottom+.57;tilt=.09 if state=='jammed'else 0;R=rz(math.degrees(tilt));pivot=np.array([0,bottom+.285,.03])
 # Freshly illustrated isometric volumes are registered by their two actual chain eyes.
 # The third source point is the ground/clearance reference. No bare CAD block faces remain.
 frameuv=[(356-82,234-3),(516-82,264-3),(428.26-82,885-3)]
 framesockets=[(-.31,2.60,-.03),(.31,2.60,-.03),(0,0,0)]
 registered3(a,frame,frameuv,framesockets)
 lower=[]
 for upperx,x in [(-.31,-.43),(.31,.43)]:
  attach=R@(np.array([x,top+.018,-.03])-pivot)+pivot;lower.append(attach);upper=np.array([upperx,2.60,-.03]);length=float(np.linalg.norm(upper-attach));start_v=chain.height-length/(1.9/chain.height)
  # Fractional UV clipping retains exact link scale while the chain reels into its housing.
  direction=(upper-attach)/length;side=np.array([1.,0,0]);side=side-direction*np.dot(side,direction);side=side/np.linalg.norm(side)*.055
  uv=[(0,start_v),(chain.width,start_v),(chain.width,chain.height),(0,chain.height)];vv=[upper-side,upper+side,attach+side,attach-side]
  for ix in [(0,1,2),(0,2,3)]:a.triangle(chain,[uv[i]for i in ix],[vv[i]for i in ix])
 headuv=[(1010-882,480-436),(1375-882,573-436),(1174.76-882,913-436)]
 base=R@(np.array([0,bottom,0])-pivot)+pivot
 registered3(a,head,headuv,[lower[0],lower[1],base])
 # Fixed painted guide lips sit in front of the moving carriage at all heights.
 for index,poly in enumerate([[(300,250),(325,251),(325,683),(301,719)],[(586,311),(611,317),(611,801),(586,773)]]):
  lips=cut(frame,[(x-82,y-3)for x,y in poly],f'crusher_fixed_guide_lip_{index}');registered3(a,lips,frameuv,framesockets)
 return a.im

FUN={'retracting_spike_trap':spikes,'bronze_iris_gate':iris,'ceiling_pendulum_blade':pendulum,'pressure_steam_vent':steam,'hinged_bridge_panel':bridge,'guided_stone_crusher':crusher}
def render(id,state=None,t=None):
 eng.H=1792 if id=='guided_stone_crusher'else 1536;ROOTPX[1]=1420 if id=='guided_stone_crusher'else 1220
 return FUN[id](state or ASSETS[id][0],t)
def font(n):
 try:return ImageFont.truetype(str(ROOT/'source/fonts/DejaVuSans.ttf'),n)
 except OSError:return ImageFont.load_default()
def comp(im,bg='#d8cebc'):
 out=Image.new('RGBA',im.size,bg);out.alpha_composite(im);return out.convert('RGB')
def main():
 for folder in ['png','animation','proof','layers']:(ROOT/folder).mkdir(parents=True,exist_ok=True)
 rows=[];sheet=Image.new('RGB',(1560,2800),'#ddd4c3');d=ImageDraw.Draw(sheet);d.text((35,25),'LANTERN / HAZARDS 05 / CLEAN INK',font=font(34),fill='#392c20');d.text((35,80),'Six illustrated assemblies / preserved mechanisms / no implied gameplay safety or timing',font=font(21),fill='#735e46')
 for row,(id,states)in enumerate(ASSETS.items()):
  rec={'id':id,'states':{},'source_master':'source/masters/guided_stone_crusher_isovolumes.png' if id=='guided_stone_crusher' else f'source/masters/{id}.png'}
  for col,state in enumerate(states):
   im=render(id,state);path=ROOT/'png'/f'{id}_{state}.png';im.save(path);b=im.getbbox();rec['states'][state]={'png':str(path.relative_to(ROOT)),'alpha_bounds_px':b,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'canvas_px':im.size,'ground_pivot_px':ROOTPX.tolist()}
   th=im.crop(b);th.thumbnail((470,350),Image.Resampling.LANCZOS);x=col*520;y=140+row*440;bg='#d0c3ae'if(row+col)%2 else'#d7cbb7';d.rectangle((x+10,y,x+510,y+428),fill=bg);sheet.paste(comp(th,bg),(x+(520-th.width)//2,y+10+(350-th.height)//2));d.text((x+25,y+369),id.replace('_',' ').title(),font=font(21),fill='#392c20');d.text((x+25,y+405),state.upper(),font=font(15),fill='#7a634a')
  rows.append(rec);print('Stills:',id,flush=True)
 sheet.save(ROOT/'proof/All_Hazard_States.png');manifest={'version':'2.0-clean-ink-candidate','content_status':'pending_art_and_motion_audit','camera':{'projection':'orthographic','elevation_degrees':35.2643897,'azimuth_degrees':45},'source_density_px_per_m':440,'default_canvas':[1536,1536],'default_root':[768,1220],'crusher_canvas':[1536,1792],'crusher_root':[768,1420],'assets':rows,'mechanical_contracts':{'iris':{'center':[0,1.15,.096],'hidden_chamber_radius_min_m':1.85,'visible_aperture_radius_m':.745,'wall_mounted_only':True},'pendulum_pivot':[0,2.38,.03],'bridge_hinge':[0,.225,-.86],'steam_outlet':[0,.218,0],'crusher':{'chain_reel_y':2.60,'raised_head_clearance':1.86,'lowered_head_clearance':.23}},'safety_scope':'Presentation art only; no damage window, safe-state, traversal or collider behavior is defined.'};(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2));(ROOT/'source/clipping_meshes.json').write_text(json.dumps(MASKS,indent=2))
 if '--stills-only'in sys.argv:return
 clips=[];seams=[]
 for id in ['retracting_spike_trap','bronze_iris_gate','ceiling_pendulum_blade']:
  out=ROOT/'animation'/id;out.mkdir(exist_ok=True);frames=[];recs=[];loop=id=='ceiling_pendulum_blade';fps=12 if loop else 24
  for i in range(24):
   t=i/24 if loop else i/23
   if not loop:t=t*t*(3-2*t)
   im=render(id,t=t);path=out/(f'swing_{i:03}.png'if loop else f'activate_{i:03}.png');im.save(path);frames.append(comp(im).resize((640,640),Image.Resampling.LANCZOS));recs.append({'file':str(path.relative_to(ROOT)),'normalized_progress_or_phase':t,'duration_ms':1000/fps,'root':ROOTPX.tolist(),'bounds':im.getbbox(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
  seq=frames if loop else[frames[0]]*8+frames+[frames[-1]]*10+frames[::-1];seq[0].save(out/'review.gif',save_all=True,append_images=seq[1:],duration=[80,80,90]*8 if loop else 60,loop=0,optimize=False)
  if loop:seams.append({'asset':id,'phase0_equals_phase1':render(id,t=0).tobytes()==render(id,t=1).tobytes(),'no_duplicate_endpoint':True})
  clips.append({'id':id+('_swing'if loop else'_activate'),'asset':id,'fps':fps,'duration_seconds':2 if loop else 1,'loop':loop,'frame_count':24,'source':'source/build_hazards.py','frames':recs});print('Clip:',id,flush=True)
 (ROOT/'animation/clips.json').write_text(json.dumps(clips,indent=2));(ROOT/'proof/loop_seam_validation.json').write_text(json.dumps(seams,indent=2))
 # Original rigid petal pivots and chamber envelope remain inspectable outside the visual aperture mask.
 env=[]
 for state in ['closed','open','jammed']:
  eng.H=1536;ROOTPX[1]=1220;im=iris(state,unclipped=True);im.save(ROOT/'proof'/f'iris_unclipped_{state}.png');env.append({'state':state,'blades':IRIS_ENVELOPES})
 (ROOT/'proof/iris_unclipped_envelopes.json').write_text(json.dumps(env,indent=2))
if __name__=='__main__':main()
