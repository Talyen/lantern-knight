"""Portable mechanical-context diagrams built only from this pack's assets."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math
import build_hazards as b
R=Path(__file__).resolve().parents[1]
def font(n):
 try:return ImageFont.truetype(str(R/'source/fonts/DejaVuSans.ttf'),n)
 except OSError:return ImageFont.load_default()
def main():
 b.eng.H=1536;b.ROOTPX[1]=1220
 art=b.Art();art.poly([(-2,-.75,-.17),(2,-.75,-.17),(2,3.1,-.17),(-2,3.1,-.17)],'#817462',None)
 mask=ImageDraw.Draw(art.im);hole=[b.p((.745*math.cos(i*math.tau/128),1.15+.745*math.sin(i*math.tau/128),.10))for i in range(128)];mask.polygon(hole,fill=(0,0,0,0));art.im.alpha_composite(Image.open(R/'png/bronze_iris_gate_open.png'))
 proof=Image.new('RGB',(1500,950),'#ded6c7');d=ImageDraw.Draw(proof);d.text((32,22),'IRIS / MOUNTING AND HIDDEN-CHAMBER CLEARANCE',font=font(28),fill='#36291e')
 for j,im in enumerate([art.im,Image.open(R/'proof/iris_unclipped_open.png').convert('RGBA')]):
  thumb=im.resize((700,700),Image.Resampling.LANCZOS);proof.paste(thumb,(j*750+25,90),thumb)
 d.text((35,795),'Visible facade: aperture mask is an opaque wall.',font=font(20),fill='#5a4530');d.text((780,795),'Unclipped rigid petals: hidden chamber required.',font=font(20),fill='#5a4530');d.text((35,850),'Reserve radius >=1.85m around(0,1.15,0.096). Verified vertex envelope:1.7922m.',font=font(22),fill='#382b20');d.text((35,900),'Technical context only. Not a freestanding working mechanism or a gameplay collision specification.',font=font(18),fill='#7a5c3e');proof.save(R/'proof/Iris_Mounting_Clearance.png')
 # The actual fixed guide strips are visible over the same translated carriage.
 page=Image.new('RGB',(1800,900),'#d9cebb');dr=ImageDraw.Draw(page);dr.text((30,25),'CRUSHER / FIXED GUIDE LIPS AND REGISTERED CHAIN EYES',font=font(29),fill='#392b1e')
 for j,state in enumerate(['raised','lowered','jammed']):
  im=Image.open(R/'png'/f'guided_stone_crusher_{state}.png').convert('RGBA');im=im.crop(im.getbbox());im.thumbnail((570,735),Image.Resampling.LANCZOS);page.paste(im,(j*600+(600-im.width)//2,100),im);dr.text((j*600+30,855),state.upper(),font=font(21),fill='#5c4730')
 page.save(R/'proof/Crusher_Guide_Lip_Detail.png')
if __name__=='__main__':main()
