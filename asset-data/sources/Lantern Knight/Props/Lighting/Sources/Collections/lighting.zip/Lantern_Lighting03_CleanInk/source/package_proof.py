from pathlib import Path
from font_support import get_font
from PIL import Image,ImageDraw,ImageFont,ImageChops
import json,hashlib,subprocess,numpy as np
R=Path(__file__).resolve().parents[1];old=R/'source/historical_before';m=json.load(open(R/'manifest.json'))
def font(n):return get_font(n)
def fit(sheet,path,rect):
 im=Image.open(path).convert('RGBA');im=im.crop(im.getbbox());im.thumbnail((rect[2]-rect[0],rect[3]-rect[1]),Image.Resampling.LANCZOS);sheet.paste(im,(rect[0]+(rect[2]-rect[0]-im.width)//2,rect[1]+(rect[3]-rect[1]-im.height)//2),im)
sheet=Image.new('RGB',(1600,1850),'#332e28');d=ImageDraw.Draw(sheet);d.text((35,28),'LANTERN / EIGHT LIGHTING REDRAWS',font=font(35),fill='#e6d2ad');d.text((35,80),'Illustrated materials, controlled flame masters, independent emission and pane warmth.',font=font(21),fill='#b6a080')
for i,a in enumerate(m['assets']):
 col=i%2;row=i//2;x=col*800;y=145+row*415;d.rectangle((x+15,y,x+785,y+396),fill='#40392d');id=a['id'];fit(sheet,old/f'{id}_lit.png',(x+28,y+20,x+303,y+320));fit(sheet,R/'png'/f'{id}_lit.png',(x+360,y+20,x+760,y+320));d.text((x+34,y+332),'BEFORE',font=font(16),fill='#b49b76');d.text((x+366,y+332),'AFTER',font=font(16),fill='#b49b76');d.text((x+34,y+363),id.replace('_',' ').title(),font=font(24),fill='#e6d2ad')
sheet.save(R/'proof/Before_After_All_Eight.png')
clips=json.load(open(R/'animation/clips.json'));seq=[]
for c in clips:
 gif=R/'animation'/c['asset']/'review.gif';subprocess.run(['ffmpeg','-y','-i',str(gif),'-r','12','-t','2','-movflags','+faststart','-pix_fmt','yuv420p',str(gif.with_suffix('.mp4'))],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
for i in list(range(24))*2:
 page=Image.new('RGB',(1280,1330),'#332e28');draw=ImageDraw.Draw(page)
 for j,c in enumerate(clips):
  im=Image.open(R/c['frames'][i]['file']).convert('RGBA').resize((640,640),Image.Resampling.LANCZOS);page.paste(im,((j%2)*640,(j//2)*665),im);draw.text(((j%2)*640+22,(j//2)*665+632),c['asset'].replace('_',' ').title(),font=font(21),fill='#e4d0ae')
 seq.append(page)
seq[0].save(R/'proof/Four_Flame_Loops.gif',save_all=True,append_images=seq[1:],duration=[80,80,90]*16,loop=0,optimize=False)
subprocess.run(['ffmpeg','-y','-i',str(R/'proof/Four_Flame_Loops.gif'),'-r','12','-t','4','-movflags','+faststart','-pix_fmt','yuv420p',str(R/'proof/Four_Flame_Loops.mp4')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
checks=[];composition=[]
for a in m['assets']:
 for state,r in a['states'].items():
  im=Image.open(R/r['png']);b=im.getbbox();checks.append({'asset':a['id'],'state':state,'rgba':im.mode=='RGBA','canvas':im.size,'edge_contact':b[0]==0 or b[1]==0 or b[2]==im.width or b[3]==im.height,'bounds':b})
 base=Image.open(R/'png'/f"{a['id']}_unlit.png").convert('RGBA');base.alpha_composite(Image.open(R/'illumination'/f"{a['id']}_pane_warmth.png"));base.alpha_composite(Image.open(R/'emission'/f"{a['id']}_lit.png"));composition.append({'asset':a['id'],'unlit_plus_pane_warmth_plus_emission_equals_lit':base.tobytes()==Image.open(R/'png'/f"{a['id']}_lit.png").tobytes()})
clipchecks=[]
for c in clips:
 arrays=[np.array(Image.open(R/f['file'])) for f in c['frames']];union=np.zeros(arrays[0].shape[:2],bool)
 for f in c['frames']:union |=np.array(Image.open(R/f['emission_file']))[:,:,3]>0
 static_equal=all(np.array_equal(arrays[0][~union],a[~union])for a in arrays)
 bounds=[Image.open(R/f['emission_file']).getbbox()for f in c['frames']]
 clipchecks.append({'asset':c['asset'],'frame_count':24,'phase0_matches_lit_still':arrays[0].tobytes()==Image.open(R/'png'/f"{c['asset']}_lit.png").tobytes(),'hardware_outside_emission_union_pixel_fixed':static_equal,'emission_bounds_by_frame':bounds,'source_anchor_contract':'Every flame is deformed around v=1; base vertices are invariant for all phases.'})
qa={'stills':checks,'layer_composition':composition,'clips':clipchecks,'loop_seams':json.load(open(R/'proof/loop_seam_validation.json')),'untouched_master_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (R/'source/masters').glob('*.png')}};(R/'proof/QA_integrity.json').write_text(json.dumps(qa,indent=2));print('Lighting proofs and layer/loop QA ready')
