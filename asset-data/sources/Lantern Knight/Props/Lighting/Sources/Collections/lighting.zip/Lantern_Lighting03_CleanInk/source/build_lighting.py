#!/usr/bin/env python3
"""Clean-ink lighting: untouched illustrated fixtures + coherent flame master deformation.
No independent frame generation. Source masks only assemble emissive/hardware layers."""
from illustration_engine import *
from font_support import get_font
from PIL import ImageDraw
RIGHT=np.array([1/math.sqrt(2),0,-1/math.sqrt(2)])
DOWN=np.array([math.sin(ELEV)/math.sqrt(2),-math.cos(ELEV),math.sin(ELEV)/math.sqrt(2)])
def rv(deg):
 v=np.array([1,1,1])/math.sqrt(3);a=math.radians(deg);K=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
 return np.eye(3)*math.cos(a)+(1-math.cos(a))*np.outer(v,v)+math.sin(a)*K
CFG={
 'watch_lantern':dict(anchor=(610,1110),root=(0,0,0),scale=.00075,fires=[((528,786),'wick',.075,.145,0)],panes=[[(350,539),(553,658),(558,1049),(353,933)],[(650,689),(847,576),(846,936),(655,1049)]]),
 'crook_street_lamp':dict(anchor=(475,1390),root=(0,0,0),scale=.00125,fires=[((743,500),'wick',.060,.10,.1)],panes=[[(636,411),(712,451),(715,581),(644,542)],[(735,452),(810,410),(804,538),(737,580)]]),
 'tripod_brazier':dict(anchor=(650,975),root=(0,0,0),scale=.00105,fires=[((650,440),'bowl',.57,.55,.13)],occluder=[[(0,505),(350,518),(690,548),(1113,458),(1312,478),(1312,1199),(0,1199)]]),
 'wall_cresset':dict(anchor=(1180,560),root=(0,1.035,-.18),scale=.00070,fires=[((550,453),'bowl',.47,.43,.27)],occluder=[[(0,527),(456,598),(807,551),(1039,382),(1312,383),(1312,1199),(0,1199)]]),
 'votive_candelabrum':dict(anchor=(610,1180),root=(0,0,0),scale=.00095,fires=[((212,466),'wick',.06,.17,.1),((607,79),'wick',.068,.19,.4),((1049,241),'wick',.057,.16,.7)]),
 'tomb_beacon':dict(anchor=(520,1400),root=(0,0,0),scale=.00090,fires=[((516,331),'bowl',.50,.43,.05)],occluder=[[(0,435),(329,426),(534,451),(715,405),(834,284),(1024,280),(1024,1536),(0,1536)]]),
 'hanging_cage_lamp':dict(anchor=(513,35),root=(0,2.135,0),scale=.00110,fires=[((514,1126),'wick',.11,.215,.25)],panes=[[(459,908),(552,908),(588,1268),(428,1271)],[(390,993),(420,921),(371,1220),(401,1296),(368,1263),(331,1166)]]),
 'alchemist_stove':dict(anchor=(597,1110),root=(0,0,0),scale=.00090,fires=[((395,973),'stove',.21,.24,.34)],panes=[[(300,790),(299,766),(309,749),(327,746),(345,761),(345,958),(329,970),(309,962)],[(374,778),(378,763),(396,756),(414,771),(417,969),(403,985),(377,976)],[(446,810),(450,793),(468,787),(485,802),(487,988),(470,1004),(448,994)]]),
}
FLAMES={'wick':(101,6,444,834),'bowl':(548,6,1219,850),'stove':(1280,116,1724,831)}

def world_pixel(id,q):
 c=CFG[id];return np.array(c['root'])+RIGHT*((q[0]-c['anchor'][0])*c['scale'])+DOWN*((q[1]-c['anchor'][1])*c['scale'])
def sprite(a,id,img,R=None,pivot=None):
 c=CFG[id];a.sprite(img,c['anchor'],c['root'],c['scale'],R,pivot)
def mask_image(id,polys,color=(255,255,255,255)):
 im=Image.new('RGBA',master(id).size);d=ImageDraw.Draw(im)
 for poly in polys:d.polygon(poly,fill=color)
 return im

def draw_flame(a,flame,base,width,height,phase):
 tex=layer('flame_masters',flame,FLAMES[flame]);phase%=1.;theta=math.tau*phase
 def vertex(u,v):
  lift=1-v;wave=.068*math.sin(theta+v*6.3)+.022*math.sin(2*theta+v*10.0)
  x=(u-.5)*width*(1+.065*math.sin(theta*2+v*4)*lift)+width*wave*lift**1.35
  yy=-height*lift*(1+.037*math.sin(theta*2+.8)*lift)
  return np.array(base)+RIGHT*x+DOWN*yy
 assert np.array_equal(vertex(.5,1),np.array(base)), 'Flame contact moved'
 for v0,v1 in zip(np.linspace(0,1,23)[:-1],np.linspace(0,1,23)[1:]):
  uv=[(0,v0*tex.height),(tex.width,v0*tex.height),(tex.width,v1*tex.height),(0,v1*tex.height)];verts=[vertex(0,v0),vertex(1,v0),vertex(1,v1),vertex(0,v1)]
  for ids in [(0,1,2),(0,2,3)]:a.triangle(tex,[uv[i] for i in ids],[verts[i] for i in ids])

# Material/fixture-specific terminal break construction, never the same generic hole.
DAMAGE={
 'watch_lantern':dict(poly=[(354,623),(393,596),(435,675),(482,700),(467,768),(495,815),(449,912),(353,910)],mode='glass',anchor=(421,851),floor=(-.20,.025,.35),rot=27),
 'crook_street_lamp':dict(poly=[(576,270),(860,270),(870,676),(580,676)],mode='drop',anchor=(724,610),floor=(.38,.045,.10),rot=-66),
 'tripod_brazier':dict(poly=[(698,750),(742,854),(734,1039),(770,1137),(714,1187),(690,1152),(703,1050),(683,932),(686,832)],mode='drop',anchor=(665,1070),floor=(-.31,.035,.31),rot=76),
 'wall_cresset':dict(poly=[(0,0),(1040,0),(1030,742),(692,738),(660,807),(489,809),(483,742),(0,745)],mode='drop',anchor=(555,710),floor=(-.27,.05,.26),rot=-24),
 'votive_candelabrum':dict(poly=[(0,340),(331,340),(352,573),(477,633),(487,722),(430,825),(318,952),(0,949)],mode='drop',anchor=(329,843),floor=(-.10,.04,.31),rot=-61),
 'tomb_beacon':dict(poly=[(55,543),(198,493),(283,578),(246,637),(324,686),(287,742),(155,691),(53,644)],mode='stone',anchor=(199,635),floor=(-.18,.03,.36),rot=46),
 'hanging_cage_lamp':dict(poly=[(375,907),(462,889),(464,943),(437,1057),(427,1248),(444,1351),(382,1373),(353,1278),(348,1130)],mode='drop',anchor=(404,1250),floor=(-.22,.04,.25),rot=-63),
 'alchemist_stove':dict(poly=[(625,0),(1222,0),(1222,360),(989,371),(930,330),(800,336),(737,322),(640,326)],mode='drop',anchor=(897,291),floor=(.42,.04,.25),rot=67),
}
def broken_fixture(a,id):
 original=master(id);c=CFG[id];d=DAMAGE[id];body=cut(original,d['poly'],id+'_broken_body',True);piece=cut(original,d['poly'],id+'_broken_piece')
 if d['mode']=='glass':
  tint=mask_image(id,[d['poly']],(39,34,29,255));sprite(a,id,tint)
  cracks=Image.new('RGBA',original.size);pen=ImageDraw.Draw(cracks)
  for pts in [[(485,640),(429,695),(451,757),(392,840)],[(429,695),(386,692),(355,747)],[(451,757),(517,813)],[(392,840),(414,919)]]:
   pen.line(pts,fill='#242526',width=7,joint='curve');pen.line(pts,fill='#d1d5cf',width=3,joint='curve')
  body.alpha_composite(cracks)
 if d['mode']=='stone':
  lip=Image.new('RGBA',body.size);pen=ImageDraw.Draw(lip);pen.line(d['poly'],fill='#dcc9a7',width=13,joint='curve');pen.line(d['poly'],fill='#3f3427',width=4,joint='curve');lip.putalpha(ImageChops.multiply(lip.getchannel('A'),original.getchannel('A')));body.alpha_composite(lip)
 sprite(a,id,body)
 # Detached parts reuse untouched source painting on one rigid terminal-state layer.
 a.sprite(piece,d['anchor'],d['floor'],c['scale']*.73,R=rv(d['rot']),pivot=d['floor'])

LAST_EMISSION=None
LAST_ILLUMINATION=None
def render(id,state='unlit',phase=0):
 global LAST_EMISSION,LAST_ILLUMINATION
 a=Art();c=CFG[id];LAST_ILLUMINATION=Image.new('RGBA',(W,H))
 if state=='broken':broken_fixture(a,id);LAST_EMISSION=Image.new('RGBA',(W,H));return a.im
 sprite(a,id,master(id));em=Art()
 if state=='lit':
  if 'panes' in c:
   tint=mask_image(id,c['panes'],(233,146,44,38));wash=Art();sprite(wash,id,tint);LAST_ILLUMINATION=wash.im;a.im.alpha_composite(wash.im)
  for q,kind,w,h,offset in c['fires']:draw_flame(em,kind,world_pixel(id,q),w,h,(phase+offset)%1)
  if 'panes' in c:
   mask=Art();sprite(mask,id,mask_image(id,c['panes']));em.im.putalpha(ImageChops.multiply(em.im.getchannel('A'),mask.im.getchannel('A')))
  if 'occluder' in c:
   fg=master(id)
   # Preserve front rim, timber and metal exactly while fire lives behind them.
   fg=cut(fg,c['occluder'][0],id+'_fire_front_occlusion')
   mask=Art();sprite(mask,id,mask_image(id,c['occluder']));em.im.putalpha(ImageChops.multiply(em.im.getchannel('A'),ImageChops.invert(mask.im.getchannel('A'))))
  a.im.alpha_composite(em.im)
 LAST_EMISSION=em.im
 return a.im

def font(n):return get_font(n)
def comp(im,bg='#332e28'):
 out=Image.new('RGBA',im.size,bg);out.alpha_composite(im);return out.convert('RGB')
def main():
 (ROOT/'emission').mkdir(exist_ok=True);(ROOT/'illumination').mkdir(exist_ok=True);rows=[];sheet=Image.new('RGB',(1560,3650),'#332e28');d=ImageDraw.Draw(sheet);d.text((35,25),'LANTERN / LIGHTING 03 / CLEAN INK',font=font(34),fill='#e8d9bf');d.text((35,80),'Eight illustrated fixtures / registered artist-drawn flame masters / four seamless loops',font=font(21),fill='#b7a082')
 for row,id in enumerate(CFG):
  rec={'id':id,'states':{},'source_master':f'source/masters/{id}.png','registration':CFG[id]}
  for col,state in enumerate(['unlit','lit','broken']):
   im=render(id,state);path=ROOT/'png'/f'{id}_{state}.png';im.save(path);b=im.getbbox();rec['states'][state]={'png':str(path.relative_to(ROOT)),'alpha_bounds_px':b,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'canvas_px':[W,H],'ground_pivot_px':ROOTPX.tolist()}
   if state=='lit':
    LAST_EMISSION.save(ROOT/'emission'/f'{id}_lit.png');LAST_ILLUMINATION.save(ROOT/'illumination'/f'{id}_pane_warmth.png')
   th=im.crop(b);th.thumbnail((470,330),Image.Resampling.LANCZOS);x=col*520;y=140+row*438;bg='#3e382e' if (row+col)%2 else '#383229';d.rectangle((x+10,y,x+510,y+424),fill=bg);sheet.paste(comp(th,bg),(x+(520-th.width)//2,y+18+(330-th.height)//2));d.text((x+25,y+361),id.replace('_',' ').title(),font=font(22),fill='#e3d1b4');d.text((x+25,y+398),state.upper(),font=font(15),fill='#b49a76')
  rows.append(rec);print('Stills:',id,flush=True)
 sheet.save(ROOT/'proof/All_Lighting_States.png');manifest={'version':'2.0-clean-ink-candidate','content_status':'pending_visual_audit','canvas':[W,H],'ground_pivot_px':ROOTPX.tolist(),'source_density_px_per_m':PPM,'camera':{'projection':'orthographic','elevation_degrees':35.2643897,'azimuth_degrees':45},'assets':rows,'light_rendering':'lit PNG has clean flame color and restrained static pane warmth; separate emission RGBA supplied, not claimed as physically based dynamic lighting','caveats':['Fixture masters are fixed-view isometric illustrations, not fully calibrated 3D meshes. Camera basis controls anchors and flame surfaces.','No hardware is independently regenerated or deformed during flame animation.']};(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2));(ROOT/'source/clipping_meshes.json').write_text(json.dumps(MASKS,indent=2));(ROOT/'source/registration.json').write_text(json.dumps(CFG,indent=2))
 if '--stills-only' in sys.argv:return
 clips=[];seams=[]
 for id in ['watch_lantern','tripod_brazier','votive_candelabrum','hanging_cage_lamp']:
  out=ROOT/'animation'/id;out.mkdir(exist_ok=True);frames=[];recs=[]
  for i in range(24):
   ph=i/24;im=render(id,'lit',ph);path=out/f'flicker_{i:03}.png';im.save(path);epath=out/f'emission_{i:03}.png';LAST_EMISSION.save(epath);frames.append(comp(im).resize((640,640),Image.Resampling.LANCZOS));recs.append({'file':str(path.relative_to(ROOT)),'emission_file':str(epath.relative_to(ROOT)),'normalized_phase':ph,'duration_ms':1000/12,'root':ROOTPX.tolist(),'bounds':im.getbbox(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
  frames[0].save(out/'review.gif',save_all=True,append_images=frames[1:],duration=[80,80,90]*8,loop=0,optimize=False)
  zero=render(id,'lit',0).tobytes();one=render(id,'lit',1).tobytes();seams.append({'asset':id,'phase_0_equals_phase_1':zero==one,'no_duplicate_endpoint_exported':True,'frames':24})
  clips.append({'id':id+'_flame_loop','asset':id,'fps':12,'duration_seconds':2,'loop':True,'frame_count':24,'source':'source/build_lighting.py','phase_endpoint_rule':'i/24 for i=0..23, phase1 pixel-matches phase0 but is not exported','frames':recs});print('Clip:',id,flush=True)
 (ROOT/'animation/clips.json').write_text(json.dumps(clips,indent=2));(ROOT/'proof/loop_seam_validation.json').write_text(json.dumps(seams,indent=2))
if __name__=='__main__':main()
