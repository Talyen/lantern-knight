#!/usr/bin/env python3
from pathlib import Path
import zipfile,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'delivery/Lantern_Workshop04_Clean_Ink_Complete.zip'
files=[p for p in ROOT.rglob('*') if p.is_file() and 'delivery' not in p.relative_to(ROOT).parts and '__pycache__' not in p.parts and not (p.parent.name=='layers' and p.suffix=='.png')]
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,Path(ROOT.name)/p.relative_to(ROOT))
rec={'path':str(DEST.relative_to(ROOT)),'bytes':DEST.stat().st_size,'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),'files':len(files),'complete_inputs_and_exports':True,'omitted':'Only regenerable derived layer PNG cache and Python bytecode. All masters, prompts, source, references, 24 states, 96 frames, manifests and proofs are included.'}
(ROOT/'delivery/package.json').write_text(json.dumps(rec,indent=2));print(json.dumps(rec,indent=2));assert rec['bytes']<100*1024**2
