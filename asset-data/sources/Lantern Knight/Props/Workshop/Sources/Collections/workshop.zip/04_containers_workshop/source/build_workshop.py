#!/usr/bin/env python3
"""Clean-ink component illustrations, fixed camera and reproducible source mesh assembly.
All generated masters are immutable. Baked body perspective is not fully 3D calibrated.
"""
from illustration_engine import *
from PIL import ImageOps
ORDER=['weathered_satchel','tied_grain_sack','reed_hamper','burial_coffin','bowed_apothecary_cabinet','spouted_coal_scuttle','canvas_rollcase','curved_spice_drawer']
REG={}
def fromscreen(xy,y=0):
 sx,sy=(np.array(xy)-ROOTPX)/PPM
 summ=(sy+y*math.cos(ELEV))*math.sqrt(2)/math.sin(ELEV);diff=sx*math.sqrt(2)
 return np.array([(summ+diff)/2,y,(summ-diff)/2])
def sourcepoint(v,anchor,s,wa=(0,0,0),y=0):
 xy=np.array(p(wa))+(np.array(v)-np.array(anchor))*s*PPM
 return fromscreen(xy,y)
def rotation_axis(axis,degrees):
 axis=np.array(axis,float);axis/=np.linalg.norm(axis);x,y,z=axis;c=math.cos(math.radians(degrees));s=math.sin(math.radians(degrees));C=1-c
 return np.array([[c+x*x*C,x*y*C-z*s,x*z*C+y*s],[y*x*C+z*s,c+y*y*C,y*z*C-x*s],[z*x*C-y*s,z*y*C+x*s,c+z*z*C]])
def quad(a,tex,uv,vs):
 for ids in [(0,1,2),(0,2,3)]:a.triangle(tex,[uv[i] for i in ids],[vs[i] for i in ids])
def satchel(state='closed',t=None):
 a=Art();id='weathered_satchel';body=layer(id,'body',(0,0,923,1024));anchor=(450,800);s=.00133
 val=(0 if state=='closed' else 1 if state=='open' else 1) if t is None else t
 flap=layer(id,'flap',(933,11,1528,502));under=layer(id,'lining',(930,509,1529,1010))
 # Source-registered curved flap mesh. Point motion is projected by the declared camera.
 lr=[sourcepoint(q,anchor,s,y=.77) for q in [(302,249),(781,410)]]
 fr=[sourcepoint(q,anchor,s,y=.74) for q in [(120,315),(622,504)]]
 lo=[sourcepoint(q,anchor,s,y=.27) for q in [(98,625),(625,860)]]
 R=rotation_axis(lr[1]-lr[0],-112*val);pivot=lr[0]
 mid=[fr[i]+(lo[i]-fr[i])*(.30/.57) for i in range(2)];rows=[lr,fr,mid,lo];vv=[0,.43,.73,1]
 def paintflap():
  # Leather progressively unrolls at the mouth fold as the lid opens. This keeps
  # the lining a continuous authored surface rather than a pair of rigid fins.
  opened=[]
  for row,v in zip(rows,vv):
   rr=[]
   for side in range(2):
    direction=fr[side]-lr[side];direction[1]=0;direction=direction/np.linalg.norm(direction)
    flat=lr[side]+direction*(.83*v)
    rr.append(row[side]*(1-val)+flat*val)
   opened.append(rr)
  for j in range(3):
   vs=[opened[j][0],opened[j][1],opened[j+1][1],opened[j+1][0]];vs=[R@(q-pivot)+pivot for q in vs]
   if j==2:
    bend=rotation_axis(vs[1]-vs[0],20*val);vs=[vs[0],vs[1],bend@(vs[2]-vs[0])+vs[0],bend@(vs[3]-vs[0])+vs[0]]
   facing=np.dot(np.cross(vs[1]-vs[0],vs[3]-vs[0]),np.array([1,1,1]))
   tex=under if facing>0 else flap
   uv=[(0,vv[j]*tex.height),(tex.width,vv[j]*tex.height),(tex.width,vv[j+1]*tex.height),(0,vv[j+1]*tex.height)];quad(a,tex,uv,vs)
 if state=='broken':
  pts=[(671,593),(679,618),(683,650),(678,687),(681,726),(678,766),(688,807),(694,849),(687,891),(697,927),(719,964),(796,987),(923,892),(923,537)]
  body,frag=fracture(body,pts,'satchel_split_gusset_seam','leather')
 if val>.42:paintflap()
 a.sprite(body,anchor,[0,0,0],s)
 if state=='broken':a.sprite(frag,anchor,[0,0,0],s,R=rz(13),pivot=sourcepoint((687,612),anchor,s))
 if val<=.42:paintflap()
 return a.im

def font(n):return ImageFont.truetype(str(ROOT/'source/fonts/DejaVuSans.ttf'),n)
def comp(im,bg='#e0d5c2'):
 out=Image.new('RGBA',im.size,bg);out.alpha_composite(im);return out.convert('RGB')
if __name__=='__main__':
 sheet=Image.new('RGB',(1800,1100),'#e0d5c2');d=ImageDraw.Draw(sheet);d.text((45,25),'WORKSHOP 04 / FIRST ILLUSTRATED SATCHEL PROOF',font=font(30),fill='#31271e')
 for i,state in enumerate(['closed','open']):
  im=satchel(state);im.save(ROOT/'png'/f'weathered_satchel_{state}.png');th=im.crop(im.getbbox());th.thumbnail((820,930));sheet.paste(comp(th),(i*900+(900-th.width)//2,100));d.text((i*900+50,1030),state,font=font(24),fill='#31271e')
 sheet.save(ROOT/'proof/first_satchel_open_closed.png')

def sprite_xy(a,img,source_anchor,world_anchor,sx,sy):
 target=np.array(p(world_anchor)); M=(1/(PPM*sx),0,source_anchor[0]-target[0]/(PPM*sx),0,1/(PPM*sy),source_anchor[1]-target[1]/(PPM*sy));a.im.alpha_composite(img.transform((W,H),Image.Transform.AFFINE,M,Image.Resampling.BICUBIC))

def fracture(img,pts,name,material):
 main=cut(img,pts,name+'_cut',True);part=cut(img,pts,name+'_fragment')
 raw={'wood':'#c99250','cloth':'#bcb48c','reed':'#e1b360','iron':'#a8a399','leather':'#a0724c'}[material]
 # Separately authored raw exposed fibers/fold lips; original master alpha is untouched.
 lip=Image.new('RGBA',img.size);d=ImageDraw.Draw(lip);outer=14 if material in ['wood','iron'] else 7 if material=='leather' else 5;inner=8 if material in ['wood','iron'] else 3;d.line(pts,fill=INK,width=outer,joint='curve');d.line(pts,fill=raw,width=inner,joint='curve')
 for j,(x,y) in enumerate(pts[:-1]):
  if j%2==0:
   if material in ['wood','iron']:d.line([(x-9,y-5),(x+10,y+13)],fill=INK,width=3)
   elif material=='cloth':d.line([(x-2,y-2),(x+9,y+5),(x+13,y+1)],fill=raw,width=2)
 lip.putalpha(ImageChops.multiply(lip.getchannel('A'),img.getchannel('A')));main.alpha_composite(lip)
 main.save(ROOT/'layers'/f'{name}_remaining.png');part.save(ROOT/'layers'/f'{name}_fragment.png');return main,part

def cabinet(state='closed',t=None):
 a=Art();id='bowed_apothecary_cabinet';body=layer(id,'body',(0,0,709,1374));anchor=(365,1127);s=.00147;val=(0 if state=='closed' else 1 if state=='open' else .35) if t is None else t
 a.sprite(body,anchor,[0,0,0],s);door=layer(id,'door',(769,4,1110,657));inside=layer(id,'door_inside',(768,675,1110,1317))
 vs=[sourcepoint(q,anchor,s,y=1.82 if i<2 else .15) for i,q in enumerate([(143,106),(468,200),(468,1184),(143,1090)])]
 pivot=vs[0];R=rotation_axis(vs[3]-vs[0],102*val);tex=door if np.dot(np.cross(R@(vs[1]-vs[0]),R@(vs[3]-vs[0])),[1,1,1])<0 else inside
 if state=='broken':tex,part=fracture(tex,[(160,350),(202,345),(201,392),(244,385),(247,457),(338,470),(338,654),(164,654)],'cabinet_splintered_lower_rail','wood')
 vv=[R@(q-pivot)+pivot for q in vs]
 normal=np.cross(vv[1]-vv[0],vv[3]-vv[0]);normal=normal/np.linalg.norm(normal)*.025
 for j in range(4):
  k=(j+1)%4;a.poly([vv[j],vv[k],vv[k]+normal,vv[j]+normal],'#7d512e',INK,1)
 quad(a,tex,[(0,0),(tex.width,0),(tex.width,tex.height),(0,tex.height)],vv)
 if state=='broken':a.sprite(part,(170,570),[-.36,.06,.51],.00135,R=rz(-18))
 return a.im

def drawer(state='closed',t=None):
 a=Art();id='curved_spice_drawer';body=cut(layer(id,'body',(0,0,929,907)),[(0,0),(929,0),(929,450),(910,480),(910,907),(0,907)],'drawer_body_atlas_isolation');anchor=(495,704);s=.00155;val=(0 if state=='closed' else 1 if state=='open' else 1) if t is None else t
 drawer=layer(id,'drawer',(931,485,1534,951));a.sprite(body,anchor,[0,0,0],s)
 # Affine source registration of complete volumetric drawer, driven by a world-space rail.
 src=np.array([(8,112),(387,255),(8,285)],float)
 target=[sourcepoint(q,anchor,s,y=.55 if i<2 else .12) for i,q in enumerate([(143,356),(568,481),(143,621)])]
 shift=np.array([0,0,.42*val]);target=[q+shift for q in target]
 if state=='broken':
  drawer,part=fracture(drawer,[(0,106),(90,143),(75,193),(125,210),(112,284),(73,273),(86,329),(0,303)],'drawer_sheared_front_corner','wood');R=rz(17);pivot=target[2];target=[R@(q-pivot)+pivot+np.array([-.14,-.10,.16]) for q in target]
 dst=np.array([p(v) for v in target]);M=np.linalg.solve(np.column_stack([dst,np.ones(3)]),src).T
 dr=drawer.transform((W,H),Image.Transform.AFFINE,tuple(M.flatten()),Image.Resampling.BICUBIC)
 a.im.alpha_composite(dr)
 if state!='broken':
  # Stationary cabinet shell occlusion replaces the former threshold reveal.
  # The tray emerges continuously beneath the top/side; its front is always nearest.
  top=cut(body,[(0,0),(929,0),(929,349),(588,466),(72,301),(0,350)],'drawer_stationary_top_occlusion')
  side=cut(body,[(610,448),(929,341),(929,907),(611,850),(590,748)],'drawer_stationary_right_occlusion')
  a.sprite(top,anchor,[0,0,0],s);a.sprite(side,anchor,[0,0,0],s)
  front=cut(drawer,[(0,95),(388,242),(406,466),(0,466)],'drawer_moving_front')
  a.im.alpha_composite(front.transform((W,H),Image.Transform.AFFINE,tuple(M.flatten()),Image.Resampling.BICUBIC))
 if state=='broken':a.sprite(part,(0,290),[-.56,.05,.71],.00155,R=rz(-19))
 return a.im

def coffin(state='closed',t=None):
 a=Art();id='burial_coffin';body=layer(id,'body',(0,0,1169,1024));anchor=(590,738);s=.00153;val=(0 if state=='closed' else 1 if state=='open' else .80) if t is None else t
 tex=layer(id,'lid',(1228,0,1508,513));inside=layer(id,'lid_inside',(1229,515,1508,1018))
 # Six source-boundary landmarks register lid to the illustrated coffin rim.
 xy=[(47,108),(217,17),(492,101),(1141,687),(932,782),(139,250)]
 world=[sourcepoint(q,anchor,s,y=.52) for q in xy];uv=[(.28,0),(.72,0),(1,.28),(.78,1),(.22,1),(0,.28)]
 pivot=world[2];R=rotation_axis(world[3]-world[2],-100*val);vv=[R@(q-pivot)+pivot for q in world]
 if state=='broken':tex,part=fracture(tex,[(0,325),(40,336),(53,310),(93,349),(109,327),(151,354),(185,342),(226,360),(280,352),(280,513),(0,513)],'coffin_cross_grain_lid_break','wood')
 if state=='broken':inside,_=fracture(inside,[(0,325),(40,336),(53,310),(93,349),(109,327),(151,354),(185,342),(226,360),(280,352),(280,513),(0,513)],'coffin_inside_cross_grain','wood')
 a.sprite(body,anchor,[0,0,0],s)
 tt=inside if np.dot(np.cross(vv[1]-vv[0],vv[-1]-vv[0]),[1,1,1])>0 else tex
 center=np.mean(vv,axis=0);cu=(.5*tt.width,.51*tt.height)
 for i in range(6):
  j=(i+1)%6;a.triangle(tt,[cu,(uv[i][0]*tt.width,uv[i][1]*tt.height),(uv[j][0]*tt.width,uv[j][1]*tt.height)],[center,vv[i],vv[j]])
 if val>.36:
  # Near wall stays in front of the rear-opening lid. No component recentering.
  front=cut(body,[(43,106),(142,251),(935,778),(1149,685),(1169,1024),(0,1024)],'coffin_front_occlusion')
  a.sprite(front,anchor,[0,0,0],s)
 if state=='broken':a.top(part,-.62,.03,.48,.48,.56,R=ry(18))
 return a.im

def sack(state='closed',t=None):
 a=Art();id='tied_grain_sack';body=cut(layer(id,'body',(0,0,939,1024)),[(0,0),(895,0),(895,785),(939,810),(939,1024),(0,1024)],'sack_atlas_isolation');anchor=(455,820);s=.00124
 if state=='broken':
  pts=[(65,593),(114,610),(154,675),(136,720),(171,764),(140,812),(0,859),(0,673)]
  body,part=fracture(body,pts,'sack_burst_left_seam','cloth');a.sprite(part,(90,790),[-.28,.03,.38],s,R=rz(-25))
 if state!='open':body=cut(body,[(0,460),(939,460),(939,1024),(0,1024)],'sack_body_below_gather')
 a.sprite(body,anchor,[0,0,0],s)
 if state!='open':
  collar=layer(id,'tied_collar',(908,70,1468,601));sprite_xy(a,collar,(280,485),sourcepoint((465,530),anchor,s),s*1.48,s*1.10)
 if state=='broken':
  grain=layer(id,'spilled_grain',(965,650,1536,1019));a.sprite(grain,(320,220),[-.28,.025,.45],.00103)
 return a.im

def hamper(state='closed',t=None):
 a=Art();id='reed_hamper';body=cut(layer(id,'body',(0,0,949,990)),[(0,0),(933,0),(933,460),(948,515),(948,650),(930,690),(925,990),(0,990)],'hamper_body_atlas_isolation');anchor=(482,781);s=.00138;tex=layer(id,'lid',(942,93,1524,510));under=layer(id,'lid_inside',(942,521,1526,960))
 if state=='broken':
  pts=[(716,310),(721,363),(730,416),(739,471),(752,524),(764,579),(789,631),(812,680),(949,700),(949,0),(735,0),(707,267)]
  body,part=fracture(body,pts,'hamper_unwoven_rim_and_reeds','reed')
  d=ImageDraw.Draw(body)
  for ribbon in [[(720,404),(761,401),(818,376),(827,383),(766,413),(723,416)],[(744,516),(787,518),(855,549),(851,558),(784,530),(745,529)],[(777,612),(810,594),(840,602),(837,610),(812,605),(781,624)]]:
   d.polygon(ribbon,fill='#c68c41');d.line(ribbon+[ribbon[0]],fill=INK,width=3,joint='curve');d.line(ribbon[:3],fill='#edc576',width=2)
  a.sprite(part,(810,650),[.60,.025,.43],.00076,R=rz(34))
 a.sprite(body,anchor,[0,0,0],s)
 if state=='closed':sprite_xy(a,tex,(291,209),sourcepoint((486,272),anchor,s),s*1.25,s*.73)
 else:a.sprite(under,(285,325),[.59,.035,-.03],.00114,R=rz(-19))
 return a.im

def scuttle(state='closed',t=None):
 a=Art();id='spouted_coal_scuttle';body=cut(layer(id,'body',(0,0,924,1024)),[(0,0),(867,0),(867,413),(924,428),(924,516),(864,531),(864,1024),(0,1024)],'scuttle_atlas_isolation');anchor=(435,811);s=.00137;tex=layer(id,'lid',(928,90,1536,524));under=layer(id,'lid_inside',(928,535,1536,1003))
 if state=='broken':
  pts=[(666,512),(704,538),(693,603),(728,630),(716,755),(757,826),(812,870),(924,873),(924,448)]
  body,part=fracture(body,pts,'scuttle_torn_folded_seam','iron');a.sprite(part,(718,710),[.65,.05,.35],s*.78,R=rz(-17))
 a.sprite(body,anchor,[0,0,0],s)
 if state=='closed':
  sprite_xy(a,tex,(294,215),sourcepoint((486,416),anchor,s),s*1.40,s*.58)
  handle=cut(body,[(0,0),(924,0),(924,362),(600,361),(600,204),(185,205),(170,525),(35,515),(0,327)],'scuttle_fixed_handle');a.sprite(handle,anchor,[0,0,0],s)
 else:a.sprite(under,(300,325),[.55,.025,.23],.00126,R=rz(-18))
 return a.im

def rollcase(state='closed',t=None):
 a=Art();id='canvas_rollcase';body=layer(id,'body',(0,0,1103,1024));anchor=(575,758);s=.00127;cap=layer(id,'end_cap',(1103,53,1536,535));under=layer(id,'end_cap_inside',(1140,543,1536,1015))
 if state=='broken':
  pts=[(993,490),(1003,504),(1009,521),(1004,537),(997,550),(999,565),(1007,580),(1030,592),(1041,610),(1047,628),(1070,639),(1105,631),(1105,470)]
  body,part=fracture(body,pts,'rollcase_torn_end_seam','cloth');a.sprite(part,anchor,[0,0,0],s,R=rz(-24),pivot=sourcepoint((1011,520),anchor,s))
 a.sprite(body,anchor,[0,0,0],s)
 if state=='closed':
  # End cap is a separately drawn isometric circular volume registered to the opening.
  sprite_xy(a,cap,(225,247),sourcepoint((938,706),anchor,s),s*.75,s*1.01)
 else:a.sprite(under,(190,330),[.56,.025,.36],.00102,R=rz(-30))
 return a.im

def render(id,state='closed',t=None):
 return {'weathered_satchel':satchel,'bowed_apothecary_cabinet':cabinet,'curved_spice_drawer':drawer,'burial_coffin':coffin,'tied_grain_sack':sack,'reed_hamper':hamper,'spouted_coal_scuttle':scuttle,'canvas_rollcase':rollcase}[id](state,t)
