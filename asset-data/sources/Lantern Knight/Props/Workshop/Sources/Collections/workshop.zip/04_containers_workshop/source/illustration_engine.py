#!/usr/bin/env python3
"""LANTERN clean-ink mechanisms. Fresh untouched illustration masters + editable
world-space assembly and clipping meshes. Never regenerates animation frames.
This authored art source is separate from the preserved original mechanism pack.
"""
from pathlib import Path
import math,json,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageChops
ROOT=Path(__file__).resolve().parents[1]
W=H=1536; PPM=440.; ROOTPX=np.array([768.,1220.]); ELEV=math.radians(35.2643897)
INK='#231d19'; STONE='#4b4035'; RAW='#c19b66'
CACHE={}; LAYERS={}; MASKS={}
def p(v):
 x,y,z=v
 return tuple(ROOTPX+PPM*np.array([(x-z)/math.sqrt(2),(x+z)*math.sin(ELEV)/math.sqrt(2)-y*math.cos(ELEV)]))
def ry(a):
 a=math.radians(a);return np.array([[math.cos(a),0,-math.sin(a)],[0,1,0],[math.sin(a),0,math.cos(a)]])
def rx(a):
 a=math.radians(a);return np.array([[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]])
def rz(a):
 a=math.radians(a);return np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]])
def master(id):
 if id not in CACHE:CACHE[id]=Image.open(ROOT/'source/masters'/f'{id}.png').convert('RGBA')
 return CACHE[id]
def layer(id,name,bbox):
 key=id+'_'+name
 if key not in LAYERS:
  im=master(id).crop(bbox);LAYERS[key]=im;im.save(ROOT/'layers'/f'{key}.png')
 return LAYERS[key]
def cut(img,pts,id,invert=False):
 """Editable source clipping mesh, preserving all master pixels and alpha."""
 MASKS[id]={'polygon_px':pts,'subtract':invert}
 m=Image.new('L',img.size,255 if invert else 0);ImageDraw.Draw(m).polygon(pts,fill=0 if invert else 255)
 out=img.copy();out.putalpha(ImageChops.multiply(img.getchannel('A'),m));return out
class Art:
 def __init__(self):self.im=Image.new('RGBA',(W,H))
 def poly(self,points,col,stroke=INK,sw=2):
  d=ImageDraw.Draw(self.im);q=[p(v) for v in points];d.polygon(q,fill=col)
  if stroke:d.line(q+[q[0]],fill=stroke,width=sw,joint='curve')
 def line(self,pts,col,sw):ImageDraw.Draw(self.im).line([p(v) for v in pts],fill=col,width=sw,joint='curve')
 def texture(self,img,o,u,v,R=None,pivot=None):
  o=np.array(o,float);u=np.array(u,float);v=np.array(v,float)
  if R is not None:
   pivot=np.array(pivot if pivot is not None else [0,0,0]);o=R@(o-pivot)+pivot;u=R@u;v=R@v
  dst=np.array([p(o),p(o+u*img.width),p(o+v*img.height)]);src=np.array([[0,0],[img.width,0],[0,img.height]],float)
  if abs(np.linalg.det(np.column_stack([dst,np.ones(3)])))<1e-5:return
  M=np.linalg.solve(np.column_stack([dst,np.ones(3)]),src).T
  transformed=img.transform((W,H),Image.Transform.AFFINE,tuple(M.flatten()),Image.Resampling.BICUBIC)
  self.im.alpha_composite(transformed)
 def sprite(self,img,source_anchor,world_anchor,metres_per_pixel,R=None,pivot=None):
  # Already-isometric painted volumes stay in the fixed camera basis.
  right=np.array([1/math.sqrt(2),0,-1/math.sqrt(2)])
  down=np.array([math.sin(ELEV)/math.sqrt(2),-math.cos(ELEV),math.sin(ELEV)/math.sqrt(2)])
  u=right*metres_per_pixel;v=down*metres_per_pixel;o=np.array(world_anchor)-u*source_anchor[0]-v*source_anchor[1]
  self.texture(img,o,u,v,R,pivot)
 def triangle(self,img,uv,verts):
  dst=np.array([p(q) for q in verts]);src=np.array(uv,float)
  lo=np.floor(dst.min(axis=0)).astype(int)-2;hi=np.ceil(dst.max(axis=0)).astype(int)+2
  lo=np.maximum(lo,0);hi=np.minimum(hi,[W,H]);size=tuple(hi-lo)
  if min(size)<=0:return
  dst=dst-lo
  M0=np.column_stack([dst,np.ones(3)])
  if abs(np.linalg.det(M0))<1e-5:return
  M=np.linalg.solve(M0,src).T;tile=img.transform(size,Image.Transform.AFFINE,tuple(M.flatten()),Image.Resampling.BICUBIC)
  mask=Image.new('L',size);ImageDraw.Draw(mask).polygon([tuple(q) for q in dst],fill=255)
  tile.putalpha(ImageChops.multiply(tile.getchannel('A'),mask));self.im.alpha_composite(tile,tuple(lo))
 def revolved(self,img,profile,center=(0,0,0),R=None,pivot=None,axis='y'):
  # Each profile row: source v, source center-u, source radius-u, world axis coordinate, world radius.
  # One painted front master is wrapped onto an actual surface of revolution.
  center=np.array(center);pivot=np.array(pivot if pivot is not None else center)
  theta=np.linspace(-math.pi/4,3*math.pi/4,19)
  quads=[]
  def pt(row,t):
   vv,cu,ru,yy,r=row
   local=np.array([r*math.sin(t),yy,r*math.cos(t)]) if axis=='y' else np.array([yy,r*math.sin(t),r*math.cos(t)])
   world=local+center
   if R is not None:world=R@(world-pivot)+pivot
   return (cu+ru*math.sin(t),vv),world
  for row0,row1 in zip(profile,profile[1:]):
   for t0,t1 in zip(theta,theta[1:]):
    q=[pt(row0,t0),pt(row0,t1),pt(row1,t1),pt(row1,t0)]
    depth=sum(sum(v[1]) for v in q);quads.append((depth,q))
  for _,q in sorted(quads,key=lambda z:z[0]):
   for ids in [(0,1,2),(0,2,3)]:self.triangle(img,[q[i][0] for i in ids],[q[i][1] for i in ids])
 def disc(self,center,r,plane='xz',fill='#58442e',n=32,R=None,pivot=None):
  pts=[];center=np.array(center);pivot=np.array(pivot if pivot is not None else center)
  for i in range(n):
   t=i*math.tau/n;v=np.array([r*math.cos(t),0,r*math.sin(t)]) if plane=='xz' else np.array([0,r*math.cos(t),r*math.sin(t)])
   q=center+v
   if R is not None:q=R@(q-pivot)+pivot
   pts.append(q)
  self.poly(pts,fill,INK,3)
 def front(self,img,x,y,z,w,h,R=None,pivot=None):
  self.texture(img,(x,y+h,z),(w/img.width,0,0),(0,-h/img.height,0),R,pivot)
 def top(self,img,x,y,z,w,depth,R=None,pivot=None):
  self.texture(img,(x,y,z),(w/img.width,0,0),(0,0,depth/img.height),R,pivot)
 def contour_depth(self,contours,x,y,z,w,h,depth,colors=('#40382f','#675947')):
  for outline in contours:
   for a,b in zip(outline,outline[1:]+outline[:1]):
    a=np.array([x+a[0]*w,y+(1-a[1])*h,z]);b=np.array([x+b[0]*w,y+(1-b[1])*h,z]);off=np.array([0,0,-depth])
    color=colors[1] if abs(b[0]-a[0])>abs(b[1]-a[1])*.8 else colors[0]
    self.poly([a,b,b+off,a+off],color,INK,2)
 def pad(self,r=.5,y=.04,depth=.10,n=8):
  pts=[(r*math.cos(math.tau*i/n+math.pi/8),y,r*math.sin(math.tau*i/n+math.pi/8)) for i in range(n)]
  for i in range(n):
   a,b=pts[i],pts[(i+1)%n];self.poly([a,b,(b[0],y-depth,b[2]),(a[0],y-depth,a[2])], '#4e4336' if i%3 else '#6a5840',INK,2)
  self.poly(pts,'#635344',INK,2)

