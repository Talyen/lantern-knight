#!/usr/bin/env python3
"""Self-contained still, animation, comparison and quality-evidence build."""
from build_workshop import *
import shutil,subprocess,platform
from PIL import __version__ as pillow_version
ANIM=['weathered_satchel','burial_coffin','bowed_apothecary_cabinet','curved_spice_drawer']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 for path in ['png','animation','proof','layers','delivery']:(ROOT/path).mkdir(exist_ok=True)
 assets=[];sheet=Image.new('RGB',(1800,4400),'#e2d7c4');d=ImageDraw.Draw(sheet);d.text((40,25),'LANTERN / WORKSHOP 04 / CLEAN INK',font=font(34),fill='#382b20')
 for row,id in enumerate(ORDER):
  item={'id':id,'source_master':f'source/masters/{id}.png','source_prompt':f'source/prompts/{id}.txt','states':{}}
  for col,st in enumerate(['closed','open','broken']):
   im=render(id,st);path=ROOT/'png'/f'{id}_{st}.png';im.save(path);bb=im.getbbox();item['states'][st]={'png':str(path.relative_to(ROOT)),'alpha_bounds_px':bb,'canvas_px':[W,H],'ground_pivot_px':ROOTPX.tolist(),'sha256':sha(path)}
   th=im.crop(bb);th.thumbnail((550,430),Image.Resampling.LANCZOS);x=col*600;y=110+row*530;sheet.paste(comp(th),(x+(600-th.width)//2,y+(430-th.height)//2));d.text((x+20,y+448),id.replace('_',' '),font=font(22),fill='#382b20');d.text((x+20,y+480),st.upper(),font=font(17),fill='#79644b')
  assets.append(item);print('States:',id,flush=True)
 sheet.save(ROOT/'proof/All_Workshop_States.png')
 manifest={'version':'2.0-clean-ink-illustrated','content_status':'candidate_art_not_runtime_integrated','projection':'orthographic','camera':{'elevation_degrees':35.2643897,'azimuth_degrees':45,'world':'right-handed XZ ground / Y up'},'source_density_px_per_m':PPM,'canvas':[W,H],'ground_pivot_px':ROOTPX.tolist(),'assets':assets,'source_method':'Eight NEW built-in imagegen component atlases. No animation frame was independently generated. Masters and alpha are immutable; exported sprites are clipped/registered component assemblies.','projection_caveat':'Body volumes are fixed-view generated isometric illustrations. Their baked perspective, rounded surfaces, lighting and painted recesses are not mathematically calibrated 3D. Moving parts use reproducible source landmarks and world-space projected transforms under the declared orthographic camera; this does not turn the painted body into exact world geometry.','migration_caveats':['Original 1536x1536 canvases, root (768,1220), 440px/m registration and semantic state/clip IDs are retained. Visual silhouettes/extents changed and require collision, sorting and bounds review.','Original SVG procedural surfaces have been replaced by raster illustration masters plus editable Python/JSON clipping/assembly; these are not pure vector assets.','Opening clips remain 24 frames at 24fps, one-shot, reverseable for closing. Preview playback is a ping-pong review loop only.','Damage is static source fragmentation with authored exposed material lips. No destruction physics or gameplay timings are supplied.','Original references are comparison-only and not active runtime art. Original master alpha is never thresholded or recolored.'],'runtime_integration':False}
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
 comparison=Image.new('RGB',(1400,3440),'#e2d7c4');cd=ImageDraw.Draw(comparison);cd.text((35,22),'WORKSHOP 04 / BEFORE → CLEAN INK',font=font(32),fill='#382b20');cd.text((35,66),'Display zoom is for comparison; fixed-root sheets verify actual registration.',font=font(19),fill='#786047')
 for row,id in enumerate(ORDER):
  for col,base in enumerate([ROOT/'source/reference_before',ROOT/'png']):
   im=Image.open(base/f'{id}_closed.png').convert('RGBA');im=im.crop(im.getbbox());im.thumbnail((600,320));x=col*700;y=110+row*410;comparison.paste(comp(im),(x+(700-im.width)//2,y));cd.text((x+20,y+332),('ORIGINAL / ' if col==0 else 'NEW CLEAN INK / ')+id.replace('_',' '),font=font(20),fill='#382b20')
 comparison.save(ROOT/'proof/before_after_contact_sheet.png')
 (ROOT/'source/clipping_meshes.json').write_text(json.dumps(MASKS,indent=2))
 if '--stills-only' in sys.argv:return
 clips=[];qa=[];movieframes=[]
 for id in ANIM:
  out=ROOT/'animation'/id;out.mkdir(exist_ok=True);frames=[];recs=[]
  for i in range(24):
   t=i/23;t=t*t*(3-2*t);im=render(id,t=t);path=out/f'open_{i:03}.png';im.save(path);frames.append(im);recs.append({'file':str(path.relative_to(ROOT)),'source':'source/build_workshop.py','normalized_progress':t,'duration_ms':1000/24,'bounds':im.getbbox(),'root':ROOTPX.tolist(),'sha256':sha(path)})
  allb=[im.getbbox() for im in frames];box=(max(0,min(b[0] for b in allb)-90),max(0,min(b[1] for b in allb)-90),min(W,max(b[2] for b in allb)+90),min(H,max(b[3] for b in allb)+90))
  box=(box[0],box[1],box[2],max(box[3],1260));thumbs=[]
  for im in frames:
   bg=comp(im);dd=ImageDraw.Draw(bg);cx,cy=map(int,ROOTPX);dd.line([(cx-17,cy),(cx+17,cy)],fill='#ae3131',width=3);dd.line([(cx,cy-17),(cx,cy+17)],fill='#ae3131',width=3);th=bg.crop(box);th.thumbnail((520,520));can=Image.new('RGB',(560,570),'#e2d7c4');can.paste(th,((560-th.width)//2,25));ImageDraw.Draw(can).text((15,545),id.replace('_',' '),font=font(19),fill='#382b20');thumbs.append(can)
  loop=[thumbs[0]]*8+thumbs+[thumbs[-1]]*8+thumbs[::-1];loop[0].save(out/'fixed_root_review.gif',save_all=True,append_images=loop[1:],duration=42,loop=0,optimize=False)
  strip=Image.new('RGB',(560*6,610),'#e2d7c4');sd=ImageDraw.Draw(strip)
  for j,i in enumerate([0,4,9,14,19,23]):strip.paste(thumbs[i],(560*j,0));sd.text((560*j+20,576),f'FRAME {i:02} / ROOT 768,1220',font=font(18),fill='#6b5840')
  strip.save(out/'fixed_root_motion_sheet.png');movieframes.append(thumbs)
  closed=np.array(Image.open(ROOT/'png'/f'{id}_closed.png'));opened=np.array(Image.open(ROOT/'png'/f'{id}_open.png'));clipqa={'id':id+'_open','endpoint_0_equals_closed':bool(np.array_equal(np.array(frames[0]),closed)),'endpoint_23_equals_open':bool(np.array_equal(np.array(frames[-1]),opened)),'unique_frames':len(set(r['sha256'] for r in recs)),'fixed_root_all_frames':all(r['root']==[768.,1220.] for r in recs),'all_alpha_bounds_inside_canvas':all(b[0]>0 and b[1]>0 and b[2]<W and b[3]<H for b in allb),'semantic_loop':False,'loop_QA':'Not applicable: original opening is one-shot. GIF/MP4 review uses hold/open/hold/reverse and is not a runtime loop.','preview_fixed_crop':box}
  qa.append(clipqa);clips.append({'id':id+'_open','asset':id,'fps':24,'frame_count':24,'duration_seconds':1,'loop':False,'frames':recs,'reverse':'Play these exact frames in reverse for closing.','proof':str((out/'fixed_root_motion_sheet.png').relative_to(ROOT))});print('Clip:',id,flush=True)
 (ROOT/'animation/clips.json').write_text(json.dumps(clips,indent=2));(ROOT/'proof/qa_report.json').write_text(json.dumps({'clip_checks':qa,'state_count':24,'clip_count':4,'frame_count':96,'all_states_transparent_RGBA':all(Image.open(ROOT/v['png']).mode=='RGBA' for a in assets for v in a['states'].values()),'visual_audit':'Independent review pending; numeric QA does not establish artistic approval.'},indent=2))
 (ROOT/'source/clipping_meshes.json').write_text(json.dumps(MASKS,indent=2));(ROOT/'source/registration.json').write_text(json.dumps({'canvas':[W,H],'root':ROOTPX.tolist(),'density':PPM,'camera_elevation':35.2643897,'camera_azimuth':45,'assembly':'Source landmarks, source crop coordinates, deformation and physical pivots are explicitly editable in build_workshop.py. All crops and fracture polygons in clipping_meshes.json are derived; master pixels/alpha remain intact.','baked_perspective':True},indent=2))
 (ROOT/'source/master_inventory.json').write_text(json.dumps([{'id':id,'file':f'source/masters/{id}.png','sha256':sha(ROOT/'source/masters'/f'{id}.png'),'size':Image.open(ROOT/'source/masters'/f'{id}.png').size,'generator':'built-in image_gen','intent':'NEW generation, no input/edit images','prompt':f'source/prompts/{id}.txt'} for id in ORDER],indent=2))
 # Optional MP4, only if ffmpeg is installed; GIFs and all PNG evidence are always built.
 ffmpeg=shutil.which('ffmpeg')
 if ffmpeg:
  tmp=ROOT/'delivery/_video_frames';tmp.mkdir(exist_ok=True);seq=list(range(24))+[23]*8+list(range(23,-1,-1))+[0]*8
  for n,i in enumerate(seq):
   frame=Image.new('RGB',(1120,1140),'#e2d7c4')
   for j,group in enumerate(movieframes):frame.paste(group[i],((j%2)*560,(j//2)*570))
   frame.save(tmp/f'{n:04}.png')
  subprocess.run([ffmpeg,'-y','-loglevel','error','-framerate','24','-i',str(tmp/'%04d.png'),'-c:v','libx264','-pix_fmt','yuv420p','-crf','20',str(ROOT/'proof/Workshop_Fixed_Root_Openings.mp4')],check=True);shutil.rmtree(tmp)
 print('COMPLETE',flush=True)
if __name__=='__main__':main()
