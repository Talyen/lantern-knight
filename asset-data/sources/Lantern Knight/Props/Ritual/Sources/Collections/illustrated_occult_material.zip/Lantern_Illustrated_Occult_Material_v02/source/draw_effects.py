#!/usr/bin/env python3
"""Original clean-ink vector animation. Hand-shaped gesture paths; no bitmap inputs.
Bezier outlines are sampled only for antialiased rasterization; SVG retains native paths.
"""
from pathlib import Path
import sys,math,json,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]; W,H=640,560; P=(320,386); SS=3
INK='#22262a'; MID='#52595d'; EDGE='#a3b1ab'; PALE='#d3d5be'
def clamp(x):return max(0,min(1,x))
def ease(x): x=clamp(x);return x*x*(3-2*x)
def lerp(a,b,t):return a+(b-a)*t
class Art:
 def __init__(self):self.im=Image.new('RGBA',(W*SS,H*SS));self.svg=[]
 def shape(self,commands,col,opacity=1):
  if opacity<=0:return
  pts=[];cur=None;ss=[]
  for cmd in commands:
   op=cmd[0];v=cmd[1:];ss.append(op+' '.join(f'{n:.3f}' for n in v))
   if op=='M':cur=v;pts.append(cur)
   elif op=='L':cur=v;pts.append(cur)
   elif op=='C':
    a=cur;b=v[:2];c=v[2:4];d=v[4:6]
    for j in range(1,25):
     t=j/24;s=1-t;pts.append(tuple(s**3*a[k]+3*s*s*t*b[k]+3*s*t*t*c[k]+t**3*d[k] for k in range(2)))
    cur=d
  if len(pts)<3:return
  lay=Image.new('RGBA',self.im.size);rgb=tuple(int(col.lstrip('#')[i:i+2],16) for i in (0,2,4))
  ImageDraw.Draw(lay).polygon([(round(x*SS),round(y*SS)) for x,y in pts],fill=rgb+(round(opacity*255),));self.im=Image.alpha_composite(self.im,lay)
  self.svg.append(f'<path d="{" ".join(ss)} Z" fill="{col}" opacity="{opacity:.4f}"/>')
 def poly(self,pts,col):self.shape([('M',*pts[0])]+[('L',*p) for p in pts[1:]],col)
 def cut(self,pts):
  # True alpha removal. The native SVG preserves the same negative-space cut.
  mask=Image.new('L',self.im.size,255);ImageDraw.Draw(mask).polygon([(round(x*SS),round(y*SS)) for x,y in pts],fill=0)
  arr=np.array(self.im);arr[:,:,3]=np.minimum(arr[:,:,3],np.array(mask));self.im=Image.fromarray(arr)
  v=' '.join(f'{x:.3f},{y:.3f}' for x,y in pts);ident='cut_'+__import__('hashlib').sha1((v+'|'+str(len(self.svg))).encode()).hexdigest()[:12];body=''.join(self.svg)
  self.svg=[f'<defs><mask id="{ident}"><rect width="640" height="560" fill="white"/><polygon points="{v}" fill="black"/></mask></defs><g mask="url(#{ident})">{body}</g>']
 def finish(self,folder,i):
  (folder/'frames').mkdir(parents=True,exist_ok=True);(folder/'vectors').mkdir(exist_ok=True)
  im=self.im.resize((W,H),Image.Resampling.LANCZOS);arr=np.array(im);arr[arr[:,:,3]==0,:3]=0;Image.fromarray(arr).save(folder/'frames'/f'{i:03}.png')
  (folder/'vectors'/f'{i:03}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">'+''.join(self.svg)+'</svg>')
def transform(cmds,x,y,sx=1,sy=1,rot=0):
 out=[];co=math.cos(rot);si=math.sin(rot)
 for c in cmds:
  vals=[]
  for j in range(1,len(c),2):
   u=c[j]*sx;v=c[j+1]*sy;vals.extend((x+u*co-v*si,y+u*si+v*co))
  out.append((c[0],*vals))
 return out
# Each whip is an authored directional gesture, not a radial repeated symbol.
GESTURES=[[(-10,6),(48,-2),(111,-88),(177,-172)],[(-20,7),(-78,-29),(-64,-78),(-119,-94)],[(0,6),(43,4),(72,55),(134,32)]]
WIDTHS=[31,21,19]
def bez(c,t):s=1-t;return tuple(s*s*s*c[0][k]+3*s*s*t*c[1][k]+3*s*t*t*c[2][k]+t*t*t*c[3][k] for k in (0,1))
def brush(a,c,width,start,end,col,phase=0):
 if end-start<.015 or width<.15:return
 left=[];right=[]
 for i in range(61):
  u=start+(end-start)*i/60;p=bez(c,u);p0=bez(c,max(0,u-.004));p1=bez(c,min(1,u+.004));dx=p1[0]-p0[0];dy=p1[1]-p0[1];ln=max(1e-3,math.hypot(dx,dy));q=i/60
  w=width*(math.sin(math.pi*q)**.70)*(.45+.75*math.sin(math.pi*u))*(1-.75*u)
  # Deliberate broad belly and nick, no procedural noise.
  w*=1-.42*math.exp(-((u-.66)/.055)**2)
  left.append((p[0]-dy/ln*w,p[1]+dx/ln*w));right.append((p[0]+dy/ln*w*.56,p[1]-dx/ln*w*.56))
 a.poly(left+right[::-1],col)
def ink(a,f):
 if f==0 or f>=35:return
 x,y=P
 if f<5:
  q=f/5
  a.shape(transform([('M',-6,13),('C',-28,-7,-16,-41,8,-57),('C',-5,-27,24,-13,8,12),('C',1,22,-3,20,-6,13)],x,y,.40+.5*q,.45+.5*q),INK)
  return
 u=(f-5)/30;growth=1-math.exp(-u*15);depart=ease((u-.25)/.65);erosion=ease((u-.22)/.78)
 for j,points in enumerate(GESTURES):
  q=clamp(u-j*.008);g=1-math.exp(-q*18);c=[(x+p[0]*(g+.12*depart),y+p[1]*(g+.12*depart)-depart*12) for p in points]
  start=.01+.87*ease((u-.15)/.68);end=1-.04*erosion
  brush(a,c,WIDTHS[j]*(1-erosion*.88),start,end,INK)
  # Broken edge highlight is a selective long glint, not an inner inset.
  if j in (0,1,2):brush(a,[(p[0]-2,p[1]-2) for p in c],WIDTHS[j]*.18*(1-erosion),max(.17,start),min(.83,end),EDGE)
  if u>.28:
   # Tear-off fragments separate as the parent stroke loses its base.
   st=.37+erosion*.29;en=st+.10*(1-erosion)
   off=[(p[0]+(j-2)*depart*11,p[1]+depart*(18-j*8)) for p in c]
   brush(a,off,9*(1-erosion),st,en,MID)
 # A broad torn central ink fold joins gestures only during the rupture phase.
 if u<.43:
  s=growth;tear=ease((u-.15)/.28);cmd=[('M',-46+tear*35,24-tear*28),('C',-74,-10,-59,-57,-92,-70),('L',-57,-61),('L',-65,-86),('C',-36,-71,-12,-71,8,-96),('L',2,-120),('L',25,-106),('L',34,-130),('C',52,-111,114,-135,169,-165),('C',139,-129,101,-79,60,-58),('L',84,-52),('L',47,-37),('L',54,-18),('C',22,-28,37,-5,72,9),('L',98,7),('L',83,18),('C',53,20,51,39,21,40),('L',31,28),('L',-2,35),('C',-22,31,-42,39,-46+tear*35,24-tear*28)]
  if tear>.01:
   # Authored fracture opens into the main force direction, removing the core rather than fading it.
   cmd=[('M',-46+tear*65,24-tear*66),('C',-74+tear*82,-10-tear*67,-59+tear*100,-57-tear*17,-92+tear*113,-70-tear*11)]+cmd[2:]
  a.shape(transform(cmd,x,y,s,s),INK)
  a.shape(transform([('M',-18,5),('C',-16,-9,-1,-27,12,-29),('C',-2,-14,8,-10,10,-4),('C',-4,-8,-9,7,-18,5)],x,y,s,s),MID)
 if .17<u<.43:
  z=ease((u-.17)/.26)
  # Two unequal expanding tears cross the connected mass and leave separate shards.
  for line,widths in [([(-115,43),(-56,13),(-31,-12),(2,-21),(26,-52),(81,-82),(183,-179)],[55,80,58,110,63,120,15]),([(-119,-146),(-53,-61),(-44,-24),(-9,15),(36,69)],[15,80,94,130,50])]:
   left=[];right=[]
   for j,p in enumerate(line):
    prev=line[max(0,j-1)];nxt=line[min(len(line)-1,j+1)];dx=nxt[0]-prev[0];dy=nxt[1]-prev[1];ln=math.hypot(dx,dy);w=widths[j]*z
    left.append((x+p[0]-dy/ln*w*.55,y+p[1]+dx/ln*w*.55));right.append((x+p[0]+dy/ln*w*.45,y+p[1]-dx/ln*w*.45))
   a.cut(left+right[::-1])
 if .32<u<.82:
  e=(u-.32)/.5;ss=math.sin(math.pi*e)
  for dx,dy,ang,sz in [(76,-103,-.6,1),(-81,-39,.7,.65),(100,50,.2,.55)]:
   fleck=[('M',-6,4),('C',-2,-7,2,-12,17,-18),('L',8,-5),('L',3,2)]
   a.shape(transform(fleck,x+dx+e*dx*.55,y+dy+e*dy*.35,ss*sz,ss*sz,ang),MID)
STONE=[('M',-21,-4),('L',-17,-17),('L',-8,-22),('L',4,-20),('L',8,-24),('L',21,-13),('L',19,-5),('L',24,0),('L',16,17),('L',5,20),('L',-1,16),('L',-16,18),('L',-23,7)]
SHADOW=[('M',-22,-2),('L',-12,1),('L',-6,-4),('L',7,2),('L',19,-6),('L',24,0),('L',16,17),('L',5,20),('L',-1,16),('L',-16,18),('L',-23,7)]
DUST=[('M',-43,9),('C',-46,-4,-31,-12,-23,-7),('C',-32,-28,-6,-35,5,-19),('C',13,-31,36,-20,31,-8),('C',47,-12,51,3,42,12),('C',29,2,17,17,7,10),('C',-4,20,-14,6,-26,14),('C',-32,16,-40,13,-43,9)]
def stone(a,f):
 if f==0 or f>=41:return
 x,y=P
 if f<5:
  q=f/5
  a.shape(transform([('M',-11,0),('C',-11,-20,-5,-41,0,-71),('L',5,-39),('L',13,-67),('C',10,-20,8,-9,2,0)],x,y,1,.45+.55*q),PALE);return
 t=(f-5)/36;q=clamp(t*1.5);scatter=1-math.exp(-t*6)
 # Compressed contact drawing: a connected broken rock mass snaps before the arcs open.
 if t<.22:
  burst=1-ease(t/.22)
  a.shape(transform([('M',-38,8),('L',-35,-13),('L',-24,-18),('L',-27,-30),('L',-10,-23),('L',-4,-44),('L',7,-31),('L',27,-34),('L',24,-19),('L',41,-13),('L',33,5),('L',12,13),('L',1,8),('L',-16,15)],x,y,1+scatter*.4,burst),INK)
  a.shape(transform([('M',-23,-12),('L',-13,-15),('L',-6,-29),('L',-1,-10),('L',14,-19),('L',10,-4),('L',26,-7),('L',9,3),('L',2,-3),('L',-12,1)],x,y,1,burst),PALE)
 # Exact fixed-ground ellipse at 35.264 degrees; designed fragments, never a full decal ring.
 for j,(st,en) in enumerate([(8,93),(119,181),(214,301)]):
  r=21+scatter*81;pts=[]
  for k in range(35):
   ang=math.radians(st+(en-st)*k/34);pts.append((x+r*math.cos(ang),y+r*.577350269*math.sin(ang)))
  if t<.66:
   a.poly(pts+[(xx,yy+2.5*(1-t)) for xx,yy in pts[::-1]],'#69665b')
 # Dust in a low expanding ground plane. Separate clouds shear and collapse, never a uniform fade.
 for j,(dx,dy,s) in enumerate([(-61,9,.85),(47,18,1),(0,-14,.60)]):
  life=clamp((t-.04-j*.016)/.78);size=math.sin(math.pi*life)**.75
  if size>0:a.shape(transform(DUST,x+dx*scatter,y+dy*scatter-28*math.sin(math.pi*life),s*size*(.5+scatter),.75*size), '#787b71' if j!=1 else '#a8a590',1)
 # Distinct masonry chunks on individually staged arcs. Centres use fixed orthographic projection.
 for j,(dx,dy,h,s,r) in enumerate([(-108,21,76,.67,-.36),(91,34,64,.86,.30),(-42,-31,105,1.02,-.19),(41,-44,83,.64,.26),(133,-11,44,.36,-.57),(-144,-3,46,.33,.47)]):
  tt=clamp((t-j*.009)/(.66+j*.024));travel=1-(1-tt)**2;lift=4*h*tt*(1-tt);xx=x+dx*travel;yy=y+dy*travel-lift
  erode=1-ease((t-.72)/.28)
  if erode<=0:continue
  rot=r*travel
  a.shape(transform(STONE,xx,yy,s*erode,s*erode,rot),INK)
  a.shape(transform(STONE,xx-1,yy-2,s*.88*erode,s*.84*erode,rot),'#aaa997')
  a.shape(transform(SHADOW,xx,yy,s*.88*erode,s*.84*erode,rot),'#606960')
  # Chipped lip and crossing crack, not triangulation.
  a.poly([(xx-9*s,yy-13*s),(xx-1*s,yy-16*s),(xx+8*s,yy-13*s),(xx-2*s,yy-13*s)],'#dfdac0')
  if s>.6 and erode>.5:a.poly([(xx-7*s,yy-5*s),(xx-2*s,yy-1*s),(xx-4*s,yy+5*s),(xx-1*s,yy+1*s),(xx+5*s,yy+3*s),(xx-1*s,yy-3*s)],INK)

def build(name,fun,n):
 folder=ROOT/name
 for f in range(n):a=Art();fun(a,f);a.finish(folder,f)
 (folder/'timing.json').write_text(json.dumps({'source_fps':30,'preview_fps':60,'frame_count':n,'duration_seconds':n/30,'canvas':[W,H],'pivot':list(P),'alpha':'straight','one_shot':True,'clear_endpoints':True,'camera':'fixed orthographic ground registration 35.264389682754654 elevation / 45 azimuth; illustrated billboard contours; no exact volumetric claim','phases':{'anticipation':[1,4],'contact':[5,7],'breakup':[8,21],'dissipation':[22,n-1]}},indent=2))
 return folder
if __name__=='__main__':
 build('ink_shadow_burst',ink,36);build('stone_crumble',stone,42)
