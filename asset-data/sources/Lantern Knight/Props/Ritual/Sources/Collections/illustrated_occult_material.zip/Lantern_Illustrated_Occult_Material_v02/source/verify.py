#!/usr/bin/env python3
"""Source replay, transparent-edge bounds and seamless-loop checks; no engine claims."""
import json,sys,hashlib
import numpy as np
from PIL import Image
from draw_effects import *
import occult,materials

def pixels(art):
 arr=np.array(art.im.resize((W,H),Image.Resampling.LANCZOS));arr[arr[:,:,3]==0,:3]=0;return arr
rows=[]
for pack,module in [('occult',occult),('materials',materials)]:
 for name,spec in module.SPECS.items():
  fn,n=spec[:2];folder=ROOT/pack/name;m=json.loads((folder/'timing.json').read_text());replays=[]
  for f in [0,n//3,n-2]:
   a=Art();fn(a,f,n);aa=pixels(a);bb=np.array(Image.open(folder/'frames'/f'{f:03}.png'));replays.append({'frame':f,'identical_rgba':bool(np.array_equal(aa,bb))})
  row={'pack':pack,'id':name,'source_replays':replays,'all_replays_pass':all(v['identical_rgba'] for v in replays)}
  if m['loop']:
   a=Art();fn(a,0,n);first=pixels(a);b=Art();fn(b,n,n);closure=pixels(b);prev=np.array(Image.open(folder/'frames'/f'{n-1:03}.png'));second=np.array(Image.open(folder/'frames'/'001.png'))
   row['loop_test']={'mathematical_endpoint_compared_to_first':True,'max_channel_delta':int(np.abs(first.astype(int)-closure.astype(int)).max()),'fraction_pixels_differing':float(np.mean(np.any(first!=closure,axis=2))),'seam_mean_rgba_delta':float(np.abs(first.astype(int)-prev.astype(int)).mean()),'first_step_mean_rgba_delta':float(np.abs(second.astype(int)-first.astype(int)).mean())}
  rows.append(row);print(pack,name,row['all_replays_pass'],row.get('loop_test',{}),flush=True)
(ROOT/'SOURCE_REPLAY_AND_LOOPS.json').write_text(json.dumps(rows,indent=2))
