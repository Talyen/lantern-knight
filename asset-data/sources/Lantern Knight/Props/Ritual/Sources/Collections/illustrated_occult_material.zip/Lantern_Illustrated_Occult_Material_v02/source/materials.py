#!/usr/bin/env python3
from occult import *
WOOD='#977149'; WOODLIGHT='#c3a67b'; WOODSHADE='#574737'

def dust(a,t,amount=1):
 x,y=P
 for j,(dx,dy,s) in enumerate([(-47,5,.65),(35,15,.85),(0,-13,.48)]):
  q=clamp((t-.05-j*.025)/.86);ss=sin(pi*q)**.8*amount
  if ss>0:a.shape(transform(DUST,x+dx*q*1.9,y+dy*q-21*sin(pi*q),s*ss,.55*ss),'#aaa38b')
def trajectory(t,j,dx,dy,h):
 q=clamp((t-.09-j*.012)/(.65+j*.018));g=1-(1-q)**2
 return P[0]+dx*g,P[1]+dy*g-4*h*q*(1-q),q,1-ease((t-.73)/.27)
def wood(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P
 if t<.24:
  q=ease(t/.10)*(1-ease((t-.12)/.12));a.shape(transform([('M',-29,8),('L',-20,-16),('L',-23,-46),('L',-8,-26),('L',0,-60),('L',9,-20),('L',30,-40),('L',20,2),('L',2,13)],x,y,q,q),INK)
 dust(a,t,.48)
 for j,(dx,dy,h,l,w,rot) in enumerate([(-126,23,71,72,11,-.9),(-69,-20,101,100,14,-.5),(56,-30,123,81,13,.6),(135,22,78,96,12,.95),(87,53,35,46,8,1.5),(-32,50,38,38,11,-1.4),(155,-12,40,35,5,.9)]):
  xx,yy,q,s=trajectory(t,j,dx,dy,h)
  if q<=0:continue
  cmd=[('M',-w*.5,9),('L',-w,-l*.15),('L',-w*.55,-l*.77),('L',-w*.22,-l*.63),('L',0,-l),('L',w*.3,-l*.46),('L',w*.7,-l*.63),('L',w,-l*.15),('L',w*.55,0),('L',w*.18,-l*.11)]
  rr=rot*q;a.shape(transform(cmd,xx,yy,s,s,rr),INK);a.shape(transform(cmd,xx,yy-1,s*.72,s*.95,rr),WOOD)
  a.shape(transform([('M',-w*.2,0),('L',-w*.2,-l*.54),('L',0,-l*.91),('L',w*.17,-l*.26),('L',w*.1,-5)],xx,yy,s,s,rr),WOODLIGHT)
  if w>10:a.shape(transform([('M',-w*.35,-l*.13),('C',0,-l*.33,-w*.33,-l*.43,-w*.22,-l*.60),('L',-w*.05,-l*.34)],xx,yy,s,s,rr),WOODSHADE)

def pottery(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P;dust(a,t,.45)
 shell=[('M',-31,-20),('C',-13,-32,17,-28,34,-9),('L',23,-5),('L',24,9),('L',9,5),('L',2,24),('C',-12,17,-25,4,-31,-20)]
 for j,(dx,dy,h,s,rot) in enumerate([(-106,22,77,.8,-.7),(68,30,100,1,.5),(-27,-35,121,.95,-.2),(136,-6,57,.55,.9),(-137,-12,43,.45,-1),(15,57,26,.46,.7)]):
  xx,yy,q,life=trajectory(t,j,dx,dy,h);sc=s*life
  if q<=0:continue
  a.shape(transform(shell,xx,yy,sc,sc,rot*q),INK)
  a.shape(transform(shell,xx,yy-2,sc*.88,sc*.83,rot*q),'#ab8060' if j%2 else '#cdc0a0')
  a.shape(transform([('M',-27,-18),('C',-14,-4,-2,7,10,9),('L',2,21),('C',-12,15,-24,1,-27,-18)],xx,yy,sc,sc,rot*q),'#795b47')
  a.shape(transform([('M',-25,-19),('C',-8,-27,14,-23,29,-10),('L',24,-8),('C',5,-18,-8,-21,-25,-16)],xx,yy,sc,sc,rot*q),'#e1d4b1')
 if .03<t<.2:
  s=sin(pi*(t-.03)/.17);a.shape(transform([('M',-31,4),('C',-21,-22,13,-30,31,-1),('L',15,9),('L',8,-8),('L',-1,4),('L',-12,-10),('L',-17,9)],x,y,s,s),'#bc9470')

def glass(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P
 for j,(dx,dy,h,l,w,rot) in enumerate([(-127,12,85,61,19,-.8),(91,14,99,77,22,.7),(21,-41,118,71,16,.25),(-47,-17,89,48,12,-.4),(138,-18,54,36,13,.8),(-97,44,37,31,11,-1.2),(45,50,39,43,15,1.0)]):
  xx,yy,q,s=trajectory(t,j,dx,dy,h)
  if q<=0:continue
  pts=[(-w*.7,7),(-w,-l*.25),(-w*.2,-l*.50),(-w*.3,-l),(w*.7,-l*.65),(w*.40,-l*.4),(w,-l*.12),(w*.4,-3)]
  cmd=[('M',*pts[0])]+[('L',*p) for p in pts[1:]];rr=rot*q
  a.shape(transform(cmd,xx,yy,s,s,rr),IRON,.60)
  outline=transform(cmd,xx,yy,s,s,rr);ps=[tuple(c[1:]) for c in outline];stroke(a,ps[:4],2.2,LIGHT);stroke(a,ps[4:]+ps[:1],1.4,TEAL)
  a.shape(transform([('M',-w*.4,0),('L',0,-l*.45),('L',w*.4,-l*.50),('L',w*.1,-l*.18)],xx,yy,s,s,rr),LIGHT,.65)
 if .03<t<.16:
  for j in range(3):
   q=j*2.1+.2;stroke(a,[(x+cos(q)*8,y+sin(q)*5),(x+cos(q)*35,y+sin(q)*23)],2,LIGHT)

def metal(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P
 # Broad bruise/dent with folded lip, held briefly rather than flying metal polyhedra.
 if t<.69:
  s=one(t,.10,.51)
  a.shape(transform([('M',-39,8),('C',-50,-10,-26,-29,2,-27),('C',30,-31,50,-9,42,10),('C',22,5,10,20,-9,11),('C',-19,24,-30,9,-39,8)],x,y,s,s),INK)
  a.shape(transform([('M',-31,-3),('C',-16,-21,16,-22,30,-8),('L',12,-9),('L',2,3),('L',-9,-4),('L',-31,-3)],x,y,s,s),IRON)
  a.shape(transform([('M',-35,-3),('C',-23,-29,14,-28,35,-7),('C',10,-22,-16,-18,-35,-3)],x,y,s,s),EDGE)
 # Unequal hot sparks draw along short independent parabolas with no radial symmetry.
 for j,(dx,dy,h) in enumerate([(-154,-12,75),(169,11,62),(110,-21,109),(-81,-19,134),(58,29,43),(-131,39,32)]):
  q=clamp((t-.08-j*.018)/.70)
  if not 0<q<1:continue
  pts=[]
  for k in range(12):
   u=max(0,q-.12+k*.12/11);pts.append((x+dx*u,y+dy*u-4*h*u*(1-u)))
  strip(a,pts,3.8*(1-q),'#bd8d50');strip(a,pts,1.6*(1-q),'#f0d6a0')

def cloth(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P
 # Two differently cut cloth remnants. Bezier folds change as trailing corners lag.
 for j,(dx,dy,h,s,rot) in enumerate([(-106,23,79,1,-.38),(98,6,105,.88,.52),(20,44,50,.46,-.7)]):
  xx,yy,q,life=trajectory(t,j,dx,dy,h)
  if q<=0:continue
  wave=sin(q*tau*1.25+j)*12*q;sc=s*life
  outline=[('M',-35,-34),('C',-12,-44,3,-22,28,-30),('L',21,-18),('L',31,-16),('L',23,-5),('L',32,0),('C',18,11+wave,18,30,1,35),('L',-2,22),('L',-9,35),('L',-14,25),('L',-23,28),('C',-13,9-wave,-38,-10,-35,-34)]
  a.shape(transform(outline,xx,yy,sc,sc,rot*q),INK);a.shape(transform(outline,xx,yy-1,sc*.88,sc*.90,rot*q),'#906247' if j!=1 else '#b5aa8c')
  a.shape(transform([('M',-30,-27),('C',-17,-6,6,-11,6,13),('C',3,24,-4,26,-8,29),('C',-4,6-wave,-31,3,-30,-27)],xx,yy,sc,sc,rot*q),'#574538' if j!=1 else '#776f5a')
  a.shape(transform([('M',-20,-31),('C',-2,-27,9,-14,22,-20),('C',11,-10,-2,-21,-20,-24)],xx,yy,sc,sc,rot*q),'#be956b' if j!=1 else '#d8cdac')
  # A few tapered thread ends emerge from different torn corners, never a fringe field.
  for k in range(2):
   a.shape(transform([('M',-8+k*10,27),('C',-14+k*10,35,-3+k*10,41+wave*.3,-11+k*10,45),('L',-10+k*10,39),('C',-8+k*10,34,-13+k*10,32,-8+k*10,27)],xx,yy,sc,sc,rot*q),INK)

SPECS={'wood_splinter_burst':(wood,42),'stone_crumble':(lambda a,f,n:stone(a,f),42),'pottery_shards':(pottery,42),'glass_chips':(glass,42),'metal_dent_sparks':(metal,36),'cloth_tear_scraps':(cloth,48)}
if __name__=='__main__':
 for name,(fn,n) in SPECS.items():
  print(name,flush=True);folder=ROOT/'materials'/name
  for f in range(n):a=Art();fn(a,f,n);a.finish(folder,f)
  (folder/'timing.json').write_text(json.dumps({'id':name,'family':name,'source_fps':30,'preview_fps':60,'frame_count':n,'duration_seconds':n/30,'loop':False,'canvas':[W,H],'pivot':list(P),'alpha':'straight','camera':'fixed orthographic ground registration; illustrative contours','world_density_px_per_metre':112,'phases':'compression/contact, directional breakup, ballistic fall or fabric drag, clean geometric disappearance'},indent=2))
