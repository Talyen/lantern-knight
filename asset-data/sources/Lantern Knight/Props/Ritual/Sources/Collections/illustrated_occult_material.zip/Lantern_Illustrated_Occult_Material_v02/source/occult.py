#!/usr/bin/env python3
"""Fourteen individually art-directed native vector occult clips, revision 02."""
from draw_effects import *
from math import sin,cos,pi,tau,sqrt

def strip(a,pts,width,col,taper=True):
 L=[];R=[]
 for j,p in enumerate(pts):
  prev=pts[max(0,j-1)];nxt=pts[min(len(pts)-1,j+1)];dx=nxt[0]-prev[0];dy=nxt[1]-prev[1];ln=max(.001,math.hypot(dx,dy));q=j/max(1,len(pts)-1);w=width(q) if callable(width) else width
  if taper:w*=sin(pi*q)**.6
  L.append((p[0]-dy/ln*w/2,p[1]+dx/ln*w/2));R.append((p[0]+dy/ln*w/2,p[1]-dx/ln*w/2))
 a.poly(L+R[::-1],col)
def arc(a,x,y,r,ratio,st,en,w,col):strip(a,[(x+r*cos(st+(en-st)*j/60),y+r*ratio*sin(st+(en-st)*j/60)) for j in range(61)],w,col)
def ellipse(a,x,y,rx,ry,col):
 a.shape([('M',x-rx,y),('C',x-rx,y-ry*.552,x-rx*.552,y-ry,x,y-ry),('C',x+rx*.552,y-ry,x+rx,y-ry*.552,x+rx,y),('C',x+rx,y+ry*.552,x+rx*.552,y+ry,x,y+ry),('C',x-rx*.552,y+ry,x-rx,y+ry*.552,x-rx,y)],col)
def stroke(a,pts,w,col=INK):strip(a,pts,w,col,False)
def one(t,on=.08,off=.7):return ease(t/on)*(1-ease((t-off)/(1-off)))
TEAL='#85a9a4'; LIGHT='#c9d7c2'; BONE='#d1c6a1'; RUST='#987955'; IRON='#5d7476'

def bolt(a,f,n,kind):
 t=f/n;x,y=P;y-=32
 if kind!='flight' and (f==0 or f==n-1):return
 if kind=='launch':
  charge=sin(pi*clamp(t/.5));g=ease((t-.27)/.45);x+=g*117
  # Two compressed sickles gather behind a bright hooked head, then whip forward.
  for s in [-1,1]:
   c=[(x-116*g,y+s*(26+19*charge)),(x-105*g,y-s*33),(x-35,y+s*12),(x+21,y)]
   brush(a,c,12*(1-t),0,1,TEAL)
  size=.25+.75*one(t,.23,.68)
 elif kind=='flight':g=1;size=1;charge=0
 else:
  # Impact is a forward comb of sheared lances and one backward fold, never radial.
  u=clamp((t-.08)/.80);g=1-math.exp(-10*u)
  for j,(dx,dy,w) in enumerate([(112,-98,14),(170,-13,22),(123,62,11),(-66,-39,20)]):
   c=[(x,y),(x+dx*.25,y+dy*.2),(x+dx*.7,y+dy*.7),(x+dx*g,y+dy*g)]
   brush(a,c,w*(1-u),ease((u-.13)/.8)*.8,1,INK);brush(a,c,w*.56*(1-u),ease((u-.13)/.8)*.8,1,LIGHT if j==1 else TEAL)
  if t<.34:
   a.shape(transform([('M',-22,9),('L',-14,-24),('L',3,-12),('L',17,-41),('L',16,-11),('L',38,1),('L',13,12),('L',-4,35),('L',-7,13)],x,y,1-t*2,1-t*2),LIGHT)
  return
 if kind=='flight':
  for j,(dy,w) in enumerate([(-13,17),(19,10)]):
   pts=[]
   for i in range(66):
    q=i/65;pts.append((x-153+q*147,y+dy*(1-q)+sin(q*7-t*tau+j)*9*(1-q)))
   strip(a,pts,lambda q:w*(.3+.7*q),INK);strip(a,[(px,py-2) for px,py in pts],lambda q:w*.48*(.2+.8*q),TEAL)
 head=[('M',-38,5),('C',-20,-4,-17,-24,7,-21),('L',-1,-8),('L',47,-3),('L',22,5),('L',-2,7),('C',-12,20,-26,19,-38,5)]
 a.shape(transform(head,x,y,size,size),INK)
 a.shape(transform([('M',-24,4),('C',-13,-5,-7,-12,2,-13),('L',0,-5),('L',38,-3),('L',-7,4),('L',-17,11)],x,y,size,size),TEAL)
 a.shape(transform([('M',-9,0),('L',39,-3),('L',3,2)],x,y,size,size),LIGHT)

def thorns(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P
 for j,(dx,dy,h,bend) in enumerate([(-54,-15,122,-56),(47,-17,153,42),(-65,21,101,-36),(45,22,118,61),(0,8,207,42)]):
  g=ease((t-.06-j*.025)/.24)*(1-ease((t-.73)/.27));xx=x+dx;yy=y+dy
  if g<=0:continue
  pts=[('M',-16,5),('C',-20,-19,-3,-h*.40,bend*.1,-h*.58),('L',bend*.1-23,-h*.67),('L',bend*.1+1,-h*.66),('C',bend*.3,-h*.80,bend*.62,-h*.92,bend,-h),('C',bend*.88,-h*.86,bend*.43,-h*.66,bend*.44,-h*.54),('L',bend*.44+21,-h*.61),('L',bend*.38+9,-h*.45),('C',bend*.3,-h*.28,21,-20,19,3),('L',4,-1)]
  a.shape(transform(pts,xx,yy,1,g),INK)
  a.shape(transform([('M',-8,-4),('C',-4,-h*.31,bend*.17,-h*.56,bend*.18,-h*.65),('C',bend*.30,-h*.79,bend*.72,-h*.91,bend*.93,-h*.97),('C',bend*.49,-h*.68,bend*.40,-h*.37,6,-2)],xx,yy,1,g),'#707d67')
  a.shape(transform([('M',4,-11),('C',11,-h*.40,bend*.30,-h*.68,bend*.91,-h*.95),('C',bend*.54,-h*.64,11,-h*.31,4,-11)],xx,yy,1,g),'#a8ad85')
  stroke(a,[(xx-27,yy+7),(xx-10,yy-2),(xx+4,yy+6),(xx+25,yy+1)],3,INK)

def ritual(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P;draw=ease(t/.46);erase=ease((t-.70)/.30)
 for j,(r,st,en) in enumerate([(111,.17,1.73),(111,2.02,3.48),(111,3.75,5.95),(88,.5,2.55),(88,3.03,5.65)]):
  end=st+(en-st)*draw;start=st+(en-st)*erase
  if end>start:arc(a,x,y,r,.577,start,end,4 if j<3 else 2,TEAL if j<3 else BONE)
 # Five unequal hand-cut rune stations grounded on the ellipse; no repeated icon motif.
 glyphs=[[(0,-10),(0,8),(8,4),(-6,-3)], [(-6,7),(5,-9),(0,0),(9,5)], [(-7,-7),(6,-7),(0,0),(5,9)], [(-8,5),(0,-10),(7,5),(-4,1)], [(-7,-6),(7,2),(-5,8),(1,-8)]]
 for j,pts in enumerate(glyphs):
  if .12+j*.055<t<.86+j*.02:
   ang=.45+j*tau/5;xx=x+133*cos(ang);yy=y+77*sin(ang);stroke(a,[(xx+u,yy+v*.65) for u,v in pts],2.8,BONE)
 if .31<t<.86:
  g=sin(pi*(t-.31)/.55);a.shape(transform([('M',-19,0),('C',-7,-19,9,-20,22,-1),('C',9,11,-5,15,-19,0)],x,y-8*g,1,g),INK)
  a.shape(transform([('M',-13,0),('C',-6,-10,8,-13,15,-1),('C',5,5,-5,7,-13,0)],x,y-8*g,1,g),LIGHT)
  a.shape(transform([('M',-2,-11),('C',5,-4,5,2,-1,8),('L',-4,0)],x,y-8*g,1,g),INK)

def chain(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P;x-=128;y-=6;g=ease((t-.07)/.34);ret=ease((t-.70)/.30);reach=240*g*(1-ret)
 pts=[];num=max(1,round(reach/22))
 for j in range(num+1):
  q=j/num;xx=x+reach*q;yy=y-60*g*(1-ret)*q+sin(q*pi)*(-24*sin(t*pi*1.8))*g*(1-ret);pts.append((xx,yy))
 for j,(xx,yy) in enumerate(pts):
  if reach<10:continue
  ang=math.atan2(pts[min(num,j+1)][1]-pts[max(0,j-1)][1],max(.01,pts[min(num,j+1)][0]-pts[max(0,j-1)][0]));rx=13;ry=4 if j%2 else 7
  ring=[('M',-rx,0),('C',-rx,-ry,rx,-ry,rx,0),('C',rx,ry,-rx,ry,-rx,0)]
  link=Art();link.shape(transform(ring,xx,yy,1,1,ang),INK)
  hole=[(xx+(rx-3)*cos(k*tau/32)*cos(ang)-(ry-2)*sin(k*tau/32)*sin(ang),yy+(rx-3)*cos(k*tau/32)*sin(ang)+(ry-2)*sin(k*tau/32)*cos(ang)) for k in range(32)]
  link.cut(hole);a.im=Image.alpha_composite(a.im,link.im);a.svg.extend(link.svg)
  # Open links preserve alpha by drawing two opposed bands rather than filling holes.
  arc(a,xx,yy,rx-2,ry/rx,.2,2.7,2.1,IRON);arc(a,xx,yy,rx-2,ry/rx,3.5,5.9,1.5,BONE)
 ex,ey=pts[-1]
 a.shape(transform([('M',-13,-8),('L',5,-9),('L',29,-27),('L',25,-8),('L',44,-2),('L',21,10),('L',4,8),('L',13,1),('L',-13,5)],ex,ey,g,g,-.25),INK)
 a.shape(transform([('M',1,-3),('L',22,-18),('L',18,-5),('L',33,-2),('L',14,4)],ex,ey,g,g,-.25),BONE)

def flame(a,f,n):
 t=f/n;x,y=P;w=sin(t*tau);v=sin(t*tau+1.2)
 outer=[('M',-39,10),('C',-74,-35,-29,-71,-40,-105),('C',-20,-87,-25,-65,-6,-78),('C',12,-99,-14,-129,14+w*14,-172),('C',8+w*6,-134,47,-119,27,-84),('C',43,-82,52,-107,57+v*9,-126),('C',66,-91,36,-65,48,-41),('C',65,-2,12,37,-39,10)]
 a.shape(transform(outer,x,y),INK);a.shape(transform(outer,x+1,y-3,.87,.93),TEAL)
 a.shape(transform([('M',-16,10),('C',-39,-18,4,-49,-6,-81),('C',7,-61,27,-60,13,-40),('C',34,-46,31,-23,24,-12),('C',17,8,-1,21,-16,10)],x,y),LIGHT)
 # Negative flame throat is removed, not painted background color.
 hole=[(x-10,y-8),(x-14+w*3,y-33),(x+5,y-65),(x+2,y-36),(x+14,y-20),(x+4,y-3)];a.cut(hole)

def lightning(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P
 if t<.14:
  arc(a,x+20,y-205,10+10*t/.14,.55,.4,4.8,3,TEAL);return
 pulse=1 if .14<t<.31 else .72 if .39<t<.49 else .42 if .58<t<.65 else 0
 if pulse==0:return
 pts=[(x+29,y-237),(x-6,y-169),(x+22,y-173),(x-25,y-111),(x+3,y-124),(x-27,y-60),(x-5,y-74),(x,y)]
 stroke(a,pts,12*pulse,INK);stroke(a,pts,5*pulse,LIGHT)
 for ps in [[(x-20,y-116),(x-73,y-88),(x-51,y-89),(x-105,y-32)],[(x-8,y-60),(x+45,y-49),(x+33,y-26),(x+103,y+10)],[(x,y),(x-38,y+15),(x-50,y+8),(x-85,y+28)]]:
  stroke(a,ps,5*pulse,TEAL);stroke(a,ps,1.3*pulse,LIGHT)

def ice(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P;g=1-math.exp(-9*t)
 if t<.18:
  a.shape(transform([('M',-28,7),('L',-19,-24),('L',-8,-14),('L',3,-46),('L',10,-17),('L',26,-26),('L',24,3),('L',2,18)],x,y,1,g),LIGHT)
 for j,(dx,dy,h,l,w) in enumerate([(-86,9,60,63,16),(59,20,100,80,20),(108,-12,61,41,12),(-25,-32,119,75,15),(-127,-24,52,38,9)]):
  q=clamp((t-j*.018)/.80);travel=1-(1-q)**2;xx=x+dx*travel;yy=y+dy*travel-4*h*q*(1-q);s=1-ease((t-.62)/.38);rot=dx*.006
  shard=[('M',-w*.45,7),('L',-w*.70,-l*.31),('L',-w*.25,-l*.48),('L',-w*.40,-l*.63),('L',w*.2,-l),('L',w*.55,-l*.37),('L',w,-l*.21),('L',w*.37,0)]
  a.shape(transform(shard,xx,yy,s,s,rot),INK);a.shape(transform(shard,xx,yy-2,s*.72,s*.93,rot),TEAL)
  a.shape(transform([('M',0,0),('L',-w*.1,-l*.59),('L',w*.2,-l*.96),('L',w*.29,-l*.33)],xx,yy-2,s,s,rot),LIGHT)

def leech(a,f,n):
 t=f/n;x,y=P;y-=59
 for j,(w,col,offset) in enumerate([(23,INK,0),(11,TEAL,-2),(3,BONE,-4)]):
  pts=[]
  for i in range(90):
   q=i/89;xx=x-157+314*q;yy=y+sin(q*tau-t*tau)*sin(q*pi)*33+offset;pts.append((xx,yy))
  strip(a,pts,lambda q:w*(.5+.6*sin(q*pi)),col)
 for side in [-1,1]:
  xx=x+side*157;arc(a,xx,y,16,.74,-1.9,1.6,5,INK);arc(a,xx,y,13,.74,-1.7,1.3,2,TEAL)
 # Narrow traveling tear slits prevent a rubber hose read.
 for j in range(3):
  q=(t+j/3)%1;xx=x-157+314*q;yy=y+sin(q*tau-t*tau)*sin(q*pi)*33
  a.shape(transform([('M',-10,0),('C',-4,-3,4,-3,13,0),('L',-4,1)],xx,yy),LIGHT)

def vortex(a,f,n):
 t=f/n;x,y=P
 # Three spatially staggered broken spirals: broad at ground, pinched aloft.
 for level in range(3):
  phase=t*tau+level*1.9;yy=y-level*53;rr=106-level*23
  for side in [0,1]:
   st=phase+side*pi;en=st+2.31
   pts=[(x+rr*cos(st+(en-st)*j/60),yy+rr*.36*sin(st+(en-st)*j/60)-j/60*30) for j in range(61)]
   strip(a,pts,17-level*3,INK);strip(a,[(px,py-2) for px,py in pts],8-level*2,IRON if side else TEAL)
  # One projecting hooked lift per tier, large deliberate gaps between tiers.
  q=(t+level/3)%1;xx=x+rr*.8*cos(q*tau);ey=yy-19
  if q<.7:a.shape(transform([('M',-7,5),('C',-17,-4,-3,-21,8,-27),('C',-5,-9,10,-3,-7,5)],xx,ey,1,1),TEAL)

def poison(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P
 plume=[('M',-34,14),('C',-51,4,-42,-19,-24,-20),('C',-38,-48,-4,-63,10,-41),('C',33,-59,58,-39,43,-15),('C',62,-17,61,7,46,13),('C',29,9,26,31,8,20),('C',-9,32,-15,11,-34,14)]
 for j,(dx,dy,s) in enumerate([(-46,-16,.8),(40,-39,1.05),(-3,-83,.75)]):
  q=clamp((t-j*.05)/.88);g=sin(pi*q)**.66;xx=x+dx*q*1.8;yy=y+dy*q-28*q
  a.shape(transform(plume,xx,yy,g*s,g*s),INK);a.shape(transform(plume,xx-1,yy-3,g*s*.88,g*s*.87),'#7f906b')
  a.shape(transform([('M',-22,-6),('C',-26,-21,-10,-28,0,-21),('C',-1,-39,22,-33,22,-20),('C',37,-26,38,-7,26,-6),('C',16,-16,3,4,-7,-4),('L',-22,-6)],xx,yy,g*s,g*s),'#b1b68a')
  if q>.52:a.cut([(xx-60*g,yy-10),(xx-12*g,yy-21),(xx+8*g,yy-7),(xx+60*g,yy-17),(xx+60*g,yy+50),(xx-60*g,yy+50)])

def ward(a,f,n):
 if f==0 or f==n-1:return
 t=f/(n-1);x,y=P;y-=72
 # Five genuinely separate sections of a pointed shield share the original broken edges.
 parts=[[(-59,-35),(-43,-83),(-8,-94),(-4,-43),(-24,-13)],[(-8,-94),(33,-87),(56,-46),(12,-29),(-4,-43)],[(-59,-35),(-24,-13),(-8,17),(-20,65),(-51,20)],[(12,-29),(56,-46),(56,17),(26,56),(-8,17)],[(-8,17),(26,56),(0,83),(-20,65)]]
 for j,p in enumerate(parts):
  q=ease((t-.26)/.54);dx=[-53,51,-79,68,8][j]*q;dy=[-67,-55,4,18,79][j]*q;erode=1-ease((t-.7)/.30);cx=sum(u for u,v in p)/len(p);cy=sum(v for u,v in p)/len(p)
  p=[(x+cx+(u-cx)*erode+dx,y+cy+(v-cy)*erode+dy) for u,v in p];a.poly(p,INK)
  a.poly([(lerp(px,x+cx+dx,.07),lerp(py,y+cy+dy,.07)) for px,py in p],IRON)
  stroke(a,p[:3],2.5,BONE)
 if t<.27:
  stroke(a,[(x-8,y-93),(x-4,y-43),(x+12,y-29),(x-8,y+17),(x,y+81)],2+8*ease(t/.27),LIGHT)

SPECS={
 'spectral_bolt_launch':(lambda a,f,n:bolt(a,f,n,'launch'),30,False,'spectral_bolt'),
 'spectral_bolt_flight':(lambda a,f,n:bolt(a,f,n,'flight'),36,True,'spectral_bolt'),
 'spectral_bolt_impact':(lambda a,f,n:bolt(a,f,n,'impact'),30,False,'spectral_bolt'),
 'thorn_eruption':(thorns,42,False,'thorn_eruption'),
 'ink_shadow_burst':(lambda a,f,n:ink(a,f),36,False,'ink_shadow_burst'),
 'ritual_circle_activation':(ritual,48,False,'ritual_circle_activation'),
 'cursed_chain_strike':(chain,42,False,'cursed_chain_strike'),
 'pale_ghost_flame':(flame,48,True,'pale_ghost_flame'),
 'lightning_fork':(lightning,30,False,'lightning_fork'),
 'cold_shard_burst':(ice,42,False,'cold_shard_burst'),
 'soul_leech_ribbon':(leech,48,True,'soul_leech_ribbon'),
 'summoning_vortex':(vortex,60,True,'summoning_vortex'),
 'poison_mist_puff':(poison,48,False,'poison_mist_puff'),
 'ward_break':(ward,36,False,'ward_break')}
if __name__=='__main__':
 for name,(fn,n,loop,family) in SPECS.items():
  print(name,flush=True);folder=ROOT/'occult'/name
  for f in range(n):a=Art();fn(a,f,n);a.finish(folder,f)
  (folder/'timing.json').write_text(json.dumps({'id':name,'family':family,'source_fps':30,'preview_fps':60,'frame_count':n,'duration_seconds':n/30,'loop':loop,'canvas':[W,H],'pivot':list(P),'alpha':'straight','camera':'fixed orthographic ground registration; deliberately illustrated world-anchored contours / no 3D volume claim','world_density_px_per_metre':112,'preview_interpolation':'none; each source drawing repeats twice'},indent=2))
