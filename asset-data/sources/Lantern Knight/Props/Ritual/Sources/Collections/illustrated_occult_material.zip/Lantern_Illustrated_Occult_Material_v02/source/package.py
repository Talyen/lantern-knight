#!/usr/bin/env python3
"""Package native drawings without resampling asset frames; review-only compositing."""
from pathlib import Path
import json,math,subprocess,hashlib
from PIL import Image,ImageDraw,ImageFont
import numpy as np
R=Path(__file__).resolve().parents[1]
FT=lambda n:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',n)
def package(pack):
 root=R/pack;review=root/'review';review.mkdir(exist_ok=True);allclips=[];qa=[];panels=[]
 for folder in sorted(p for p in root.iterdir() if p.is_dir() and (p/'timing.json').exists()):
  m=json.loads((folder/'timing.json').read_text());files=sorted((folder/'frames').glob('*.png'));ims=[Image.open(p).convert('RGBA') for p in files];boxes=[im.getbbox() for im in ims if im.getbbox()];box=(min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes));w=box[2]-box[0];h=box[3]-box[1];tw=w+12;th=h+12;cols=max(1,2048//tw);rows=max(1,2048//th);cap=cols*rows;atlasdir=folder/'atlases';atlasdir.mkdir(exist_ok=True);frameinfo=[]
  for page in range(math.ceil(len(ims)/cap)):
   count=min(cap,len(ims)-page*cap);nc=min(cols,count);nr=math.ceil(count/cols);atlas=Image.new('RGBA',(nc*tw,nr*th))
   for local in range(count):
    idx=page*cap+local;im=ims[idx].crop(box);xx=(local%cols)*tw+6;yy=(local//cols)*th+6;atlas.paste(im,(xx,yy));atlas.paste(im.crop((0,0,w,1)).resize((w,2)),(xx,yy-2));atlas.paste(im.crop((0,h-1,w,h)).resize((w,2)),(xx,yy+h));atlas.paste(im.crop((0,0,1,h)).resize((2,h)),(xx-2,yy));atlas.paste(im.crop((w-1,0,w,h)).resize((2,h)),(xx+w,yy));frameinfo.append({'frame':idx,'atlas':f'atlases/{page:02}.png','rect':[xx,yy,w,h],'source_rect':list(box),'pivot_in_rect':[m['pivot'][0]-box[0],m['pivot'][1]-box[1]],'duration_seconds':1/30})
   atlas.save(atlasdir/f'{page:02}.png',optimize=True)
  m['frames']=frameinfo;m['atlas']={'gutter_px':6,'extrusion_px':2,'max_size':2048,'sampler':'clamp; disable mipmaps or use per-sprite mip generation; two extruded edge pixels plus four transparent gutter pixels','rotation':False,'trim':'one union crop shared across all frames; original canvas and pivot retained'}
  (folder/'manifest.json').write_text(json.dumps(m,indent=2));allclips.append({k:v for k,v in m.items() if k!='frames'})
  # Six representative source drawings; true timing labels, clear endpoints intentionally omitted.
  n=len(ims);keys=[max(1,round(n*q)) for q in [.07,.17,.29,.44,.66,.87]];board=Image.new('RGB',(1440,590),'#d8d5c8');d=ImageDraw.Draw(board);d.text((22,14),folder.name.replace('_',' ').upper(),font=FT(24),fill='#20292b');d.text((22,48),f'{n} source drawings / 30 fps / {n/30:.3f} seconds / '+('seamless periodic loop' if m['loop'] else 'one-shot'),font=FT(17),fill='#555d5b')
  for j,k in enumerate(keys):
   crop=ims[k].copy();crop.thumbnail((235,360),Image.Resampling.LANCZOS);board.paste(crop,(j*240+(240-crop.width)//2,104),crop);d.text((j*240+13,80),f'{k:03} | {k/30:.3f}s',font=FT(16),fill='#20292b')
   dark=Image.new('RGB',(240,170),'#263035');tile=ims[k].crop(box);tile.thumbnail((222,148),Image.Resampling.LANCZOS);dark.paste(tile,((240-tile.width)//2,(170-tile.height)//2),tile);board.paste(dark,(j*240,420))
  board.save(review/f'{folder.name}_phases.jpg',quality=95);panels.append(board)
  # Dark/light review at exact source scale; no optical-flow invented frames.
  tmp=folder/'_preview';tmp.mkdir(exist_ok=True)
  for i,im in enumerate(ims):
   bg=Image.new('RGB',(1280,620),'#d8d5c8');d=ImageDraw.Draw(bg);d.rectangle((640,0,1280,620),fill='#263035');bg.paste(im,(0,45),im);bg.paste(im,(640,45),im);d.text((18,12),folder.name.replace('_',' ')+' / source '+str(i),font=FT(19),fill='#525951');d.text((656,12),'30 fps source / 60 Hz held-frame preview',font=FT(18),fill='#d8d5c8');bg.save(tmp/f'{i:03}.jpg',quality=92)
  subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-i',str(tmp/'%03d.jpg'),'-vf','fps=60','-c:v','libx264','-crf','19','-pix_fmt','yuv420p',str(review/f'{folder.name}_60hz.mp4')],check=True)
  for p in tmp.glob('*'):p.unlink()
  tmp.rmdir()
  qa.append({'id':folder.name,'frame_count':n,'canvas':list(ims[0].size),'content_bounds':box,'edge_safe':all(box[k]>0 if k<2 else box[k]<ims[0].size[k-2] for k in range(4)),'clear_first':ims[0].getbbox() is None,'clear_last':ims[-1].getbbox() is None,'loop':m['loop'],'unique_images':len({hashlib.sha256(im.tobytes()).hexdigest() for im in ims})})
 overview=Image.new('RGB',(1440,210*len(panels)),'#d8d5c8')
 for i,panel in enumerate(panels):panel=panel.resize((512,210),Image.Resampling.LANCZOS);overview.paste(panel,(0,i*210));d=ImageDraw.Draw(overview);d.text((550,i*210+60),allclips[i]['id'].replace('_',' '),font=FT(27),fill='#263035')
 overview.save(review/'overview.jpg',quality=94)
 (root/'manifest.json').write_text(json.dumps({'schema':'lantern.revision02.illustrated-effects','pack':pack,'clip_count':len(allclips),'source_fps':30,'preview_fps':60,'source_native':'deterministic authored vector paths, editable per-frame SVG; PNGs are direct 3x antialiased renders','camera':{'elevation':35.264389682754654,'azimuth':45,'registration':'fixed; effect roots and ground ellipses registered; contour artwork is art-directed, not a true volumetric renderer'},'clips':allclips},indent=2));(root/'qa_report.json').write_text(json.dumps(qa,indent=2))
 (root/'README.txt').write_text('LANTERN / REVISION 02 / '+pack.upper()+'\n\nOriginal native-vector illustration and animation. Full-canvas transparent straight-alpha PNGs, editable SVG frames, stable union-cropped atlases and per-frame timing/pivots. Original versions preserved separately.\n\nImport: use 30 fps; review movies repeat each drawing twice at 60 Hz without interpolation. Alpha blend normal. Fixed pivot (320,386) in source canvas 640x560. Union atlas crop does not change registration. Atlas padding is six pixels: two edge-extrusion pixels and four transparent gutter pixels. Disable generic atlas mipmaps or generate per-sprite mip chains. No engine integration is claimed.\n\nCamera limitation: ground ellipses are registered to 35.264389682754654-degree elevation and 45-degree azimuth; contour effects and material fragments are authored illustrative billboards rather than volumetric meshes. Do not use as arbitrary-angle 3D assets.\n\nSources are in ../source. All paths are authored; no bitmap repainting or image-generation frame cascades.\n')
 print(pack,'packaged',len(allclips),flush=True)
if __name__=='__main__':
 import sys
 for p in sys.argv[1:]:package(p)
