#!/usr/bin/env python3
"""New illustrated container components, world-space lids and controlled source clipping.
All original generated masters remain untouched. No frame-level regeneration."""
from illustration_engine import *
from font_support import get_font
import illustration_engine as eng
from PIL import ImageDraw

# Source calibration corners: rear-left, rear-right, front-right, front-left.
BOXES={
 'pilgrim_chest':dict(body=(0,0,1035,887),q=[(330,90),(978,395),(712,550),(62,248)],size=(1.30,.74,.60),lid=(1009,27,1763,386),cap=(1116,450,1654,856),rise=.22,type='dome',isolate=[(0,70),(350,65),(1035,390),(1035,887),(0,887)]),
 'shrine_reliquary':dict(body=(0,0,940,1024),q=[(318,259),(884,560),(619,742),(63,394)],size=(1.30,.71,.50),lid=(817,47,1509,433),cap=(997,679,1482,915),rise=.36,type='gable',isolate=[(0,385),(315,239),(940,551),(940,1024),(0,1024)]),
 'masons_tool_chest':dict(body=(0,0,922,887),q=[(207,77),(866,397),(690,542),(57,204)],size=(1.52,.64,.44),lid=(936,369,1759,676),rise=.035,type='flat'),
 'shipping_crate':dict(body=(0,0,1015,887),q=[(548,24),(958,183),(446,349),(104,154)],size=(.89,.86,.85),lid=(1090,126,1731,762),rise=.045,type='flat'),
 'provision_hopper':dict(body=(0,0,902,1024),q=[(475,30),(846,213),(433,421),(73,204)],size=(.88,.68,.94),lid=(959,225,1508,854),rise=.045,type='flat'),
 'iron_lockbox':dict(body=(0,0,1065,816),q=[(725,35),(74,203),(282,420),(1007,225)],size=(.89,.58,.51),lid=(1100,176,1916,694),rise=.045,type='flat'),
}
ASSET_ORDER=['pilgrim_chest','cooper_barrel','reliquary_urn','shrine_reliquary','masons_tool_chest','shipping_crate','provision_hopper','iron_lockbox']

def registered(a,img,source,world):
 """Four rim anchors rectify the baked view into the exact world-projected aperture."""
 dst=np.array([p(v) for v in world]);src=np.array(source,float);A=[];b=[]
 for (x,y),(u,v) in zip(dst,src):
  A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
 c=np.linalg.solve(np.array(A,float),np.array(b,float))
 out=img.transform((W,H),Image.Transform.PERSPECTIVE,tuple(c),Image.Resampling.BICUBIC)
 a.im.alpha_composite(out)

BOTTOM={
 'pilgrim_chest':[(56,529),(717,850),(1000,704)],
 'shrine_reliquary':[(49,628),(615,965),(904,790)],
 'masons_tool_chest':[(49,399),(694,755),(890,583)],
 'shipping_crate':[(76,603),(452,872),(977,658)],
 'provision_hopper':[(97,760),(447,969),(822,786)],
 'iron_lockbox':[(1028,591),(291,781),(41,561)],
}
def paintbody(a,img,id,walls_only=False,Rt=None,pivot=None):
 # Real orthogonal face meshes preserve verticals. Source art supplies all material design.
 c=BOXES[id];w,d,h=c['size'];B,R,F,L=c['q'];Lb,Fb,Rb=BOTTOM[id]
 BL=(-w/2,h,-d/2);BR=(w/2,h,-d/2);FR=(w/2,h,d/2);FL=(-w/2,h,d/2)
 wb=w*.78 if id=='provision_hopper' else w;db=d*.78 if id=='provision_hopper' else d
 def quad(uv,vv):
  if Rt is not None:
   pv=np.array(pivot);vv=[Rt@(np.array(v)-pv)+pv for v in vv]
  for ids in [(0,1,2),(0,2,3)]:a.triangle(img,[uv[i] for i in ids],[vv[i] for i in ids])
 if not walls_only:quad([B,R,F,L],[BL,BR,FR,FL])
 quad([F,R,Rb,Fb],[FR,BR,(wb/2,.025,-db/2),(wb/2,.025,db/2)])
 quad([L,F,Fb,Lb],[FL,FR,(wb/2,.025,db/2),(-wb/2,.025,db/2)])

def fracture(img,poly,name,material='wood'):
 part=cut(img,poly,name+'_fragment');main=cut(img,poly,name+'_missing',True)
 # Authored raw material cut-face strokes in a derived layer, never sampled edge stretching.
 lip=Image.new('RGBA',img.size);d=ImageDraw.Draw(lip);col={'wood':'#c49a61','iron':'#93877a','ceramic':'#e5d7b9'}[material]
 d.line(poly,fill=col,width=13 if material=='ceramic' else 8,joint='curve');d.line(poly,fill='#312419',width=3,joint='curve')
 lip.putalpha(ImageChops.multiply(lip.getchannel('A'),img.getchannel('A')));main.alpha_composite(lip)
 return main,part

def lid_tex(id,under=False):
 if not under:return layer(id,'lid',BOXES[id]['lid'])
 # Fresh authored material-specific undersides, separate from the exterior illustration.
 bbox=(20,145,705,563) if id not in ['shrine_reliquary','iron_lockbox'] else (745,145,1430,563) if id=='shrine_reliquary' else (1465,145,2165,563)
 return layer('lid_undersides',id+'_inside',bbox)

def lid(a,id,state,t):
 c=BOXES[id];w,d,h=c['size'];rise=c['rise'];kind=c['type'];angle=94*t;R=rx(-angle);pivot=np.array([0,h,-d/2]);tex=lid_tex(id);under=lid_tex(id,True)
 if state=='broken' and id not in ['masons_tool_chest','iron_lockbox']:
  tw,th=tex.size;poly=[(tw*.61,0),(tw*.67,th*.16),(tw*.61,th*.31),(tw*.72,th*.43),(tw*.69,th*.56),(tw*.76,th*.72),(tw*.73,th),(tw,th),(tw,0)]
  tex,piece=fracture(tex,poly,id+'_lid_damage','iron' if id=='iron_lockbox' else 'wood');a.top(piece,-.42,.045,.22,w*.50,d*.75,R=ry(26))
 # Material underside on the actual chord plane is independently authored.
 a.top(under,-w/2,h-.016,-d/2,w,d,R=R,pivot=pivot)
 def at(u,v):
  yy=h+(rise*math.sin(math.pi*v) if kind=='dome' else rise*(1-abs(2*v-1)) if kind=='gable' else rise)
  q=np.array([(u-.5)*w,yy,(v-.5)*d]);return R@(q-pivot)+pivot
 # Top facing switches naturally to the separately painted underside as the lid swings.
 steps=24 if kind=='dome' else 2 if kind=='gable' else 1
 for v0,v1 in zip(np.linspace(0,1,steps+1)[:-1],np.linspace(0,1,steps+1)[1:]):
  verts=[at(0,v0),at(1,v0),at(1,v1),at(0,v1)];normal=np.cross(verts[1]-verts[0],verts[3]-verts[0]);view=np.array([1,1,1])
  # winding top is negative: source outer face visible when its normal faces the camera.
  if np.dot(-normal,view)<=0:continue
  uv=[(0,v0*tex.height),(tex.width,v0*tex.height),(tex.width,v1*tex.height),(0,v1*tex.height)]
  for ids in [(0,1,2),(0,2,3)]:a.triangle(tex,[uv[i] for i in ids],[verts[i] for i in ids])
 # Thin clean lid edge faces give thickness without replacing illustrated top artwork.
 corners=[np.array([-w/2,h,-d/2]),np.array([w/2,h,-d/2]),np.array([w/2,h,d/2]),np.array([-w/2,h,d/2])]
 for i in [1,2]:
  p0,p1=corners[i],corners[(i+1)%4];pts=[p0,p1,p1+np.array([0,.026,0]),p0+np.array([0,.026,0])]
  a.poly([R@(q-pivot)+pivot for q in pts],'#55402e' if id!='iron_lockbox' else '#655036',INK,2)
 if kind in ['dome','gable']:
  cap=layer(id,'lid_end',c['cap']);a.texture(cap,(w/2,h+rise,-d/2),(0,0,d/cap.width),(0,-rise/cap.height,0),R,pivot)
 return R,pivot

def box_asset(id,state='closed',t=None):
 a=Art();c=BOXES[id];w,d,h=c['size'];body=layer(id,'body',c['body'])
 if 'isolate' in c:body=cut(body,c['isolate'],id+'_atlas_isolation')
 q=c['q'];world=[(-w/2,h,-d/2),(w/2,h,-d/2),(w/2,h,d/2),(-w/2,h,d/2)]
 if state=='broken':
  # Fracture follows the individual visible front wall, not a generic triangular punchout.
  B,R,F,L=[np.array(x,float) for x in q];height=max(110,body.height-F[1]-35)
  def fp(u,v):return tuple((L+(F-L)*u+np.array([0,height*v])).tolist())
  damage={
   'pilgrim_chest':[(.24,.48),(.32,.45),(.38,.50),(.48,.44),(.54,.49),(.68,.47),(.66,.79),(.57,.75),(.54,.81),(.43,.76),(.40,.82),(.32,.78),(.25,.80)],
   'shrine_reliquary':[(.67,.12),(.75,.08),(.87,.13),(.95,.24),(.93,.33),(.88,.42),(.90,.54),(.83,.62),(.74,.60),(.66,.50),(.63,.37),(.62,.24)],
   'masons_tool_chest':[(.02,0),(.38,0),(.34,.16),(.32,.20),(.25,.18),(.27,.31),(.18,.27),(.16,.40),(.09,.36),(.02,.55)],
   'shipping_crate':[(.40,.45),(.55,.50),(.48,.62),(.68,.60),(.73,.89),(.43,.95),(.29,.81),(.33,.68),(.23,.60)],
   'provision_hopper':[(.55,.05),(.91,.06),(.90,.18),(.84,.16),(.86,.26),(.78,.25),(.72,.36),(.62,.31),(.58,.21)],
   'iron_lockbox':[(.80,.09),(.96,0),(1.02,0),(1.02,.98),(.86,.90),(.86,.63),(.80,.44),(.84,.28)],
  }
  poly=[fp(*q) for q in damage[id]]
  material='iron' if id=='iron_lockbox' else 'ceramic' if id=='shrine_reliquary' else 'wood'
  broken,part=fracture(body,poly,id+'_body_damage',material)
  shade=Image.new('RGBA',body.size);ImageDraw.Draw(shade).polygon(poly,fill='#241d16');paintbody(a,shade,id);body=broken
  if id!='iron_lockbox':a.top(part,-.44,.05,.24,w*.53,d*.70,R=ry(-19))
 paintbody(a,body,id)
 val=(0 if state=='closed' else 1 if state=='open' else .66) if t is None else t
 lid(a,id,state,val)
 # Front shell occludes the hinge/lid when their world depth takes them behind the rim.
 if val>.48:
  B,R,F,L=[tuple(z) for z in q];shellpoly=[L,F,R,(body.width,body.height),(0,body.height)]
  paintbody(a,body,id,walls_only=True)
 if state=='broken' and id=='iron_lockbox':paintbody(a,part,id,Rt=ry(-52),pivot=[w/2-.04,.25,d/2])
 return a.im

def barrel(state='closed',t=None):
 a=Art();id='cooper_barrel';body=layer(id,'body',(44,0,825,1024));top=layer(id,'lid',(848,294,1472,907));anchor=(436-44,956);scale=.00096
 if state=='broken':
  poly=[(239,353),(270,377),(253,454),(290,440),(274,551),(302,573),(300,677),(329,665),(324,1005),(474,1005),(457,841),(475,800),(450,665),(471,609),(444,472),(470,408),(448,340)]
  shade=Image.new('RGBA',body.size);ImageDraw.Draw(shade).polygon(poly,fill='#271d14');a.sprite(shade,anchor,[0,0,0],scale)
  body,frag=fracture(body,poly,'barrel_split_staves');a.top(frag,-.24,.04,.26,.40,.49,R=ry(36))
 a.sprite(body,anchor,[0,0,0],scale)
 if state=='closed':a.top(top,-.298,.943,-.298,.596,.596)
 else:a.top(top,.40,.035,-.42,.596,.596,R=ry(-11))
 return a.im

def urn(state='closed',t=None):
 a=Art();id='reliquary_urn';body=layer(id,'body',(63,0,904,1024));cap=layer(id,'lid',(958,510,1488,923));anchor=(474-63,949)
 if state=='broken':
  poly=[(159,509),(197,489),(246,506),(283,551),(301,580),(289,619),(321,650),(332,699),(303,736),(283,778),(241,801),(203,781),(172,747),(147,701),(154,658),(137,614),(145,555)]
  shade=Image.new('RGBA',body.size);ImageDraw.Draw(shade).polygon(poly,fill='#383027');shade.putalpha(ImageChops.multiply(shade.getchannel('A'),body.getchannel('A')));a.sprite(shade,anchor,[0,0,0],.00095)
  body,frag=fracture(body,poly,'urn_ceramic_shatter','ceramic');a.top(frag,-.25,.037,.24,.35,.48,R=ry(24))
 a.sprite(body,anchor,[0,0,0],.00095)
 a.sprite(cap,(1218-958,803-510),[0,.956,0] if state=='closed' else [.57,.035,.16],.000867)
 return a.im

def render(id,state='closed',t=None):return barrel(state,t) if id=='cooper_barrel' else urn(state,t) if id=='reliquary_urn' else box_asset(id,state,t)
def font(n):return get_font(n)
def comp(im,bg='#d9cfbf'):
 out=Image.new('RGBA',im.size,bg);out.alpha_composite(im);return out.convert('RGB')
def main():
 rows=[];sheet=Image.new('RGB',(1560,3650),'#ded6c8');d=ImageDraw.Draw(sheet);d.text((35,25),'LANTERN / CONTAINERS 01 / CLEAN INK',font=font(34),fill='#382b20');d.text((35,80),'Fresh illustrated volumes and material-specific lids / registered opening geometry',font=font(21),fill='#735e47')
 for row,id in enumerate(ASSET_ORDER):
  rec={'id':id,'states':{},'source_master':f'source/masters/{id}.png'}
  for col,state in enumerate(['closed','open','broken']):
   im=render(id,state);path=ROOT/'png'/f'{id}_{state}.png';im.save(path);b=im.getbbox();rec['states'][state]={'png':str(path.relative_to(ROOT)),'alpha_bounds_px':b,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'canvas_px':[W,H],'ground_pivot_px':ROOTPX.tolist()}
   th=im.crop(b);th.thumbnail((470,330),Image.Resampling.LANCZOS);x=col*520;y=140+row*438;bg='#d2c6b3' if (row+col)%2 else '#d9cebd';d.rectangle((x+10,y,x+510,y+424),fill=bg);sheet.paste(comp(th,bg),(x+(520-th.width)//2,y+18+(330-th.height)//2));d.text((x+25,y+361),id.replace('_',' ').title(),font=font(22),fill='#382b20');d.text((x+25,y+398),state.upper(),font=font(15),fill='#7b654d')
  rows.append(rec);print('Stills:',id,flush=True)
 sheet.save(ROOT/'proof/All_Container_States.png');manifest={'version':'2.0-clean-ink-candidate','content_status':'pending_visual_audit','canvas':[W,H],'ground_pivot_px':ROOTPX.tolist(),'source_density_px_per_m':PPM,'camera':{'projection':'orthographic','elevation_degrees':35.2643897,'azimuth_degrees':45},'assets':rows,'caveats':['Generated body volumes are fixed-view illustrations. The illustrated body walls and rim are mapped onto controlled world-space face meshes; painted interior recess details remain artistic, not fully calibrated 3D surface data.','Source-baked lighting is not runtime-relightable.','Colliders and engine bounds require review.']};(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2));(ROOT/'source/clipping_meshes.json').write_text(json.dumps(MASKS,indent=2));(ROOT/'source/registration.json').write_text(json.dumps(BOXES,indent=2))
 if '--stills-only' in sys.argv:return
 clips=[]
 for id in ['pilgrim_chest','shrine_reliquary','iron_lockbox']:
  out=ROOT/'animation'/id;out.mkdir(exist_ok=True);frames=[];recs=[]
  for i in range(24):
   t=i/23;t=t*t*(3-2*t);im=render(id,t=t);path=out/f'open_{i:03}.png';im.save(path);frames.append(comp(im).resize((640,640),Image.Resampling.LANCZOS));recs.append({'file':str(path.relative_to(ROOT)),'normalized_progress':t,'duration_ms':1000/24,'root':ROOTPX.tolist(),'bounds':im.getbbox(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
  seq=[frames[0]]*8+frames+[frames[-1]]*10+frames[::-1];seq[0].save(out/'review.gif',save_all=True,append_images=seq[1:],duration=60,loop=0,optimize=False);clips.append({'id':id+'_open','asset':id,'fps':24,'duration_seconds':1,'loop':False,'frame_count':24,'source':'source/build_containers.py','frames':recs});print('Clip:',id,flush=True)
 (ROOT/'animation/clips.json').write_text(json.dumps(clips,indent=2))
if __name__=='__main__':main()
