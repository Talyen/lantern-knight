"""Portable fonts for review labels only; never changes source artwork.
Set LANTERN_FONT_PATH to a TrueType/OpenType font file, or 'default' to use
Pillow's bundled font. Without an override, prefer installed DejaVu Sans.
"""
import os
from PIL import ImageFont

def get_font(size, bold=False):
    override = os.environ.get("LANTERN_FONT_PATH", "").strip()
    if override.lower() in {"default", "pillow"}:
        return _default(size)
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    candidates = ([os.path.expanduser(override)] if override else []) + [
        name, "/usr/share/fonts/truetype/dejavu/" + name,
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial Bold.ttf" if bold else "/Library/Fonts/Arial.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except (OSError, ValueError):
            pass
    return _default(size)

def _default(size):
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        # Compatibility with older Pillow. Pillow >=10.1 keeps requested sizing.
        return ImageFont.load_default()
