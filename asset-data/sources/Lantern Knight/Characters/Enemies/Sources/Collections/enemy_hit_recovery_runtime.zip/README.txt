LANTERN — MONK + CRAWLER HIT / RECOVERY — TEST v01
7 October 2026. Two new one-shot animation clips, six unique native drawings each.

PLAYBACK
Monk: 38 ticks / 0.633333 seconds at 60 Hz. Holds 3,4,8,6,7,10.
Crawler: 38 ticks / 0.633333 seconds at 60 Hz. Holds 3,5,8,5,7,10.
Both clips are non-looping. Return to the existing move/ready state after tick 38.
60 Hz is exposure timing, not 60 unique drawings. No interpolated pixels.
Videos show existing move pose, hit clip, return to existing move pose, repeated three times. Each video is 276 frames / 4.6 seconds at 60 fps. The surrounding holds are review-only, not part of the runtime animation.

IMPORT
Monk: 640x576 cells, fixed pivot top-left (320,500), bottom-left normalized (0.5,0.1319444444).
Crawler: 768x768 cells, fixed pivot top-left (448,488), bottom-left normalized (0.5833333333,0.3645833333).
Each PNG atlas has 3 columns and 2 rows. Use row-major cell order, no trimming or rotation.
Explicit proposed PPU: 256 for both new clips and the corresponding existing movement references. Existing packages had not calibrated PPU. If the project uses another PPU, apply the same value to matching old/new character clips, not individual cels.
No engine import, collision, repeated-hit interruption, knockback distance, or damage validation has occurred.

NATIVE REGISTRATION
Source sheets are 1536x1024 with six nominal 512x512 cells. Connected-figure ownership preserves fingers crossing nominal gutters. Native RGB is unchanged; alpha <=16 is cleared and alpha >=250 made opaque. No resizing, warping, mirroring, repainting, or per-frame fitting.
One fixed clip-wide registration correction was made after comparing recovered pose with the exact current move pose: Monk +15,+50 pixels relative to previous grid convention; Crawler +35,+25. Resulting source-cell translations are +79,+105 (Monk) and +163,+153 (Crawler), before subtracting each cell origin. All relative recoil/lift and cloth motion is preserved; lowest pixels are NOT pinned per frame.
Atlas/frame metadata records each source rectangle, integer translation, alpha bounds, hold and SHA256.

VISUAL REVIEW AND LIMITS
Monk: ochre robe, blank brass mask, two hands on one bell. Sharp compression, buoyant recoil, heavy settle and ready recovery. Peak recoil exposes both shoes. Bell and hands remain attached.
Crawler: two attached arms/hands and continuously closed charcoal/ivory cocoon. Head snap, compressed accordion brace, settle and forward pull recovery. No exposed lower-body stump.
Camera target is orthographic elevation35.2643897 degrees / azimuth45, world+X / screen-down-right. Drawn projection is visually approximated, not mathematically certified.
The corrected recovered poses align much closer to existing movement but remain new artwork: Monk recovered silhouette is 374px wide vs420px in the selected movement drawing, while height is381px vs387px. Crawler is433x373px vs479x398px. Hand reach, cloth width, head angle, and pose differ; an observable pose/volume pop remains at the cut. No per-frame or per-axis scaling was used to hide this. Gameplay review should assess the transition at actual world size. No production-ready or engine-validation claim is made.

FILES
runtime/: twelve RGBA cels, two native atlases, per-character JSON manifests and timing CSVs, deterministic QA record.
previews/: light contact sheets, exact old/new handoff comparisons, 60 Hz MP4s.
source/: untouched fresh generated sheets, exact prompts, only the needed reference files, provenance, reproducible extraction/video assembly script.
Built-in image generation was used; prompts include Sunburst 2.5, but the tool does not certify a backend model.
