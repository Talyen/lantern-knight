from pathlib import Path
import numpy as np
from PIL import Image
import layered_actors as a
r=a.build_wisp()
root=Path(__file__).resolve().parents[1]
for i in range(60):
 im=a.wisp_frame(r,i/60)
 for size in [768,384]:
  out=root/f"frames_{size}";out.mkdir(exist_ok=True)
  tier=im if size==768 else im.resize((size,size),Image.Resampling.LANCZOS)
  arr=np.array(tier);arr[arr[:,:,3]==0,:3]=0
  Image.fromarray(arr).save(out/f"hover_{i:03}.png")
