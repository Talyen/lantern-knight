from pathlib import Path
import subprocess
R=Path(__file__).resolve().parents[1]
clips=['idle','scuttle_front','mandible_attack','recoil','scuttle_side','scuttle_rear']
args=['ffmpeg','-hide_banner','-loglevel','error']
for c in clips:args+=['-i',str(R/f'review/{c}_60Hz.mp4')]
filters=[]
for i,c in enumerate(clips):filters.append(f"[{i}:v]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='{c.upper()}':x=24:y=24:fontsize=24:fontcolor=0xe0d8c5[v{i}]")
filters.append(''.join(f'[v{i}]' for i in range(len(clips)))+f'concat=n={len(clips)}:v=1:a=0,format=yuv420p[out]')
args+=['-filter_complex',';'.join(filters),'-map','[out]','-c:v','libx264','-crf','16','-y',str(R/'review/All_Clips_60Hz.mp4')]
subprocess.run(args,check=True)
