import sys,json,math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np
sys.path.insert(0,str(Path(__file__).parent));import beetle_cutout_rig as B
from layered_actors import label
R=B.R;P=R/'review';rig=B.build();root=(384,520);ppm=320

def project(x,z):return root[0]+ppm*(x-z)/math.sqrt(2),root[1]+ppm*(x+z)/math.sqrt(6)
def inverse(px,py):
 a=(px-root[0])/ppm*math.sqrt(2);b=(py-root[1])/ppm*math.sqrt(6);return [(a+b)/2,0,(b-a)/2]
def diag(phase):
 bg=Image.new('RGBA',(768,768),'#cfcec0');d=ImageDraw.Draw(bg)
 for i in range(-6,7):
  for fix in ['x','z']:
   pp=[project(i*.2,k) if fix=='x' else project(k,i*.2) for k in [-1.4,1.4]];d.line(pp,fill='#acb5ab',width=1)
 im,poses=B.frame(rig,phase,'scuttle');bg.alpha_composite(im);d=ImageDraw.Draw(bg)
 d.ellipse((root[0]-5,root[1]-5,root[0]+5,root[1]+5),fill='#cf5938')
 for n,(name,js) in enumerate(poses.items()):
  pp=[(p[0]*.42+59,p[1]*.42+242) for p in js];col=['#4b717a','#984d3e','#847f36','#685481','#296957','#ab7132'][n]
  d.line(pp,fill=col,width=2)
  for x,y in [pp[0],pp[-1]]:d.ellipse((x-5,y-5,x+5,y+5),outline=col,width=2)
  x,y=pp[-1];d.text((x+8,y-10),f'{n+1}',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18),fill=col)
 return bg,poses
sheet=Image.new('RGB',(1920,1180),'#dbd7c9');d=ImageDraw.Draw(sheet);label(d,(30,25),'CLOCKWORK BEETLE / FOOTPRINT & OCCLUSION GATE',30);label(d,(30,69),'Exact 35.2643897 / 45 ground grid; artwork is an approximate illustrated view. Six joints, not six forced-visible feet.',20)
for i,t in enumerate([0,.25,.5]):
 im,poses=diag(t);sheet.paste(im.resize((620,620),Image.Resampling.LANCZOS).convert('RGB'),(20+i*640,110));label(d,(35+i*640,745),f'SCUTTLE PHASE {t:.2f}',21)
 art,_=B.frame(rig,t,'scuttle');art=art.resize((266,266),Image.Resampling.LANCZOS);sheet.paste(art,(193+i*640,775),art)
label(d,(30,1090),'1 Far front   2 Far middle   3 Far rear (body-occluded)   4 Near front   5 Near middle   6 Near rear',19)
label(d,(30,1130),'Ground coordinates are inferred from the illustrated contact positions, not recovered from calibrated 3D artwork.',18);sheet.save(P/'Footprint_Three_Phases.jpg',quality=95)
# True metadata order is recorded rather than inferred from a fixed legend.
_,poses=diag(0);foots=[]
for n,(name,j) in enumerate(poses.items()):
 p=j[-1];px=[p[0]*.42+59,p[1]*.42+242];foots.append({'label':n+1,'id':name,'pixel':px,'inferred_ground_world_m':inverse(*px),'occlusion':'shell-occluded' if name=='far_rear' else 'visible/partly visible'})
(R/'qa/footprint.json').write_text(json.dumps({'ground_root_px':root,'grid_projection_elevation':35.264389682754654,'azimuth':45,'ppm':ppm,'ground_plane_inferred_from_art':True,'feet':foots},indent=2))
print(foots)
