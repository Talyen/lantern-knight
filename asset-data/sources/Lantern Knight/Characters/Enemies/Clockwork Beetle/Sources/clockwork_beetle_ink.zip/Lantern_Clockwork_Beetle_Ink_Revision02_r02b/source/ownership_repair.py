"""r02b ownership and occlusion correction. Raw masters remain byte-identical.
Moving jaw masks own their complete cutting contour. Foreground shell coverage
is restored from the same source, never regenerated, above articulated limbs.
"""
from PIL import Image,ImageDraw,ImageChops,ImageFilter
import numpy as np
from scipy import ndimage

def mask(size,points):
 m=Image.new('L',size);ImageDraw.Draw(m).polygon(points,fill=255);return m

def retain_main_component(im):
 a=np.array(im);labels,n=ndimage.label(a[:,:,3]>12)
 if not n:return im
 sizes=np.bincount(labels.ravel());sizes[0]=0;k=int(sizes.argmax());main=labels==k
 # Keep soft edge samples contiguous to the dominant body component only.
 main=ndimage.binary_dilation(main,iterations=3);a[~main]=0
 return Image.fromarray(a)

FRONT_SHELL=[(448,309),(529,184),(612,91),(791,26),(941,8),(1000,15),(1200,141),(1255,230),(1327,349),(1227,374),(1208,388),(1143,410),(1107,452),(1051,479),(1009,483),(986,456),(964,459),(929,456),(823,451),(803,415),(771,397),(741,360),(730,415),(716,430),(680,426),(664,471),(622,471),(604,453),(584,459),(575,486),(540,498),(514,511),(442,504),(414,494),(407,449),(407,419),(411,402),(449,355)]
REAR_SHELL=[(307,148),(417,89),(571,6),(628,0),(703,19),(751,56),(790,101),(774,155),(749,199),(748,255),(728,306),(714,327),(658,349),(637,412),(591,435),(544,450),(514,492),(450,524),(384,549),(319,553),(300,508),(261,454),(253,405),(247,379),(251,349),(254,303),(278,260),(294,227),(300,197),(306,160)]
SIDE_SHELL=[(99,280),(169,166),(295,63),(446,7),(514,0),(685,70),(799,169),(827,219),(884,270),(908,348),(859,374),(829,397),(803,382),(775,380),(734,388),(688,411),(653,424),(622,405),(602,369),(558,351),(529,366),(489,383),(461,382),(400,365),(351,345),(308,332),(258,316),(209,296),(182,291)]

JAW_CONTOURS={
'far_mandible':[(375,437),(432,447),(440,488),(421,527),(403,551),(392,573),(375,584),(388,616),(375,650),(352,704),(368,833),(322,835),(277,785),(232,722),(222,656),(250,608),(284,548),(333,486),(352,443)],
'near_mandible':[(530,502),(573,469),(656,476),(690,529),(690,743),(592,834),(340,890),(340,810),(428,703),(438,659),(477,630),(511,600),(505,562)]}

def foreground(src,view,jaw_masks=()):
 shape={'front':FRONT_SHELL,'rear':REAR_SHELL,'side':SIDE_SHELL}[view];m=mask(src.size,shape)
 if view=='side':m=ImageChops.lighter(m,mask(src.size,[(804,170),(840,163),(865,207),(850,226),(822,223),(802,204)]))
 if view=='side':m=ImageChops.lighter(m,mask(src.size,[(880,310),(926,337),(956,367),(979,405),(1002,449),(1012,518),(1004,600),(966,615),(886,596),(815,550),(773,488),(735,424),(742,365),(800,342),(846,375),(873,382)]))
 for jm in jaw_masks:m=ImageChops.subtract(m,jm)
 return m

def broaden_leg_mask(srcsize,points,foreground_mask,jawmasks=()):
 m=Image.fromarray(ndimage.maximum_filter(np.array(mask(srcsize,points)),size=29,mode='constant',cval=0))
 m=ImageChops.subtract(m,foreground_mask)
 for jm in jawmasks:m=ImageChops.subtract(m,jm)
 return m

def body_from_masks(src,limbmask,foreground_mask,jawmasks=()):
 m=ImageChops.lighter(ImageChops.invert(limbmask),foreground_mask)
 for jm in jawmasks:m=ImageChops.subtract(m,jm)
 out=src.copy();out.putalpha(ImageChops.multiply(src.getchannel('A'),m));return retain_main_component(out)


def draw_underlaps(canvas,view,body_delta=(0,0),leg_poses=(),jaw_pivots=()):
 """Authored near-black socket/shadow overlaps. Never replace the illustration."""
 d=ImageDraw.Draw(canvas);dx,dy=body_delta
 polys={
 'front':[[(424,435),(488,472),(566,510),(630,510),(699,505),(795,500),(871,490),(923,498),(1020,474),(1118,426),(1197,380),(1185,470),(1080,539),(1000,567),(942,568),(898,550),(847,570),(795,574),(735,586),(687,592),(629,555),(567,536),(506,530),(435,512)]],
 'rear':[[(511,442),(572,437),(586,464),(558,489),(503,516),(459,530),(386,545),(343,548),(319,534),(374,517),(457,493)],[(344,228),(279,190),(253,239),(228,273),(237,307),(267,328),(292,314),(305,264)]],
 'side':[[(207,325),(311,343),(411,376),(536,383),(620,385),(683,386),(674,426),(613,453),(561,439),(505,457),(429,433),(349,397),(261,384),(201,364)],[(823,232),(858,209),(904,283),(946,328),(975,379),(959,391),(927,350),(883,307),(848,274)]]}
 for poly in polys[view]:d.polygon([(x+dx,y+dy) for x,y in poly],fill='#171c18')
 ratio=canvas.width/1536
 for js in leg_poses:
  for k,width in [(0,26),(1,22),(2,22)]:
   d.line([tuple(js[k]),tuple(js[k+1])],fill='#111713',width=max(6,round(width*ratio)))
  for j,radius in [(1,32),(2,27),(3,22)]:
   x,y=js[j];r=radius*ratio;d.ellipse((x-r,y-r,x+r,y+r),fill='#111713')
 for x,y,r in jaw_pivots:d.ellipse((x+dx-r,y+dy-r,x+dx+r,y+dy+r),fill='#111713')

ARMOR_MASKS={
 ('front','far_front'):[(392,292),(429,307),(439,359),(400,397),(392,428),(302,498),(242,517),(224,489),(294,400),(332,318)],
 ('front','near_front'):[(744,532),(785,518),(832,550),(865,594),(878,624),(842,625),(801,612),(777,646),(747,640)],
 ('front','near_middle'):[(1022,456),(1108,446),(1166,520),(1216,608),(1245,750),(1128,720),(1050,640),(1007,588)],
 ('front','near_rear'):[(1219,355),(1309,355),(1399,450),(1435,590),(1331,609),(1264,493),(1197,465)],
 ('side','near_rear'):[(159,284),(212,292),(231,341),(184,398),(115,488),(51,478),(60,420),(102,362)],
 ('side','near_middle'):[(329,332),(393,340),(419,383),(392,444),(330,502),(320,565),(218,557),(232,498),(269,423)],
 ('side','near_front'):[(586,389),(628,382),(666,429),(680,500),(681,599),(602,617),(575,565),(572,491),(548,448)],
 ('side','far_front'):[(827,185),(870,185),(898,218),(927,269),(967,331),(928,360),(885,311),(841,274)],
 ('rear','near_rear'):[(558,430),(592,437),(615,482),(588,552),(562,608),(495,620),(498,566),(512,490)],
 ('rear','near_middle'):[(681,334),(727,338),(780,414),(806,532),(735,554),(700,500),(673,453),(650,420)],
 ('rear','near_front'):[(765,207),(813,211),(849,249),(894,368),(877,418),(824,398),(804,343),(759,304),(745,267)],
 ('rear','far_rear'):[(156,248),(207,262),(218,301),(190,351),(145,425),(86,421),(111,348),(121,292)],
 ('rear','far_middle'):[(229,139),(287,129),(310,169),(297,219),(254,272),(210,294),(193,267),(208,202)]}

def armor_owner_masks(size,view,name):
 poly=ARMOR_MASKS.get((view,name));return None if poly is None else np.array(mask(size,poly))>0
