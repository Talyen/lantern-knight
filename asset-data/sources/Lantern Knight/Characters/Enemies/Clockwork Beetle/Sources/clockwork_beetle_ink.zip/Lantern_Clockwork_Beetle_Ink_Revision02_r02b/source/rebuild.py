"""Rebuild delivered frame tiers from the preserved masters and explicit part rig."""
from pathlib import Path
import numpy as np
from PIL import Image
import beetle_cutout_rig as B
import beetle_additional_rigs as A
O=Path(__file__).resolve().parents[1]
rigs={'front':B.build(),'side':A.build('side'),'rear':A.build('rear')}
for clip,view,n,loop in [('idle','front',48,True),('scuttle_front','front',24,True),('mandible_attack','front',30,False),('recoil','front',24,False),('scuttle_side','side',24,True),('scuttle_rear','rear',24,True)]:
 for i in range(n):
  t=i/n if loop else i/(n-1)
  im,_=B.frame(rigs[view],t,'scuttle' if clip=='scuttle_front' else clip) if view=='front' else A.frame(rigs[view],t)
  arr=np.array(im);arr[arr[:,:,3]==0,:3]=0;im=Image.fromarray(arr)
  for size in [768,384]:
   out=O/f'frames_{size}'/clip;out.mkdir(parents=True,exist_ok=True);tier=im if size==768 else im.resize((size,size),Image.Resampling.LANCZOS);a=np.array(tier);a[a[:,:,3]==0,:3]=0;Image.fromarray(a).save(out/f'{i:03}.png')
