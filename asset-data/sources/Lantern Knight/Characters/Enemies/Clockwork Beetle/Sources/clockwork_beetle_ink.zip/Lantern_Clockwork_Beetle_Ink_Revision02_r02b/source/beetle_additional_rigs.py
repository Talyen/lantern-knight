"""Additional authored view masters. Same source-layer method, approximate viewpoints.
NOT calibrated 135/225 degree renders and NOT mirrored original-view frames.
"""
import sys,json,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageChops
sys.path.insert(0,str(Path(__file__).parent));import beetle_cutout_rig as B;import layered_actors as L
S=L.S;P=L.P
VIEWS={
'side':{
 'view':'side', 'direction':[1,0], 'placement':[58,160], 'scale':.61,
 'legs':[
 dict(id='near_rear',joints=[[310,354],[200,345],[100,474],[62,545],[12,620]],points=[(312,324),(191,294),(157,289),(80,363),(45,453),(54,498),(30,526),(0,536),(0,633),(23,638),(75,582),(95,558),(106,513),(132,470),(168,427),(194,389),(250,384),(289,409),(322,367)]),
 dict(id='near_middle',joints=[[558,407],[395,394],[287,546],[249,618],[185,702]],points=[(572,378),(493,392),(424,376),(374,348),(332,347),(298,381),(276,439),(229,511),(226,548),(254,560),(232,594),(204,604),(168,630),(161,713),(208,722),(230,667),(268,649),(283,615),(297,584),(324,557),(325,516),(349,472),(370,450),(416,445),(461,483),(514,452),(559,451),(583,415)]),
 dict(id='near_front',joints=[[654,419],[588,475],[646,581],[677,660],[751,741]],points=[(648,382),(610,379),(577,409),(551,450),(553,498),(581,512),(584,559),(592,594),(609,631),(648,666),(667,691),(705,704),(746,758),(782,753),(779,708),(753,663),(714,648),(701,622),(677,598),(675,565),(665,526),(657,484),(679,444),(679,406)]),
 dict(id='far_front',joints=[[828,261],[846,229],[930,321],[974,390],[1030,437]],points=[(807,199),(852,189),(893,225),(913,269),(959,307),(977,351),(984,373),(1026,371),(1042,411),(1042,459),(1014,455),(981,427),(960,399),(955,370),(924,354),(906,327),(862,279),(825,269)])
 ],
 'hidden':[('far_middle',[[635,298],[587,236],[612,148],[652,216],[684,278]]),('far_rear',[[347,240],[419,185],[396,108],[293,192],[212,258]])]
},
'rear':{
 'view':'rear', 'direction':[.65,-.76], 'placement':[115,143], 'scale':.66,
 'legs':[
 dict(id='near_rear',joints=[[570,445],[554,482],[533,609],[517,674],[532,740]],points=[(529,435),(568,428),(596,451),(606,499),(588,552),(562,595),(559,628),(543,659),(560,694),(546,751),(508,751),(482,703),(482,668),(503,642),(507,611),(500,588),(508,531),(506,475)]),
 dict(id='near_middle',joints=[[642,420],[684,400],[750,525],[778,585],[816,655]],points=[(642,368),(675,347),(716,343),(746,374),(771,427),(780,470),(802,518),(782,541),(786,558),(810,574),(842,600),(853,640),(834,670),(793,661),(771,620),(754,611),(738,582),(737,552),(719,528),(707,484),(680,443),(638,452),(615,426)]),
 dict(id='near_front',joints=[[736,284],[772,266],[858,382],[874,439],[915,496]],points=[(747,220),(781,209),(812,228),(839,257),(861,302),(891,358),(885,391),(887,416),(910,423),(928,430),(930,511),(904,516),(868,478),(852,458),(846,433),(840,407),(839,390),(815,353),(789,310),(752,304),(723,292)]),
 dict(id='far_rear',joints=[[263,327],[196,305],[123,427],[104,467],[44,532]],points=[(261,290),(211,283),(183,259),(157,256),(122,304),(109,351),(83,404),(97,443),(82,452),(45,453),(23,491),(25,550),(57,550),(91,505),(123,489),(135,456),(145,428),(152,389),(184,349),(221,349),(261,363)]),
 dict(id='far_middle',joints=[[348,228],[276,200],[238,245],[207,293],[180,345]],points=[(316,142),(275,141),(240,148),(215,179),(201,220),(187,263),(179,289),(193,320),(219,333),(242,293),(254,272),(279,239),(299,220),(343,237)])
 ],
 'hidden':[('far_front',[[649,215],[605,164],[638,104],[725,160],[762,230]])]
}}

def build(view):
 import ownership_repair as OR
 spec=VIEWS[view];src=Image.open(S/f'beetle_{view}_master.png').convert('RGBA');allmask=Image.new('L',src.size);legs=[];fg=OR.foreground(src,view)
 for ld in spec['legs']:
  m=OR.broaden_leg_mask(src.size,ld['points'],fg);allmask=ImageChops.lighter(allmask,m);im=OR.retain_main_component(L.layer(src,m));parts=B.split_leg(im,ld['joints'],ld['id'],view);legs.append(dict(id=ld['id'],joints=np.array(ld['joints'],float),parts=parts))
 body=OR.body_from_masks(src,allmask,fg)
 # Open the nearly straight rear near-leg knee once in source space, giving the
 # gait real flexion reserve instead of allowing a stretched/disconnected shin.
 if view=='rear':
  leg=next(l for l in legs if l['id']=='near_rear');oldjs=leg['joints'].copy();newjs=oldjs.copy();newjs[2]=[570,597];newparts=[]
  for i,im in enumerate(leg['parts']):
   cv=Image.new('RGBA',src.size);B.rigid_place(im,oldjs[i],oldjs[i+1],newjs[i],newjs[i+1],cv,True);newparts.append(cv)
  leg['joints']=newjs;leg['parts']=newparts
 reference=legs[-1]
 for name,js in spec['hidden']:
  parts=[]
  for i,im in enumerate(reference['parts']):
   cv=Image.new('RGBA',src.size);B.rigid_place(im,reference['joints'][i],reference['joints'][i+1],js[i],js[i+1],cv,True);parts.append(cv)
  legs.append(dict(id=name,joints=np.array(js,float),parts=parts))
 out=S/f'beetle_{view}_layers';out.mkdir(exist_ok=True);body.save(out/'body.png')
 for ld in legs:
  for i,im in enumerate(ld['parts']):im.save(out/f'{ld["id"]}_{i}.png')
 (out/'rig.json').write_text(json.dumps({'view':view,'perspective':'separately authored approximate illustrated view, not calibrated 3D heading','legs':{l['id']:l['joints'].tolist() for l in legs},'ground_root_px':[384,520],'direction':spec['direction']},indent=2))
 return src,body,legs,spec

def pose(leg,t,direction):
 rest=leg['joints'];j=rest.copy();body=np.array((0,-1.5*(1-math.cos(2*math.tau*t))));j[0]+=body;j[1]+=body
 tripod=leg['id'] in ['far_front','near_middle','far_rear'];phase=(t+(.5 if tripod else 0))%1;duty=.62;stride=26
 if phase<duty:q=phase/duty;along=(q-.5)*stride;lift=0
 else:q=(phase-duty)/(1-duty);along=(.5-B.ease(q))*stride;lift=15*math.sin(math.pi*q)
 delta=-np.array(direction)*along;delta[1]-=lift;j[3]+=delta;j[4]+=delta
 l1=B.dist(rest[1],rest[2]);l2=B.dist(rest[2],rest[3])
 if B.dist(j[1],j[3])>l1+l2-.02 or B.dist(j[1],j[3])<abs(l1-l2)+.02:
  v=rest[1]-rest[0];best=None
  for ang in np.linspace(-1.1,1.1,221):
   c=math.cos(ang);s=math.sin(ang);candidate=j[0]+np.array([c*v[0]-s*v[1],s*v[0]+c*v[1]]);r=B.dist(candidate,j[3]);pen=max(0,r-(l1+l2-.02))*1000+max(0,abs(l1-l2)+.02-r)*1000+abs(ang)
   if best is None or pen<best[0]:best=(pen,candidate)
  j[1]=best[1]
 j[2]=B.solve_two(j[1],rest[2]+body,j[3],l1,l2);return j

def frame(rig,t):
 src,body,legs,spec=rig;canvas=Image.new('RGBA',src.size);poses={}
 import ownership_repair as OR
 OR.draw_underlaps(canvas,spec['view'],(0,-1.5*(1-math.cos(2*math.tau*t))),[pose(l,t,spec['direction']) for l in legs])
 for leg in sorted(legs,key=lambda l:0 if l['id'].startswith('far') else 2):
  js=pose(leg,t,spec['direction']);poses[leg['id']]=js.tolist()
  for i,im in enumerate(leg['parts']):B.rigid_place(im,leg['joints'][i],leg['joints'][i+1],js[i],js[i+1],canvas)
 dy=-1.5*(1-math.cos(2*math.tau*t));B.rigid_place(body,[0,0],[1,0],[0,dy],[1,dy],canvas)
 out=Image.new('RGBA',(768,768));canvas=canvas.resize(tuple(round(s*spec['scale']) for s in src.size),Image.Resampling.LANCZOS);out.alpha_composite(canvas,tuple(spec['placement']));return out,poses

def proof():
 for v in VIEWS:
  rig=build(v);out=P/f'beetle_{v}_scuttle_pilot';out.mkdir(exist_ok=True);frames=[]
  for i in range(24):
   im,_=frame(rig,i/24);im.save(out/f'frame_{i:03}.png');bg=Image.new('RGBA',(768,768),'#cfcdbc');bg.alpha_composite(im);frames.append(bg.convert('RGB').resize((512,512),Image.Resampling.LANCZOS))
  frames[0].save(P/f'Beetle_{v}_Scuttle_Pilot.gif',save_all=True,append_images=frames[1:],duration=[30,30,40]*8,loop=0,disposal=2)
if __name__=='__main__':proof()
