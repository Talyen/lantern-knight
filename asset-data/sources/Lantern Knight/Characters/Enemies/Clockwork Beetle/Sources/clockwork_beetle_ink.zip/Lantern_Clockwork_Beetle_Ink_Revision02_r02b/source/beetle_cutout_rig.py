"""Six-legged source-art cutout rig. Geometry changes joints, never repaints frames.
Fixed-length 2D IK; original-view approximation. The two extra far legs are built
from the approved master leg's independently placed segments, not whole-leg stamps.
"""
import sys,math,json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageChops
sys.path.insert(0,str(Path(__file__).parent))
import layered_actors as L
R=L.R;S=L.S;P=L.P

def point(p):return np.array(p,dtype=float)
def dist(a,b):return float(np.linalg.norm(a-b))
def rigid_place(im,p0,p1,q0,q1,canvas,allow_scale=False):
 """Draw a cropped source image through a rigid segment transform."""
 p0,p1,q0,q1=map(point,(p0,p1,q0,q1));u=p1-p0;v=q1-q0
 ang=math.atan2(v[1],v[0])-math.atan2(u[1],u[0]);scale=dist(q0,q1)/dist(p0,p1) if allow_scale else 1
 c=math.cos(ang)*scale;s=math.sin(ang)*scale
 A=np.array([[c,-s],[s,c]]);b=q0-A@p0
 box=im.getbbox()
 if not box:return
 corners=np.array([[box[0],box[1]],[box[2],box[1]],[box[2],box[3]],[box[0],box[3]]]);tc=corners@A.T+b
 lo=np.floor(tc.min(axis=0)-2).astype(int);hi=np.ceil(tc.max(axis=0)+2).astype(int)
 lo=np.maximum(lo,[0,0]);hi=np.minimum(hi,canvas.size)
 if np.any(hi<=lo):return
 inv=np.linalg.inv(A);offset=inv@(lo-b)-np.array(box[:2]);src=im.crop(box)
 out=src.transform(tuple(hi-lo),Image.Transform.AFFINE,(*inv[0],offset[0],*inv[1],offset[1]),resample=Image.Resampling.BICUBIC)
 canvas.alpha_composite(out,tuple(lo))

def split_leg(im,joints,name="",view="front"):
 h,w=im.height,im.width;yy,xx=np.mgrid[:h,:w];xy=np.stack((xx,yy),axis=-1);ds=[]
 for a,b in zip(joints,joints[1:]):
  a,b=point(a),point(b);v=b-a;t=np.clip(np.sum((xy-a)*v,axis=-1)/(v@v),0,1);q=a+t[...,None]*v;ds.append(np.sum((xy-q)**2,axis=-1))
 labels=np.argmin(np.stack(ds),axis=0);parts=[]
 import ownership_repair as OR
 armor=OR.armor_owner_masks(im.size,view,name)
 if armor is not None:labels[armor]=1
 for i in range(len(joints)-1):
  m=(labels==i)
  # Art overlap disks at both source joints keep rotation joins filled.
  for j in [i,i+1]:
   x,y=joints[j];radius=(24 if j in [0,len(joints)-1] else 34)*(im.width/1536)
   m |= ((xx-x)**2+(yy-y)**2<radius**2)
  if armor is not None:
   if i==1:m |= armor
   else:m &= ~armor
  parts.append(OR.retain_main_component(L.layer(im,Image.fromarray((m*255).astype('uint8')))))
 return parts

def build():
 src,body,legs,jaws=L.build_beetle();legart=[]
 for spec,im in legs[:4]:
  js=[spec['root']]+spec['joints'];part=split_leg(im,js,spec['id'],'front')
  legart.append(dict(id=spec['id'],joints=np.array(js,float),parts=part))
 far_source=legart[0]
 targets=[('far_middle',[[760,355],[610,287],[438,245],[325,302],[278,381]]),('far_rear',[[1032,297],[909,230],[824,157],[818,216],[810,265]])]
 for name,js in targets:
  newparts=[]
  for i,im in enumerate(far_source['parts']):
   cv=Image.new('RGBA',src.size);rigid_place(im,far_source['joints'][i],far_source['joints'][i+1],js[i],js[i+1],cv,True);newparts.append(cv)
  legart.append(dict(id=name,joints=np.array(js,float),parts=newparts))
 out=S/'beetle_articulated_layers';out.mkdir(exist_ok=True)
 for leg in legart:
  for i,im in enumerate(leg['parts']):im.save(out/f'{leg["id"]}_segment_{i}.png')
 (S/'beetle_six_leg_joint_source.json').write_text(json.dumps({l['id']:l['joints'].tolist() for l in legart},indent=2))
 return src,body,legart,jaws

def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def key(t,ks):
 for (a,x),(b,y) in zip(ks,ks[1:]):
  if a<=t<=b:return x+(y-x)*ease((t-a)/(b-a))
 return ks[-1][1]

def body_pose(t,clip):
 if clip=='idle':return point((0,-3*(1-math.cos(math.tau*t)))),1.8*(1-math.cos(math.tau*t))
 if clip=='scuttle':return point((0,-2*(1-math.cos(2*math.tau*t)))),1
 if clip=='mandible_attack':
  x=key(t,[(0,0),(.34,12),(.48,-28),(.64,-25),(1,0)]);y=key(t,[(0,0),(.34,-5),(.48,9),(.64,7),(1,0)]);jaw=key(t,[(0,0),(.34,17),(.43,17),(.50,-6),(.63,-4),(1,0)]);return point((x,y)),jaw
 if clip=='recoil':
  x=key(t,[(0,0),(.2,28),(.4,22),(.7,-3),(1,0)]);return point((x,-x*.42)),key(t,[(0,0),(.2,7),(.5,3),(1,0)])
 raise ValueError(clip)

def solve_two(a,pole,b,l1,l2):
 v=b-a;r=np.linalg.norm(v);r=max(abs(l1-l2)+.001,min(l1+l2-.001,r));u=v/np.linalg.norm(v);side=np.array([-u[1],u[0]])
 if np.dot(pole-a,side)<0:side=-side
 along=(l1*l1-l2*l2+r*r)/(2*r);high=math.sqrt(max(0,l1*l1-along*along));return a+u*along+side*high

def leg_pose(leg,t,clip,body):
 rest=leg['joints'];j=rest.copy();j[0]+=body;j[1]+=body
 if clip=='scuttle':
  tripod=leg['id'] in ['far_front','near_middle','far_rear'];phase=(t+(.5 if tripod else 0))%1;duty=.62;stride=44
  if phase<duty:q=phase/duty;along=(q-.5)*stride;lift=0
  else:q=(phase-duty)/(1-duty);along=(.5-ease(q))*stride;lift=26*math.sin(math.pi*q)
  delta=point((.866*along,-.5*along-lift));j[3]+=delta;j[4]+=delta
 l1=dist(rest[1],rest[2]);l2=dist(rest[2],rest[3])
 # A third articulated coxa joint supplies reach before any segment would stretch.
 if dist(j[1],j[3])>l1+l2-.02 or dist(j[1],j[3])<abs(l1-l2)+.02:
  v=rest[1]-rest[0];best=None
  for ang in np.linspace(-1.1,1.1,221):
   c=math.cos(ang);s=math.sin(ang);candidate=j[0]+np.array([c*v[0]-s*v[1],s*v[0]+c*v[1]])
   r=dist(candidate,j[3]);penalty=max(0,r-(l1+l2-.02))*1000+max(0,abs(l1-l2)+.02-r)*1000+abs(ang)
   if best is None or penalty<best[0]:best=(penalty,candidate)
  j[1]=best[1]
 j[2]=solve_two(j[1],rest[2]+body,j[3],l1,l2)
 return j

def frame(rig,t,clip='idle',contacts=False):
 src,body,legs,jaws=rig;canvas=Image.new('RGBA',src.size);bp,jaw=body_pose(t,clip);poses={}
 import ownership_repair as OR
 OR.draw_underlaps(canvas,'front',bp,[leg_pose(l,t,clip,bp) for l in legs],[(416,468,25),(580,534,33)])
 for leg in sorted(legs,key=lambda l:0 if l['id'].startswith('far') else 2):
  js=leg_pose(leg,t,clip,bp);poses[leg['id']]=js.tolist()
  for i,im in enumerate(leg['parts']):rigid_place(im,leg['joints'][i],leg['joints'][i+1],js[i],js[i+1],canvas)
 for spec,im in jaws:
  p=point(spec['pivot']);ang=math.radians(spec['sign']*jaw);q=p+bp;v=point((math.cos(ang),math.sin(ang)))
  rigid_place(im,p,p+[1,0],q,q+v,canvas)
 rigid_place(body,[0,0],[1,0],bp,bp+[1,0],canvas)
 out=Image.new('RGBA',(768,768));canvas=canvas.resize((645,430),Image.Resampling.LANCZOS);out.alpha_composite(canvas,(59,242))
 if contacts:
  d=ImageDraw.Draw(out)
  for name,j in poses.items():
   x,y=j[-1];x=x*.42+59;y=y*.42+242;d.ellipse((x-5,y-3,x+5,y+3),fill='#d46738')
 return out,poses

def proof():
 rig=build();im,_=frame(rig,0);im.save(P/'beetle_articulated_six_leg_rest.png');frame(rig,0,contacts=True)[0].save(P/'beetle_articulated_contacts.png')
 bg=Image.new('RGBA',(1200,800),'#d8d3c6');thumb=L.cropthumb(im,(1000,630));bg.alpha_composite(thumb,((1200-thumb.width)//2,70));d=ImageDraw.Draw(bg);L.label(d,(30,20),'CLOCKWORK BEETLE / CONNECTED SIX-LEG SOURCE',27);L.label(d,(30,745),'Segment-level placements; separately articulated far limbs; dark socket overlaps',19);bg.convert('RGB').save(P/'Beetle_Articulated_Six_Leg_Gate.jpg',quality=95)
 for clip,n in [('scuttle',24),('mandible_attack',30)]:
  frames=[];fo=P/f'beetle_{clip}_pilot';fo.mkdir(exist_ok=True)
  for i in range(n):
   im,pose=frame(rig,i/n if clip=='scuttle' else i/(n-1),clip);im.save(fo/f'frame_{i:03}.png');bg=Image.new('RGBA',(768,768),'#d1cec2');bg.alpha_composite(im);frames.append(bg.convert('RGB').resize((576,576),Image.Resampling.LANCZOS))
  frames[0].save(P/f'Beetle_{clip}_Pilot.gif',save_all=True,append_images=frames[1:],duration=[30,30,40]*(n//3),loop=0,disposal=2)
if __name__=='__main__':proof()
