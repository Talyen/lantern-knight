#!/usr/bin/env python3
"""Cutout animation source. New illustrated masters; hand-authored masks and rigid pivots.
No frame regeneration and no whole-image deformation. World anchors are held fixed.
Each moving part uses a proper rigid 2D transform; masks follow drawn overlapping folds.
"""
from pathlib import Path
import numpy as np,math,json
from PIL import Image,ImageDraw,ImageChops,ImageFont
R=Path(__file__).resolve().parents[1]; S=R/'source'; P=R/'proofs'; P.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def mask(size,points):
 m=Image.new('L',size);ImageDraw.Draw(m).polygon(points,fill=255);return m

def layer(src,m):
 l=src.copy();l.putalpha(ImageChops.multiply(l.getchannel('A'),m));return l

def rotate(im,angle,pivot,dx=0,dy=0):
 t=math.radians(angle);c=math.cos(t);s=math.sin(t);x,y=pivot
 # forward x'=cos*x-sin*y + x-cos*px+sin*py; inverse samples source
 xx=x+dx;yy=y+dy
 return im.transform(im.size,Image.Transform.AFFINE,(c,s,x-c*xx-s*yy,-s,c,y+s*xx-c*yy),resample=Image.Resampling.BICUBIC)

def label(d,xy,text,size=22,color='#253332'):d.text(xy,text,font=ImageFont.truetype(FONT,size),fill=color)

def cropthumb(im,size):
 box=im.getchannel('A').point(lambda x:255 if x>50 else 0).getbbox(); im=im.crop(box);im.thumbnail(size,Image.Resampling.LANCZOS);return im

WISP_PARTS=[
 dict(id='right_trailing_tip',pivot=[869,791],angle=2.4,lag=-1.1,points=[(770,750),(873,702),(1024,850),(1024,1350),(833,1350),(827,927),(800,892),(777,826)]),
 dict(id='left_torn_tail',pivot=[322,809],angle=-2.5,lag=-.7,points=[(242,764),(329,745),(403,780),(405,924),(391,993),(427,1130),(246,1150)]),
 dict(id='central_torn_tail',pivot=[512,1036],angle=2.05,lag=-.25,points=[(450,1010),(549,978),(596,995),(625,1083),(662,1280),(658,1536),(448,1536),(427,1130)]),
]

def build_wisp():
 src=Image.open(S/'wisp_front_master.png').convert('RGBA');parts=[];combined=Image.new('L',src.size)
 for spec in WISP_PARTS:
  m=mask(src.size,spec['points']);combined=ImageChops.lighter(combined,m);parts.append((spec,layer(src,m)))
 base=layer(src,ImageChops.invert(combined))
 # Each root overlap is independently retained above the moving strip, covering cut seams.
 overlays=[]
 for spec,_ in parts:
  x,y=spec['pivot']; rootmask=mask(src.size,[(x-100,y-85),(x+100,y-85),(x+80,y+13),(x-75,y+13)])
  overlays.append(layer(src,rootmask))
 out=S/'wisp_layers';out.mkdir(exist_ok=True);base.save(out/'cowl_and_body.png')
 for spec,im in parts:im.save(out/(spec['id']+'.png'))
 for i,im in enumerate(overlays):im.save(out/f'overlap_{i:02}.png')
 (S/'wisp_rig.json').write_text(json.dumps({'canvas_source':list(src.size),'parts':WISP_PARTS,'source_fps':30,'frames':60,'fixed_root_px':[384,710],'cutout_type':'rigid-part ink cutout; no whole-image bending','source_view':'front three-quarter illustrated approximation; no exact camera claim'},indent=2))
 return src,base,parts,overlays

def wisp_frame(rig,t,output_size=768):
 src,base,parts,overlays=rig;canvas=Image.new('RGBA',src.size)
 # The source body remains still. Only distal cloth tails use independent delayed angular motion.
 for spec,im in parts:
  ang=spec['angle']*(math.sin(math.tau*t+spec['lag'])-math.sin(spec['lag']))
  canvas.alpha_composite(rotate(im,ang,spec['pivot']))
 canvas.alpha_composite(base)
 for im in overlays:canvas.alpha_composite(im)
 # Native source is a 2D illustrated view. Scale is calibrated separately, not perspective.
 canvas=canvas.resize((440,660),Image.Resampling.LANCZOS)
 output=Image.new('RGBA',(768,768));bob=round(4*math.sin(math.tau*t))
 output.alpha_composite(canvas,(170,16+bob))
 if output_size!=768:output=output.resize((output_size,output_size),Image.Resampling.LANCZOS)
 return output

def proof_wisp():
 rig=build_wisp();out=P/'wisp_illustrated_pilot';out.mkdir(exist_ok=True);frames=[]
 for i in range(60):
  im=wisp_frame(rig,i/60);im.save(out/f'frame_{i:03}.png')
  bg=Image.new('RGBA',(768,768),'#1b292f');bg.alpha_composite(im);frames.append(bg.convert('RGB').resize((512,512),Image.Resampling.LANCZOS))
 frames[0].save(P/'Wisp_Illustrated_Hover_Pilot.gif',save_all=True,append_images=frames[1:],duration=[30,30,40]*20,loop=0,disposal=2)
 phases=Image.new('RGB',(1600,960),'#d9d6c9');d=ImageDraw.Draw(phases);label(d,(28,23),'SHROUD WISP  /  ILLUSTRATED HOVER GATE',28);label(d,(28,65),'One source drawing | independent delayed cloth tips | cowl and face preserved',18)
 for j,i in enumerate([0,15,30,45]):
  bgcol='#1b292f' if j%2 else '#c8cec7';tile=Image.new('RGBA',(380,620),bgcol);im=Image.open(out/f'frame_{i:03}.png');im=cropthumb(im,(340,580));tile.alpha_composite(im,((380-im.width)//2,16));phases.paste(tile.convert('RGB'),(20+j*400,115));label(d,(30+j*400,752),f'Frame {i:02} / {i/30:.2f}s',18)
 for j,i in enumerate([0,15,30,45]):
  im=cropthumb(Image.open(out/f'frame_{i:03}.png'),(130,166));phases.paste(im,(130+j*400,788),im)
 label(d,(30,815),'13 m / 1440p',15);label(d,(30,838),'~166 px tall',15)
 phases.save(P/'Wisp_Hover_Phase_Gate.jpg',quality=95)

if __name__=='__main__':proof_wisp()

# Four visible leg studies from the master. The two far-side legs are authored
# from the far-front segment vocabulary, each at its own root and placement.
BEETLE_LEGS=[
 dict(id='far_front',root=[460,382],joints=[[413,353],[272,519],[210,603],[135,705]],points=[(440,297),(380,284),(327,321),(226,484),(207,550),(107,580),(87,730),(170,742),(234,626),(253,576),(269,553),(284,520),(301,489),(330,460),(365,440),(397,415),(406,387),(449,371)]),
 dict(id='near_front',root=[707,553],joints=[[749,615],[831,762],[792,880],[714,997]],points=[(689,542),(723,520),(817,533),(865,589),(877,651),(917,742),(895,799),(843,859),(821,905),(753,934),(742,1030),(684,1029),(676,949),(693,875),(744,861),(781,824),(790,757),(771,709),(756,663),(703,652),(691,594)]),
 dict(id='near_middle',root=[873,527],joints=[[1034,542],[1173,731],[1208,821],[1290,944]],points=[(892,520),(931,529),(1046,476),(1089,469),(1131,512),(1225,672),(1241,722),(1225,764),(1248,793),(1295,807),(1319,853),(1318,950),(1258,979),(1226,910),(1194,868),(1182,821),(1156,765),(1136,708),(1070,632),(1069,588),(1018,590),(958,631),(912,616),(865,566)]),
 dict(id='near_rear',root=[1119,459],joints=[[1237,428],[1376,565],[1408,644],[1458,735]],points=[(1094,439),(1200,378),(1290,357),(1324,405),(1404,476),(1415,555),(1406,592),(1432,618),(1477,623),(1500,679),(1491,747),(1432,766),(1381,699),(1371,643),(1336,590),(1327,536),(1277,482),(1224,480),(1140,514),(1094,495)]),
]
BEETLE_JAWS=[
 dict(id='far_mandible',pivot=[416,468],sign=1,points=[(393,441),(415,457),(420,498),(397,540),(368,558),(351,595),(346,625),(366,648),(331,664),(331,691),(333,712),(321,722),(326,764),(355,815),(310,825),(261,776),(224,710),(221,626),(249,554),(300,494),(359,449)]),
 dict(id='near_mandible',pivot=[580,534],sign=-1,points=[(559,496),(598,475),(641,498),(663,554),(654,599),(650,642),(613,710),(560,771),(489,817),(422,846),(382,849),(400,824),(455,784),(487,744),(455,742),(482,714),(488,688),(503,665),(489,654),(500,635),(528,628),(518,593),(522,555)]),
]

def affine_layer(im,pivot,newpivot,angle=0,scale=1):
 theta=math.radians(angle);c=math.cos(theta)/scale;s=math.sin(theta)/scale;x,y=pivot;xx,yy=newpivot
 return im.transform(im.size,Image.Transform.AFFINE,(c,s,x-c*xx-s*yy,-s,c,y+s*xx-c*yy),resample=Image.Resampling.BICUBIC)

def build_beetle():
 import ownership_repair as OR
 src=Image.open(S/'beetle_front_master.png').convert('RGBA');legs=[];jaws=[];allmask=Image.new('L',src.size)
 jaw_masks=[OR.mask(src.size,OR.JAW_CONTOURS[sp['id']]) for sp in BEETLE_JAWS]
 fg=OR.foreground(src,'front',jaw_masks)
 for spec in BEETLE_LEGS:
  m=OR.broaden_leg_mask(src.size,spec['points'],fg,jaw_masks);allmask=ImageChops.lighter(allmask,m);legs.append((spec,OR.retain_main_component(layer(src,m))))
 for spec,m in zip(BEETLE_JAWS,jaw_masks):
  allmask=ImageChops.lighter(allmask,m);jaws.append((spec,OR.retain_main_component(layer(src,m))))
 body=OR.body_from_masks(src,allmask,fg,jaw_masks)
 out=S/'beetle_layers';out.mkdir(exist_ok=True);body.save(out/'shell_and_head.png')
 for spec,im in legs+jaws:im.save(out/(spec['id']+'.png'))
 (S/'beetle_raw_master_segmentation.json').write_text(json.dumps({'source_canvas':list(src.size),'legs':[s for s,_ in legs],'mandibles':OR.JAW_CONTOURS,'construction':'r02b complete jaw contour ownership and restored shell foreground; raw master masks only','delivered_ground_anchor_px':[384,520]},indent=2))
 return src,body,legs,jaws

def beetle_frame(rig,t,clip='idle',output_size=768,contacts=False):
 src,body,legs,jaws=rig;canvas=Image.new('RGBA',src.size)
 # Mild source-part proof. Grounded IK segment motion replaces this for export.
 bob=2*(1-math.cos(math.tau*t));attack=max(0,math.sin(math.pi*t))
 if clip=='attack':bob=-5*attack
 for spec,im in sorted(legs,key=lambda x:0 if x[0]['id'].startswith('far') else 2):
  canvas.alpha_composite(im)
 for spec,im in jaws:
  amount=1.5*(1-math.cos(math.tau*t))
  if clip=='attack':amount=13*math.sin(math.pi*min(1,t/.6)) if t<.6 else -4*math.sin(math.pi*(t-.6)/.4)
  canvas.alpha_composite(rotate(im,spec['sign']*amount,spec['pivot'],0,-bob))
 canvas.alpha_composite(rotate(body,0,(0,0),0,-bob))
 canvas=canvas.resize((645,430),Image.Resampling.LANCZOS)
 out=Image.new('RGBA',(768,768));out.alpha_composite(canvas,(59,242))
 if contacts:
  d=ImageDraw.Draw(out)
  for spec,_ in legs:
   x,y=spec['joints'][-1];x=x*.42+59;y=y*.42+242;d.ellipse((x-5,y-3,x+5,y+3),fill='#d25e36')
 return out.resize((output_size,output_size),Image.Resampling.LANCZOS) if output_size!=768 else out

def proof_beetle():
 rig=build_beetle();im=beetle_frame(rig,0);im.save(P/'beetle_six_leg_rest.png');beetle_frame(rig,0,contacts=True).save(P/'beetle_six_leg_contacts.png')
 bg=Image.new('RGBA',(1000,900),'#d8d3c6');art=cropthumb(im,(920,720));bg.alpha_composite(art,((1000-art.width)//2,70));d=ImageDraw.Draw(bg);label(d,(25,20),'CLOCKWORK BEETLE / SIX-LEG DRAWING GATE',25);label(d,(25,805),'Six authored limb placements; same illustrated source vocabulary',19);label(d,(25,840),'Illustrated perspective approximation | no front/rear mirror substitution',18);bg.convert('RGB').save(P/'Beetle_Six_Leg_Gate.jpg',quality=95)
