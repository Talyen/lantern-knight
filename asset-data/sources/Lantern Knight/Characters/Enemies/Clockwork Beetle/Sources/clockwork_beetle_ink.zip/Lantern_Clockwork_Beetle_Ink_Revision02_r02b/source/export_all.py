from pathlib import Path
import sys,json,hashlib,shutil,math,subprocess
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,str(Path(__file__).parent));import beetle_cutout_rig as B;import beetle_additional_rigs as A;import layered_actors as L
R=L.R;O=R;O.mkdir(exist_ok=True)
for d in ['frames_768','frames_384','stills','atlases','review','source','qa','animation','technical_reference']:(O/d).mkdir(exist_ok=True)
rigs={'front':B.build(),'side':A.build('side'),'rear':A.build('rear')}
clips=[('idle','front',48,True),('scuttle_front','front',24,True),('mandible_attack','front',30,False),('recoil','front',24,False),('scuttle_side','side',24,True),('scuttle_rear','rear',24,True)]
allqa={};review_frames=[];sourcehash={};rest=[]
for clip,view,n,loop in clips:
 out=O/'frames_768'/clip;out.mkdir(exist_ok=True);smallout=O/'frames_384'/clip;smallout.mkdir(exist_ok=True);tiles=[];hashes=[];bboxes=[];maxbone=0;contactmax=0;poses=[]
 for i in range(n):
  t=i/n if loop else i/(n-1)
  if view=='front':im,pose=B.frame(rigs[view],t,'scuttle' if clip=='scuttle_front' else clip)
  else:im,pose=A.frame(rigs[view],t)
  arr=np.array(im);arr[arr[:,:,3]==0,:3]=0;im=Image.fromarray(arr);im.save(out/f'{i:03}.png');small=im.resize((384,384),Image.Resampling.LANCZOS);sa=np.array(small);sa[sa[:,:,3]==0,:3]=0;small=Image.fromarray(sa);small.save(smallout/f'{i:03}.png');tiles.append(small);hashes.append(hashlib.sha256(im.tobytes()).hexdigest());bboxes.append(im.getchannel('A').getbbox());poses.append(pose)
  bg=Image.new('RGBA',(1000,800),'#d4d1c4' if i//8%2==0 else '#213039');bg.alpha_composite(im,(110,16));d=ImageDraw.Draw(bg);L.label(d,(24,18),clip.upper()+' / '+view.upper(),24,'#c5bcaa' if i//8%2 else '#263431');L.label(d,(24,752),'30 fps source | 60 Hz preview duplicates poses | approximate illustrated view',17,'#c5bcaa' if i//8%2 else '#263431');review_frames.append(bg.convert('RGB'))
  for ld in rigs[view][2]:
   js=np.array(pose[ld['id']]);rs=ld['joints'];maxbone=max(maxbone,max(abs(B.dist(js[k],js[k+1])-B.dist(rs[k],rs[k+1])) for k in range(4)))
   if clip in ['idle','mandible_attack','recoil']:contactmax=max(contactmax,B.dist(js[-1],rs[-1]))
 if view=='front':f0=B.frame(rigs[view],0,'scuttle' if clip=='scuttle_front' else clip)[0];fe=B.frame(rigs[view],1,'scuttle' if clip=='scuttle_front' else clip)[0]
 else:f0=A.frame(rigs[view],0)[0];fe=A.frame(rigs[view],1)[0]
 diff=int(np.max(np.abs(np.array(f0,dtype=int)-np.array(fe,dtype=int))))
 rows=math.ceil(n/8);atlas=Image.new('RGBA',(3136,392*rows));rects=[]
 for i,im in enumerate(tiles):
  x=(i%8)*392+4;y=(i//8)*392+4;atlas.alpha_composite(im,(x,y));rects.append({'frame':i,'rect':[x,y,384,384],'pivot_px':[192,260]})
 atlas.save(O/f'atlases/{clip}_384.png');(O/f'atlases/{clip}_384.json').write_text(json.dumps({'image':f'{clip}_384.png','source_fps':30,'padding_px':4,'rects':rects},indent=2))
 meta={'clip':clip,'view':view,'frame_count':n,'source_fps':30,'duration_seconds':n/30,'loop':loop,'ground_anchor_px':[384,520],'pivot_normalized_bottom_left':[.5,248/768],'in_place':True,'view_accuracy':'approximate illustrated view; not a calibrated exact heading','root_motion_note':'For scuttle, stance moves backward in sprite. Advance actor along heading to keep world contacts stationary. Other clips keep all six contacts planted.','footprint':poses,'source_is_cutout':True}
 if clip.startswith('scuttle'):
  stride=44*.42 if view=='front' else 26*A.VIEWS[view]['scale'];direction=[-.866,.5] if view=='front' else A.VIEWS[view]['direction'];meta['suggested_screen_velocity_master_px_per_second']=[v*stride/(.62*(n/30)) for v in direction];meta['stance_duty_fraction']=.62
 (O/f'animation/{clip}.json').write_text(json.dumps(meta,indent=2))
 allqa[clip]={'frames':n,'unique_pixel_frames':len(set(hashes)),'maximum_segment_length_error_source_px':maxbone,'maximum_planted_contact_error_source_px':contactmax if clip in ['idle','mandible_attack','recoil'] else None,'loop_endpoint_max_channel_difference':diff if loop else None,'oneshot_returns_to_rest':diff==0 if not loop else None,'minimum_padding_px':min(min(bb[0],bb[1],768-bb[2],768-bb[3]) for bb in bboxes)}
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-framerate','30','-i',str(out/'%03d.png'),'-filter_complex','color=c=0x213039:s=768x768:r=30[bg];[bg][0:v]overlay=shortest=1,fps=60,format=yuv420p','-c:v','libx264','-crf','16','-y',str(O/f'review/{clip}_60Hz.mp4')],check=True)
 if view=='front' and clip=='idle':f0.save(O/'stills/front_rest.png')
 elif view in ['side','rear']:f0.save(O/f'stills/{view}_rest.png')
 print(clip,allqa[clip],flush=True)
# Persistent proof frame samples: anticipation, impact, recovery and loop extrema.
sheet=Image.new('RGB',(1800,1430),'#d8d4c7');d=ImageDraw.Draw(sheet);L.label(d,(30,22),'CLOCKWORK BEETLE / SOURCE-INK MOTION REVIEW',28)
for row,(clip,view,n,loop) in enumerate(clips):
 L.label(d,(22,95+row*210),clip.upper(),17)
 for col,fr in enumerate([0,n//4,n//2,(3*n)//4,n-1]):
  im=Image.open(O/f'frames_768/{clip}/{fr:03}.png');im=L.cropthumb(im,(245,160));x=290+col*295;y=78+row*210;sheet.paste(im,(x+(245-im.width)//2,y),im);L.label(d,(x,y+165),f'{fr:02}',14)
L.label(d,(30,1365),'Each view uses one authored source master; no regenerated frames. Original calibrated 3D source retained separately.',18);sheet.save(O/'review/All_Motion_Phases.jpg',quality=95)
# Three resting view drawings and prior vs new art.
three=Image.new('RGB',(1800,1040),'#d8d4c7');d=ImageDraw.Draw(three);L.label(d,(30,22),'CLOCKWORK BEETLE / THREE SOURCE DRAWINGS',28);L.label(d,(30,66),'Front, right-facing oblique and rear oblique | all are approximate illustrated viewpoints',20)
for col,v in enumerate(['front','side','rear']):
 im=Image.open(O/f'stills/{v}_rest.png');th=L.cropthumb(im,(540,550));three.paste(th,(30+col*600+(540-th.width)//2,160),th);L.label(d,(40+col*600,755),v.upper(),21);sm=L.cropthumb(im,(195,155));three.paste(sm,(200+col*600,830),sm)
three.save(O/'review/Three_Rest_Views.jpg',quality=95)
comp=Image.new('RGB',(1500,980),'#d8d4c7');d=ImageDraw.Draw(comp);L.label(d,(30,23),'CLOCKWORK BEETLE / BEFORE AND AFTER',28)
for x,p,title in [(20,Path('lantern_overnight/06_clockwork_beetle/png/clockwork_beetle_yaw_000.png'),'BEFORE / CALIBRATED 3D STUDY'),(775,O/'stills/front_rest.png','AFTER / ILLUSTRATED CUTOUT STUDY')]:
 im=Image.open(p);th=L.cropthumb(im,(680,610));comp.paste(th,(x+(680-th.width)//2,120),th);L.label(d,(x+20,770),title,20);th=L.cropthumb(im,(190,150));comp.paste(th,(x+240,810),th)
comp.save(O/'review/Before_After.jpg',quality=95)
# Encode all source poses in one uninterrupted review, at duplicate-pose 60 Hz.
subprocess.run([sys.executable,str(Path(__file__).with_name('build_review_video.py'))],check=True)
for f in [Path('lantern_overnight/06_clockwork_beetle/Clockwork_Beetle_Source.blend'),Path('lantern_overnight/06_clockwork_beetle/scuttle_proof/Clockwork_Beetle_Scuttle_Source.blend')]+list(Path('lantern_overnight/07_clockwork_beetle_motion/source/actions').glob('*.blend')):shutil.copy(f,O/'technical_reference'/f.name)
(O/'technical_reference/README.txt').write_text('These unchanged prior Blender rigs retain exact projection, rigging, heading and action evidence. They are technical references, not preferred revision-02 visuals. Do not substitute their old low-poly render output for the new illustrated sprites.\n')
(O/'qa/validation.json').write_text(json.dumps({'clips':allqa,'all_frames_rgba':True,'canvas':[768,768],'source_fps':30,'preview_hz':60,'preview_is_duplicate_pose_display':True,'ground_anchor_px':[384,520],'canonical_hero_unchanged':True,'projection_claim':'Illustrated approximations. Ground diagnostics use exact target camera mathematics, inferred from artwork.'},indent=2))
print('DONE',flush=True)
