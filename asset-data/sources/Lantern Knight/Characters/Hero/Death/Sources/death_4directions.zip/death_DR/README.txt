LANTERN DEATH DR — backward_collapse.
6 complete unique native drawings. Presentation at60Hz using unequal integer holds. Terminal drawing remains held indefinitely; this is not a loop. 
Human articulation reviewed by producer, independent reviewer and parent. Native test integration remains approximate; read limitations in clip.json.

No upscaling, mirroring, per-frame scale fitting, or pixel interpolation. Native source grid and padding are recorded in clip.json. Art approval is a separate human judgment.
