from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
from scipy.ndimage import label,binary_dilation,binary_fill_holes
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve
from scipy.spatial import ConvexHull
P=Path(__file__).parent
# Six isolated wrong-side cloth patches, no body/limb/prop geometry touched.
src=P/'source/death_UR_kneel_v01_native.png';a=np.array(Image.open(src).convert('RGBA'));original=a.copy();fullmask=np.zeros(a.shape[:2],bool)
regions=[(290,295,350,380),(790,260,850,340),(1280,340,1360,430),(300,798,350,842),(775,815,850,900),(1250,810,1330,890)]
records=[]
for x0,y0,x1,y1 in regions:
 crop=a[y0:y1,x0:x1];m=(crop[:,:,0]>70)&(crop[:,:,0]<180)&(crop[:,:,1]>crop[:,:,0]*.63)&(crop[:,:,2]>crop[:,:,0]*.4)&(crop[:,:,3]>200);ls,n=label(m);counts=np.bincount(ls.ravel());counts[0]=0;m=ls==counts.argmax();ys,xs=np.where(m)
 hull=ConvexHull(np.array([xs,ys]).T);poly=[(int(xs[i]+x0),int(ys[i]+y0)) for i in hull.vertices];maskim=Image.new('1',(a.shape[1],a.shape[0]));ImageDraw.Draw(maskim).polygon(poly,fill=1);mask=binary_dilation(np.array(maskim),iterations=3);mask=binary_fill_holes(mask);fullmask|=mask
 ys,xs=np.where(mask);index={(y,x):i for i,(y,x) in enumerate(zip(ys,xs))};A=lil_matrix((len(ys),len(ys)));b=np.zeros((len(ys),3))
 for i,(y,x) in enumerate(zip(ys,xs)):
  A[i,i]=4
  for yy,xx in [(y-1,x),(y+1,x),(y,x-1),(y,x+1)]:
   j=index.get((yy,xx))
   if j is None:b[i]+=a[yy,xx,:3]
   else:A[i,j]=-1
 a[ys,xs,:3]=np.clip(spsolve(A.tocsr(),b),0,255).astype(np.uint8);records.append({'mask_pixels':len(ys),'bounded_search_region':[x0,y0,x1,y1]})
Image.fromarray(a).save(P/'source/death_UR_kneel_v01_corrected_native.png');Image.fromarray((fullmask*255).astype('uint8')).save(P/'qa/death_UR_right_coat_patch_masks.png')
# UL source cel6 has a clipped outermost sword tip. Use complete cel5 as the terminal.
# Traditionally paint only the glass interiors to extinguish its last ember. Native pixels,
# source body/prop silhouette, lamp cage, floor position and all other cels unchanged.
srcUL=P/'source/death_UL_kneel_v01_native.png';a=np.array(Image.open(srcUL).convert('RGBA'));mask=Image.new('L',(a.shape[1],a.shape[0]));dr=ImageDraw.Draw(mask)
planes=[([(624,873),(635,877),(635,910),(624,905)],(47,43,36)), ([(641,879),(665,871),(665,908),(641,916)],(59,52,41))]
for pts,col in planes:
 local=Image.new('L',mask.size);ImageDraw.Draw(local).polygon(pts,fill=255);m=np.array(local)>0
 # Preserve existing very dark cage/ink pixels within the glass planes.
 m &= a[:,:,:3].max(axis=2)>55
 a[m,:3]=col;dr.polygon(pts,fill=255)
Image.fromarray(a).save(P/'source/death_UL_kneel_v01_terminal5_dark_native.png');mask.save(P/'qa/death_UL_terminal5_glass_masks.png')
meta={'operations':['UR: classical harmonic rust-cloth fill only inside6isolated traced/detected wrong right-coat patch masks. Alpha and every pixel outside masks unchanged.','UL: complete original cel5chosen as terminal because cel6swordtip reaches/clips native source edge. Only two lamp glass interiors in cel5painted dark with existing ink/cage retained. No blade/body/hand pixel changed.'],'no_scaling_mirroring_warping':True,'patch_records':records,'limits':['Traditional glass repaint is an extinguish-state correction, not a new full-body drawing. UL count remains5.','No exact floor collision calibration implied.']}
(P/'qa/traditional_corrections.json').write_text(json.dumps(meta,indent=2))
for name in ['death_UR_kneel_v01_corrected','death_UL_kneel_v01_terminal5_dark']:
 im=Image.open(P/f'source/{name}_native.png').convert('RGBA');b=Image.new('RGBA',im.size,(231,233,234,255));b.alpha_composite(im);b.convert('RGB').save(P/f'qa/{name}_neutral.png')
