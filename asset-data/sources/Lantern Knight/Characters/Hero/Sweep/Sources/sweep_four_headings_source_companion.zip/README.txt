LANTERN SWEEP — SOURCE COMPANION

Four true actor headings; nine selected drawings per complete action. This companion contains the high-resolution+X native masters and saved cleanup originals/masks, the three new eight-action native sheets and extracted native cels, prompts, source hashes, small extraction/density metadata, unified animation manifests and camera/prop contracts.

Extract beside or into the runtime archive to restore the shared clips/<direction>/ paths. Runtime PNGs, atlases, the ready textures and offline player are in the runtime archive. Combined preview MP4 is delivered separately.

No new art processing was performed for this split. All source files are byte-identical to the preserved full bundle. The full bundle and original runtime source folder remain unchanged. The documented native-test limitations, sharedready occlusion, legacy+X ready and approximate registration still apply.
