FOUR TRUE LOW-CARRY LUNGE HEADINGS: DRworld+X,DLworld+Z,ULworld−X,URworld−Z.

Native action-art tests, not certified drop-in runtime assets. All four share the same elevated camera construction and comfortable low lantern carry. Every source sheet has8drawings and is preserved. Unequal timing is54ticks/0.9s at60Hz. Exact-loop previews repeat firstReady: DR/UL/URuse7unique drawings; DLuses6after omitting a faulty retractdrawing. Originals remain available.

No mirroring, per-framefit, imageupscaling, sourcewarp or bodyrepaint. Fixedsheetorigins and commonpadding peraction retainsourcefoot/bodydrift. One approximate PPU andpivot peraction matches sharedreadyworldsize; uncertainty explicitlyrecorded. This metadata does not prove physicallyplantedfeet or exactprojection of illustratedpixels.

CurrentDRnativeZIP was keptunchanged; its small integrationcompanion is added here. Rejectedoverhead20frameversion is excluded. Rootmust review humanposes and sequences beforedelivery. No newinbetweens.
