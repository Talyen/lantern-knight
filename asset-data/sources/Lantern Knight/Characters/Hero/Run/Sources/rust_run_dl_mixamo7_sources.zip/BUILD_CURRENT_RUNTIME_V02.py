"""Rebuild current QA v02 native frames and atlas. Requires Python 3, Pillow, NumPy.
Run: python BUILD_CURRENT_RUNTIME_V02.py [output_directory]
The raw paintings stay unchanged. Only the documented sparse QA pixel patch is applied.
"""
from pathlib import Path
from PIL import Image
import numpy as np, json, hashlib, sys
R=Path(__file__).resolve().parent
O=Path(sys.argv[1]) if len(sys.argv)>1 else R/'rebuilt_runtime_v02'
O.mkdir(parents=True,exist_ok=True);(O/'frames').mkdir(exist_ok=True)
c=json.load(open(R/'qa_v02/rebuild_contract.json'));m=json.load(open(R/'qa_v02/runtime_manifest_v02.json'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(R/c['source_sheet'])==m['source_sheet_sha256'], 'Raw source hash mismatch'
src=Image.open(R/c['source_sheet']).convert('RGBA');atlas=Image.new('RGBA',c['atlas_size'])
patch=np.array(Image.open(R/'qa_v02/frame_patch_rgba.png'));mask=np.array(Image.open(R/'qa_v02/exact_changed_pixel_mask.png'))>0
results=[]
for f in m['frames']:
 a=np.array(src.crop(f['source_sheet_rect']));a[a[:,:,3]==0]=0
 for x,y,x1,y1 in f.get('source_cell_exclusions',[]):a[y:y1,x:x1]=0
 im=Image.new('RGBA',m['canvas']);im.paste(Image.fromarray(a),tuple(f['common_canvas_translation']))
 if f['index']==c['patched_frame_index']:
  a=np.array(im);a[mask]=patch[mask];im=Image.fromarray(a)
 target=O/f['file'];im.save(target)
 assert sha(target)==f['sha256'], 'Frame hash mismatch: '+f['file']
 x,y,w,h=f['atlas_rect'];tx,ty=f['common_canvas_translation'];atlas.paste(im.crop((tx,ty,tx+w,ty+h)),(x,y))
 results.append({'file':f['file'],'sha256':sha(target),'exact_runtime_v02_hash':True})
atlas.save(O/'atlas.png');assert sha(O/'atlas.png')==c['expected_atlas_sha256'],'Atlas hash mismatch'
(O/'manifest.json').write_bytes((R/'qa_v02/runtime_manifest_v02.json').read_bytes())
report={'all_current_frame_and_atlas_hashes_match':True,'frames':results,'atlas_sha256':sha(O/'atlas.png'),'engine_verified':False}
(O/'rebuild_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
