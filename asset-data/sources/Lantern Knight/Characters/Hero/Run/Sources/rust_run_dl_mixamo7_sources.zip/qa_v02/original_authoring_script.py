from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import shutil,json,hashlib
from scipy.ndimage import label
R=Path(__file__).parent; O=R/'corrected_v02';O.mkdir(exist_ok=True)
for d in ['DL','UL']:
 if not (O/d).exists():shutil.copytree(R/d,O/d)
# Remove exactly the disconnected visible fragment, not any character pixel.
p=O/'UL/frames/run_03.png'; a=np.array(Image.open(R/'UL/frames/run_03.png'));l,n=label(a[:,:,3]>0); lab=l[942,690];mask=l==lab;assert mask.sum()==405
m=Image.fromarray((mask*255).astype('uint8'));m.save(O/'UL_fragment_mask.png');a[mask]=0;Image.fromarray(a).save(p)
# Transfer only the internal shaft/cuff detail from same anatomical boot in prior cel.
src=np.array(Image.open(R/'DL/frames/run_04.png'));dst=np.array(Image.open(R/'DL/frames/run_05.png'))
s=np.float32([[701,801],[740,794],[747,847],[714,848]])
t=np.float32([[703,817],[737,814],[732,858],[705,858]])
A=[];B=[]
for (x,y),(u,v) in zip(t,s):
 A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);B.extend([u,v])
coef=np.linalg.solve(np.array(A),np.array(B));warped=np.array(Image.fromarray(src).transform((dst.shape[1],dst.shape[0]),Image.Transform.PERSPECTIVE,coef,Image.Resampling.BICUBIC))
ma=Image.new('L',(dst.shape[1],dst.shape[0]));ImageDraw.Draw(ma).polygon([tuple(v) for v in t],fill=255);ma=ma.filter(ImageFilter.GaussianBlur(.65));mix=np.array(ma)/255;mix*=((dst[:,:,3]>200)&(warped[:,:,3]>200));out=dst.copy();out[:,:,:3]=np.round(dst[:,:,:3]*(1-mix[:,:,None])+warped[:,:,:3]*mix[:,:,None]).astype('uint8');# Reinforce existing toe-cap and instep seam paths with subpixel leather ink/highlight.
seam=Image.new('RGBA',(dst.shape[1]*4,dst.shape[0]*4)); sd=ImageDraw.Draw(seam)
paths=[[(682,881),(685,882.5),(688,886),(690,891)],[(701,864),(706,867),(711,872),(715,878)]]
for pts in paths:
 sd.line([(round(x*4),round(y*4)) for x,y in pts],fill=(38,24,16,145),width=3,joint='curve')
 sd.line([(round((x-.6)*4),round((y-.7)*4)) for x,y in pts],fill=(111,75,47,110),width=2,joint='curve')
se=np.array(seam.resize((dst.shape[1],dst.shape[0]),Image.Resampling.LANCZOS));sm=se[:,:,3]/255;sm*=dst[:,:,3]>200
out[:,:,:3]=np.round(out[:,:,:3]*(1-sm[:,:,None])+se[:,:,:3]*sm[:,:,None]).astype('uint8')
Image.fromarray(out).save(O/'DL/frames/run_05.png');Image.fromarray(np.uint8(np.maximum(mix,sm)*255)).save(O/'DL_boot_detail_mask.png')
# comparison
cn=Image.new('RGB',(750,420),'#ddd');dr=ImageDraw.Draw(cn)
for i,(title,im) in enumerate([('Before',Image.fromarray(dst)),('After',Image.fromarray(out)),('Donor run04',Image.fromarray(src))]):
 cr=im.crop((650,790,760,918)).resize((220,256));cn.paste(cr,(i*250+10,40),cr);dr.text((i*250+10,10),title,fill='black')
cn.save(O/'DL_boot_before_after.png')
