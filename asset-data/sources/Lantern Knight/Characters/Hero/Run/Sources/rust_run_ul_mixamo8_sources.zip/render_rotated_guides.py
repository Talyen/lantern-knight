from pathlib import Path
import sys,json,math
import numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).parent;C=P.parent/'run_repair_v04/volume_guides/production_camera_35p264_world45';sys.path.insert(0,str(C));from shared_volume_renderer import render_objects,namespace
from shared_camera import LOCAL_TO_CAMERA
SRC=C/'mixamo_torch_run8_source_follow';crop=(250,260,950,960);S=350;root=np.array([635,800]);cam=LOCAL_TO_CAMERA[:2]
raw=(C.parent/'render_right_contact_cuff_landmarks.py').read_text();triangle_code='for mi,m in enumerate(meshes):'+raw.split('for mi,m in enumerate(meshes):')[1].split('out=BASE/')[0]
for label,deg,forward in [('DL',-90,[0,0,1]),('UL',180,[-1,0,0]),('UR',90,[0,0,-1])]:
 crop={'DL':(250,260,950,960),'UL':(250,200,950,900),'UR':(350,200,1050,900)}[label]
 out=P/'guides'/label;out.mkdir(exist_ok=True);th=math.radians(deg);rot=np.array([[math.cos(th),-math.sin(th),0],[math.sin(th),math.cos(th),0],[0,0,1.]])
 sheet=Image.new('RGB',(2048,1024),(238,240,235));records=[]
 for i,t in enumerate(range(0,40,5)):
  d=json.load(open(SRC/f'tick_{t:02d}/provenance.json'));objects=[];bounds=[]
  for orig in d['ellipsoids']:
   obj=dict(orig);center=rot@np.array(orig['center']);axes=rot@np.array(orig['axes']);obj['center']=center.tolist();obj['axes']=axes.tolist();objects.append(obj)
   uv=root+S*cam@center;ext=S*np.sqrt(np.sum((cam@axes*np.array(orig['radii'])[None,:])**2,axis=1));bounds.extend([uv-ext,uv+ext])
  meshes=[]
  for orig in d['sword_meshes']:
   obj=dict(orig);vv=np.array(orig['vertices'])@rot.T;obj['vertices']=vv.tolist();meshes.append(obj);bounds.extend(root+S*vv@cam.T)
  bounds=np.array(bounds);bbox=[*bounds.min(0),*bounds.max(0)];fits=bbox[0]>=crop[0]and bbox[1]>=crop[1]and bbox[2]<crop[2]and bbox[3]<crop[3]
  assert fits,(label,t,bbox)
  if label in ['DL','UL'] and (out/f'tick_{t:02d}.png').exists():cell=Image.open(out/f'tick_{t:02d}.png').convert('RGB')
  else:
   im,ids,depth=render_objects(objects);g=dict(namespace);g.update(objects=objects,meshes=meshes,im=im,ids=ids,depth=depth,rgb=np.array(im,dtype=float));exec(compile(triangle_code,'rotated_rigid_meshes','exec'),g);im=Image.fromarray(np.uint8(g['rgb']));cell=im.crop(crop).resize((512,512),Image.Resampling.LANCZOS);cell.save(out/f'tick_{t:02d}.png')
  sheet.paste(cell,((i%4)*512,(i//4)*512));records.append({'tick':t,'source_provenance':str(SRC/f'tick_{t:02d}/provenance.json'),'rotated_local_joints':{k:(rot@v).tolist()for k,v in d['local_joints'].items()},'projected_geometry_bbox_master':bbox,'fits_common_crop':bool(fits)});print(label,t,flush=True)
 sheet.save(out/'run8_guide_sheet.png');(out/'manifest.json').write_text(json.dumps({'screen_label':label,'actor_forward_world':forward,'local_rotation_degrees':deg,'rotation_matrix_local':rot.tolist(),'rotation_determinant':float(np.linalg.det(rot)),'camera_unchanged':True,'body_and_prop_geometry':'Rigid actor rotation only; no pose, scale, proportion or mesh changes. Source joint relative distances invariant.','source_ticks':list(range(0,40,5)),'cycle_ticks':40,'crop_master':crop,'reference_ppu':350,'cell_size':[512,512],'cell_root':[(635-crop[0])*512/700,(800-crop[1])*512/700],'frames':records},indent=2))
 print('DONE',label,flush=True)
