"""One bounded traditional cloth cleanup. Source and every alpha/silhouette pixel stay unchanged."""
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
from scipy.ndimage import label,binary_fill_holes,binary_dilation
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve
P=Path(__file__).resolve().parent;SRC=P/'source/UR_lowcarry8_native.png';im=Image.open(SRC).convert('RGBA');a=np.array(im);out=a.copy();fullmask=np.zeros(a.shape[:2],bool);records=[]
# Tight native cel-space bounds enclosing only each tan patch and its stitching.
boxes=[(267,141,289,162),(274,130,294,150),(276,136,295,156),(268,146,289,168),(244,121,270,143),(253,130,278,160),(263,133,288,165),(277,140,300,166)]
centers=[(277,152),(283,141),(285,147),(278,157),(256,132),(266,146),(276,149),(289,153)]
for i,(box,center) in enumerate(zip(boxes,centers)):
 ox=round(i%4*im.width/4);oy=round(i//4*im.height/2);x0,y0,x1,y1=box;x0+=ox;x1+=ox;y0+=oy;y1+=oy
 # Color detection selects the patch; explicit bounds stop selection at the cuff.
 crop=a[y0:y1,x0:x1];rgb=crop[:,:,:3].astype(float);r,g,b=rgb.transpose(2,0,1);seed=(g/r.clip(1)>.72)&(b/r.clip(1)>.48)&(r>55)&(g>45)&(crop[:,:,3]>250)
 lab,n=label(seed);counts=np.bincount(lab.ravel());selected=int(np.argmax(counts[1:])+1);core=lab==selected;m=binary_dilation(binary_fill_holes(core),iterations=2)
 # Leave cream cuff, skin, transparent edges and the sleeve outer contour untouched.
 cream=(r>150)&(g>135)&(b>105)&(g/r.clip(1)>.77);m &= ~cream;m &= crop[:,:,3]>=250
 # Reconstruct rust-cloth field from immediate unchanged boundary, using harmonic interpolation.
 ys,xs=np.where(m);index={tuple(v):k for k,v in enumerate(zip(ys,xs))};A=lil_matrix((len(ys),len(ys)));B=np.zeros((len(ys),3))
 for k,(y,x) in enumerate(zip(ys,xs)):
  A[k,k]=4
  for dy,dx in [(-1,0),(1,0),(0,-1),(0,1)]:
   yy=y+dy;xx=x+dx;j=index.get((yy,xx))
   if j is None:B[k]+=a[y0+yy,x0+xx,:3]
   else:A[k,j]=-1
 colors=np.clip(spsolve(A.tocsr(),B),0,255).astype(np.uint8);out[y0+ys,x0+xs,:3]=colors;fullmask[y0:y1,x0:x1]|=m
 records.append({'cel':i+1,'mask_bounds_native_cel':box,'patched_pixels':int(m.sum()),'method':'Classical harmonic interpolation of immediate neighboring rust-cloth RGB inside tightly bounded patch/stitch mask. No generative inpainting.'})
result=P/'source/UR_lowcarry8_cloth_cleanup_v01.png';Image.fromarray(out).save(result);Image.fromarray(fullmask.astype('uint8')*255).save(P/'metadata/right_sleeve_patch_mask_v01.png');changed=np.any(a!=out,axis=2)
assert np.array_equal(a[:,:,3],out[:,:,3]);assert not np.any(changed&~fullmask);assert np.all(a[:,:,3][fullmask]>=250)
# Native-size before/after patch crops. No image resampling.
comparison=Image.new('RGB',(8*100,280),(191,196,196));dd=ImageDraw.Draw(comparison)
for i,(box,_) in enumerate(zip(boxes,centers)):
 ox=round(i%4*im.width/4);oy=round(i//4*im.height/2);cx=(box[0]+box[2])//2;cy=(box[1]+box[3])//2;rect=(ox+cx-40,oy+cy-50,ox+cx+40,oy+cy+50)
 for row,arr in enumerate([a,out]):
  cr=Image.fromarray(arr).crop(rect);bg=Image.new('RGBA',cr.size,(191,196,196,255));bg.alpha_composite(cr);comparison.paste(bg.convert('RGB'),(i*100+10,row*130+22));dd.text((i*100+5,row*130+5),f'{i+1} '+('BEFORE' if row==0 else 'AFTER'),fill=(20,24,24))
comparison.save(P/'review/right_patch_before_after_native.png')
contact=Image.new('RGB',(im.width,im.height+60),(189,194,194));dd=ImageDraw.Draw(contact)
for i in range(8):
 x=i%4;y=i//4;rect=(round(x*im.width/4),round(y*im.height/2),round((x+1)*im.width/4),round((y+1)*im.height/2));cr=Image.fromarray(out).crop(rect);cr.save(P/f'review/clean_cel_{i+1:02d}_native.png');bg=Image.new('RGBA',cr.size,(189,194,194,255));bg.alpha_composite(cr);contact.paste(bg.convert('RGB'),(rect[0],rect[1]+30*(y+1)));dd.text((rect[0]+8,rect[1]+30*y+8),f'CEL {i+1}  TICK {i*5}  CLOTH CLEANUP',fill=(22,24,23))
contact.save(P/'review/lowcarry8_clean_contact_gray.png');report={'status':'ONE_TRADITIONAL_CLEANUP_CANDIDATE_PENDING_VISUAL_REVIEW','source':str(SRC),'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'output':str(result),'output_sha256':hashlib.sha256(result.read_bytes()).hexdigest(),'mask':'metadata/right_sleeve_patch_mask_v01.png','native_size':im.size,'changed_pixels':int(changed.sum()),'mask_pixels':int(fullmask.sum()),'outside_mask_identical':bool(not np.any(changed&~fullmask)),'alpha_identical':bool(np.array_equal(a[:,:,3],out[:,:,3])),'all_edited_pixels_originally_near_opaque_250plus':bool(np.all(a[:,:,3][fullmask]>=250)),'scope':'Only erroneous right upper sleeve patch/stitches. No arm outline, skin, cuff, wrap, prop, pose, silhouette or alpha changes. No imagegen. No scale or per-frame fit.','records':records};(P/'metadata/right_sleeve_patch_cleanup_v01.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
