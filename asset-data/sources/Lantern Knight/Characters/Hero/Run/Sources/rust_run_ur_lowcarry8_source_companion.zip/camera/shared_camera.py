"""Shared camera contract for run/lunge/sweep. World Y-up, XZ ground. No motion edits."""
import numpy as np
ELEVATION_DEG=35.264389682754654
WORLD_AZIMUTH_DEG=45.0 # atan2(camera Z offset,camera X offset)
WORLD_UP=np.array([0.,1.,0.])
TARGET_TO_CAMERA=np.array([1.,1.,1.])/np.sqrt(3)
SCREEN_RIGHT_WORLD=np.array([1.,0.,-1.])/np.sqrt(2)
SCREEN_UP_WORLD=np.array([-1.,2.,-1.])/np.sqrt(6)
WORLD_TO_CAMERA=np.stack([SCREEN_RIGHT_WORLD,-SCREEN_UP_WORLD,TARGET_TO_CAMERA])
# Columns are old anatomical local forward, far/left, up in world space.
# local +X -> world +X, local +Y -> world -Z, local +Z -> world +Y.
LOCAL_TO_WORLD=np.array([[1.,0.,0.],[0.,0.,1.],[0.,-1.,0.]])
LOCAL_TO_CAMERA=WORLD_TO_CAMERA@LOCAL_TO_WORLD
GAMEPLAY_VERTICAL_SPAN_METERS=13.0
UNITY_ORTHOGRAPHIC_SIZE=6.5
ART_MASTER_PIXELS_PER_METER=350.0
ART_CANVAS=(1280,1000)
ART_FOOT_ROOT=(635.,800.) # Projection of fixed world origin at ground level, NOT a per-frame fitted foot.
ART_CLOSE_CROP=(350,260,980,950)
ART_CLOSE_RESIZE=2

def local_to_world(points,actor_heading_degrees=0.,origin=(0,0,0)):
 # Positive heading takes world+X toward world+Z; independent of locked camera.
 a=np.deg2rad(actor_heading_degrees);c,s=np.cos(a),np.sin(a)
 yaw=np.array([[c,0,-s],[0,1,0],[s,0,c]])
 return np.asarray(points)@(yaw@LOCAL_TO_WORLD).T+np.asarray(origin)

def project_world(points,root=ART_FOOT_ROOT,pixels_per_meter=ART_MASTER_PIXELS_PER_METER):
 return np.asarray(root)+pixels_per_meter*(np.asarray(points)@WORLD_TO_CAMERA.T)[...,:2]

def project_local(points,root=ART_FOOT_ROOT,pixels_per_meter=ART_MASTER_PIXELS_PER_METER,actor_heading_degrees=0.):
 return project_world(local_to_world(points,actor_heading_degrees),root,pixels_per_meter)
