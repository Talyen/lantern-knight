from pathlib import Path
import sys,json,math,copy,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent
C=P.parent/'run_repair_v04/volume_guides/production_camera_35p264_world45'
sys.path.insert(0,str(C))
from shared_camera import LOCAL_TO_CAMERA,LOCAL_TO_WORLD,ELEVATION_DEG,WORLD_AZIMUTH_DEG
from shared_volume_renderer import render_objects,namespace
SRC=C/'mixamo_torch_run8_source_follow'
TICKS=list(range(0,40,5));ROT=np.array([[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]])
CROP=(270,200,1070,1000);CELL=512;ROOT=np.array([635.,800.]);PPM=350.
source=[json.load(open(SRC/f'tick_{t:02d}/provenance.json')) for t in TICKS]
yaws=np.array([math.atan2(d['torso_axes_local'][0][1],d['torso_axes_local'][1][1]) for d in source]);phase=(yaws-yaws.mean())/max(abs(yaws-yaws.mean()))
def unit(a):return a/np.linalg.norm(a)
def axes(a,b):
 z=unit(b-a);seed=np.array([0.,1.,0.])
 if abs(z@seed)>.95:seed=np.array([1.,0.,0.])
 x=unit(np.cross(seed,z));return np.stack([x,np.cross(z,x),z],axis=1)
def ell(name,c,r,color,ax=np.eye(3)):
 return dict(name=name,center=np.array(c).tolist(),radii=list(r),axes=np.array(ax).tolist(),color=color)
def bone(name,a,b,r,color,ext=.017):return ell(name,(a+b)/2,[r,r,np.linalg.norm(b-a)/2+ext],color,axes(a,b))
def project(v):return ROOT+PPM*(LOCAL_TO_CAMERA@ROT@v)[:2]
triangle_raw=(C.parent/'render_right_contact_cuff_landmarks.py').read_text()
triangle_code='for mi,m in enumerate(meshes):'+triangle_raw.split('for mi,m in enumerate(meshes):')[1].split('out=BASE/')[0]
records=[];sheet=Image.new('RGB',(2048,1024),(238,240,235));contact=Image.new('RGB',(2048,1164),(238,240,235));skeleton=Image.new('RGB',(2048,1164),(244,244,239));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
for n,(tick,d,q) in enumerate(zip(TICKS,source,phase)):
 j={k:np.array(v,dtype=float) for k,v in d['local_joints'].items()};s=j['LeftArm'];olde=j['LeftForeArm'];oldw=j['LeftHand'];a=np.linalg.norm(olde-s);b=np.linalg.norm(oldw-olde)
 # Authored low carry; source chest axial rotation modulates a small carriage swing.
 w=s+np.array([-.10+.025*q,.32+.015*q,-.330+.015*q])
 delta=w-s;distance=np.linalg.norm(delta);direction=unit(delta);pole=np.array([.40,.70,-.70]);bend=unit(pole-direction*(pole@direction));along=(a*a-b*b+distance*distance)/(2*distance);height=math.sqrt(a*a-along*along);e=s+along*direction+height*bend
 j['LeftForeArm']=e;j['LeftHand']=w
 for key in j:
  if key.startswith('LeftHand') and key!='LeftHand':j[key]=j[key]+w-oldw
 # Keep every source body/leg/right-arm primitive and rigid sword. Rebuild only left arm and one lamp.
 replaced={'Left upper arm','Left elbow','Left forearm','Left grip'}
 objects=[copy.deepcopy(x) for x in d['ellipsoids'] if x['name'] not in replaced and 'lantern' not in x['name']]
 objects += [bone('Left upper arm',s,e,.052,[38,88,215]),ell('Left elbow',e,[.045]*3,[38,88,215]),bone('Left forearm',e,w,.043,[38,88,215]),ell('Left grip',w,[.042,.042,.050],[38,88,215])]
 # Material landmarks on source-arm joints, not extra anatomy.
 objects += [ell('left cream elbow cuff',e-.012*unit(e-s),[.062,.062,.022],[241,220,175],axes(s,e)),bone('left long brown bracer',e+.05*unit(w-e),w-.035*unit(w-e),.048,[106,69,43],0)]
 angle=math.radians(3)*float(q);rr=np.array([[math.cos(angle),0,math.sin(angle)],[0,1,0],[-math.sin(angle),0,math.cos(angle)]]);center=w+rr@np.array([0.,0.,-.195]);corners=[center+rr@np.array([x,0,z]) for x,z in [(-.066,.106),(.066,.106),(.066,-.106),(-.066,-.106)]]
 for z in range(4):objects.append(bone('left lantern cage '+str(z),corners[z],corners[(z+1)%4],.014,[65,52,31],.014))
 objects.append(bone('left lantern handle',w,center+rr@np.array([0,0,.12]),.009,[65,52,31],.009));objects.append(ell('lantern glass',center,[.052,.035,.082],[255,191,51],rr))
 for ob in objects:ob['center']=(ROT@ob['center']).tolist();ob['axes']=(ROT@ob['axes']).tolist()
 meshes=copy.deepcopy(d['sword_meshes'])
 for ob in meshes:ob['vertices']=(np.array(ob['vertices'])@ROT.T).tolist()
 im,ids,depth=render_objects(objects);g=dict(namespace);g.update(objects=objects,meshes=meshes,im=im,ids=ids,depth=depth,rgb=np.array(im,dtype=float));exec(compile(triangle_code,'lowcarry_mesh_render','exec'),g);im=Image.fromarray(np.uint8(g['rgb']));folder=P/'guides'/f'tick_{tick:02d}';folder.mkdir(exist_ok=True);im.save(folder/'reference_full.png');cell=im.crop(CROP).resize((CELL,CELL),Image.Resampling.LANCZOS);cell.save(folder/'reference_cell.png');x=(n%4)*CELL;y=(n//4)*CELL;sheet.paste(cell,(x,y));contact.paste(cell,(x,(n//4)*582+55));dc=ImageDraw.Draw(contact);dc.text((x+12,(n//4)*582+6),f'Cel {n+1} / tick {tick} / left wrist {w[2]:.3f}m',font=font,fill=(23,28,30));dc.text((x+12,(n//4)*582+29),f'Elbow {math.degrees(math.acos(np.clip(unit(s-e)@unit(w-e),-1,1))):.1f} deg / low carry',font=font,fill=(23,28,30))
 sk=cell.copy();dd=ImageDraw.Draw(sk)
 pts=[]
 for k,v in [('S',s),('E',e),('W',w)]:
  uv=(project(v)-CROP[:2])*CELL/800;pts.append(tuple(uv));dd.ellipse((uv[0]-5,uv[1]-5,uv[0]+5,uv[1]+5),fill=(255,245,50),outline=(30,30,30),width=2);dd.text((uv[0]+7,uv[1]-10),k,font=font,fill=(25,20,20))
 dd.line(pts,fill=(255,230,20),width=3);skeleton.paste(sk,(x,(n//4)*582+55));ImageDraw.Draw(skeleton).text((x+12,(n//4)*582+8),f'Cel {n+1}: S shoulder / E elbow / W wrist',font=font,fill=(25,25,25))
 lengths=[float(np.linalg.norm(e-s)),float(np.linalg.norm(w-e))];chest=(j['Spine1']+j['Neck'])/2
 r={'cel':n+1,'source_tick':tick,'torso_yaw_phase_signal':float(q),'source_upper_arm_m':float(a),'source_forearm_m':float(b),'adapted_upper_arm_m':lengths[0],'adapted_forearm_m':lengths[1],'length_error_m':[lengths[0]-float(a),lengths[1]-float(b)],'left_shoulder_local_before_heading':s.tolist(),'left_elbow_local_before_heading':e.tolist(),'left_wrist_local_before_heading':w.tolist(),'source_left_elbow':olde.tolist(),'source_left_wrist':oldw.tolist(),'elbow_interior_degrees':float(math.degrees(math.acos(np.clip(unit(s-e)@unit(w-e),-1,1)))),'wrist_below_chest_m':float(chest[2]-w[2]),'wrist_below_shoulder_m':float(s[2]-w[2]),'wrist_forward_of_shoulder_m':float(w[0]-s[0]),'elbow_below_shoulder_m':float(s[2]-e[2]),'lantern_center_m':center.tolist(),'lantern_bottom_height_m':float(min(v[2] for v in corners)-.014),'projected_wrist_cell':((project(w)-CROP[:2])*CELL/800).tolist(),'projected_root_cell':((ROOT-CROP[:2])*CELL/800).tolist(),'local_joints_after_heading':{k:(ROT@v).tolist() for k,v in j.items()},'ellipsoids':objects,'sword_meshes':meshes}
 (folder/'provenance.json').write_text(json.dumps(r,indent=2));records.append(r);print('READY',tick,flush=True)
sheet.save(P/'guides/lowcarry_guide_sheet.png');contact.save(P/'guides/lowcarry_labeled_contact.png');skeleton.save(P/'guides/lowcarry_joint_proof.png')
meta={'status':'LOW_CARRY_GUIDE_TEST_NOT_UNALTERED_MOCAP','adaptation':'Source Standing Torch Run Forward body, legs, right-arm motion and root bob retained. Left elbow/wrist intentionally reauthored as a low carry using exact-length two-bone IK with outward-forward elbow pole. Small wrist/carriage swing is driven by sampled source shoulder-axis yaw. No source finger/axial hand rotation claim.','unmodified_source_joints':[k for k in j if k!='LeftForeArm' and not k.startswith('LeftHand')],'camera_elevation_deg':ELEVATION_DEG,'camera_world_azimuth_deg':WORLD_AZIMUTH_DEG,'world_heading':[0,0,-1],'screen_heading':'UR','camera_changed':False,'source_ticks':TICKS,'duration_ticks':40,'fps':60,'blade_length_m':.78,'sword_grip_to_tip_m':.855,'grid':[4,2],'cell_size':[CELL,CELL],'reference_ppm':PPM,'common_crop':CROP,'cell_root':((ROOT-CROP[:2])*CELL/800).tolist(),'frames':records}
(P/'metadata/guide_manifest.json').write_text(json.dumps(meta,indent=2));print('COMPLETE',str(P/'guides/lowcarry_guide_sheet.png'))
