from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
from scipy.ndimage import label,binary_dilation
p=Path(__file__).parent;src=p/'source/mixamo_eight_v01_native.png';a=np.array(Image.open(src).convert('RGBA'));rgb=a[:,:,:3].astype(float);r,g,b=rgb.transpose(2,0,1);v=rgb.max(2);sat=(v-rgb.min(2))/np.maximum(v,1);yy,xx=np.indices(v.shape);roi=(yy%(a.shape[0]/2))>a.shape[0]/2*.30
color=((r>g*1.28)&(b>g*1.15)&(r>b*.87))|((b>r*1.22)&(b>g*1.18));seed=roi&color&(sat>.25)&(a[:,:,3]>32);labs,n=label(seed);sizes=np.bincount(labs.ravel());ok=np.flatnonzero(sizes>=8);ok=ok[ok!=0];sel=binary_dilation(np.isin(labs,ok),iterations=2)&color&(sat>.20)&(a[:,:,3]>0)&roi
weight=np.where(sel,np.clip((sat-.20)/.24,0,1),0);target=(v*.30+8)[...,None]*np.array([1,.97,.94]);z=a.copy();z[:,:,:3]=np.rint(rgb*(1-weight[...,None])+target*weight[...,None]).clip(0,255).astype('uint8');changed=np.any(a!=z,2)
Image.fromarray(z).save(p/'source/mixamo_eight_charcoal_v01.png');Image.fromarray((changed*255).astype('uint8')).save(p/'metadata/charcoal_mask_v01.png');bg=Image.new('RGBA',(a.shape[1],a.shape[0]),(187,193,196,255));bg.alpha_composite(Image.fromarray(z));bg.convert('RGB').save(p/'review/mixamo_eight_charcoal_v01_gray.jpg')
(p/'metadata/charcoal_v01.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'changed_rgb_pixels':int(changed.sum()),'alpha_identical':bool(np.array_equal(a[:,:,3],z[:,:,3])),'method':'Temporary magenta/cobalt pant material recolor only, component/hue mask; no geometry or source-alpha changes. Original preserved.','status':'bounded wardrobe cleanup candidate'},indent=2))
