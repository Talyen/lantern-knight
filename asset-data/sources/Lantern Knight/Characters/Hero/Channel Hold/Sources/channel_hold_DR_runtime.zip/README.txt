channel_hold_DR
Original generated 2D artwork is an art-review/integration-test candidate, not engine-approved animation.
No camera metric, physical blade length, collisions, IK, gameplay events, healing mechanics, or controller wiring certified.
Native distinct cels with integer holds at 60 Hz. No optical flow, mesh warp, synthetic in-betweens, mirroring, or image upscaling.
First/last drawings are not pixel-identical to shared ready. Runtime transition/root/scale review remains required.
Pose compatible with existing lantern_DR cel04. Near boot was rigidly registered to its (159,475) contact landmark; drawing and body height differ slightly, so the seam is not certified pixel-perfect.

Runtime: use the PNG frames or atlas. MP4 is an opaque review preview. PPU is an approximate starting value.
