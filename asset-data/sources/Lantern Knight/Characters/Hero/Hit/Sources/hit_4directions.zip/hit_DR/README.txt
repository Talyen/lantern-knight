LANTERN HIT DR — recoil_and_recovery.
8 complete unique native drawings. Presentation at60Hz using unequal integer holds. Complete hit response and recovery; non-looping. 
Human articulation reviewed by producer, independent reviewer and parent. Native test integration remains approximate; read limitations in clip.json.

No upscaling, mirroring, per-frame scale fitting, or pixel interpolation. Native source grid and padding are recorded in clip.json. Art approval is a separate human judgment.
