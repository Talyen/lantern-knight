from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json
P=Path(__file__).parent
R=np.array([1,0,-1])/np.sqrt(2);D=np.array([1,-2,1])/np.sqrt(6)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
W,H=1000,820;ROOT=np.array([500,510]);PPU=230
chains=[(['Hips','Spine','Spine1','Spine2','Neck','Head'],(90,100,106),24),(['LeftShoulder','LeftArm','LeftForeArm','LeftHand'],(30,125,172),20),(['RightShoulder','RightArm','RightForeArm','RightHand'],(218,116,51),20),(['LeftUpLeg','LeftLeg','LeftFoot','LeftToeBase'],(30,125,172),26),(['RightUpLeg','RightLeg','RightFoot','RightToeBase'],(218,116,51),26)]
for slug in ['standing-small-hit-front','death-from-standing-idle']:
 j=json.load(open(P/'reference/mixamo'/slug/'joint-samples.json'))
 for direction,angle in [('DR',0),('DL',90),('UL',180),('UR',270)]:
  a=np.deg2rad(angle-45);rot=np.array([[np.cos(a),0,-np.sin(a)],[0,1,0],[np.sin(a),0,np.cos(a)]])
  board=Image.new('RGB',(W*4,H*2),(237,239,235))
  for i,s in enumerate(j['sheet_samples']):
   pts={k:rot@np.array(v) for k,v in s['joints_yup_m'].items()}
   xy={k:ROOT+PPU*np.array([v@R,v@D]) for k,v in pts.items()};im=Image.new('RGB',(W,H),(237,239,235));dr=ImageDraw.Draw(im)
   segments=[]
   for chain,color,width in chains:
    for aa,bb in zip(chain[:-1],chain[1:]):segments.append(((pts[aa]+pts[bb]).sum(),aa,bb,color,width))
   # Upper torso and hip spans are projection references, not invented new source motion.
   segments += [((pts['LeftArm']+pts['RightArm']).sum(),'LeftArm','RightArm',(100,105,108),28),((pts['LeftUpLeg']+pts['RightUpLeg']).sum(),'LeftUpLeg','RightUpLeg',(100,105,108),26)]
   for dep,aa,bb,col,width in sorted(segments):
    pa,pb=tuple(xy[aa]),tuple(xy[bb]);dr.line([pa,pb],fill=col,width=width)
    for pt in [pa,pb]:dr.ellipse((pt[0]-width/2,pt[1]-width/2,pt[0]+width/2,pt[1]+width/2),fill=col)
   hx,hy=xy['Head'];dr.ellipse((hx-19,hy-26,hx+19,hy+26),fill=(160,164,164),outline=(54,59,62),width=2)
   # Small actor-forward arrow from fixed floor origin.
   forward=np.array([np.cos(np.deg2rad(angle))*.34,0,np.sin(np.deg2rad(angle))*.34]);fp=ROOT+PPU*np.array([forward@R,forward@D]);dr.line([tuple(ROOT),tuple(fp)],fill=(86,139,102),width=3)
   dr.ellipse((ROOT[0]-3,ROOT[1]-3,ROOT[0]+3,ROOT[1]+3),fill=(86,139,102))
   dr.text((18,18),f'{i+1:02d}  {direction}  source f{s["frame"]:.0f}',font=font,fill=(40,45,47))
   board.paste(im,((i%4)*W,(i//4)*H))
  board.save(P/'reference'/f'{slug}_{direction}_exact_joint_guide.png')
meta={'camera_elevation':35.264389682754654,'camera_azimuth':45,'basis_right':R.tolist(),'basis_down':D.tolist(),'cell':[W,H],'root':ROOT.tolist(),'ppu':PPU,'guide_actor_yaw_offset_degrees':-45,'guide_actor_yaw_offset_basis':'Initial death shoulder span implies approximately world+45degree forward; normalize this fixed embedded pose yaw before requested direction rotation. Approximate anatomical-facing normalization, not verified FBX rest orientation.','source':'Unaltered65-joint Mixamo sheets with actor-only yaw around worldY. No source motion modification. Anatomical right orange, left blue. Shape thickness approximate; joint projection exact. No props; art adapts hand gestures to held props.'}
(P/'reference/directional_joint_guide_metadata.json').write_text(json.dumps(meta,indent=2))
