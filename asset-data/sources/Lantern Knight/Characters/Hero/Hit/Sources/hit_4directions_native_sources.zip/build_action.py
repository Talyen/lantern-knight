"""Extract a fresh coherent sheet and build native-pixel audit / runtime candidates.
No image generation, morphing, interpolation, mirror, upscaling or per-frame scale fitting.
Input is an explicitly observed grid/anchor configuration, never inferred art approval.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, hashlib, subprocess, shutil, argparse, zipfile
P=Path(__file__).resolve().parent
FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17)
WORLD={'DR':[1,0,0], 'DL':[0,0,1], 'UL':[-1,0,0], 'UR':[0,0,-1]}

def main(config_path):
 cfg=json.loads(Path(config_path).read_text()); clip=cfg['clip']; direction=cfg['direction']
 source=P/cfg['source']; im=Image.open(source).convert('RGBA'); out=P/cfg['output']; out.mkdir(parents=True,exist_ok=True)
 framesdir=out/'frames';framesdir.mkdir(exist_ok=True);q=out/'qa';q.mkdir(exist_ok=True)
 grid=cfg['grid']; cols=grid['columns'];step=grid['step'];origin=grid['origin'];size=grid['cell_size'];pad=grid.get('padding',16)
 W,H=size[0]+2*pad,size[1]+2*pad;frames=[];records=[]
 for i,rec in enumerate(cfg['frames']):
  source_i=rec.get('source_cel',i+1)-1
  x,y=origin[0]+(source_i%cols)*step[0],origin[1]+(source_i//cols)*step[1]
  # Crop regular cell including gutter only. Whole native RGBA values remain intact.
  # Component-aware ownership preserves cel edges crossing nominal sheet gutters.
  # Only weak disconnected background specks are removed, retaining original RGBA locally.
  if cfg.get('component_ownership',True):
   import numpy as np
   from scipy.ndimage import label,binary_dilation,find_objects
   arr=np.array(im);lab,n=label(arr[:,:,3]>50);components=[]
   for k,sl in enumerate(find_objects(lab)):
    if sl is not None:
     count=int((lab[sl]==k+1).sum())
     if count>500:components.append((k+1,sl,count))
   components.sort(key=lambda z:(int((z[1][0].start+z[1][0].stop)/2>=im.height/2),z[1][1].start))
   target=components[source_i][0];keep=binary_dilation(lab==target,iterations=5)
   arr[~keep]=0
   native=Image.fromarray(arr).crop((x-pad,y-pad,x+size[0]+pad,y+size[1]+pad))
  else:
   cel=im.crop((x,y,x+size[0],y+size[1]));native=Image.new('RGBA',(W,H));native.alpha_composite(cel,(pad,pad))
  name=f'{clip}_{direction}_{i+1:02d}.png';native.save(framesdir/name);frames.append(native)
  observed={key:([v[0]+pad,v[1]+pad] if key=='visible_support_marker_xy' and isinstance(v,list) and len(v)==2 and all(isinstance(c,(int,float)) for c in v) else v) for key,v in rec.get('observations',{}).items()}
  records.append(dict(rec,index=i+1,file='frames/'+name,source_box=[x,y,x+size[0],y+size[1]],observations_native_padded=observed,sha256=hashlib.sha256((framesdir/name).read_bytes()).hexdigest()))
 atlas=Image.new('RGBA',(W*cols,H*((len(frames)+cols-1)//cols)))
 for i,cel in enumerate(frames):atlas.alpha_composite(cel,((i%cols)*W,(i//cols)*H))
 atlas.save(out/f'{clip}_{direction}_native_atlas.png')
 for label,matte in [('light',(234,235,231)),('dark',(25,29,34))]:
  board=Image.new('RGB',(W*cols,(H+36)*((len(frames)+cols-1)//cols)),matte);d=ImageDraw.Draw(board)
  for i,cel in enumerate(frames):
   xx,yy=(i%cols)*W,(i//cols)*(H+36);board.paste(cel,(xx,yy),cel);d.text((xx+12,yy+H+5),f'{i+1:02d}  {records[i]["phase"]}',fill=(245,245,239) if label=='dark' else (29,32,36),font=FONT)
  board.save(q/f'{clip}_{direction}_all_native_{label}.png')
 # Exact unequal 60Hz exposure. Every tick references an original native drawing.
 V=q/'tmp_video';V.mkdir(exist_ok=True);ticks=[]
 for i,r in enumerate(records):ticks.extend([i]*r['hold_ticks_60hz'])
 VW,VH=(W+100+1)//2*2,(H+90+1)//2*2
 for i,cel in enumerate(frames):
  b=Image.new('RGBA',(VW,VH),(226,228,229,255));b.alpha_composite(cel,(50,24));ImageDraw.Draw(b).text((18,VH-30),f'{clip} {direction} | native cel {i+1}/{len(frames)} | 60Hz holds',fill=(28,32,36),font=FONT);b.convert('RGB').save(V/f'cel_{i:02d}.png')
 # ffmpeg concat durations are integer 60Hz; no tweened pixels.
 for speed,name in [(1,'60hz'),(2,'half_speed')]:
  listing=''.join(f"file '{(V/f'cel_{i:02d}.png').resolve()}'\nduration {1/60:.12f}\n" for i in ticks for _ in range(speed))
  listing+=f"file '{(V/f'cel_{ticks[-1]:02d}.png').resolve()}'\n";txt=V/f'{name}.txt';txt.write_text(listing)
  subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-r','60','-i',str(txt),'-frames:v',str(len(ticks)*speed),'-c:v','libx264','-crf','18','-pix_fmt','yuv420p',str(out/f'{clip}_{direction}_{name}.mp4')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 shutil.rmtree(V)
 meta={**{k:v for k,v in cfg.items() if k not in ['frames']}, 'frames':records,'native_cell_size':[W,H],'source_size':list(im.size),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'native_drawings':len(frames),'total_ticks_60hz':len(ticks),'duration_seconds':len(ticks)/60,'world_forward':WORLD[direction],'operations':['Native fixed-grid extraction with connected-figure gutter ownership; disconnected weak alpha background specks removed, original local alpha preserved','Uniform transparent padding','Native atlas reassembly','Native-pixel preview compositing'],'resized':False,'mirrored':False,'interpolated':False,'source_backend':'Built-in image_gen; requested Sunburst2.5(gpt-image-2.5-sunburst) phrase included. Backend selection not verified.','camera_claim_limit':'Deterministic reference camera is exact; generated art is visually approximate and requires human review.'}
 (out/'clip.json').write_text(json.dumps(meta,indent=2)+'\n')
 (out/'README.txt').write_text(cfg.get('readme','Runtime candidate, not final art approval.')+'\n\nNo upscaling, mirroring, per-frame scale fitting, or pixel interpolation. Native source grid and padding are recorded in clip.json. Art approval is a separate human judgment.\n')
 sums=''.join(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(out)}\n' for f in sorted(out.rglob('*')) if f.is_file() and f.name!='SHA256SUMS.txt');(out/'SHA256SUMS.txt').write_text(sums)
 print(json.dumps({'output':str(out),'frames':len(frames),'seconds':len(ticks)/60,'native_cell':[W,H]},indent=2))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('config');main(ap.parse_args().config)
