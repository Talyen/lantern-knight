from pathlib import Path
from PIL import Image
import json,math
P=Path(__file__).parent
near={
'DR':[[163,427],[594,429],[1024,429],[1460,429],[181,851],[598,853],[1023,860],[1456,858]],
'DL':[[323,405],[819,404],[1300,401],[1824,405],[333,780],[817,782],[1305,784],[1808,790]],
'UL':[[199,389],[689,387],[1165,388],[1670,390],[198,766],[691,771],[1195,783],[1683,782]],
'UR':[[272,397],[771,393],[1252,390],[1755,385],[266,783],[767,783],[1265,786],[1757,785]]}
source_names={('death','UL'):'death_UL_kneel_v01_terminal5_dark_native.png',('death','UR'):'death_UR_kneel_v01_corrected_native.png'}
settings={('hit','DR'):(254.6,[219,415],411,565),('hit','DL'):(245.6,[248,373],398,567),('hit','UL'):(216.3,[229,376],367,594),('hit','UR'):(233.2,[191,383],377,566),('death','DR'):(258.3,[193,419],417,565),('death','DL'):(246.3,[265,388],399,567),('death','UL'):(305.2,[245,505],518,594),('death','UR'):(318.5,[198,517],515,566)}
death_anchors={'DR':[[141,437],[637,429],[1122,437],[1551,435],[235,728],[654,680],[1070,660],[0,0]],'DL':[[348,415],[832,414],[1330,399],[1765,381],[336,678],[932,640],[1400,595],[1887,594]],'UL':[[220,540],[741,530],[1255,508],[284,922],[794,916],[0,0]],'UR':[[282,540],[771,530],[1278,510],[241,914],[743,914],[1245,914]]}
for action in ['hit','death']:
 for d in ['DR','DL','UL','UR']:
  name=source_names.get((action,d),f'{action}_{d}_v01_native.png');im=Image.open(P/'source'/name);cols=3 if action=='death' and d in ['UL','UR'] else 4;dx=math.ceil(im.width/cols);dy=math.ceil(im.height/2);pad=96
  indices=list(range(1,9))
  if action=='death' and d=='DR':indices=[1,3,4,5,6,7]
  elif action=='death' and d=='UL':indices=[1,2,3,4,5]
  elif action=='death' and d=='UR':indices=[1,2,3,4,5,6]
  if action=='hit':phases=['ready','impact snap','recoil','recoil apex','low catch','rise','guard recovery','ready settle'];holds=[3,2,3,2,2,4,5,9]
  elif d=='DR':phases=['ready','fatal recoil/buckle','hips descend','pelvis contact','back contact','terminal dead hold'];holds=[4,5,5,5,7,64]
  elif d=='DL':phases=['ready','fatal recoil','buckle','kneeling descent','pelvis contact','back contact','settle','terminal dead hold'];holds=[3,4,5,5,5,6,8,54]
  elif d=='UL':phases=['ready','fatal jolt','first knee','both-knee bow','extinguished bowed terminal'];holds=[5,6,9,12,58]
  else:phases=['ready','fatal recoil','knees descend','bowed kneel','ember','extinguished bowed terminal'];holds=[5,6,8,10,12,49]
  ppu,pivot,bh,rh=settings[(action,d)];frames=[]
  for seq,(idx,ph,h) in enumerate(zip(indices,phases,holds)):
   xy=(near[d] if action=='hit' else death_anchors[d])[idx-1];ox=(idx-1)%cols*dx;oy=(idx-1)//cols*dy
   frames.append({'source_cel':idx,'phase':ph,'hold_ticks_60hz':h,'observations':{'visible_support_marker_xy':[xy[0]-ox,xy[1]-oy],'original_source_marker_xy':xy,'confidence':'moderate for visible boot sole; low for inferred knee/hip/back support hidden by garment','kind':'near boot sole approximate point' if action=='hit' else 'visible boot/heel or inferred garment support region; not a calibrated collision contact','observation_method':'Manual visual point on original native sheet, rounded to nearest few pixels. Fixed source-grid origin, never per-frame fitted.'}})
  variant='recoil_and_recovery' if action=='hit' else ('backward_collapse' if d in ['DR','DL'] else 'kneel_and_extinguish')
  excluded={}
  if action=='death' and d=='DR':excluded={'2':'Sword-tip overlap tangent on near boot','8':'Outer boot cut by native sheet edge; complete cel7is terminal'}
  if action=='death' and d=='UL':excluded={'6':'Outermost sword tip reaches/clips native image edge. Complete cel5with bounded glass-only extinguish is terminal.'}
  limits=['Approximate visually matched camera; exact camera matrices apply to construction guides, not generated art.','One approximate PPU and one common pivot per action/heading; native pixels untouched by density setting.','Native sheet registration preserves authored body/ground movement. No per-frame recentering or scale fitting; residual drawing drift remains.','Blade length/width and coat hem redraw variation remain; no metric contact or seamless shared-ready join certified.']
  if action=='hit' and d=='UL':limits.append('Far sword becomes exposed with a different carried angle from shared-ready. State transition needs engine review.')
  if variant=='kneel_and_extinguish':limits.append('Intentional alternate death variant with bowed kneeling hold; not an exact rotation of DR/DL full collapse. Game may fade/reset from terminal.')
  cfg={'clip':action,'direction':d,'source':'source/'+name,'output':f'delivery/{action}_{d}','status':'HUMAN_FIRST_REVIEWED_NATIVE_RUNTIME_TEST','variant':variant,'loop':False,'terminal_hold_indefinite':action=='death','exit':'last cel holds indefinitely; game owns reset/fade' if action=='death' else 'return to same-direction ready; exact join unverified','grid':{'columns':cols,'origin':[0,0],'step':[dx,dy],'cell_size':[dx,dy],'padding':pad},'component_ownership':True,'frames':frames,'excluded_source_cels':excluded,'runtime_integration':{'ppu':ppu,'common_pivot_xy':[pivot[0]+pad,pivot[1]+pad],'common_pivot_normalized_bottom_left':[(pivot[0]+pad)/(dx+2*pad),1-(pivot[1]+pad)/(dy+2*pad)],'shared_ready_ppu':350,'shared_ready_pivot_xy':[301,556],'density_method':'Single whole-action initial standing crown-to-near-sole visual height ratio versus same-direction shared-ready. No per-cel normalization.','observed_entry_body_height_px':bh,'reference_ready_body_height_px':rh,'registration_confidence':'Approximate/low-to-moderate. Pivot estimated from first standing support and ready root offset, common for entire action. Needs engine contact/transition review.'},'camera_contract':'../contracts/camera_contract.json','prop_target_contract':'../contracts/shared_prop_contract.json','guide_facing_normalization_degrees':-45 if d!='DR' else 0,'limits':limits,'readme':f'LANTERN {action.upper()} {d} — {variant}.\n{len(frames)} complete unique native drawings. Presentation at60Hz using unequal integer holds. '+('Terminal drawing remains held indefinitely; this is not a loop. ' if action=='death' else 'Complete hit response and recovery; non-looping. ')+('\nBack-view kneel/extinguish is intentionally a different death variant from front-view collapse. ' if variant=='kneel_and_extinguish' else '')+'\nHuman articulation reviewed by producer, independent reviewer and parent. Native test integration remains approximate; read limitations in clip.json.'}
  (P/'plans'/f'{action}_{d}.json').write_text(json.dumps(cfg,indent=2))
