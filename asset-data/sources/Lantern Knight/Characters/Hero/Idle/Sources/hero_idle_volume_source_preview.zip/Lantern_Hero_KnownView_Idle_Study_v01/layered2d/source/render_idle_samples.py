import bpy,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;O=P.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'Lamplighter_C_RUST_KnownView_Layered_Idle_v01.blend'))
s=bpy.context.scene;frames=[]
for i in range(24):
 s.frame_set(1+2*i);path=O/'frames'/('lamplighter_C_RUST_knownview_idle_%03d.png'%i);s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
 frames.append({'index':i,'file':'frames/'+path.name,'sample_time_seconds':i/12,'duration_ticks':1,'timebase_hz':12,'source_timeline_frame':1+2*i,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'untrimmed_canvas_px':[932,2396],'root_px':[544,2168]})
meta=json.loads((P/'rig_source.json').read_text());manifest={'schema':'limited-art-study/v1','asset_id':meta['asset_id'],'production_approved':False,'scope':'One uncalibrated known-view idle study. Not a walk/attack clip.','canonical_sha256':meta['canonical_sha256'],'clip_id':'known_view_idle_study','duration_ticks':24,'timebase_hz':12,'loop':True,'frames':frames,'preview_presentation_fps':60,'atlas':None,'attachments':{'lantern_bail_grip_source_px':[412,540],'lantern_body_hinge_source_px':[410,574]},'source_resolution_px':[466,1198],'export_scale':2,'export_note':'2x oversampled derivatives of original source pixels; no added authored detail.','root_note':'Stable canvas registration only, no game-meter or camera calibration.'}
(O/'study_manifest.json').write_text(json.dumps(manifest,indent=2))
print('IDLE_SAMPLE_SEQUENCE_READY')
