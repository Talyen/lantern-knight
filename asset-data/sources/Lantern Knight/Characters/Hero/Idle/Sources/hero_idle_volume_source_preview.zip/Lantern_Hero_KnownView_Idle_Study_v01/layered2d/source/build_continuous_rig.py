"""Editable known-view UV rig using layer-defined controls on a continuous mesh.
A continuous texture mesh avoids cracks between adjacent source cutout layers.
No new art, hidden surfaces, or production-camera claims.
"""
import bpy,json,math
from pathlib import Path
P=Path(__file__).resolve().parent;O=P.parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
meta=json.loads((P/'rig_source.json').read_text());controls=json.loads((P/'control_fields.json').read_text());W,H=meta['source_size_px']
sc=bpy.context.scene;sc.render.engine='BLENDER_EEVEE_NEXT';sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGBA';sc.render.film_transparent=True;sc.render.resolution_x=W*2;sc.render.resolution_y=H*2;sc.render.resolution_percentage=100
if hasattr(sc.eevee,'taa_render_samples'):sc.eevee.taa_render_samples=16
sc.view_settings.view_transform='Standard';sc.view_settings.look='None';sc.render.fps=24;sc.frame_start=1;sc.frame_end=48;sc.world.color=(0,0,0);sc.render.use_freestyle=False
base=next(iter(controls.values()));xs=base['grid_x'];ys=base['grid_y'];NX=len(xs);vs=[(x,-y,0) for y in ys for x in xs];uvs=[(x/W,1-y/H) for y in ys for x in xs]
faces=[(j*NX+i,j*NX+i+1,(j+1)*NX+i+1,(j+1)*NX+i) for j in range(len(ys)-1) for i in range(NX-1)]
me=bpy.data.meshes.new('Canonical_continuous_UV_surface');me.from_pydata(vs,[],faces);me.update();uv=me.uv_layers.new(name='Original_source_pixels')
for poly in me.polygons:
 for vi,li in zip(poly.vertices,poly.loop_indices):uv.data[li].uv=uvs[vi]
ob=bpy.data.objects.new('C_RUST_SOURCE__ONE_KNOWN_VIEW',me);bpy.context.collection.objects.link(ob);ob['canonical_reference_sha256']=meta['canonical_sha256'];ob['source_view']='Original concept front three-quarter, uncalibrated';ob['source_pixel_root']=[272,1084]
m=bpy.data.materials.new('Canonical_unrepainted_pixels');m.use_nodes=True;m.surface_render_method='DITHERED';n=m.node_tree.nodes;n.clear();lk=m.node_tree.links;tx=n.new('ShaderNodeTexImage');tx.image=bpy.data.images.load(str(O/'proofs/Lamplighter_C_RUST_known_view_static.png'),check_existing=True);tx.interpolation='Linear';tx.extension='CLIP';tx.image.pack();tx.label='Original foreground RGB with source matte excluded'
em=n.new('ShaderNodeEmission');em.inputs[1].default_value=1;tr=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');out=n.new('ShaderNodeOutputMaterial');lk.new(tx.outputs['Color'],em.inputs[0]);lk.new(tx.outputs['Alpha'],mix.inputs[0]);lk.new(tr.outputs[0],mix.inputs[1]);lk.new(em.outputs[0],mix.inputs[2]);lk.new(mix.outputs[0],out.inputs['Surface']);me.materials.append(m)
ob.shape_key_add(name='Canonical_Rest')
for name,co in controls.items():
 key=ob.shape_key_add(name=name+'_independent_control');key.slider_min=-1;key.slider_max=1;axis=0 if co['axis']=='x' else 1
 for i,weight in enumerate(co['weights']):key.data[i].co[axis]+=co['amplitude_source_px']*weight*(1 if axis==0 else -1)
 for f in range(1,50):
  t=(f-1)/48;key.value=.5-.5*math.cos(2*math.pi*t) if name=='torso_coat_and_belts' else math.sin(2*math.pi*t);key.keyframe_insert('value',frame=f)
# The brass lantern body has an independent tiny hinge sweep. Its carried bail,
# hand and fingers remain fixed. A short pinned region joins existing pixels.
key=ob.shape_key_add(name='Lantern_body_hinge_control');key.slider_min=-1;key.slider_max=1
for i,(x,yneg,z) in enumerate(vs):
 y=-yneg
 if 352<=x<=466 and 555<=y<=732:
  # Restrict to the original lantern silhouette region; beyond alpha is safe.
  xf=max(0,min(1,(x-352)/17));yf=max(0,min(1,(y-555)/18));yf=yf*yf*(3-2*yf);weight=xf*yf
  theta=math.radians(.9);dx=(x-410)*(math.cos(theta)-1)+(y-574)*math.sin(theta);dy=-(x-410)*math.sin(theta)+(y-574)*(math.cos(theta)-1)
  key.data[i].co.x+=dx*weight;key.data[i].co.y-=dy*weight
for f in range(1,50):key.value=math.sin(2*math.pi*(f-1)/48);key.keyframe_insert('value',frame=f)
for fc in me.shape_keys.animation_data.action.fcurves:
 for kp in fc.keyframe_points:kp.interpolation='LINEAR'
cd=bpy.data.cameras.new('Original_known_view_flat_camera');cam=bpy.data.objects.new('Original_known_view_flat_camera',cd);bpy.context.collection.objects.link(cam);cam.location=(W/2,-H/2,2000);cd.type='ORTHO';cd.ortho_scale=H;cd.clip_end=3000;sc.camera=cam;sc.frame_set(1)
text=bpy.data.texts.new('README_LIMITED_PROOF');text.write('Single known concept view, not camera-calibrated. Original foreground pixels are sampled through UVs. One continuous mesh has independent layer-defined cloth controls and a small lantern-body hinge. Head, hands, sword and feet remain locked. No hidden surfaces authored; this is not a walk/attack proof. See rig_source.json, control_fields.json and README.txt.')
bpy.ops.wm.save_as_mainfile(filepath=str(P/'Lamplighter_C_RUST_KnownView_Layered_Idle_v01.blend'))
for idx,frame in [(0,1),(6,13),(18,37)]:
 sc.frame_set(frame);sc.render.filepath=str(O/'proofs'/('Idle_extreme_%02d.png'%idx));bpy.ops.render.render(write_still=True)
print('CONTINUOUS_SOURCE_PROOF_READY')
