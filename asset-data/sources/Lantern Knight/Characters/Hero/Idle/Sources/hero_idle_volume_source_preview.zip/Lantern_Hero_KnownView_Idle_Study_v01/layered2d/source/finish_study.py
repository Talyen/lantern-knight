from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import numpy as np,json,hashlib
from scipy import ndimage as ndi
P=Path(__file__).resolve().parent;O=P.parent
for n in ['frames_native','preview','qa/preview_frames']:(O/n).mkdir(exist_ok=True,parents=True)
files=sorted((O/'frames').glob('lamplighter_C_RUST_knownview_idle_*.png'))
assert len(files)==24,len(files)
master=json.loads((O/'study_manifest.json').read_text());native=[]
fontroot='/usr/share/fonts/truetype/dejavu/'
font=lambda s:ImageFont.truetype(fontroot+'DejaVuSans.ttf',s)
bold=lambda s:ImageFont.truetype(fontroot+'DejaVuSans-Bold.ttf',s)
reference=Image.open(O/'proofs/Lamplighter_C_RUST_known_view_static.png').convert('RGBA')
A=np.array(Image.open(files[0]));regions={'face_identity':(193,42,283,140),'both_feet':(75,846,466,1104),'sword_hand':(56,524,94,568),'lantern_hand':(393,499,436,539)}
validation={'source_frames':24,'source_sample_rate_hz':12,'clip_duration_s':2,'preview_fps':60,'tested_fixed_regions_source_pixels':regions,'max_RGBA_error_in_fixed_regions':{},'new_transparent_pixels_inside_8px_eroded_rest':{},'retained_source_matte_fringe':'Known limitation, visible on very dark backgrounds.'}
eroded=ndi.binary_erosion(A[:,:,3]>=200,iterations=16)
for idx,fn in enumerate(files):
 im=Image.open(fn).convert('RGBA');arr=np.array(im);res=im.resize((466,1198),Image.Resampling.LANCZOS);nf=O/'frames_native'/fn.name;res.save(nf)
 native.append({'index':idx,'file':'frames_native/'+nf.name,'sample_time_seconds':idx/12,'duration_ticks':1,'timebase_hz':12,'source_timeline_frame':1+2*idx,'sha256':hashlib.sha256(nf.read_bytes()).hexdigest(),'untrimmed_canvas_px':[466,1198],'root_px':[272,1084]})
 v={}
 for name,(x0,y0,x1,y1) in regions.items():v[name]=int(np.abs(A[y0*2:y1*2,x0*2:x1*2].astype(int)-arr[y0*2:y1*2,x0*2:x1*2].astype(int)).max())
 validation['max_RGBA_error_in_fixed_regions'][str(idx)]=v
 validation['new_transparent_pixels_inside_8px_eroded_rest'][str(idx)]=int(np.sum(eroded&(arr[:,:,3]<200)))
 canvas=Image.new('RGBA',(1920,1080),'#1e2224');d=ImageDraw.Draw(canvas)
 d.text((62,32),'LAMPLIGHTER  /  C · RUST',font=bold(32),fill='#eee5d5')
 d.text((64,78),'Original pixels, controlled motion',font=font(21),fill='#bab2a4')
 d.rounded_rectangle((1465,37,1858,75),radius=8,fill='#513827');d.text((1483,47),'LIMITED KNOWN-VIEW STUDY',font=bold(17),fill='#ead2ac')
 d.line((62,114,1858,114),fill='#4b4137',width=1)
 d.text((90,132),'SOURCE-DERIVED STATIC',font=bold(17),fill='#d5cbb9');d.text((650,132),'INDEPENDENT IDLE CONTROLS',font=bold(17),fill='#d5cbb9')
 for x,img in [(90,reference),(650,res)]:
  body=img.crop((0,0,466,1106)).resize((366,869),Image.Resampling.LANCZOS);canvas.alpha_composite(body,(x+15,168))
 d.line((563,150,563,1035),fill='#353a3b',width=1);d.line((1125,150,1125,1035),fill='#353a3b',width=1)
 d.text((1180,156),'CLOTH DETAIL',font=bold(17),fill='#d5cbb9');d.text((1610,156),'LANTERN DETAIL',font=bold(17),fill='#d5cbb9')
 # Crops from the actual exported sample. No extra movement or motion synthesis.
 coat=res.crop((82,427,367,730)).resize((365,388),Image.Resampling.LANCZOS);canvas.alpha_composite(coat,(1175,207))
 lamp=res.crop((351,510,466,728)).resize((215,408),Image.Resampling.LANCZOS);canvas.alpha_composite(lamp,(1612,200))
 d.text((1180,632),'Shared cloth seams stay pinned.',font=font(20),fill='#d9d0c0')
 d.text((1180,670),'Face, hands, sword and feet stay fixed.',font=font(20),fill='#d9d0c0')
 d.text((1180,708),'The carried lantern body has a small hinge sweep.',font=font(20),fill='#d9d0c0')
 d.text((1180,782),'24 source samples · 12 fps · 2-second loop',font=font(19),fill='#a9a79e')
 d.text((1180,814),'60 fps presentation, with each sample held.',font=font(19),fill='#a9a79e')
 d.text((1180,878),'Original concept view. No camera calibration.',font=font(20),fill='#e0b57e')
 d.text((1180,914),'Walk / attack / other directions remain blocked.',font=font(20),fill='#e0b57e')
 d.text((1180,968),'Fine source-matte fringe is retained, not repainted.',font=font(18),fill='#a9a79e')
 d.line((650,1054,1098,1054),fill='#48443d',width=2);d.line((650,1054,650+round(448*idx/24),1054),fill='#c99351',width=3)
 canvas.convert('RGB').save(O/'qa/preview_frames'/('preview_%03d.png'%idx))
 if idx==6:canvas.convert('RGB').save(O/'preview/Lamplighter_KnownView_Idle_Review_Poster.png')
# Contact sheet: actual source samples at rest, extreme, rest, reverse extreme.
sheet=Image.new('RGBA',(1920,1260),'#222628');d=ImageDraw.Draw(sheet);d.text((52,30),'KNOWN-VIEW IDLE STUDY  /  SOURCE SAMPLES',font=bold(30),fill='#eee5d5')
for j,i in enumerate([0,6,12,18]):
 im=Image.open(O/'frames_native'/files[i].name).convert('RGBA');im=im.crop((0,0,466,1106)).resize((422,1002),Image.Resampling.LANCZOS);sheet.alpha_composite(im,(35+j*475,135));d.text((45+j*475,91),f'Sample {i:02d}  ·  {i/12:.1f}s',font=font(22),fill='#d9c9ae')
d.text((52,1190),'Single uncalibrated concept view. Fixed feet and face. No walk, sword attack or alternate heading is implied.',font=font(21),fill='#c2b8a7')
sheet.convert('RGB').save(O/'preview/Lamplighter_KnownView_Idle_ContactSheet.png')
validation['fixed_regions_all_exact']=all(all(v==0 for v in row.values()) for row in validation['max_RGBA_error_in_fixed_regions'].values())
validation['no_new_interior_holes']=all(v==0 for v in validation['new_transparent_pixels_inside_8px_eroded_rest'].values())
validation['canonical_file_sha256']=hashlib.sha256((O.parent/'reference/canonical_original_C_RUST.png').read_bytes()).hexdigest()
(O/'qa/motion_validation.json').write_text(json.dumps(validation,indent=2))
master['frames']=native;master['export_scale']=1;master['export_note']='Source-size derivatives of the 2x Blender proof renders; interpolation is UV resampling, not newly drawn pixels.';master['approval_scope']='Static likeness passed. Limited idle motion study only. Full production gate remains blocked.'
(O/'study_manifest_native.json').write_text(json.dumps(master,indent=2));print(json.dumps({'fixed_regions_all_exact':validation['fixed_regions_all_exact'],'no_new_interior_holes':validation['no_new_interior_holes'],'source_files':len(native)}))
