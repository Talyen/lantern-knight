"""Prepare spatial weights for a source-textured layered rig.
Pins all shared internal seams; only free cloth edges flex. No hidden art drawn.
"""
from pathlib import Path
import json,numpy as np
from PIL import Image
from scipy import ndimage as ndi
P=Path(__file__).resolve().parent
meta=json.loads((P/'rig_source.json').read_text());w,h=meta['source_size_px']
sil=np.array(Image.open(P.parent/'proofs/Lamplighter_C_RUST_known_view_static.png'))[:,:,3]>0
yy,xx=np.mgrid[:h,:w];controls={}
for l in meta['layers']:
 mask=np.array(Image.open(P/l['mask_file']))>0
 internal=mask&ndi.binary_dilation(sil&~mask)
 distance=ndi.distance_transform_edt(~internal)
 pin=np.clip((distance-1)/16,0,1);pin=pin*pin*(3-2*pin)
 weights=np.zeros((h,w),np.float32)
 if l['motion']=='coat_left':weights=pin*np.clip((yy-435)/275,0,1)**1.3;axis='x';amp=3.4
 elif l['motion']=='coat_right':weights=pin*np.clip((yy-436)/280,0,1)**1.3;axis='x';amp=-2.8
 elif l['motion']=='torso_breath':weights=pin*np.exp(-((xx-229)/91)**2-((yy-315)/100)**2);axis='y';amp=-1.25
 else:continue
 weights*=mask
 # Extend the same weights a few pixels past free alpha edges, preserving the
 # geometry of the actual silhouette instead of pinning transparent vertices.
 dist,idx=ndi.distance_transform_edt(~mask,return_indices=True)
 ext=weights[tuple(idx)];weights=np.where((~mask)&(~sil)&(dist<10),ext,weights)
 # Grid spacing is 6 original pixels. All vertices and UVs are editable.
 xs=list(range(0,w,6))+[w];ys=list(range(0,h,6))+[h]
 sampled=[]
 for y in ys:
  for x in xs:sampled.append(round(float(weights[min(y,h-1),min(x,w-1)]),6))
 controls[l['name']]={'grid_x':xs,'grid_y':ys,'axis':axis,'amplitude_source_px':amp,'weights':sampled,'internal_seam_pin_px':16}
 np.save(P/(l['name']+'_weights.npy'),weights.astype(np.float32))
(P/'control_fields.json').write_text(json.dumps(controls,separators=(',',':')))
meta['status']='STATIC_LIKENESS_PASSED_LIMITED_IDLE_AUTHORIZED';meta['motion_scope']='Subtle independent cloth and lantern-body idle only; head, bare hands, sword and feet remain planted.';meta['camera_contract_compatible']=False
meta['clip']={'id':'known_view_idle_study','duration_ms':2000,'source_samples':24,'source_fps':12,'preview_fps':60,'loop':True,'root_motion':False,'lantern_hinge_max_angle_deg':.9,'not_walk_or_attack':True}
(P/'rig_source.json').write_text(json.dumps(meta,indent=2))
