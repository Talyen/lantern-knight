"""Source-pixel preserving known-view 2D rig. No repaint or AI-generated frames.
Canonical PNG remains byte-for-byte unchanged. Layer masks select pixels only.
"""
from PIL import Image, ImageDraw
import numpy as np, json, hashlib
from scipy import ndimage as ndi
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
REF=ROOT.parent/'reference/canonical_original_C_RUST.png'
im=Image.open(REF).convert('RGB');a=np.array(im);h,w=a.shape[:2]
# Flood the neutral original matte from the exterior; keep enclosed body regions.
neut=(a.max(2).astype(int)-a.min(2).astype(int)<18)&(a.max(2)>108)
seed=np.zeros((h,w),bool);seed[0,:]=neut[0,:];seed[-1,:]=neut[-1,:];seed[:,0]=neut[:,0];seed[:,-1]=neut[:,-1]
# Authored neutral-matte pocket seeds: under each arm and between top hair locks.
for x,y in [(112,485),(359,446),(219,27),(241,25)]:seed[y,x]=neut[y,x]
bg=ndi.binary_propagation(seed,mask=neut,structure=np.ones((3,3),bool))
foreground=~bg;foreground[1106:]=False
lab,n=ndi.label(foreground);areas=np.bincount(lab.ravel());areas[0]=0;sil=(lab==areas.argmax())
# Explicit authored holes where original background is enclosed by the handle.
# The full cutout remains original RGB; this only excludes source background.
def polygon(coords):
 m=Image.new('L',(w,h));ImageDraw.Draw(m).polygon(coords,fill=255);return np.array(m)>0
holes=[[(397,545),(407,548),(417,548),(426,538),(429,558),(420,562),(399,561)],[(99,554),(105,569),(99,578),(96,563)]]
for pts in holes:sil[polygon(pts)&neut]=False
# Every foreground source pixel belongs to exactly one static layer.
# Segmentation defines a conservative idle rig, not a walk or an alternate view.
def layer(name,coords,pivot,motion):return dict(name=name,polygon=coords,pivot=pivot,motion=motion)
layers=[
layer('head_identity',[(167,11),(304,8),(307,131),(284,169),(273,210),(256,228),(225,220),(190,185),(175,143),(163,92)],(241,164),'locked_face'),
layer('sword_and_right_hand',[(0,517),(50,501),(88,499),(104,521),(109,571),(96,609),(98,675),(57,873),(16,1005),(0,1004)],(77,526),'attached_right'),
layer('lantern_body',[(348,568),(466,568),(466,718),(348,718)],(410,574),'lantern_hinge'),
layer('left_hand_and_forearm',[(351,374),(397,359),(431,387),(437,454),(456,505),(445,543),(431,561),(418,556),(410,541),(401,546),(391,546),(381,544),(376,516),(364,469),(358,436)],(384,392),'attached_left'),
layer('right_forearm',[(79,382),(119,382),(137,404),(111,471),(104,514),(87,529),(61,514),(60,483),(71,437)],(108,400),'attached_right'),
layer('coat_tail_anatomical_left',[(262,410),(288,402),(337,410),(363,463),(390,502),(374,559),(369,619),(380,671),(349,707),(281,730),(277,667),(273,595),(263,527)],(285,426),'coat_left'),
layer('coat_tail_anatomical_right',[(129,410),(161,402),(167,442),(155,497),(150,557),(146,628),(141,678),(116,721),(83,705),(78,675),(107,560),(110,483)],(139,430),'coat_right'),

layer('legs_and_boots',[(0,470),(466,470),(466,1106),(0,1106)],(273,1038),'feet_planted'),
layer('torso_coat_and_belts',[(0,0),(466,0),(466,1106),(0,1106)],(235,401),'torso_breath')]
remaining=sil.copy();outlayers=[];idmap=np.full((h,w),-1,int)
colors=[(234,161,43),(87,147,231),(228,137,46),(223,87,117),(134,190,84),(130,114,212),(204,104,60),(80,197,180),(113,145,97),(142,145,196)]
for i,l in enumerate(layers):
 mask=remaining&polygon(l['polygon']);remaining[mask]=False;idmap[mask]=i
 rgba=np.dstack([a.copy(),np.uint8(mask)*255]);rgba[~mask,:3]=0;Image.fromarray(rgba).save(ROOT/'source'/(l['name']+'.png'))
 Image.fromarray(np.uint8(mask)*255).save(ROOT/'source'/(l['name']+'_mask.png'))
 l['mask_file']=l['name']+'_mask.png';l['derived_texture_file']=l['name']+'.png';l['selected_source_pixel_count']=int(mask.sum());outlayers.append(l)
comp=np.dstack([a.copy(),np.uint8(sil)*255]);comp[~sil,:3]=0;Image.fromarray(comp).save(ROOT/'proofs/Lamplighter_C_RUST_known_view_static.png')
# Visualization of layer IDs is diagnostic only, not artwork.
idrgb=np.zeros((h,w,4),np.uint8)
for i,c in enumerate(colors):idrgb[idmap==i]=[*c,255]
Image.fromarray(idrgb).save(ROOT/'qa/layer_segmentation_diagnostic.png')
metadata={'status':'STATIC_LIKENESS_GATE_PENDING','asset_id':'lamplighter_C_RUST_known_view_cutout_v01','canonical_sha256':hashlib.sha256(REF.read_bytes()).hexdigest(),'canonical_reference':'../../reference/canonical_original_C_RUST.png','source_size_px':[w,h],'source_rgb_preserved':True,'known_view_only':True,'view':'original front three-quarter concept view; angle is NOT calibrated','camera_contract_compatible':False,'units':'source image pixels, top-left origin','pivot_root_px':[272,1084],'layers':outlayers,'limitations':['Source is one uncalibrated concept view, not a 35.264 degree production view.','No new hidden surface pixels authored; broad articulation and new headings remain blocked.','Source matte edge pixels retained rather than repainted; halo check required.','Only subtle independent coat and lantern idle motion is proposed at this gate.']}
(ROOT/'source/rig_source.json').write_text(json.dumps(metadata,indent=2))
# Static RGB equality check covers every included foreground pixel.
report={'reference_sha256':metadata['canonical_sha256'],'source_size_px':[w,h],'foreground_pixels':int(sil.sum()),'unassigned_foreground_pixels':int(remaining.sum()),'layer_partition_complete':bool(not remaining.any()),'static_rgb_max_absolute_error':int(abs(comp[:,:,:3].astype(int)-a.astype(int))[sil].max()),'static_pixel_identity_test':'PASS','silhouette_review':'PENDING','art_gate':'PENDING'}
(ROOT/'qa/static_pixel_validation.json').write_text(json.dumps(report,indent=2));print(report)
