from PIL import Image,ImageDraw,ImageFont,ImageFilter
from pathlib import Path
import math,json
root=Path(__file__).resolve().parents[1];out=root/'placement_proof';W,H=1920,1080;scale=H/13;e=math.radians(35.264389682754654);a=math.radians(45)
def project(x,z,y=0):return (W/2+(x*math.cos(a)-z*math.sin(a))*scale,760+((x*math.sin(a)+z*math.cos(a))*math.sin(e)-y*math.cos(e))*scale)
# Sprite cards retain native image projection; floor/control points use exact camera.
items=[
 ('vegetation_tall_split_pine_01','volume_15_tree_forms',-5,-4,5.0,.50,.88),
 ('vegetation_pale_birch_cluster_01','volume_15_tree_forms',4,-5,4.0,.56,.88),
 ('vegetation_broad_hollow_oak_01','volume_15_tree_forms',-5,3,4.1,.56,.86),
 ('vegetation_windswept_yew_01','volume_15_tree_forms',6,0,3.6,.46,.88),
 ('vegetation_lightning_split_dead_trunk_01','volume_15_tree_forms',0,-6,2.8,.53,.86),
 ('vegetation_low_dense_juniper_01','volume_15_tree_forms',1,5,1.5,.50,.78),
 ('arch_gothic_wall_01','volume_02_gothic',-1,-1,1.35,.50,.75),
 ('arch_pointed_arch_01','volume_02_gothic',2,-1,3.0,.51,.83),
 ('arch_crypt_door_01','volume_02_gothic',0,1,2.5,.52,.90),
]
manifest=[]
for grid in [True,False]:
 im=Image.new('RGBA',(W,H),'#6c726b');d=ImageDraw.Draw(im)
 # Quiet exact projected plane bounds.
 corners=[project(-14,-14),project(14,-14),project(14,14),project(-14,14)];d.polygon(corners,fill='#87877a')
 if grid:
  for k in range(-14,15,2):
   d.line([project(k,-14),project(k,14)],fill='#a09e8c',width=1)
   d.line([project(-14,k),project(14,k)],fill='#a09e8c',width=1)
 shadow=Image.new('RGBA',(W,H),(0,0,0,0));sd=ImageDraw.Draw(shadow)
 for id,pack,x,z,m,px,py in items:
  r=m*.16
  pts=[project(x+math.cos(t*math.pi/24)*r,z+math.sin(t*math.pi/24)*r*.7) for t in range(48)]
  sd.polygon(pts,fill=(28,32,27,58))
 im=Image.alpha_composite(im,shadow.filter(ImageFilter.GaussianBlur(4)))
 for id,pack,x,z,m,px,py in sorted(items,key=lambda v:sum(v[2:4])):
  path=(root/'assets' if pack==root.name else out/'reference_assets')/f'{id}.png';src=Image.open(path).convert('RGBA');bbox=src.getchannel('A').point(lambda v:255 if v>=128 else 0).getbbox()
  # Crop is inspection layout only. Native deliverables stay untouched.
  src=src.crop(bbox);h=round(m*scale*math.cos(e));w=round(src.width*h/src.height);src=src.resize((w,h),Image.Resampling.LANCZOS);sx,sy=project(x,z);lx=round(sx-px*w);ly=round(sy-py*h);im.alpha_composite(src,(lx,ly))
  if grid:
   d=ImageDraw.Draw(im);d.ellipse((sx-4,sy-4,sx+4,sy+4),fill='#ecb868');d.line([(sx-12,sy),(sx+12,sy)],fill='#312e28',width=1);d.line([(sx,sy-9),(sx,sy+9)],fill='#312e28',width=1)
   manifest.append({'asset':id,'world_root_xz':[x,z],'visual_height_m_assumed':m,'root_anchor_normalized_in_alpha128_bbox':[px,py],'source':path.relative_to(root).as_posix(),'camera_projected_root_screen':[round(sx,3),round(sy,3)]})
 d=ImageDraw.Draw(im);d.rectangle((0,0,W,78),fill='#202a2b');d.text((28,18),'LANTERN / TREE + ARCHITECTURE PLACEMENT PROOF',fill='#e2dcc9');d.text((28,43),'Exact ground projection: elevation 35.2643897 deg / azimuth 45 deg / vertical span 13 m. 2 m grid. Native sprite views remain approximate.',fill='#b7c3be')
 im.convert('RGB').save(out/('tree_architecture_fixed_camera_grid.png' if grid else 'tree_architecture_fixed_camera_clean.png'))
(out/'placement_manifest.json').write_text(json.dumps({'camera':{'elevation_deg':35.264389682754654,'azimuth_deg':45,'vertical_span_m':13,'resolution':[W,H]},'limitations':'Exact ground/control-point projection only. Native raster sprites are screen-facing illustration cards; pine has the most frontal crown view. Subtle projected contact shadows are separate preview layers, never baked into masters; scale and root anchors are manually chosen placement assumptions. No new camera bake, geometry, depth occlusion, collision or engine validation. Cropping/resizing is inspection layout only; source PNGs unchanged.','items':manifest},indent=2))
