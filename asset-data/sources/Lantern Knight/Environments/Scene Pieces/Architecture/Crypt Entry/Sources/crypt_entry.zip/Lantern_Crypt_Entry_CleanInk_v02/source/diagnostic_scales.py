from compose_scenes import *
from PIL import ImageFont
name=sys.argv[1] if len(sys.argv)>1 else 'crypt_entry'
root=ROOT if (ROOT/'scene_layout.json').exists() else ROOT/name
name=json.loads((root/'scene_layout.json').read_text())['scene']
im=Image.open(root/'renders'/f'{name}_1920x1080.png').convert('RGB');d=ImageDraw.Draw(im);f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
pts=[(890,620,'1.8 m proxy at threshold'),(665,720,'1.8 m proxy beside tomb')] if name=='crypt_entry' else [(975,660,'1.8 m proxy at workshop'),(1500,860,'1.8 m proxy at canal edge')]
r=[]
for sx,sy,label in pts:
 p=world(sx,sy);q=(np.array(p)+[0,1.8,0]).tolist();s=screen(p);t=screen(q);height=s[1]-t[1];color=(239,160,235)
 d.line([tuple(s),tuple(t)],fill=color,width=3);d.line([(sx-12,sy),(sx+12,sy)],fill=color,width=3);d.line([(t[0]-12,t[1]),(t[0]+12,t[1])],fill=color,width=3)
 d.ellipse((sx-9,t[1]+9,sx+9,t[1]+27),outline=color,width=2);d.line([(sx,t[1]+28),(sx,t[1]+78)],fill=color,width=2);d.line([(sx-21,t[1]+56),(sx,t[1]+38),(sx+21,t[1]+56)],fill=color,width=2);d.line([(sx-15,sy),(sx,t[1]+78),(sx+15,sy)],fill=color,width=2)
 d.rectangle((sx+15,t[1]-2,sx+320,t[1]+49),fill=(15,22,27));d.text((sx+20,t[1]+2),label,font=f,fill=color);d.text((sx+20,t[1]+26),f'{height:.3f} vertical projected px',font=f,fill=(218,224,228));r.append({'base_world':p,'top_world':q,'height_metres':1.8,'projected_height_pixels':height})
d.rectangle((20,18,1070,87),fill=(11,20,25));d.text((32,26),'DIAGNOSTIC ONLY - exact 35.264389682754654 / 45 orthographic, 13 m span',font=f,fill=(225,231,234));d.text((32,53),'Proxies are measurement guides, not canonical hero art. Generated card dimensions remain estimates.',font=f,fill=(195,202,210))
im.save(root/'qa'/'scale_proxy_1920x1080.png');(root/'qa'/'scale_proxy.json').write_text(json.dumps({'rulers':r,'no_hero_used':True,'nominal_card_dimensions':[{c['id']:c['nominal_world_dimensions_m']} for c in json.loads((root/'scene_layout.json').read_text())['cards'] if 'nominal_world_dimensions_m' in c]},indent=2))
