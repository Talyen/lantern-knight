"""Offline, editable orthographic cutout composition. Source bitmaps are copied intact.
Only UV projection, card placement/resampling and scene material lighting are applied.
World axes X right, Y up, Z ground. Exact camera; illustrated card views approximate.
Run: python source/compose_scenes.py crypt_entry [--verify]
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import numpy as np, json, math, hashlib, sys, shutil
ROOT=Path(__file__).resolve().parents[1]
W,H=1920,1080;SPAN=13;PPM=H/SPAN
E=math.radians(35.264389682754654);A=math.radians(45)
RIGHT=np.array([math.cos(A),0,-math.sin(A)])
UP=np.array([-math.sin(E)*math.sin(A),math.cos(E),-math.sin(E)*math.cos(A)])
TOWARD=np.cross(RIGHT,UP)
def world(sx,sy,y=0):
 r=(sx-W/2)/PPM;u=(H/2-sy)/PPM
 # x-z ground inversion at selected y
 v=np.linalg.solve(np.array([[RIGHT[0],RIGHT[2]],[UP[0],UP[2]]]),np.array([r,u-UP[1]*y]))
 return [float(v[0]),float(y),float(v[1])]
def screen(v):return [W/2+np.dot(v,RIGHT)*PPM,H/2-np.dot(v,UP)*PPM]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sampled(im,x,z,metres=4,offset=(0,0)):
 arr=np.asarray(im.convert('RGB'));ih,iw=arr.shape[:2]
 ix=np.floor(((x-offset[0])/metres%1)*iw).astype(int);iz=np.floor(((z-offset[1])/metres%1)*ih).astype(int)
 return arr[iz,ix].astype(np.float32)
def render(name):
 root=ROOT if (ROOT/'scene_layout.json').exists() else ROOT/name;layout=json.loads((root/'scene_layout.json').read_text());name=layout['scene'];assets={a['id']:a for a in layout['assets']}
 for a in assets.values():assert sha(root/a['file'])==a['sha256'],a['id']
 yy,xx=np.mgrid[0:H,0:W];r=(xx-W/2)/PPM;u=(H/2-yy)/PPM
 x=r/math.sqrt(2)-u/(math.sqrt(2)*math.sin(E));z=-r/math.sqrt(2)-u/(math.sqrt(2)*math.sin(E))
 def tex(n):return Image.open(root/assets[n]['file'])
 base_y=layout['ground'].get('base_plane_height_metres',0);base_shift=base_y*math.cos(E)/(math.sqrt(2)*math.sin(E))
 base=sampled(tex(layout['ground']['base']),x+base_shift,z+base_shift,layout['ground'].get('base_tile_metres',4))
 # Explicit world-space floor zones, no screen-view texture rebaking.
 for zone in layout['ground']['zones']:
  mask=Image.new('L',(W,H));d=ImageDraw.Draw(mask);d.polygon([tuple(screen(v)) for v in zone['world_polygon']],fill=255)
  if zone.get('feather_px'):mask=mask.filter(ImageFilter.GaussianBlur(zone['feather_px']))
  m=np.asarray(mask,dtype=np.float32)[...,None]/255
  t=sampled(tex(zone['asset']),x,z,zone.get('tile_metres',4))
  base=base*(1-m)+t*m
 # Lighting is scene-level multiplicative diffuse treatment, not source art alteration.
 light=np.ones((H,W,3),np.float32)*np.array(layout['ground']['ambient'])
 for pool in layout['ground'].get('light_pools',[]):
  px,pz=pool['world'][0],pool['world'][2];g=np.maximum(0,1-((x-px)**2+(z-pz)**2)**.5/pool['radius'])**pool.get('falloff',1.4)
  light+=g[...,None]*np.array(pool['rgb'])
 
 for sh in layout['ground'].get('shadow_polygons',[]):
  mask=Image.new('L',(W,H));ImageDraw.Draw(mask).polygon([tuple(screen(v)) for v in sh['world_polygon']],fill=255)
  if sh.get('softness_px'):mask=mask.filter(ImageFilter.GaussianBlur(sh['softness_px']))
  m=np.asarray(mask,dtype=np.float32)[...,None]/255;light*=1-m*(1-sh['multiplier'])
 floor=np.clip(base*light,0,255).astype('uint8');canvas=Image.fromarray(floor).convert('RGBA')
 # Ground features use exact top-down UV quadrilaterals. Cards retain their own pixels.
 records=[]
 for c in sorted(layout['cards'],key=lambda q:q['layer']):
  asset=assets[c['asset']];im=tex(c['asset']).convert('RGBA');iw,ih=im.size;pivot=c['pivot_px'];scale=c['projected_pixels_per_source_pixel'];pos=screen(c['world_position']);
  if c.get('contact'):
   contact=Image.new('RGBA',(W,H));d=ImageDraw.Draw(contact);rx,rz=c['contact'];pts=[screen(np.array(c['world_position'])+np.array([rx*math.cos(t),-.01,rz*math.sin(t)])) for t in np.linspace(0,math.tau,50)]
   d.polygon([tuple(v) for v in pts],fill=(6,13,17,155));canvas=Image.alpha_composite(canvas,contact.filter(ImageFilter.GaussianBlur(3)))
  # Source alpha stays unchanged. The shader multiplier is recorded in JSON.
  ar=np.asarray(im).copy();ar[:,:,:3]=(ar[:,:,:3].astype(float)*np.array(c.get('material_tint',[1,1,1]))).clip(0,255).astype('uint8');im=Image.fromarray(ar)
  if c.get('flip_x'):
   im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT);pivot=[iw-pivot[0],pivot[1]]
  nw,nh=max(1,round(iw*scale)),max(1,round(ih*scale));im=im.resize((nw,nh),Image.Resampling.LANCZOS)
  left,top=round(pos[0]-pivot[0]*scale),round(pos[1]-pivot[1]*scale)
  
  if c.get('native_recess_polygon_px'):
   recess=Image.new('RGBA',(W,H));ImageDraw.Draw(recess).polygon([(left+px*scale,top+py*scale) for px,py in c['native_recess_polygon_px']],fill=(7,14,18,255));canvas=Image.alpha_composite(canvas,recess)
  canvas.alpha_composite(im,(left,top));records.append({'id':c['id'],'projected_anchor_px':pos,'source_sha256':asset['sha256'],'screen_box':[left,top,left+nw,top+nh]})
 canvas.convert('RGB').save(root/'renders'/f'{name}_1920x1080.png')
 canvas.convert('RGB').resize((960,540),Image.Resampling.LANCZOS).save(root/'renders'/f'{name}_gameplay_960.png')
 q={'camera_exact':True,'camera_basis':{'right':RIGHT.tolist(),'up':UP.tolist(),'toward':TOWARD.tolist()},'world_units':'metres','resolution':[W,H],'vertical_span':SPAN,'virtual_1_8m_ruler_pixels':1.8*math.cos(E)*PPM,'source_pixels_unchanged':True,'card_views_exact':False,'no_hero':True,'cards':records}
 (root/'qa'/'projection_validation.json').write_text(json.dumps(q,indent=2))
 print(root/'renders'/f'{name}_1920x1080.png')
if __name__=='__main__':render(sys.argv[1] if len(sys.argv)>1 else 'crypt_entry')
