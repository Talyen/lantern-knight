Seven independent fresh rasterillustration repairs;t06stillpuddle+t07dampspread retained byte-for-byte. Four coverage masks:two regenerated to follow new boundary alpha,two original masks retained.
Technical mask SVG paths are derived from paired PNG alpha,not independent new artwork.
