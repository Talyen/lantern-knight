Six independent fresh illustrated repairs; original quiet puddle bed and stepping slabs retained, with their SVG sources. No edit cascades.
Uniform fitting is packaging only; rejected candidates excluded.
