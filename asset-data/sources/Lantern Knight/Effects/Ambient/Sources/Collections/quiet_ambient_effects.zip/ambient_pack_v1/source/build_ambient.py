#!/usr/bin/env python3
"""Original periodic/one-shot ambient vector art. No image inputs or AI synthesis."""
from pathlib import Path
import math,json,hashlib,subprocess,zipfile
import numpy as np
from PIL import Image,ImageDraw
from vfx_core import Canvas,proj,local,font,clamp,smooth,C,W,H,PIVOT,DENSITY,ELEVATION,AZIMUTH,SS
ROOT=Path(__file__).resolve().parents[1]
if ROOT.name=='ambient_pack_v1':ROOT=ROOT.parent
C.update({'smoke':'#8d9085','smokelight':'#b7b6a4','leaf':'#947644','leafshade':'#615640'})
SPECS={
 'lamp_flame':{'label':'Lamp flame','frames':24,'fps':24,'loop':True,'space':'screen_billboard','description':'Small flame with a stable socket base and periodic tip/shoulder motion. No glow halo.'},
 'rising_motes':{'label':'Rising motes','frames':24,'fps':12,'loop':True,'space':'projected_world','description':'Four fixed amber motes rise and fade through a compact 0.75 m emitter column.'},
 'quiet_smoke':{'label':'Quiet smoke curl','frames':24,'fps':12,'loop':True,'space':'screen_billboard','description':'Low-opacity clean-edged smoke ribbon with periodic advection. No texture noise.'},
 'tumbling_leaf':{'label':'Tumbling leaf','frames':24,'fps':12,'loop':False,'space':'projected_world','description':'One muted leaf falls, turns in 3D, drifts and fades near the ground. Not a color variant.'},
 'pond_ripple':{'label':'Soft pond ripple','frames':24,'fps':12,'loop':False,'space':'projected_world','description':'Three broken reflection arcs spread across the exact projected ground plane and fade.'},
 'droplet_splash':{'label':'Droplet splash','frames':24,'fps':24,'loop':False,'space':'projected_world','description':'Three small droplets rise/fall, then leave two delayed ripple arcs. Separate behavior from the pond ripple.'},
}

def bezier(p0,p1,p2,p3,n=10):
 return [((1-q)**3*p0[0]+3*(1-q)**2*q*p1[0]+3*(1-q)*q*q*p2[0]+q**3*p3[0],(1-q)**3*p0[1]+3*(1-q)**2*q*p1[1]+3*(1-q)*q*q*p2[1]+q**3*p3[1]) for q in [i/n for i in range(n+1)]]

def flame(c,t):
 x,y=PIVOT;phase=2*math.pi*t
 sway=7*math.sin(phase)+2*math.sin(2*phase+.8);height=58+4*math.sin(phase+1.1);w=14+1.8*math.sin(phase+.6)
 tip=(x+sway,y-height)
 pts=[]
 sections=[((x,y),(x-w*1.5,y-7),(x-w*1.0,y-24),(x-w*.37,y-36)),((x-w*.37,y-36),(x-w*.46,y-29),(x-w*.1,y-27),(x+w*.17,y-26)),((x+w*.17,y-26),(x+w*.32,y-35),(x+sway-5,y-height+10),tip),(tip,(x+sway+4,y-height+18),(x+w*1.28,y-28),(x+w,y-16)),((x+w,y-16),(x+w*.95,y-3),(x+w*.23,y+1),(x,y))]
 for s in sections:pts+=bezier(*s)
 c.poly(pts,'ochre',.95)
 c.poly([(x+(px-x)*.79,y+(py-y)*.92) for px,py in pts],'amber',1)
 inner=bezier((x-5,y-2),(x-9,y-11),(x+4,y-22),(x+sway*.35,y-34))+bezier((x+sway*.35,y-34),(x+12,y-16),(x+7,y-5),(x-5,y-2))
 c.poly(inner,'bone',.98)
 # Fine dark slit creates intentional clean-ink separation at the shoulder.
 c.poly([(x-w*.75,y-23),(x-w*.36,y-32),(x-w*.46,y-22)],'ochre',.85)

def motes(c,t):
 for i in range(4):
  q=(t+i/4)%1;a=math.sin(math.pi*q)**1.8
  x=[-.17,.11,-.04,.20][i]+.045*math.sin(2*math.pi*q+i)
  z=[-.07,.04,.11,-.03][i];y=.05+.70*q
  xx,yy=proj((x,y,z));sz=[2.7,2.1,2.4,1.8][i]
  c.poly([(xx-sz,yy),(xx-.15*sz,yy-sz*1.6),(xx+sz*.65,yy),(xx,yy+sz)],'amber',a*.86)
  c.poly([(xx-.3*sz,yy),(xx,yy-.7*sz),(xx+.3*sz,yy)],'bone',a*.60)

def smoke(c,t):
 x,y=PIVOT;phase=2*math.pi*t
 outer=[];inner=[]
 for j in range(65):
  q=j/64
  cx=x+17*math.sin(q*3*math.pi-phase)*q+8*q
  cy=y-112*q
  width=(4+14*q)*(math.sin(math.pi*q)**.8)
  outer.append((cx-width,cy));inner.append((cx+width,cy))
 c.poly(outer+inner[::-1],'smoke',.29)
 inner1=[];inner2=[]
 for j in range(65):
  q=j/64;cx=x+17*math.sin(q*3*math.pi-phase)*q+8*q;cy=y-112*q
  width=(2+6*q)*(math.sin(math.pi*q)**.8)
  inner1.append((cx-width*.4,cy));inner2.append((cx+width,cy))
 c.poly(inner1+inner2[::-1],'smokelight',.17)

def leaf(c,t):
 if t<=0 or t>=1:return
 a=smooth(t/.12)*(1-smooth((t-.85)/.15));cx=-.38+.81*t;cz=.13*math.sin(2*math.pi*t);cy=1.22*(1-t)
 yaw=math.radians(40+270*t);tilt=math.radians(24+100*math.sin(math.pi*t));roll=math.radians(55*math.sin(2*math.pi*t))
 shape=[(0,.24),(-.08,.12),(-.102,-.035),(-.064,-.17),(0,-.25),(.06,-.14),(.083,.025),(.05,.155)]
 def vertex(u,v):
  xx=u;yy=v*math.sin(tilt);zz=v*math.cos(tilt)
  xxx=xx*math.cos(roll)-yy*math.sin(roll);yyy=xx*math.sin(roll)+yy*math.cos(roll)
  return (cx+xxx*math.cos(yaw)+zz*math.sin(yaw),cy+yyy,cz-xxx*math.sin(yaw)+zz*math.cos(yaw))
 pts=[vertex(u,v) for u,v in shape];c.worldpoly(pts,'ink',a*.82)
 c.worldpoly([vertex(u*.82,v*.91) for u,v in shape],'leaf',a)
 c.worldpoly([vertex(0,.21),vertex(-.061,.10),vertex(-.082,-.032),vertex(-.05,-.16),vertex(0,-.22)],'leafshade',a)
 c.worldpoly([vertex(-.004,-.24),vertex(.002,.20),vertex(.008,.12),vertex(.005,-.27)],'ochre',a*.52)

def world_arc(c,r,w,start,end,alpha,col='bone',cx=0,cz=0):
 outer=[];inner=[]
 for j in range(45):
  q=j/44;ang=math.radians(start+(end-start)*q);ww=w*(math.sin(math.pi*q)**.6)
  outer.append((cx+math.cos(ang)*(r+ww/2),.012,cz+math.sin(ang)*(r+ww/2)))
  inner.append((cx+math.cos(ang)*(r-ww/2),.012,cz+math.sin(ang)*(r-ww/2)))
 c.worldpoly(outer+inner[::-1],col,alpha)

def ripple(c,t):
 if t<=0 or t>=1:return
 a=smooth(t/.10)*(1-smooth((t-.28)/.72));r=.05+.79*smooth(t)
 for start,end,weight in [(8,112,1),(130,231,.74),(252,350,.85)]:
  world_arc(c,r,.039,start,end,a*.40,'charcoal')
  world_arc(c,r+.015,.023,start+4,end-4,a*.61*weight,'bone')
 if t>.2:
  r2=.03+.45*smooth((t-.20)/.8)
  world_arc(c,r2,.019,30,173,a*.23,'bone')

def splash(c,t):
 if t<=0 or t>=1:return
 a=smooth(t/.07)*(1-smooth((t-.62)/.38))
 for i,deg in enumerate([18,145,259]):
  q=clamp(t/(.51+i*.025));ang=math.radians(deg);r=.025+.28*q;yy=(.31+i*.035)*math.sin(math.pi*q)
  if 0<q<1:
   x=r*math.cos(ang);z=r*math.sin(ang);xx,y=proj((x,yy,z));w=1.9*(1-.35*q);h=5.3*(1-.5*q)
   c.poly([(xx-w,y),(xx,y-h),(xx+w,y),(xx,y+h*.54)],'charcoal',a*.46)
   c.poly([(xx-w*.6,y),(xx,y-h*.75),(xx+w*.50,y),(xx,y+h*.23)],'bone',a*.83)
 if t>.22:
  q=(t-.22)/.78;r=.08+.55*smooth(q);aa=math.sin(math.pi*q)*.6
  world_arc(c,r,.030,-20,119,aa,'bone');world_arc(c,r,.028,147,296,aa*.62,'charcoal')
 if t>.45:
  q=(t-.45)/.55;world_arc(c,.03+.32*smooth(q),.021,24,258,math.sin(math.pi*q)*.35,'bone')

FUNCS={'lamp_flame':flame,'rising_motes':motes,'quiet_smoke':smoke,'tumbling_leaf':leaf,'pond_ripple':ripple,'droplet_splash':splash}

def render(name,i):
 spec=SPECS[name];c=Canvas();t=i/spec['frames'] if spec['loop'] else i/(spec['frames']-1)
 FUNCS[name](c,t);return c

def export_clip(name,out):
 spec=SPECS[name];n=spec['frames'];fps=spec['fps'];folder=out/'frames'/name;folder.mkdir(parents=True,exist_ok=True);svgs=out/'vectors'/name;svgs.mkdir(parents=True,exist_ok=True)
 images=[];frames=[];bounds=[]
 for i in range(n):
  c=render(name,i);im=c.export(folder/f'{i:03d}.png');images.append(im);(svgs/f'{i:03d}.svg').write_text(c.svg_text());bounds.append(im.getbbox())
 b=[x for x in bounds if x];union=[min(x[0] for x in b)-2,min(x[1] for x in b)-2,max(x[2] for x in b)+2,max(x[3] for x in b)+2]
 cw,ch=union[2]-union[0],union[3]-union[1];pad=3;cols=6;rows=math.ceil(n/cols);atlas=Image.new('RGBA',(cols*(cw+2*pad),rows*(ch+2*pad)))
 for i,im in enumerate(images):
  x=pad+(i%cols)*(cw+pad*2);y=pad+(i//cols)*(ch+pad*2);atlas.paste(im.crop(union),(x,y))
  frames.append({'id':i,'file':f'frames/{name}/{i:03d}.png','svg':f'vectors/{name}/{i:03d}.svg','rectPx':[x,y,cw,ch],'sourceSizePx':[W,H],'trimOffsetPx':union[:2],'atlasSourceCropPx':union,'pivotPx':list(PIVOT),'atlasPivotPx':[PIVOT[0]-union[0],PIVOT[1]-union[1]],'durationRational':[1,fps],'durationSeconds':1/fps,'alphaBoundsPx':list(bounds[i]) if bounds[i] else None})
 (out/'atlases').mkdir(exist_ok=True);atlas.save(out/'atlases'/f'{name}.png',optimize=True)
 return {'id':name,**spec,'frameCount':n,'frames':frames,'sourceFPS':fps,'durationSeconds':n/fps,'durationRational':[n,fps],'atlas':f'atlases/{name}.png','atlasSizePx':list(atlas.size),'atlasPaddingPx':pad,'atlasCropPolicy':'constant union crop for the whole clip, untrimmed loose PNGs','pivotMeaning':'emitter / water-impact / fall root; zero additional baked socket height','finishBehavior':'wrap to frame 0 with no duplicate endpoint' if spec['loop'] else 'remove after transparent final frame','blend':{'pngAlpha':'straight (unassociated)','premultipliedAlpha':False,'recommended':'normal source-over','sourceFactor':'SRC_ALPHA','destinationFactor':'ONE_MINUS_SRC_ALPHA','textureColorSpace':'sRGB','blendColorSpace':'linear preferred','alphaIsLinear':True,'additiveRequired':False},'visualEvents':[],'gameplayAuthority':'none'}

def qa(out,clips):
 report={'passed':True,'issues':[],'clipCount':len(clips),'frameCount':sum(c['frameCount'] for c in clips),'loopSeams':{},'minimumMarginPx':999,'atlasCropMatches':True,'zeroRGBUnderZeroAlpha':True}
 for clip in clips:
  atlas=Image.open(out/clip['atlas']).convert('RGBA');arrays=[];hashes=set()
  for f in clip['frames']:
   im=Image.open(out/f['file']).convert('RGBA');a=np.array(im);arrays.append(a);hashes.add(hashlib.sha256(a.tobytes()).hexdigest())
   if np.any(a[a[:,:,3]==0,:3]):report['issues'].append('Hidden RGB '+f['file']);report['zeroRGBUnderZeroAlpha']=False
   x,y,w,h=f['rectPx']
   if atlas.crop((x,y,x+w,y+h)).tobytes()!=im.crop(f['atlasSourceCropPx']).tobytes():report['issues'].append('Atlas mismatch '+f['file']);report['atlasCropMatches']=False
   b=im.getbbox()
   if b:report['minimumMarginPx']=min(report['minimumMarginPx'],b[0],b[1],W-b[2],H-b[3])
  expected=clip['frameCount'] if clip['loop'] else clip['frameCount']-1
  if len(hashes)!=expected:report['issues'].append('Unexpected duplicate frames '+clip['id'])
  if max(atlas.size)>2048:report['issues'].append('Texture exceeds 2048 '+clip['id'])
  if clip['loop']:
   # Alpha-weighted differences avoid counting irrelevant RGB values at low alpha.
   values=[a.astype(np.float32)*a[:,:,3,None]/255 for a in arrays]
   differences=[float(np.abs(values[(i+1)%len(values)]-values[i]).mean()) for i in range(len(values))]
   seam=differences[-1];others=max(differences[:-1]);ratio=seam/max(others,.00001)
   report['loopSeams'][clip['id']]={'lastToFirstMeanAbsoluteDifference':round(seam,6),'maxOtherAdjacentDifference':round(others,6),'seamToMaxAdjacentRatio':round(ratio,4),'sampleConvention':'phase=i/24; no duplicated endpoint','passed':ratio<=1.25}
   if ratio>1.25:report['issues'].append('Loop seam outlier '+clip['id'])
  elif arrays[0][:,:,3].max()!=0 or arrays[-1][:,:,3].max()!=0:report['issues'].append('Nontransparent one-shot endpoints '+clip['id'])
 if report['minimumMarginPx']<4:report['issues'].append('Clipping margin below 4 px')
 report['passed']=not report['issues'];(out/'qa_report.json').write_text(json.dumps(report,indent=2)+'\n');return report

def background(light):
 bg=(209,205,191) if light else (38,44,43);floor=(198,195,180) if light else (45,51,49);line=(178,176,163) if light else (51,57,54)
 im=Image.new('RGB',(640,315),bg);d=ImageDraw.Draw(im);d.polygon([(0,115),(640,65),(640,315),(0,315)],fill=floor)
 for k in range(-3,8):
  x=k*160;d.line([(x,100),(x+480,315)],fill=line);d.line([(x,100),(x-480,315)],fill=line)
 return im

def make_preview(out,clips):
 review=out/'review';review.mkdir(exist_ok=True);allframes={c['id']:[Image.open(out/f['file']).convert('RGBA') for f in c['frames']] for c in clips}
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1280x800','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','21','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(review/'ambient_review_60hz.mp4')]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for tick in range(864):
  page=tick//288;pt=tick%288;pair=clips[page*2:page*2+2];im=Image.new('RGB',(1280,800),(24,29,29));d=ImageDraw.Draw(im)
  d.text((30,19),'LANTERN  /  QUIET AMBIENT EFFECTS',font=font(23,True),fill=(244,236,217));d.text((30,53),'Six distinct motion behaviors  ·  controlled source drawings  ·  60 Hz review',font=font(15),fill=(175,179,169))
  for row,clip in enumerate(pair):
   seconds=pt/60;cycle=seconds if clip['loop'] else seconds%2.4;fi=math.floor(cycle*clip['sourceFPS']);fi=fi%clip['frameCount'] if clip['loop'] else fi;fr=allframes[clip['id']][fi] if fi<clip['frameCount'] else None
   for col in range(2):
    card=background(col==1);cd=ImageDraw.Draw(card);tx=(44,50,47) if col else (238,230,210)
    cd.text((25,14),clip['label'],font=font(18,True),fill=tx)
    cd.text((25,40),('Light' if col else 'Dark')+' ground  |  '+('loop' if clip['loop'] else 'one-shot'),font=font(12),fill=tx)
    root=(320,255)
    if clip['id'] in ['lamp_flame','rising_motes','quiet_smoke']:
     root=(320,216)
     # Plain original display fixture, not exported art and not the hero's lantern.
     ink=(62,67,60);edge=(119,112,90)
     cd.polygon([(302,216),(338,216),(334,223),(306,223)],fill=ink);cd.polygon([(316,223),(324,223),(326,256),(314,256)],fill=ink)
     cd.polygon([(303,258),(337,258),(329,264),(311,264)],fill=ink);cd.line([(306,216),(334,216)],fill=edge,width=2)
    if fr:
     scaled=fr.resize((round(W*.742),round(H*.742)),Image.Resampling.LANCZOS);card.paste(scaled,(round(root[0]-PIVOT[0]*.742),round(root[1]-PIVOT[1]*.742)),scaled)
    cd=ImageDraw.Draw(card);cd.text((25,289),f"24 frames / {clip['sourceFPS']} fps / {clip['durationSeconds']:.1f}s  ·  "+(f'frame {fi+1:02d}' if fr else 'cleared'),font=font(12),fill=tx);im.paste(card,(col*640,91+row*321))
  d=ImageDraw.Draw(im);d.text((30,746),'Exact ground projection: 35.2643897° / 45°.  Flame and smoke are explicit facing-camera billboards.',font=font(13),fill=(185,187,176));d.text((30,771),'No gameplay consequences, engine changes or borrowed art.  Preview is 1080p-equivalent scale at a 13 m view.',font=font(12),fill=(141,149,141))
  if pt==40:im.save(review/f'proof_page_{page+1:02d}.jpg',quality=94)
  proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('ffmpeg failed')
 sheet=Image.new('RGB',(1536,258*len(clips)),(28,33,33))
 for row,clip in enumerate(clips):
  for j in range(6):
   idx=[1,5,9,13,17,21][j];bg=(205,202,189) if j%2 else (43,49,47);tx=(45,51,48) if j%2 else (238,230,211)
   cell=Image.new('RGB',(256,258),bg);fr=allframes[clip['id']][idx].resize((256,224),Image.Resampling.LANCZOS);cell.paste(fr,(0,17),fr);cd=ImageDraw.Draw(cell);cd.text((10,4),clip['label'],font=font(12,True),fill=tx);cd.text((10,240),f"frame {idx:02d} / 24  |  {clip['sourceFPS']} fps",font=font(10),fill=tx);sheet.paste(cell,(j*256,row*258))
 sheet.save(review/'source_frame_contact.jpg',quality=94)

def main():
 out=ROOT/'ambient_pack_v1';out.mkdir(exist_ok=True);clips=[]
 for name in SPECS:print('Building',name,flush=True);clips.append(export_clip(name,out))
 manifest={'schema':'lantern.controlled-vfx.v1','version':'1.0.0','status':'original ambient art candidate; owner/runtime validation not implied','authoring':'deterministic vector geometry with periodic parameters; no image inputs or AI synthesis','camera':{'projection':'orthographic','elevationDegrees':ELEVATION,'azimuthDegrees':AZIMUTH,'azimuthConvention':'from +Z toward +X','worldAxes':'right-handed XZ ground +Y vertical','sourcePixelsPerWorldMetre':DENSITY,'imageOrigin':'top_left','sourceCanvasPx':[W,H],'rootPivotPx':list(PIVOT),'screenRight':[math.sqrt(.5),0,-math.sqrt(.5)],'screenUp':[-1/math.sqrt(6),math.sqrt(2/3),-1/math.sqrt(6)],'matrixConvention':'basis row dot world; image y negates screen-up; multiply by density then add pivot'},'gameplayAuthority':'none','license':'Original artwork for the Lantern project; no external art assets included.','clips':clips}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');report=qa(out,clips);print(json.dumps(report,indent=2),flush=True)
 if not report['passed']:raise SystemExit(2)
 make_preview(out,clips)
 source=out/'source';source.mkdir(exist_ok=True)
 for name in ['build_ambient.py','vfx_core.py']:(source/name).write_text((Path(__file__).parent/name).read_text())
 budget={'atlasMaximumDimensionPx':max(max(c['atlasSizePx']) for c in clips),'allAtlasBaseRGBA8Bytes':sum(c['atlasSizePx'][0]*c['atlasSizePx'][1]*4 for c in clips),'mipmapsIncluded':False,'runtimePerformanceTested':False,'notes':'Raw RGBA8 base-level estimate, not measured GPU memory or compressed PNG size. Do not upload both loose frames and atlases.'};(out/'texture_budget.json').write_text(json.dumps(budget,indent=2)+'\n')
 (out/'README.txt').write_text('''LANTERN — QUIET AMBIENT EFFECTS / v1.0
Original vector/code-authored art. Six distinct behaviors, 144 RGBA source drawings.

CONTENTS
Lamp flame: 24 frames at 24 fps; 1 s loop; stable socket base.
Rising motes: 24 frames at 12 fps; 2 s loop; four deliberate rising particles.
Quiet smoke curl: 24 frames at 12 fps; 2 s loop; clean translucent ribbon.
Tumbling leaf: 24 frames at 12 fps; 2 s one-shot; real 3D rotation and ground projection.
Soft pond ripple: 24 frames at 12 fps; 2 s one-shot; broken spreading reflection arcs.
Droplet splash: 24 frames at 24 fps; 1 s one-shot; three droplets and delayed ripples.
These are six motion designs, not recolor duplicates or AI-generated frame variations.

SOURCE / CAMERA / PLACEMENT
PNG and corresponding editable SVG exist for every authored frame. Source geometry,
timing and palette are in source/build_ambient.py and source/vfx_core.py.
Right-handed XZ ground; +Y height; orthographic elevation 35.264389682754654 degrees,
azimuth 45 degrees from +Z toward +X. Ground effects are actually projected geometry.
Flame and smoke are deliberately SCREEN BILLBOARDS; their manifest says so. They
are not claims of arbitrary-direction 3D bakes. Their root is the bottom emitter.
Source density 112 px/m; 512 x 448 canvas, top-left image origin, fixed pivot
(256,286). Socket emitters add no baked socket height. Place pivot at the socket.
Leaf/ripples use the ground root. Source measurements are visual dimensions only.
At 1440 px buffer / 13 m span, scale all source pixels uniformly by 0.98901;
at 1080 px / 13 m span use 0.74176, as in the preview. Do not distort axes.

TIMING
Each loop samples phase=i/24, excludes a duplicated terminal drawing and wraps to
frame 0. The next frame at the boundary is one ordinary phase step later. Loop QA
compares the boundary difference with ordinary adjacent differences. One-shots use
transparent first and final frames and are removed at their end. All durations are
explicit rational values in manifest.json. The 60 Hz MP4 repeats source frames for
2.5 or 5 render samples as appropriate; 24 fps uses the natural 2/3 sample cadence.
It does not claim 60 distinct drawings per second or optical-flow interpolation.
No effect controls damage, status, collision, movement, water simulation or timers.

ATLAS / ALPHA
One fixed union crop per clip; loose PNGs retain their complete canvas. Manifest
records sourceSizePx, trimOffsetPx, pivotPx, atlasPivotPx and exact atlas rectangles.
All atlases are at most 2048 px on either axis, with 3 px transparent gutters.
PNG alpha is STRAIGHT / UNASSOCIATED, never pre-multiplied. RGB under zero alpha is
zero. RGB is sRGB; alpha is linear. Normal source-over blending uses SRC_ALPHA and
ONE_MINUS_SRC_ALPHA. If the engine explicitly premultiplies uploads, use the matching
ONE / ONE_MINUS_SRC_ALPHA factors instead and do not premultiply twice. Use linear
colour blending where supported. Additive blending and bloom are not required.
Disable mipmaps for these atlases; mipmapped use needs alpha-aware extrusion and
padding per mip level. Default linear sampling at the native scale is the target.

REBUILD / VERIFY
Python 3, Pillow, numpy and ffmpeg with libx264. Run python source/build_ambient.py.
Rebuilding uses deterministic parameters; no outside images, internet or engine.
qa_report.json covers hidden RGB, exact atlas crop mapping, source uniqueness,
transparent endpoints, margins and cyclic seam checks. SHA256SUMS.txt indexes all
exported files except itself. texture_budget.json reports raw base RGBA8 allocation,
not compressed file size or a runtime test. Review images and the MP4 use simple
original display fixtures only; those fixtures are not exported game assets.

BOUNDARIES
No locked hero art was edited. No Unity, Codex or three.js integration was performed.
Attachment placement, alpha sorting, loading, gameplay synchronization and scene
performance remain for the owner's engineering work. Generated 6 October 2026.
''')
 hashes=[]
 for f in sorted(out.rglob('*')):
  if f.is_file() and f.name!='SHA256SUMS.txt':hashes.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(out).as_posix())
 (out/'SHA256SUMS.txt').write_text('\n'.join(hashes)+'\n')
 zp=ROOT/'Lantern_Quiet_Ambient_Effects_v1.zip'
 with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(out.rglob('*')):
   if f.is_file():z.write(f,f.relative_to(out.parent))
 if zp.stat().st_size>12_000_000:raise ValueError('Archive exceeds 12 MB')
 print('ZIP',zp,zp.stat().st_size,hashlib.sha256(zp.read_bytes()).hexdigest(),flush=True)
if __name__=='__main__':main()
