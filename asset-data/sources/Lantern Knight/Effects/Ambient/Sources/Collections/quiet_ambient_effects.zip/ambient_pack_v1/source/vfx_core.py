#!/usr/bin/env python3
"""Original deterministic Clean Ink effect geometry. No image inputs or AI frame generation.
Python 3 + Pillow + numpy; ffmpeg is used only for 60 Hz review movies.
"""
from pathlib import Path
import argparse, hashlib, json, math, subprocess, zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
if ROOT.name in ('combat_pack_v1','early_review'): ROOT = ROOT.parent
W,H=512,448
PIVOT=(256,286)
DENSITY=112.0
SS=3
FPS=30
ELEVATION=35.264389682754654
AZIMUTH=45.0
C={'ink':'#272b2b','charcoal':'#454947','bone':'#f5edda','ivory':'#fff8e7','amber':'#e8aa49','ochre':'#b87634','dust':'#a79b80','lightdust':'#d0c5aa'}

def clamp(t,a=0,b=1): return max(a,min(b,t))
def smooth(t): t=clamp(t); return t*t*(3-2*t)
def rgba(color, alpha):
 color=C.get(color,color).lstrip('#')
 return tuple(int(color[i:i+2],16) for i in (0,2,4))+(round(clamp(alpha)*255),)
def local(x,y,z,yaw=0):
 a=math.radians(yaw)
 return (x*math.cos(a)+z*math.sin(a),y,-x*math.sin(a)+z*math.cos(a))
def proj(p):
 x,y,z=p;a=math.radians(AZIMUTH);e=math.radians(ELEVATION)
 return (PIVOT[0]+DENSITY*(math.cos(a)*x-math.sin(a)*z),PIVOT[1]-DENSITY*(-math.sin(e)*math.sin(a)*x+math.cos(e)*y-math.sin(e)*math.cos(a)*z))

class Canvas:
 def __init__(self):
  self.image=Image.new('RGBA',(W*SS,H*SS));self.svg=[]
 def poly(self,pts,col,alpha=1):
  if alpha<=0 or len(pts)<3:return
  color=rgba(col,alpha)
  layer=Image.new('RGBA',self.image.size)
  ImageDraw.Draw(layer).polygon([(round(x*SS),round(y*SS)) for x,y in pts],fill=color)
  self.image=Image.alpha_composite(self.image,layer)
  v=' '.join(f'{x:.3f},{y:.3f}' for x,y in pts)
  self.svg.append(f'<polygon points="{v}" fill="{C.get(col,col)}" fill-opacity="{clamp(alpha):.5f}"/>')
 def worldpoly(self,pts,col,alpha=1,yaw=0):self.poly([proj(local(*p,yaw)) for p in pts],col,alpha)
 def export(self,path):
  im=self.image.resize((W,H),Image.Resampling.LANCZOS)
  a=np.array(im); a[a[:,:,3]==0,:3]=0
  im=Image.fromarray(a);im.save(path,optimize=True)
  return im
 def svg_text(self):return '<svg xmlns="http://www.w3.org/2000/svg" width="512" height="448" viewBox="0 0 512 448">\n'+ '\n'.join(self.svg)+'\n</svg>\n'

def font(size,bold=False):
 name='DejaVuSans'+('-Bold' if bold else '')+'.ttf'
 for candidate in ['/usr/share/fonts/truetype/dejavu/'+name,name]:
  try:return ImageFont.truetype(candidate,size)
  except OSError:pass
 return ImageFont.load_default(size=size)

