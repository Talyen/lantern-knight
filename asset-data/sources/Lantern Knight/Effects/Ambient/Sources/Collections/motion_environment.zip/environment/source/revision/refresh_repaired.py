from build_pack import *
for pack in ['combat','flare_treatments']:
 out=ROOT/pack;m=json.load(open(out/'manifest.json'))
 for i,c in enumerate(m['clips']):
  if c.get('revisionStatus')!='repaired':continue
  name=c.get('effect',c.get('treatment',c.get('family')));head=c.get('headingDegrees') or 0
  c,ims=clip_export(out,c,name,c['frameCount'],head)
  if head in [0,135]:review(out,c,ims)
  m['clips'][i]=c
 (out/'manifest.json').write_text(json.dumps(m,indent=2));print('REFRESHED',pack,flush=True)
