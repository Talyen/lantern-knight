from build_pack import *
import ink_motion as ink
class Capture:
 def poly(self,*args,**kwargs):pass
records=[]
for name,kind in [('layered_flame_tongues',0),('fractured_amber_panes',1),('curling_ember_ribbons',2)]:
 for heading in range(0,360,45):
  points=[];original=ink.proj
  def save(p):points.append(p);return (0,0)
  ink.proj=save
  try:
   for i in range(24):ink.flare(Capture(),i/23,heading,kind)
  finally:ink.proj=original
  a=math.radians(heading);radii=[];angles=[]
  for x,y,z in points:
   xx=x*math.cos(a)-z*math.sin(a);zz=x*math.sin(a)+z*math.cos(a)-.05;radii.append(math.hypot(xx,zz))
   if radii[-1]>1e-7:angles.append(abs(math.degrees(math.atan2(xx,zz))))
  rec={'id':f'{name}__d{heading:03d}','checkedProjectedVertices':len(points),'maxRadiusMetres':max(radii),'maxHalfAngleDegrees':max(angles),'passed':max(radii)<=2.1+1e-7 and max(angles)<=28+1e-7};records.append(rec)
r={'passed':all(r['passed'] for r in records),'nominalEnvelope':{'radiusMetres':2.1,'halfAngleDegrees':28,'localEmitter':[0,.86,.05]},'camera':'Exact world-space yaw before orthographic35.264389682754654 elevation/45 azimuth; no rendered-sprite rotation.','authority':'Illustrative visual envelope only; no gameplay area, damage or actor socket authority.','records':records}
(ROOT/'flare_treatments'/'ENVELOPE_QA.json').write_text(json.dumps(r,indent=2));(ROOT/'combat'/'LANTERN_ENVELOPE_QA.json').write_text(json.dumps(r,indent=2));print(r['passed'])
