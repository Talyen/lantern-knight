"""Authored curved silhouettes and phase topology; no rendered-sprite direction rotation."""
import math
from vfx_core import *
TAU=math.tau
C.update({'rust':'#a75e33','gold':'#e4a54b','light':'#f6d68b','core':'#fff0c4','smoke':'#74857f','mist':'#a7b9a9','reed':'#65735d','reedlight':'#a4af80','paper':'#d3c7a4','paperback':'#8f9688'})
def bez(a,b,c,d,n=18):
 return [tuple((1-t)**3*a[k]+3*(1-t)**2*t*b[k]+3*(1-t)*t*t*c[k]+t**3*d[k] for k in range(len(a))) for t in [j/n for j in range(n+1)]]
def shape(c,segments,col,a=1,transform=lambda p:p):
 pts=[]
 for s in segments:pts+=bez(*s)
 c.poly([transform(p) for p in pts],col,a)
def stroke(c,pts,w,col,a=1):
 l=[];r=[]
 for i,p in enumerate(pts):
  q=pts[min(len(pts)-1,i+1)];b=pts[max(0,i-1)];dx=q[0]-b[0];dy=q[1]-b[1];d=max(.001,math.hypot(dx,dy));v=w*math.sin(math.pi*i/(len(pts)-1))**.55
  l.append((p[0]-dy/d*v,p[1]+dx/d*v));r.append((p[0]+dy/d*v,p[1]-dx/d*v))
 c.poly(l+r[::-1],col,a)
def tongue(c,root,tip,width,bend,col,a,tr):
 x,z=root;xx,zz=tip;dz=zz-z
 # Flame-specific asymmetry: a broad rising shoulder, hooked tip and concave split.
 seg=[((x,z),(x-width,z+dz*.30),(xx-width*.68+bend,zz-dz*.20),(xx-width*.24,zz-dz*.19)),((xx-width*.24,zz-dz*.19),(xx-width*.20,zz-dz*.05),(xx-width*.08,zz-dz*.045),(xx,zz)),((xx,zz),(xx-width*.12,zz-dz*.28),(xx+width*.18,zz-dz*.25),(xx+width*.30,zz-dz*.34)),((xx+width*.30,zz-dz*.34),(xx+width*.14,zz-dz*.22),(xx+width*.65,zz-dz*.33),(xx+width*.73,zz-dz*.41)),((xx+width*.73,zz-dz*.41),(xx+width*.32,zz-dz*.45),(x+width*.55+bend,z+dz*.25),(x,z))]
 shape(c,seg,'ink',a,tr)
 # Same silhouette inset about its moving centre retains a thin outer contour,
 # with a broad warm interior and a hooked dark negative-space incision.
 mid=((x+xx)*.5,(z+zz)*.5)
 inset=[[((u-mid[0])*.90+mid[0],(v-mid[1])*.94+mid[1]) for u,v in section] for section in seg]
 shape(c,inset,col,a,tr)

def dash(c,t,yaw=135):
 if t<=0 or t>=1:return
 q=smooth(t/.35);cut=smooth((t-.46)/.54)
 def tr(p):return proj(local(p[0],.035,-p[1],yaw))
 for i in range(3):
  side=[-.19,.04,.27][i];tail=.10+1.35*q;root=.04+cut*1.20
  if tail-root<.05:continue
  tongue(c,(side,root),(side+.16*math.sin(t*5+i),tail),.11*(1-cut*.7),-.13,'paperback' if i==1 else 'gold',.7*(1-smooth((t-.8)/.2)),tr)

def smoke(c,t):
 for j in range(3):
  q=(t+j/3)%1;a=math.sin(math.pi*q)**1.1*.42;cx,cy=proj((.22*q,.66*q,0));r=8+15*q
  # Separate puff lobes and opening clefts: no scaled common blob.
  for k in range(1 if q<.42 else 3):
   sep=max(0,q-.42)*21;xx=cx+(k-1)*sep;yy=cy-k*sep*.5;rr=r*(1 if q<.42 else [.62,.55,.38][k])
   seg=[((xx-rr,yy),(xx-rr*1.4,yy-rr*.56),(xx-rr*.5,yy-rr*1.13),(xx,yy-rr*.74)),((xx,yy-rr*.74),(xx+rr*.33,yy-rr*1.37),(xx+rr*1.18,yy-rr*.39),(xx+rr*.9,yy)),((xx+rr*.9,yy),(xx+rr*.36,yy+rr*.29),(xx-rr*.63,yy+rr*.46),(xx-rr,yy))]
   shape(c,seg,'smoke',a)

def papers(c,t):
 for j in range(2):
  q=(t+j*.5)%1;a=smooth(q/.12)*(1-smooth((q-.8)/.2));phase=q*TAU+j;tilt=.9*math.sin(phase);yaw=q*2.4+j
  def tr(p):
   u,v=p;curl=.065*math.sin(v*12+phase);x=u*math.cos(yaw)+v*math.sin(yaw);z=-u*math.sin(yaw)+v*math.cos(yaw);return proj((-.48+.96*q+x,.08+.16*math.sin(math.pi*q)+v*tilt+curl,z+j*.14))
  seg=[((-.11,-.15),(-.07,-.17),(.06,-.16),(.105,-.13)),((.105,-.13),(.115,-.01),(.08,.10),(.11,.15)),((.11,.15),(.04,.13),(-.08,.17),(-.10,.14)),((-.10,.14),(-.12,.05),(-.08,-.09),(-.11,-.15))]
  shape(c,seg,'ink',a,tr);shape(c,seg,'paper',a,lambda p:tr((p[0]*.90,p[1]*.93)))
  shape(c,[((.04,-.15),(.00,-.06),(.03,.08),(.07,.15)),((.07,.15),(.13,.09),(.11,-.10),(.04,-.15))],'paperback',a*.88,tr)
  for k in range(3):stroke(c,[tr(p) for p in bez((-.074,-.065+k*.032),(-.03,-.05+k*.032),(.01,-.065+k*.032),(.034,-.05+k*.032))],.28,'ink',a*.6)

def reeds(c,t):
 for i,(x,z,h) in enumerate([(-.22,.02,.65),(-.17,.01,.88),(-.08,.06,.52),(.02,.0,1.02),(.09,-.04,.74),(.20,.07,.84),(.26,.02,.56)]):
  sway=.052*math.sin(TAU*t+i*.5);pts=bez((x,0,z),(x,h*.35,z),(x+sway,h*.8,z+.02),(x+sway*1.6,h,z+.01));stroke(c,[proj(p) for p in pts],1.20,'ink');stroke(c,[proj(p) for p in pts],.62,'reedlight')
  for k,side in enumerate([-1,1]):
   base=(x+sway*.3,h*(.3+k*.19));tip=(base[0]+side*(.18+.05*(i%3))+sway,base[1]+.18)
   seg=[(base,(base[0]+side*.11,base[1]+.14),(tip[0]-side*.05,tip[1]+.09),tip),(tip,(tip[0]-side*.07,tip[1]+.018),(base[0]+side*.03,base[1]+.045),base)]
   shape(c,seg,'reed' if i%2 else 'ink',1,lambda p:proj((p[0],p[1],z)))

def mist(c,t):
 for j in range(4):
  q=(t+[0,.21,.49,.78][j])%1;a=math.sin(math.pi*q)**1.5*[.17,.22,.14,.19][j];cx=-.7+q*1.2;z=[-.44,-.10,.22,.46][j]
  def tr(p):return proj((cx+p[0]*[1.1,.72,.95,.63][j],.05+.035*math.sin(q*TAU+p[0]*3),z+p[1]*[.8,1.2,.9,1.1][j]+.025*math.sin(p[0]*8+q*TAU+j)))
  # Interlocking cloud banks separated by a deliberate broad channel.
  seg=[((-.66,-.02),(-.51,-.22),(-.31,-.08),(-.16,-.16)),((-.16,-.16),(.02,-.31),(.19,-.07),(.32,-.12)),((.32,-.12),(.61,-.16),(.72,.05),(.47,.12)),((.47,.12),(.26,.25),(.14,.02),(-.04,.10)),((-.04,.10),(-.23,.20),(-.34,.03),(-.66,-.02))]
  shape(c,seg,'mist',a,tr)

def leaves(c,t):
 for j in range(3):
  q=(t+j/3)%1;a=smooth(q/.13)*(1-smooth((q-.82)/.18));roll=q*TAU*1.5+j;ang=q*4+j;edge=math.cos(roll)
  def tr(p):
   u,v=p;u*=edge;x=u*math.cos(ang)+v*math.sin(ang);z=-u*math.sin(ang)+v*math.cos(ang);return proj((-.9+1.8*q+x,.04+.25*math.sin(math.pi*q)+abs(u)*.4,z+(j-1)*.33))
  seg=[((0,-.14),(-.06,-.09),(-.10,-.01),(-.085,.04)),((-.085,.04),(-.05,.07),(-.04,.09),(0,.13)),((0,.13),(.09,.055),(.082,-.015),(.047,-.055)),((.047,-.055),(.018,-.074),(.025,-.12),(0,-.14))]
  shape(c,seg,'ink',a,tr);shape(c,seg,'rust' if j==0 else 'gold',a,lambda p:tr((p[0]*.78,p[1]*.87)))
  stroke(c,[tr(p) for p in bez((0,-.15),(-.012,-.08),(.012,.09),(0,.16))],.42,'light',a*.65)

def stagger(c,t):
 if t<=0 or t>=1:return
 a=smooth(t/.12)*(1-smooth((t-.63)/.37))
 for j in range(3):
  q=clamp((t-j*.04)/.8);x=256+(j-1)*(13+15*q);y=286-18*math.sin(math.pi*q)+j*3;ang=j*1.6+q*2.3;s=4+2*(j%2)
  pts=[(-s,-s*.3),(-s*.1,-s*1.4),(s*.58,-s*.25),(s*.36,s*.67),(-s*.18,s*.4)]
  tr=lambda p:(x+p[0]*math.cos(ang)-p[1]*math.sin(ang),y+p[0]*math.sin(ang)+p[1]*math.cos(ang))
  c.poly([tr(p) for p in pts],'ink',a);c.poly([tr((u*.66,v*.80)) for u,v in pts],'gold',a)

def flame_mass(c,pts,col,a,tr):
 # Curved connected shoulders, sharp flame tips. Curve each edge with biased
 # off-chord controls; topology is explicitly replaced at breakup.
 seg=[]
 for j,(p,q) in enumerate(zip(pts,pts[1:]+pts[:1])):
  dx=q[0]-p[0];dz=q[1]-p[1];bow=[.08,-.07,.04,-.035][j%4]
  seg.append((p,(p[0]+dx*.27+bow,p[1]+dz*.28),(p[0]+dx*.72-bow,p[1]+dz*.72),q))
 shape(c,seg,col,a,tr)
def flame_A(c,t,yaw=135,kind=0):
 if t<=0 or t>=1:return
 def tr(p):
  an,r=p;r=clamp(r)*2.1;theta=math.radians(clamp(an,-1,1)*28)
  return proj(local(math.sin(theta)*r,.86+.30*math.sin(math.pi*r/2.1),.05+math.cos(theta)*r,yaw))
 if t<.20:
  u=t/.20
  pts=[(0,0),(-.7,.055),(-.85,.15+u*.12),(-.22,.12),(0,.23+u*.09),(.4,.12),(.77,.18),(.59,.055)]
  flame_mass(c,pts,'rust',smooth(t/.06),tr)
  flame_mass(c,[(x*.65,r*.7) for x,r in pts],'light',smooth(t/.06),tr)
 elif t<.48:
  u=(t-.20)/.28;reach=.55+.45*math.sin(min(1,u*2.8)*math.pi/2);flutter=math.sin(u*5)*.05
  pts=[(0,0),(-.75,.28),(-.91,.52),(-.74,.57),(-.97,.83),(-.44,.69),(-.49,.91),(-.16,.77),(.05,1),(.29,.74),(.58,.90),(.47,.59),(.94,.72),(.75,.44),(.72,.26)]
  pts=[(x+(flutter if j%3 else -flutter),r*reach) if j else(0,0) for j,(x,r) in enumerate(pts)]
  flame_mass(c,pts,'ink',1,tr)
  flame_mass(c,[(x*.96,r*.975) for x,r in pts],'rust',1,tr)
  # A connected pale ignition front occupies the mass, with unequal dark cuts.
  inner=[(0,.025),(-.56,.25),(-.62,.51),(-.29,.44),(-.37,.76),(-.06,.60),(.075,.90),(.24,.60),(.47,.72),(.35,.40),(.65,.53),(.48,.22)]
  flame_mass(c,[(x,r*reach) for x,r in inner],'gold',1,tr)
  core=[(0,.03),(-.26,.25),(-.22,.42),(-.09,.36),(.045,.67),(.14,.39),(.29,.40),(.23,.18)]
  flame_mass(c,[(x,r*reach) for x,r in core],'core',1-smooth((u-.68)/.32)*.4,tr)
 else:
  u=(t-.48)/.52
  # Four unequal masses shear apart; the two smaller ones clear early.
  lobes=[(-.65,.84,.63,.40,0),(-.13,1.0,.72,.12,.04),(.43,.83,.57,.31,.09),(.83,.67,.34,.48,.15)]
  for j,(an,end,width,base,delay) in enumerate(lobes):
   q=clamp((u-delay)/(1-delay));rootR=base+q*(end-base+.12)
   if rootR>end-.035:continue
   bent=.16*math.sin(q*5+j*1.8);op=1-smooth((q-.84)/.16)
   tongue(c,(an*.62,rootR),(an+bent,end),width*(1-q*.75),-.08+j*.04,'rust' if j%2 else 'gold',op,tr)
   if j<2:tongue(c,(an*.62,rootR+.025),(an+bent*.7,end-.045),width*.38*(1-q*.75),0,'light',op,tr)
  if u>.20:
   for j,(an,r) in enumerate([(-.80,.89),(-.30,.99),(.37,.92),(.87,.80)]):
    q=clamp((u-.20)/.80);a=math.sin(math.pi*q)**.65;rr=min(.99,r+.05*q)
    flame_mass(c,[(an-.025,rr-.045*(1-q)),(an-.07,rr-.018),(an+.025,rr),(an+.055,rr-.034*(1-q))],'light',a,tr)

def flare(c,t,yaw=135,kind=0):
 if kind==0:return flame_A(c,t,yaw,0)
 if t<=0 or t>=1:return
 def tr(p):
  an,r=p;rr=clamp(r)*2.1;theta=math.radians(clamp(an,-1,1)*28);return proj(local(math.sin(theta)*rr,.86+.24*math.sin(math.pi*rr/2.1),.05+math.cos(theta)*rr,yaw))
 if kind==1:
  g=smooth(t/.31);split=smooth((t-.39)/.42);a=1-smooth((t-.83)/.17)
  # A small central plate ignites first. Unequal offset panes fracture away,
  # their inner edges retract at distinct speeds, exposing expanding gaps.
  for j,(lo,hi,reach) in enumerate([(-.94,-.28,.80),(-.34,.27,1.0),(.24,.88,.86)]):
   root=split*[.87,.71,.78][j];reach*=g
   if root>=reach-.045:continue
   mid=(lo+hi)/2;lean=.07*math.sin(t*8+j)
   pts=[(mid*.12,root),(lo+.05*split,.49*g+root*.20),(lo+lean,reach*.89),(mid-.06,reach),(hi-lean,reach*.93),(hi-.08*split,.46*g+root*.15)]
   c.poly([tr(p) for p in pts],'ink',a)
   center=(mid,(root+reach)*.5);c.poly([tr((center[0]+(x-center[0])*.92,center[1]+(r-center[1])*.94)) for x,r in pts],'gold' if j!=1 else 'light',a)
   c.poly([tr(p) for p in [(mid*.12,root+.02),(lo+.07,.50*g+root*.20),(mid,reach*.75),(mid+.055,reach*.35+root*.6)]],'rust',a*.72)
  if t>.47:
   q=(t-.47)/.53
   for j,an in enumerate([-.77,-.16,.57]):
    rr=.71+j*.06+.1*q;w=.13*(1-q);pts=[(an-w,rr-.08),(an+.05,rr-.105),(an+w,rr),(an-w*.3,rr+.025)];c.poly([tr(p) for p in pts],'gold',math.sin(math.pi*q))
 else:
  # Curved ember sheets: the front unfurls along a changing path, then tail and
  # tip separate. No fixed full-loop insignia is scaled or faded intact.
  u=clamp(t/.62);clear=clamp((t-.48)/.52)
  for j in range(2):
   sign=1 if j==0 else -1;end=min(1,clamp((t-j*.045)/.40));start=clear*(.84 if j==0 else 1.02)
   if start>=end:continue
   pts=bez((0,0),(sign*.7,.27),(sign*.96,.64),(sign*.42,.93),30)+bez((sign*.42,.93),(-sign*.16,.96),(-sign*.30,.68),(sign*.14,.68+.10*math.sin(t*7)),30)[1:]
   lo=int(start*(len(pts)-1));hi=max(lo+2,int(end*(len(pts)-1)));part=pts[lo:hi+1];left=[];right=[]
   for k,(an,rr) in enumerate(part):
    p=part[max(0,k-1)];q=part[min(len(part)-1,k+1)];dx=q[0]-p[0];dy=q[1]-p[1];l=max(.001,math.hypot(dx,dy));s=k/max(1,len(part)-1);w=(.10 if j==0 else .065)*math.sin(math.pi*s)**.6*(1-clear*.35)
    left.append((an-dy/l*w,rr+dx/l*w));right.append((an+dy/l*w,rr-dx/l*w))
   polygon=left+right[::-1];c.poly([tr(p) for p in polygon],'ink')
   inner=[((a+b)*.5,(r+s)*.5) for (a,r),(b,s) in zip(left,right)]
   pale=[];dark=[]
   for p,q,z in zip(left,right,inner):pale.append((z[0]+(p[0]-z[0])*.74,z[1]+(p[1]-z[1])*.74));dark.append((z[0]+(q[0]-z[0])*.74,z[1]+(q[1]-z[1])*.74))
   c.poly([tr(p) for p in pale+dark[::-1]],'light' if j==0 else 'gold')
  if t>.61:
   q=(t-.61)/.39
   for an,rr in [(-.64,.94),(.37,.84),(.73,.92)]:
    tongue(c,(an,rr-.06*(1-q)),(an+.04,rr+.035),.06*(1-q),.03,'gold',math.sin(math.pi*q),tr)
