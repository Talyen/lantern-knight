from pathlib import Path
import json,math,shutil,subprocess,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw
from ink_motion import *
ROOT=Path(__file__).resolve().parent.parent
OLD=ROOT.parents[1]/'lantern_overnight'
MASTER=Path(__file__).parent/'masters/hanging_banner_fresh.png'
def banner(t):
 # Authored cloth master is bound to a fixed-top dense inverse mesh.
 # Rod and top attachments remain perfectly immobile. This is 2D illustrative deformation.
 im=Image.open(MASTER).convert('RGBA');im.thumbnail((200,432),Image.Resampling.LANCZOS)
 canvas=Image.new('RGBA',(512*3,448*3));x=256*3-im.width//2;y=286*3-14
 canvas.alpha_composite(im,(x,y));mesh=[];step=24
 def inv(xx,yy):
  q=clamp((yy-y-48)/(im.height-48));s=math.sin(TAU*t-q*2.1);dx=14*q*q*s+4*q*math.sin(TAU*t*2-q*3);dy=3*q*q*math.sin(TAU*t-q*2.8);return xx-dx,yy-dy
 for yy in range(0,448*3,step):
  for xx in range(0,512*3,step):
   x1=min(xx+step,512*3);y1=min(yy+step,448*3);mesh.append(((xx,yy,x1,y1),sum([inv(*p) for p in [(xx,yy),(xx,y1),(x1,y1),(x1,yy)]],())))
 warped=canvas.transform(canvas.size,Image.Transform.MESH,mesh,Image.Resampling.BICUBIC)
 warped.paste(canvas.crop((0,0,512*3,y+48)),(0,0))
 out=warped.resize((512,448),Image.Resampling.LANCZOS)
 ar=np.array(out);ar[ar[:,:,3]==0,:3]=0;return Image.fromarray(ar)
def render(name,i,n,heading=135):
 t=i/n if name in ['hanging_banner','loose_papers','reeds_sway','chimney_puff','rolling_ground_mist','autumn_leaf_gust'] else i/(n-1)
 if name=='hanging_banner':return banner(t),None
 c=Canvas()
 if name in ['layered_flame_tongues','fractured_amber_panes','curling_ember_ribbons','lantern_cone_flare']:flare(c,t,heading,{'fractured_amber_panes':1,'curling_ember_ribbons':2}.get(name,0))
 else:{'stagger_shards':stagger,'dash_wake':lambda c,t:dash(c,t,heading),'loose_papers':papers,'reeds_sway':reeds,'chimney_puff':smoke,'rolling_ground_mist':mist,'autumn_leaf_gust':leaves}[name](c,t)
 im=c.image.resize((W,H),Image.Resampling.LANCZOS);ar=np.array(im);ar[ar[:,:,3]==0,:3]=0;return Image.fromarray(ar),c.svg_text()
def clip_export(out,old,name,n,heading=135):
 c=dict(old);cid=c['id'];folder=out/'frames'/cid;folder.mkdir(parents=True,exist_ok=True);vec=out/'vectors'/cid;vec.mkdir(parents=True,exist_ok=True);ims=[];bounds=[];frames=[]
 for i in range(n):
  im,svg=render(name,i,n,heading);im.save(folder/f'{i:03}.png',optimize=True);ims.append(im);bounds.append(im.getbbox())
  if svg:(vec/f'{i:03}.svg').write_text(svg)
 visible=[b for b in bounds if b];crop=[min(b[0] for b in visible)-2,min(b[1] for b in visible)-2,max(b[2] for b in visible)+2,max(b[3] for b in visible)+2];cw,ch=crop[2]-crop[0],crop[3]-crop[1];pad=4;cols=min(8,2048//(cw+8));per=cols*(2048//(ch+8));atls=[]
 for start in range(0,n,per):
  count=min(per,n-start);rows=math.ceil(count/cols);atlas=Image.new('RGBA',(cols*(cw+8),rows*(ch+8)));an=f'atlases/{cid}__{start//per:02}.png';(out/'atlases').mkdir(exist_ok=True)
  for k in range(count):
   i=start+k;x=4+(k%cols)*(cw+8);y=4+(k//cols)*(ch+8);atlas.paste(ims[i].crop(crop),(x,y));f={'id':i,'file':f'frames/{cid}/{i:03}.png','atlas':an,'rectPx':[x,y,cw,ch],'sourceSizePx':[W,H],'trimOffsetPx':crop[:2],'atlasSourceCropPx':crop,'pivotPx':list(PIVOT),'atlasPivotPx':[PIVOT[0]-crop[0],PIVOT[1]-crop[1]],'durationRational':[1,30],'durationSeconds':1/30,'alphaBoundsPx':bounds[i]}
   if name!='hanging_banner':f['svg']=f'vectors/{cid}/{i:03}.svg'
   frames.append(f)
  atlas.save(out/an,optimize=True);atls.append({'file':an,'sizePx':list(atlas.size)})
 c.update(frames=frames,frameCount=n,sourceFPS=30,durationSeconds=n/30,durationRational=[n,30],atlases=atls,atlasPaddingPx=4,revision='r02',revisionStatus='repaired',rootPivotPx=list(PIVOT),sourceAnimation='native authored phase silhouettes' if name!='hanging_banner' else 'fresh illustrated raster master bound to fixed-top periodic 2D cloth mesh',cameraCaveat='Exact world projection of authored effect geometry; illustrative dimensions, no gameplay or socket calibration.' if name!='hanging_banner' else 'Illustrative front-facing cloth master, not exact camera-projected 3D cloth; rod/top fixed at source anchor. No alternate-view claim.')
 for key in ['atlas','atlasSizePx']:c.pop(key,None)
 if name=='hanging_banner':c.update(space='illustrative_2d_cloth',pivotMeaning='top-centre rod attachment, same pixel anchor; apparent cloth height is illustrative, not calibrated world geometry')
 return c,ims

def review(out,c,ims):
 rd=out/'review';rd.mkdir(exist_ok=True);sel=[0,len(ims)//6,len(ims)//3,len(ims)//2,len(ims)*2//3,len(ims)*5//6,len(ims)-1];sheet=Image.new('RGB',(7*256,2*256),(25,31,31));dr=ImageDraw.Draw(sheet)
 for row,bg in enumerate([(25,31,31),(215,211,192)]):
  for j,k in enumerate(sel):
   sheet.paste(bg,(j*256,row*256,(j+1)*256,(row+1)*256));im=ims[k].resize((256,224));sheet.paste(im,(j*256,row*256+24),im);dr.text((j*256+8,row*256+5),f"{c['id']} / {k}",fill=(175,146,93))
 sheet.save(rd/f"{c['id']}_phases.jpg",quality=93)
 # Exact source hold at 30fps, each frame repeated twice for 60Hz file.
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','512x448','-framerate','30','-i','-','-vf','fps=60','-c:v','libx264','-pix_fmt','yuv420p',str(rd/f"{c['id']}_60hz.mp4")],stdin=subprocess.PIPE)
 for im in ims:
  bg=Image.new('RGB',im.size,(25,31,31));bg.paste(im,(0,0),im);p.stdin.write(bg.tobytes())
 p.stdin.close();assert p.wait()==0

def proof():
 out=ROOT/'proof';out.mkdir(exist_ok=True)
 for name,n in [('layered_flame_tongues',24),('hanging_banner',60)]:
  c,ims=clip_export(out,{'id':name,'loop':name=='hanging_banner'},name,n);review(out,c,ims)
  (out/f'{name}.json').write_text(json.dumps(c,indent=2))
PACKS={
 'combat':('03_effects/combat_pack_v1',{'lantern_cone_flare':24,'dash_wake':18,'stagger_shards':24}),
 'flare_treatments':('11_lantern_flare_treatments/flare_treatments_v1',{'layered_flame_tongues':24,'fractured_amber_panes':24,'curling_ember_ribbons':24}),
 'environment':('07_environment_motion/environment_motion_v1',{'hanging_banner':60,'loose_papers':60,'reeds_sway':60,'chimney_puff':60}),
 'weather':('10_weather_atmosphere/weather_atmosphere_v1',{'rolling_ground_mist':120,'autumn_leaf_gust':90})}
def full():
 for pack,(loc,changes) in PACKS.items():
  oldpath=OLD/loc;out=ROOT/pack;out.mkdir(exist_ok=True)
  m=json.loads((oldpath/'manifest.json').read_text());clips=[];mapping=[]
  for old in m['clips']:
   name=old.get('effect',old.get('treatment',old.get('family')));heading=old.get('headingDegrees') or 0;cid=old['id']
   if name in changes:
    c,ims=clip_export(out,old,name,changes[name],heading)
    if heading in [0,135] or name=='hanging_banner':review(out,c,ims)
    mapping.append({'oldID':cid,'newID':cid,'status':'repaired','oldSourceFrames':old['frameCount'],'newSourceFrames':c['frameCount'],'timingChange':old['frameCount']!=c['frameCount']})
   else:
    c=dict(old);c['revisionStatus']='retained_byte_identical';ims=[]
    for f in old['frames']:
     for key in ['file','svg']:
      if key in f:
       dest=out/f[key];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(oldpath/f[key],dest)
     if heading in [0,135]:ims.append(Image.open(out/f['file']).convert('RGBA'))
    for page in old.get('atlases',[]):
     dest=out/page['file'];dest.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(oldpath/page['file'],dest)
    if 'atlas' in old:
     dest=out/old['atlas'];dest.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(oldpath/old['atlas'],dest)
    if ims:review(out,c,ims)
    mapping.append({'oldID':cid,'newID':cid,'status':'retained_byte_identical','timingChange':False})
   clips.append(c)
  m.update(schema='lantern.motion-polish.r02',status='art-polished offline sprite candidates; no engine integration or runtime performance certification',clips=clips,clipCount=len(clips),sourceFPS=30,previewHz=60,oldIDMap=mapping)
  if pack=='environment':m['camera']['limitation']='hanging_banner is now an illustrative front-facing textured cloth mesh; other world-space members retain projection. Do not apply global exact-camera label to banner.'
  (out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'SUPERSESSION.json').write_text(json.dumps(mapping,indent=2))
  shutil.copytree(oldpath/'source',out/'source'/'retained_original',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
  shutil.copytree(ROOT/'source',out/'source'/'revision',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
  (out/'README.txt').write_text('LANTERN CLEAN INK MOTION POLISH R02\nComplete pack; retained members explicitly marked in manifest and byte-identical.\nSource 30fps; previews are 60Hz by repeating each drawing twice. This is not a runtime FPS claim.\nRepaired clips preserve IDs and root pivot (256,286); timing changes are in SUPERSESSION.json. Re-import frames and timing from new manifest; do not use old atlas rectangles.\nFrame-level atlas field is authoritative for repaired multi-page safe atlases; retained clips use clip-level atlas. All atlases <=2048px, straight alpha, normal source-over, sRGB color/linear alpha. Disable mipmaps or extrude per frame for mipmapped usage; transparent gutters alone are not mip-safe.\nCamera: vector world geometry uses exact 35.264389682754654 elevation /45 azimuth projection at112px per metre. Smoke contour lobes face camera. Banner is a generated illustrated front master on a fixed-top 2D mesh, not 3D camera calibrated. Leaves/papers/reeds are authored projected geometry. Headings are source-space yaw, never rotated rendered sprites.\nAll dimensions and phase events are illustrative. No collision or damage authority. Keep functional telegraphs separate. Lantern local emitter remains (0,.86,.05), nominal2.1m radius,28deg half-angle; no actor socket calibration.\nNo engine integration or runtime performance acceptance. Review sheets are at half source size; source PNGs are512x448. Banner master is included.\n')
  print('DONE',pack,flush=True)
if __name__=='__main__':
 if '--full' in sys.argv:full()
 else:proof()
