"""Portable repaired-frame replay: python source/revision/replay_repaired.py /tmp/replay"""
from pathlib import Path
import sys,json,hashlib
from build_pack import clip_export
pack=Path(__file__).resolve().parents[2]
if not (pack/'manifest.json').exists():raise SystemExit('Run the copy inside a delivered pack under source/revision/.')
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);manifest=json.loads((pack/'manifest.json').read_text());reports=[]
for c in manifest['clips']:
 if c.get('revisionStatus')!='repaired':continue
 name=c.get('effect',c.get('treatment',c.get('family')))
 new,ims=clip_export(out,c,name,c['frameCount'],c.get('headingDegrees') or 0)
 different=[f['file'] for f in new['frames'] if hashlib.sha256((out/f['file']).read_bytes()).digest()!=hashlib.sha256((pack/f['file']).read_bytes()).digest()]
 reports.append({'id':c['id'],'replayedFrames':len(ims),'pixelFileMismatches':different})
(out/'REPLAY_REPORT.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2))
