from build_pack import *
import zipfile
names={'combat':'Combat','flare_treatments':'FlareTreatments','environment':'Environment','weather':'Weather'}
delivery=ROOT/'delivery';delivery.mkdir(exist_ok=True);records=[]
for pack,label in names.items():
 out=ROOT/pack
 qa=json.load(open(out/'QA.json'));assert qa['passed'],qa['issues']
 replay=json.load(open(out/'SOURCE_REPLAY.json'));assert not any(r['pixelFileMismatches'] for r in replay)
 shutil.copytree(ROOT/'source',out/'source'/'revision',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 if pack!='environment':shutil.rmtree(out/'source'/'revision'/'masters',ignore_errors=True)
 shutil.copy2(ROOT/'ART_REVIEW.txt',out/'ART_REVIEW.txt')
 for p in out.rglob('__pycache__'):shutil.rmtree(p)
 m=json.load(open(out/'manifest.json'))
 if pack=='flare_treatments':m['treatmentPreference']={'preferred':'layered_flame_tongues','alternatives':['fractured_amber_panes','curling_ember_ribbons'],'note':'C is a deliberately thinner optional treatment, not the preferred main flare.'}
 (out/'manifest.json').write_text(json.dumps(m,indent=2))
 hashes={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='FILES_SHA256.json'}
 (out/'FILES_SHA256.json').write_text(json.dumps(hashes,indent=2))
 path=delivery/f'Lantern_Motion_{label}_r02.zip'
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(out.rglob('*')):
   if p.is_file():z.write(p,arcname=f'{pack}/{p.relative_to(out)}')
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 size=path.stat().st_size;assert size<90*1024*1024
 rec={'pack':pack,'archive':str(path.relative_to(ROOT)),'sizeBytes':size,'sizeMiB':round(size/1024**2,3),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'manifestMember':f'{pack}/manifest.json','clipCount':len(m['clips']),'frameCount':sum(c['frameCount'] for c in m['clips']),'repairedClipCount':sum(c['revisionStatus']=='repaired' for c in m['clips']),'retainedClipCount':sum(c['revisionStatus']=='retained_byte_identical' for c in m['clips']),'crcVerified':True,'sourceReplayedFrames':sum(r['replayedFrames'] for r in replay)}
 records.append(rec);print(rec,flush=True)
(delivery/'FROZEN_INDEX.json').write_text(json.dumps(records,indent=2))
