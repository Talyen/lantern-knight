from pathlib import Path
import json,hashlib,subprocess,zipfile
import numpy as np
from PIL import Image
from build_pack import ROOT,PACKS,OLD,render

def run():
 allreports={}
 for pack,(loc,changes) in PACKS.items():
  out=ROOT/pack;m=json.loads((out/'manifest.json').read_text());issues=[];rows=[];minimum=999;retained=0
  for c in m['clips']:
   images=[];hashes=[];atlas_cache={};minmargin=999
   for f in c['frames']:
    im=Image.open(out/f['file']).convert('RGBA');images.append(im);ar=np.array(im);hashes.append(hashlib.sha256(im.tobytes()).hexdigest());b=im.getbbox()
    if im.size!=(512,448):issues.append('canvas '+f['file'])
    if np.any(ar[ar[:,:,3]==0,:3]):issues.append('hidden RGB '+f['file'])
    if b:minmargin=min(minmargin,b[0],b[1],512-b[2],448-b[3])
    an=f.get('atlas',c.get('atlas'))
    if an not in atlas_cache:atlas_cache[an]=Image.open(out/an).convert('RGBA')
    atlas=atlas_cache[an];x,y,w,h=f['rectPx'];crop=f['atlasSourceCropPx'];pad=c['atlasPaddingPx']
    if max(atlas.size)>2048:issues.append('oversize atlas '+an)
    if atlas.crop((x,y,x+w,y+h)).tobytes()!=im.crop(crop).tobytes():issues.append('atlas mismatch '+f['file'])
    for box in [(x-pad,y-pad,x+w+pad,y),(x-pad,y+h,x+w+pad,y+h+pad),(x-pad,y,x,y+h),(x+w,y,x+w+pad,y+h)]:
     if atlas.crop(box).getchannel('A').getextrema()[1]:issues.append('nonclear gutter '+f['file'])
    if c['revisionStatus']=='retained_byte_identical':
     if hashlib.sha256((out/f['file']).read_bytes()).digest()!=hashlib.sha256((OLD/loc/f['file']).read_bytes()).digest():issues.append('retained mismatch '+f['file'])
   minimum=min(minimum,minmargin)
   if minmargin<6:issues.append('boundary margin '+c['id'])
   loopcheck=None
   name=c.get('effect',c.get('treatment',c.get('family')))
   if c['revisionStatus']=='repaired':
    if c.get('loop'):
     first,_=render(name,0,c['frameCount'],c.get('headingDegrees') or 0);period,_=render(name,c['frameCount'],c['frameCount'],c.get('headingDegrees') or 0)
     diff=np.abs(np.array(first).astype(int)-np.array(period).astype(int));loopcheck={'periodMaximumChannelDifference':int(diff.max()),'periodMeanChannelDifference':float(diff.mean()),'firstLastIntentionallyNotDuplicated':True}
     if diff.max()>1:issues.append('period mismatch '+c['id'])
     arrs=[np.array(im).astype(np.int16) for im in images]
     steps=[float(np.abs(arrs[j+1]-arrs[j]).mean()) for j in range(len(arrs)-1)]
     seam=float(np.abs(arrs[0]-arrs[-1]).mean());loopcheck.update(seamMeanAbsDifference=seam,largestInteriorStepMeanAbsDifference=max(steps),seamToLargestStepRatio=seam/max(max(steps),.000001))
     if seam>max(steps)*1.5+.01:issues.append('seam jump '+c['id'])
    elif images[0].getbbox() or images[-1].getbbox():issues.append('endpoint not clear '+c['id'])
   else:retained+=1
   rows.append({'id':c['id'],'status':c['revisionStatus'],'frames':len(images),'uniqueFrames':len(set(hashes)),'minimumMarginPx':minmargin,'loop':loopcheck,'firstLastMeanAbsDifference':float(np.abs(np.array(images[0]).astype(int)-np.array(images[-1]).astype(int)).mean())})
  videos=[]
  for p in (out/'review').glob('*.mp4'):
   x=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=r_frame_rate,nb_frames,duration','-of','json',str(p)]))['streams'][0];videos.append({'file':p.name,**x})
   if x['r_frame_rate']!='60/1':issues.append('preview rate '+p.name)
  report={'passed':not issues,'issues':issues,'clipCount':len(rows),'retainedByteIdenticalClipCount':retained,'minimumBoundaryMarginPx':minimum,'clips':rows,'previews':videos,'tests':'Every alpha frame, atlas crop and transparent gutter. Periodic source endpoint equality for repaired loops. Nonloop clear endpoints. Retained PNG hashes against original. Source timing30fps versus60Hz video header. These are offline file tests, not uninterrupted human playback or engine certification.'}
  (out/'QA.json').write_text(json.dumps(report,indent=2));allreports[pack]={'passed':not issues,'issues':issues,'frames':sum(r['frames'] for r in rows),'clips':len(rows)}
  print(pack,allreports[pack],flush=True)
 (ROOT/'QA_SUMMARY.json').write_text(json.dumps(allreports,indent=2))
if __name__=='__main__':run()
