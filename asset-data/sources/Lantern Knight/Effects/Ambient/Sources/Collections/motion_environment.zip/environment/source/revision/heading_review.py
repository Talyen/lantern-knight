from build_pack import *
for pack,families in [('flare_treatments',['layered_flame_tongues','fractured_amber_panes','curling_ember_ribbons']),('combat',['lantern_cone_flare','dash_wake'])]:
 for family in families:
  out=ROOT/pack;sheet=Image.new('RGB',(1024,512),(25,31,31));d=ImageDraw.Draw(sheet)
  for j,h in enumerate(range(0,360,45)):
   cid=f'{family}__d{h:03d}';p=out/'frames'/cid/('008.png' if family!='dash_wake' else '006.png');im=Image.open(p).convert('RGBA').resize((256,224));x=(j%4)*256;y=(j//4)*256;sheet.paste(im,(x,y+28),im);d.text((x+10,y+8),f'{family} / world yaw{h}',fill=(221,194,134))
  sheet.save(out/'review'/f'{family}_eight_headings.jpg',quality=93)
