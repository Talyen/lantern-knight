#!/usr/bin/env python3
"""Quiet original scene-motion accents. Deterministic authored SVG/PNG loops."""
from pathlib import Path
import argparse,hashlib,json,math,shutil,subprocess,zipfile
import numpy as np
from PIL import Image,ImageDraw
from vfx_core import Canvas,proj,font,clamp,smooth,C,W,H,PIVOT,DENSITY,ELEVATION,AZIMUTH
SOURCE=Path(__file__).resolve().parent;ROOT=SOURCE.parent
if ROOT.name in ('early_review','environment_motion_v1'):ROOT=ROOT.parent
TAU=math.tau
C.update({'ink':'#29302e','cloth':'#8b6355','clothshade':'#614c47','clothlight':'#b49274','reed':'#747d62','reedlight':'#adb18c','paper':'#d0c8a8','papershade':'#9b9e8e','water':'#a9c4bc','wateredge':'#647d78','smoke':'#7f8b83','smokelight':'#a1a89a','dust':'#a9a58d','moth':'#33413a','mothedge':'#899383'})
SPECS={
'hanging_banner':dict(family='hanging_banner',label='Hanging cloth / gentle breeze',frames=30,loop=True,space='projected_world',axis='local vertical XY plane; depth flexes in Z',pivotMeaning='fixed top-centre attachment; cloth hangs down in local -Y',description='One notched cloth hangs from a stable top edge; a broad shadow fold and a low-amplitude traveling bend give gentle motion.',visibleElementBudget=1),
'loose_papers':dict(family='loose_papers',label='Loose papers / skitter',frames=30,loop=True,space='projected_world',axis='ground +X drift with small lifts',pivotMeaning='ground-centred skitter region at local Y=0',description='Two clean folded sheets flutter through short world-space trajectories. Invisible fade boundaries hide emitter resets.',visibleElementBudget=2),
'reeds_sway':dict(family='reeds_sway',label='Reeds / anchored sway',frames=30,loop=True,space='projected_world',axis='anchored XZ roots and +Y stems',pivotMeaning='fixed shared ground root',description='Three broad tapered stems bend with phase-offset leaves; roots remain exactly planted.',visibleElementBudget=3),
'dripping_water':dict(family='dripping_water',label='Water drip / soft impact',frames=30,loop=True,space='projected_world',axis='vertical +Y drop above XZ ripple',pivotMeaning='ground or water-surface impact point; drop starts 0.68 m above it',description='One small falling drop lands, then two staggered broken ripples fade before the next drop. No spray field.',visibleElementBudget=3),
'chimney_puff':dict(family='chimney_puff',label='Chimney puff / sparse emission',frames=30,loop=True,space='world_centres_with_screen_billboard_lobes',axis='local +Y rise and +X drift',pivotMeaning='chimney-mouth socket; no additional baked socket height',description='Two broad, low-opacity smoke lobes rise from the socket. Their centres are projected world positions; the cloud contours face camera.',visibleElementBudget=2),
'dust_fall':dict(family='dust_fall',label='Dust fall / four flecks',frames=30,loop=True,space='world_centres_with_screen_billboard_flecks',axis='local -Y fall from overhead socket',pivotMeaning='overhead dust-shed attachment; grains fall in local -Y',description='Four designed facing-camera angular flecks have projected falling world centres and low opacity. This is a localized sparse accent, not a screen grain overlay.',visibleElementBudget=4),
'fluttering_moth':dict(family='fluttering_moth',label='Moth / fluttering silhouette',frames=30,loop=True,space='projected_world',axis='small hover path, true 3D wing folds',pivotMeaning='ground-centred hover region; body stays about 0.32 m above it',description='One flat two-tone moth silhouette follows a small periodic hover path while its wings fold four times per loop.',visibleElementBudget=1),
'water_glint':dict(family='water_glint',label='Water / quiet glints',frames=30,loop=True,space='projected_world',axis='XZ surface at local Y=0.01 m',pivotMeaning='centre of a small water-surface glint patch',description='Three short tapered reflection slivers breathe and drift gently. No rings, particle field, additive blend or bloom.',visibleElementBudget=3),
}

def bez(p0,p1,p2,p3,n=18):
 out=[]
 for j in range(n+1):
  t=j/n;s=1-t;out.append(tuple(s*s*s*p0[k]+3*s*s*t*p1[k]+3*s*t*t*p2[k]+t*t*t*p3[k] for k in range(len(p0))))
 return out

def ribbon(c,pts,width,col,alpha=1,taper=True):
 left=[];right=[]
 for i,(x,y) in enumerate(pts):
  p=pts[max(0,i-1)];q=pts[min(len(pts)-1,i+1)];dx=q[0]-p[0];dy=q[1]-p[1];ln=max(math.hypot(dx,dy),.00001);f=i/(len(pts)-1);w=(width(f) if callable(width) else width)*(math.sin(math.pi*f)**.5 if taper else 1)
  left.append((x-dy/ln*w/2,y+dx/ln*w/2));right.append((x+dy/ln*w/2,y-dx/ln*w/2))
 c.poly(left+right[::-1],col,alpha)

def wribbon(c,pts,width,col,alpha=1,taper=True):ribbon(c,[proj(p) for p in pts],width,col,alpha,taper)
def arc(c,r,w,start,end,col,a,y=.014):
 outer=[];inner=[]
 for j in range(49):
  q=j/48;ang=math.radians(start+(end-start)*q);ww=w*math.sin(math.pi*q)**.45
  outer.append(((r+ww/2)*math.cos(ang),y,(r+ww/2)*math.sin(ang)));inner.append(((r-ww/2)*math.cos(ang),y,(r-ww/2)*math.sin(ang)))
 c.worldpoly(outer+inner[::-1],col,a)

def banner(c,t):
 p=TAU*t
 def surf(u,q):
  return (u*(1-.12*q)+.034*math.sin(p+q*1.8)*q**1.4,-1.06*q+.016*math.sin(p+.8+u*2)*q**2,.11*math.sin(p+q*2.0+u*3)*q**1.7)
 left=[surf(-.28,j/24) for j in range(25)];right=[surf(.28,j/24) for j in range(25)]
 bottom=[surf(-.28,1),surf(-.065,1),surf(.015,.87),surf(.082,1),surf(.28,.98)]
 outline=left+bottom+right[::-1];c.worldpoly(outline,'ink')
 inside=[surf(-.25,.015+.96*j/24) for j in range(25)]+[surf(-.065,.975),surf(.013,.85),surf(.085,.972)]+[surf(.25,.015+.96*j/24) for j in range(24,-1,-1)]
 c.worldpoly(inside,'cloth')
 # One broad fold; no mesh wireframe, grain or stripes across the fabric.
 fold=[surf(-.245,.02+.95*j/24) for j in range(25)]+[surf(-.005+.020*math.sin(p+q*1.2),q) for q in [.96-j*.94/24 for j in range(25)]]
 c.worldpoly(fold,'clothshade',.80)
 ridge=[surf(.12+.025*math.sin(p+j/24),.08+.80*j/24) for j in range(25)];wribbon(c,ridge,2.3,'clothlight',.55)
 # Stable stitched top lip, included as part of this original cloth asset.
 c.worldpoly([surf(-.28,0),surf(.28,0),surf(.27,.042),surf(-.27,.042)],'ink')
 c.worldpoly([surf(-.245,.012),surf(.245,.012),surf(.24,.025),surf(-.24,.025)],'clothlight',.7)


def papers(c,t):
 for i in range(2):
  q=(t+i*.5)%1;a=smooth(q/.10)*(1-smooth((q-.78)/.22));x=-.52+1.05*q;z=[-.13,.18][i]+.035*math.sin(TAU*q+i);y=.025+.18*math.sin(math.pi*q)**1.5
  yaw=math.radians(-27+78*q+i*28);tilt=.20+.43*math.sin(TAU*q+i*.8);roll=.16*math.sin(2*TAU*q+.4*i)
  def v(u,vv):
   xx=u*math.cos(roll);yy=vv*math.sin(tilt)+u*math.sin(roll);zz=vv*math.cos(tilt)
   return (x+xx*math.cos(yaw)+zz*math.sin(yaw),y+yy,z-xx*math.sin(yaw)+zz*math.cos(yaw))
  uv=[(-.095,-.13),(.065,-.13),(.102,-.08),(.102,.13),(-.095,.13)]
  c.worldpoly([v(u,vv) for u,vv in uv],'ink',a)
  c.worldpoly([v(u*.88,vv*.90) for u,vv in uv],'paper' if i==0 else 'papershade',a)
  c.worldpoly([v(.044,-.111),v(.087,-.075),v(.04,-.068)],'papershade' if i==0 else 'paper',a)
  # A single restrained fold, not text or surface noise.
  wribbon(c,[v(-.07,-.025),v(.07,.007)],1.25,'ink',a*.25,False)


def reeds(c,t):
 p=TAU*t
 for i,(x,z,h) in enumerate([(-.18,-.03,.67),(.0,.03,.94),(.18,.01,.75)]):
  phase=p+i*.94;sw=.058*math.sin(phase);dz=.025*math.sin(phase+.7)
  centre=bez((x,0,z),(x-.005,h*.33,z),(x+sw*.60,h*.78,z+dz*.60),(x+sw,h,z+dz))
  # Stems are actual vertical-plane tapered blade polygons, not dotted line particles.
  left=[];right=[]
  for j,(xx,yy,zz) in enumerate(centre):
   q=j/(len(centre)-1);w=.044*(1-q)**.40+.008
   left.append((xx-w/2,yy,zz));right.append((xx+w/2,yy,zz))
  c.worldpoly(left+right[::-1],'ink');wribbon(c,centre,2.5,'reedlight',.78)
  for side,frac,L in [(-1,.40,.31),(1,.63,.26)]:
   yy=h*frac;bx=x+sw*frac**2;bz=z+dz*frac**2;tip=(bx+side*L*.65+sw*.3,yy+L*.70,bz+side*.035)
   midline=bez((bx,yy,bz),(bx+side*.075,yy+.12,bz),(tip[0]-side*.030,tip[1]-.040,tip[2]),tip)
   left=[];right=[];inside_l=[];inside_r=[]
   for k,(lx,ly,lz) in enumerate(midline):
    a0=midline[max(0,k-1)];a1=midline[min(len(midline)-1,k+1)];dx=a1[0]-a0[0];dy=a1[1]-a0[1];ln=max(math.hypot(dx,dy),.000001);q=k/(len(midline)-1);width=(.086 if i==1 or side==1 else .064)*math.sin(math.pi*q)**.70;ox=-dy/ln*width/2;oy=dx/ln*width/2
    left.append((lx+ox,ly+oy,lz));right.append((lx-ox,ly-oy,lz));inside_l.append((lx+ox*.67,ly+oy*.67,lz-.004));inside_r.append((lx-ox*.67,ly-oy*.67,lz-.004))
   c.worldpoly(left+right[::-1],'ink');c.worldpoly(inside_l+inside_r[::-1],'reed' if side<0 else 'reedlight',.94)


def drip(c,t):
 q=t
 if q<.52:
  u=q/.52;a=smooth(u/.10)*(1-smooth((u-.91)/.09));y=.68*(1-u*u);x=.025*math.sin(math.pi*u)
  w=.032;h=.055+.022*u
  c.worldpoly([(x,y+h,0),(x+w,y,0),(x,y-h*.4,0),(x-w,y,0)],'wateredge',a)
  c.worldpoly([(x,y+h*.71,-.003),(x+w*.49,y,-.003),(x,y-h*.17,-.003),(x-w*.49,y,-.003)],'water',a)
 if q>.42:
  u=clamp((q-.42)/.58);a=math.sin(math.pi*u)**1.2;r=.055+.44*smooth(u)
  for st,en in [(14,123),(168,318)]:arc(c,r,.045,st,en,'wateredge',a*.59);arc(c,r+.004,.021,st+5,en-5,'water',a*.8)
 if q>.62:
  u=clamp((q-.62)/.38);a=math.sin(math.pi*u)**1.5
  arc(c,.025+.23*smooth(u),.029,45,204,'water',a*.47)


def chimney(c,t):
 for i in range(2):
  q=(t+i*.5)%1;a=(math.sin(math.pi*q)**1.6)*.40;x=.24*q;z=.02*math.sin(math.pi*q);y=.05+.68*q;xx,yy=proj((x,y,z));r=(10+20*q)*(1-.10*i)
  pts=[]
  for j in range(81):
   th=TAU*j/80;rr=r*(1+.13*math.sin(3*th+.8+i*.55)+.055*math.sin(5*th-.4-i*.3));pts.append((xx+rr*math.cos(th),yy+rr*.72*math.sin(th)))
  c.poly(pts,'smoke',a)
  cap=pts[42:78]+bez(pts[77],(xx+r*.2,yy-r*.15),(xx-r*.5,yy-r*.15),pts[42])
  c.poly(cap,'smokelight',a*.48)


def dust(c,t):
 for i in range(4):
  q=(t+i*.25)%1;a=(math.sin(math.pi*q)**1.4)*[.52,.42,.45,.38][i];x=[-.16,.09,-.045,.15][i]+.12*q;z=[-.05,.07,.10,-.09][i];y=-.64*q
  theta=TAU*q+i;u=.025;v=.033;cx,cy=proj((x,y,z));sx=math.cos(theta)*u*DENSITY;sy=math.sin(theta)*u*DENSITY*.6
  pts=[(cx-sx,cy-sy),(cx+sy*.7,cy-v*DENSITY),(cx+sx,cy+sy),(cx-sy*.5,cy+v*DENSITY*.5)]
  c.poly(pts,'ink',a*.70);mid=(cx,cy-.4);c.poly([(mid[0]+(xx-mid[0])*.68,mid[1]+(yy-mid[1])*.68) for xx,yy in pts],'dust',a)


def moth(c,t):
 p=TAU*t;x=.15*math.sin(p);z=.05*math.sin(2*p+.7);y=.32+.05*math.cos(p);yaw=.45*math.sin(p+.3);fold=math.radians(23+43*math.sin(4*p));wing=[(.012,.020),(.098,.080),(.145,.025),(.088,-.038),(.012,-.030)]
 def vertex(u,vv,side):
  xx=side*u*math.cos(fold);yy=u*math.sin(fold);zz=vv
  return (x+xx*math.cos(yaw)+zz*math.sin(yaw),y+yy,z-xx*math.sin(yaw)+zz*math.cos(yaw))
 for side in [-1,1]:
  pts=[vertex(u,v,side) for u,v in wing];c.worldpoly(pts,'mothedge')
  mid=vertex(.055,.014,side);c.worldpoly([tuple(mid[k]+(v[k]-mid[k])*.79 for k in range(3)) for v in pts],'moth')
 body=[vertex(.0,.052,1),vertex(.015,.005,1),vertex(0,-.050,1),vertex(.015,.005,-1)];c.worldpoly(body,'ink')


def glint(c,t):
 for i,(x,z,L) in enumerate([(-.28,-.13,.31),(.20,.01,.38),(-.01,.20,.25)]):
  q=(t+i/3)%1;a=math.sin(math.pi*q)**2*.80;length=L*(.60+.45*math.sin(math.pi*q));cx=x+.05*(q-.5);cz=z+.022*math.sin(math.pi*q);w=.037*(.7+.3*math.sin(math.pi*q))
  pts=[(cx-length/2,.012,cz),(cx-length*.23,.012,cz-w),(cx+length/2,.012,cz+.005),(cx+length*.22,.012,cz+w)]
  c.worldpoly(pts,'wateredge',a*.80)
  c.worldpoly([(cx-length*.42,.014,cz),(cx-length*.18,.014,cz-w*.50),(cx+length*.42,.014,cz+.002),(cx+length*.15,.014,cz+w*.32)],'water',a)

FUNCS={'hanging_banner':banner,'loose_papers':papers,'reeds_sway':reeds,'dripping_water':drip,'chimney_puff':chimney,'dust_fall':dust,'fluttering_moth':moth,'water_glint':glint}

def render(name,i):
 spec=SPECS[name];c=Canvas();FUNCS[name](c,i/spec['frames']);return c

def export_clip(name,out):
 spec=SPECS[name];n=spec['frames'];folder=out/'frames'/name;folder.mkdir(parents=True,exist_ok=True);svgs=out/'vectors'/name;svgs.mkdir(parents=True,exist_ok=True);images=[];frames=[];bounds=[]
 for i in range(n):
  c=render(name,i);im=c.export(folder/f'{i:03d}.png');images.append(im);(svgs/f'{i:03d}.svg').write_text(c.svg_text());bounds.append(im.getbbox())
 b=[x for x in bounds if x];union=[min(x[0] for x in b)-2,min(x[1] for x in b)-2,max(x[2] for x in b)+2,max(x[3] for x in b)+2]
 cw,ch=union[2]-union[0],union[3]-union[1];pad=4;cols=min(6,max(1,2048//(cw+2*pad)));rows=math.ceil(n/cols);atlas=Image.new('RGBA',(cols*(cw+2*pad),rows*(ch+2*pad)))
 for i,im in enumerate(images):
  x=pad+(i%cols)*(cw+pad*2);y=pad+(i//cols)*(ch+pad*2);atlas.paste(im.crop(union),(x,y))
  frames.append({'id':i,'file':f'frames/{name}/{i:03d}.png','svg':f'vectors/{name}/{i:03d}.svg','rectPx':[x,y,cw,ch],'sourceSizePx':[W,H],'trimOffsetPx':union[:2],'atlasSourceCropPx':union,'pivotPx':list(PIVOT),'atlasPivotPx':[PIVOT[0]-union[0],PIVOT[1]-union[1]],'durationRational':[1,30],'durationSeconds':1/30,'alphaBoundsPx':list(bounds[i]) if bounds[i] else None})
 (out/'atlases').mkdir(exist_ok=True);atlas.save(out/'atlases'/f'{name}.png',optimize=True)
 return {'id':name,**spec,'frameCount':n,'frames':frames,'sourceFPS':30,'durationSeconds':n/30,'durationRational':[n,30],'atlas':f'atlases/{name}.png','atlasSizePx':list(atlas.size),'atlasPaddingPx':pad,'atlasCropPolicy':'constant union crop for whole clip, untrimmed loose PNGs','pivotMeaning':spec['pivotMeaning'],'finishBehavior':'wrap with no duplicate endpoint' if spec['loop'] else 'remove after transparent final frame','blend':{'pngAlpha':'straight (unassociated)','premultipliedAlpha':False,'recommended':'normal source-over','sourceFactor':'SRC_ALPHA','destinationFactor':'ONE_MINUS_SRC_ALPHA','textureColorSpace':'sRGB','blendColorSpace':'linear preferred','alphaIsLinear':True,'additiveRequired':False,'additiveWarning':'Do not use additive blend for this artwork: ink outlines, dark masses and layered translucent fills rely on source-over.'},'gameplayAuthority':'none; environmental motion candidate only'}

def qa(out,clips):
 report={'passed':True,'issues':[],'warnings':[],'familyCount':len(set(c['family'] for c in clips)),'clipCount':len(clips),'frameCount':sum(c['frameCount'] for c in clips),'sourceFPS':30,'loopSeams':{},'minimumMarginPx':999,'atlasCropMatches':True,'zeroRGBUnderZeroAlpha':True,'sourceUniqueness':{}}
 for clip in clips:
  atlas=Image.open(out/clip['atlas']).convert('RGBA');arrays=[];hashes=set()
  for f in clip['frames']:
   im=Image.open(out/f['file']).convert('RGBA');arr=np.array(im);arrays.append(arr);hashes.add(hashlib.sha256(arr.tobytes()).hexdigest())
   if np.any(arr[arr[:,:,3]==0,:3]):report['issues'].append('Hidden RGB '+f['file']);report['zeroRGBUnderZeroAlpha']=False
   x,y,w,h=f['rectPx']
   if atlas.crop((x,y,x+w,y+h)).tobytes()!=im.crop(f['atlasSourceCropPx']).tobytes():report['issues'].append('Atlas mismatch '+f['file']);report['atlasCropMatches']=False
   b=im.getbbox()
   if b:report['minimumMarginPx']=min(report['minimumMarginPx'],b[0],b[1],W-b[2],H-b[3])
  expected=clip['frameCount'] if clip['loop'] else clip['frameCount']-1
  report['sourceUniqueness'][clip['id']]={'uniquePixelFrames':len(hashes),'sourceFrameCount':clip['frameCount']}
  if len(hashes)!=expected:report['warnings'].append('Repeated pixel states; review whether the hold or shorter cadence is intentional: '+clip['id'])
  if max(atlas.size)>2048:report['issues'].append('Texture exceeds 2048 '+clip['id'])
  if clip['loop']:
   values=[]
   for arr in arrays:
    aa=arr.astype(np.float32)/255;values.append(np.concatenate([aa[:,:,:3]*aa[:,:,3,None],aa[:,:,3,None]],axis=2))
   diff=[float(np.abs(values[(i+1)%len(values)]-values[i]).mean()) for i in range(len(values))]
   ratio=diff[-1]/max(max(diff[:-1]),.000001)
   report['loopSeams'][clip['id']]={'lastToFirstMeanAbsoluteDifference':round(diff[-1],8),'maxOtherAdjacentDifference':round(max(diff[:-1]),8),'seamToMaxAdjacentRatio':round(ratio,4),'sampleConvention':'phase=i/30; no duplicated terminal drawing','passed':ratio<=1.25}
   if ratio>1.25:report['issues'].append('Loop seam outlier '+clip['id'])
  elif arrays[0][:,:,3].max()!=0 or arrays[-1][:,:,3].max()!=0:report['issues'].append('Nontransparent one-shot endpoints '+clip['id'])
 if report['minimumMarginPx']<6:report['issues'].append('Clipping margin below 6 px')
 report['passed']=not report['issues'];(out/'qa_report.json').write_text(json.dumps(report,indent=2)+'\n');return report


def floor(light,size,scale,root):
 bg=(202,201,185) if light else (35,43,43);ln=(183,184,169) if light else (46,54,53);im=Image.new('RGB',size,bg);d=ImageDraw.Draw(im)
 # Quiet projected XZ guide grid, with no borrowed floor texture.
 for i in range(-4,8):
  a=(i*.9,0,-3.5);b=(i*.9,0,3.5);p=proj(a);q=proj(b);d.line([(root[0]+(p[0]-PIVOT[0])*scale,root[1]+(p[1]-PIVOT[1])*scale),(root[0]+(q[0]-PIVOT[0])*scale,root[1]+(q[1]-PIVOT[1])*scale)],fill=ln)
  a=(-3.5,0,i*.9);b=(3.5,0,i*.9);p=proj(a);q=proj(b);d.line([(root[0]+(p[0]-PIVOT[0])*scale,root[1]+(p[1]-PIVOT[1])*scale),(root[0]+(q[0]-PIVOT[0])*scale,root[1]+(q[1]-PIVOT[1])*scale)],fill=ln)
 return im

def card(frame,light,size=(560,338),scale=1440/13/DENSITY,label='',detail=''):
 root=(size[0]//2-30,176);im=floor(light,size,scale,root);d=ImageDraw.Draw(im);tx=(46,55,48) if light else (231,229,211)
 if frame:
  fr=frame.resize((round(W*scale),round(H*scale)),Image.Resampling.LANCZOS);im.paste(fr,(round(root[0]-PIVOT[0]*scale),round(root[1]-PIVOT[1]*scale)),fr)
 d=ImageDraw.Draw(im);d.text((16,13),label,font=font(14,True),fill=tx);d.text((16,size[1]-26),detail,font=font(11),fill=tx)
 # 1.8 m vertical ruler is a calibration reference only, not a hero proxy or UI asset.
 ry=230;rx=size[0]-32;ht=1.8*math.sqrt(2/3)*DENSITY*scale;d.line((rx,ry,rx,round(ry-ht)),fill=tx,width=2);d.line((rx-4,ry,rx+4,ry),fill=tx,width=2);d.line((rx-4,round(ry-ht),rx+4,round(ry-ht)),fill=tx,width=2);d.text((rx-47,ry+8),'1.8 m',font=font(10),fill=tx)
 return im


def proofs(out,clips):
 review=out/'review';review.mkdir(exist_ok=True);allfr={c['id']:[Image.open(out/f['file']).convert('RGBA') for f in c['frames']] for c in clips}
 for j,c in enumerate(clips):
  page=Image.new('RGB',(1120,766),(25,31,32));d=ImageDraw.Draw(page);d.text((22,15),c['label'],font=font(23,True),fill=(237,232,216));d.text((22,49),'Original 30 fps loop / fixed local anchor / normal alpha / exact camera where world-projected',font=font(13),fill=(177,190,178))
  idx=12
  for row,(scale,desc) in enumerate([(1440/13/DENSITY,'1440 px buffer / 13 m vertical view'),(1080/16/DENSITY,'1080 px buffer / 16 m stress view')]):
   for col in range(2):
    ca=card(allfr[c['id']][idx],col==1,scale=scale,label=('LIGHT' if col else 'DARK')+' / phase 12 of 30',detail=desc+' | '+c['space'].replace('world_centres_with_screen_',''))
    # Small local-anchor cross is presentation-only, never exported in source PNGs.
    cd=ImageDraw.Draw(ca);colr=(117,125,106) if col else (127,141,126);cd.line((246,176,254,176),fill=colr,width=1);cd.line((250,172,250,180),fill=colr,width=1);page.paste(ca,(col*560,82+row*342))
  page.save(review/f"proof_{j+1:02d}_{c['id']}.jpg",quality=95)
 sheet=Image.new('RGB',(1536,246*len(clips)),(25,31,32))
 for row,c in enumerate(clips):
  for j,idx in enumerate([0,5,10,15,20,25]):
   light=j%2==1;tx=(48,54,46) if light else (233,231,213);cell=Image.new('RGB',(256,246),(204,201,184) if light else (37,45,43));fr=allfr[c['id']][idx].resize((256,224),Image.Resampling.LANCZOS);cell.paste(fr,(0,8),fr);cd=ImageDraw.Draw(cell);cd.text((8,5),c['label'],font=font(11,True),fill=tx);cd.text((8,229),f'phase {idx:02d} / 30 | 30 fps',font=font(10),fill=tx);sheet.paste(cell,(j*256,row*246))
 sheet.save(review/'All_Loop_Keyframes.jpg',quality=94)
 overview=Image.new('RGB',(1120,80+338*math.ceil(len(clips)/2)),(25,31,32));d=ImageDraw.Draw(overview);d.text((22,15),'LANTERN / QUIET ENVIRONMENT MOTION',font=font(25,True),fill=(237,232,214));d.text((22,48),f'{len(clips)} original loops | authored vector shapes | sparse elements | exact 1440 px / 13 m pixel density',font=font(14),fill=(178,192,180))
 for j,c in enumerate(clips):
  ca=card(allfr[c['id']][12],j%2==1,label=c['label'],detail=c['space']);overview.paste(ca,((j%2)*560,80+(j//2)*338))
 overview.save(review/'Environment_Motion_Overview.jpg',quality=95)
 selected=[c for c in clips if c['id'] in ['hanging_banner','reeds_sway']]
 if selected:
  ext=Image.new('RGB',(2240,80+338*len(selected)),(25,31,32));ed=ImageDraw.Draw(ext);ed.text((22,15),'FIXED ANCHORS / FULL-CYCLE SILHOUETTE EXTREMES',font=font(25,True),fill=(237,232,214));ed.text((22,48),'Frames chosen from minimum/maximum alpha-weighted silhouette centre X, plus start and half-cycle. Actual game pixel density.',font=font(14),fill=(178,192,180))
  for row,c in enumerate(selected):
   means=[]
   for fr in allfr[c['id']]:
    aa=np.asarray(fr)[:,:,3].astype(np.float64);means.append(float((aa*np.arange(W)[None,:]).sum()/max(aa.sum(),1)))
   indices=[0,int(np.argmin(means)),15,int(np.argmax(means))];labels=['phase zero','leftmost silhouette centre','half cycle','rightmost silhouette centre']
   for j,(idx,label) in enumerate(zip(indices,labels)):
    ca=card(allfr[c['id']][idx],j%2==1,label=c['label'],detail=f'{label} | phase {idx:02d} / 30');cd=ImageDraw.Draw(ca);cc=(110,124,108) if j%2 else (150,166,143);cd.line((244,176,256,176),fill=cc);cd.line((250,170,250,182),fill=cc);ext.paste(ca,(j*560,80+row*338))
  ext.save(review/'Fixed_Anchor_Motion_Extremes.jpg',quality=95)
 return allfr

def movie(out,clips,allfr):
 pages=math.ceil(len(clips)/2);page_ticks=240
 proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1120x800','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(out/'review'/'Environment_Motion_60Hz.mp4')],stdin=subprocess.PIPE)
 cache={}
 for c in clips:
  for col in range(2):
   cache[c['id'],col]=[card(fr,col==1,label=c['label'],detail=f"phase {i:02d} / 30 | true 30 fps loop | {'light' if col else 'dark'} | 1440 px / 13 m") for i,fr in enumerate(allfr[c['id']])]
 for tick in range(pages*page_ticks):
  page=tick//page_ticks;fi=((tick%page_ticks)//2)%30;im=Image.new('RGB',(1120,800),(24,31,31));d=ImageDraw.Draw(im);d.text((22,15),'LANTERN / ENVIRONMENT MOTION LOOPS',font=font(24,True),fill=(236,232,214));d.text((22,49),'30 authored frames per second / exact 2:1 sample holds at 60 Hz / four complete loops per page',font=font(13),fill=(178,192,181))
  for row,c in enumerate(clips[page*2:page*2+2]):
   for col in range(2):im.paste(cache[c['id'],col][fi],(col*560,82+row*344))
  d=ImageDraw.Draw(im);d.text((22,778),'No random discontinuity, all-over grain, bloom or engine changes. Grounded art uses the exact 35.264389682754654° / 45° camera.',font=font(10),fill=(164,179,169));proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('ffmpeg failed')

README='''LANTERN / QUIET ENVIRONMENT MOTION / v1.0
Eight original scene accents: hanging cloth, skittering papers, reeds, water drip and
ripple, chimney puffs, falling dust, moth silhouette and water glints. These add small
localized motion to static scenes; they are not gameplay or UI implementations.
Each clip: 30 genuinely authored frames at 30 fps, 1-second loop, no duplicated final
frame. Full pack: 240 source PNGs plus matching SVGs, 8 atlases. The early gate contains
cloth, reeds and papers only. No borrowed art or AI-generated animation frames.

QUIET DESIGN / COST
One cloth, two sheets, three reeds, one drop plus at most two ripple groups, two smoke
lobes, four dust flecks, one moth, three glint slivers. No whole-screen particle field.
Clean edges, few value planes, deliberate folds. Banner motion is low-amplitude, not
fast large flapping; foliage roots and attachment pivots stay planted. Texture budget
reports raw atlas allocation separately from ZIP or PNG size; no runtime test implied.

CAMERA / ANCHORS
Orthographic elevation 35.264389682754654°; azimuth 45° from +Z toward +X. Right-handed
XZ ground, +Y up. Source canvas 512 x 448, density 112 px/m, pivot (256,286), image origin
top-left. Camera basis, atlas crop offsets and stable per-frame pivots are recorded.
Banner pivot is its TOP ATTACHMENT; cloth hangs in local negative Y. Dust pivot is an
OVERHEAD SHED SOCKET; flecks fall in local negative Y. Chimney pivot is its MOUTH SOCKET;
there is no extra baked chimney height. Reed roots, paper patch, moth hover region and
water accents use their documented local ground/surface anchors. Translate those local
origins into the scene; do not align sprites by their changing alpha bounds.

Cloth, papers, reeds, the drop/ripple, moth and glints use actual projected geometry.
Chimney cloud contours and dust flecks are explicitly FACING-CAMERA BILLBOARDS whose
centres move in projected world space. No arbitrary-view 3D claim is made for them.
Preview anchor marks and 1.8 m rulers are calibration aids only, not exported assets.
Proofs show real 1440 px / 13 m density (scale 0.98901099) and a 1080 px / 16 m stress
view (scale 0.60267857). They are unzoomed local crops, not full viewports.

PERIODICITY
The source samples phase i/30, and each draw is held twice in the 60 Hz movie. No frame
interpolation or speed-up. Cloth/reed/wing parameters are periodic analytic functions.
Paper, smoke, dust and glints use staggered periodic emitter cycles with opacity zero
at each recycle boundary. A recycle is a new visual element, not a physical teleport.
The drip cycle fades its final ripples before the next drop. Loop QA compares all
adjacent samples and the last-to-first boundary; no hidden random inputs are used.

ALPHA / PACKING
PNG is straight/unassociated alpha; RGB under zero alpha is zero. Normal source-over:
SRC_ALPHA / ONE_MINUS_SRC_ALPHA. RGB sRGB, alpha linear. Linear-space blending preferred.
If texture upload premultiplies once, use ONE / ONE_MINUS_SRC_ALPHA accordingly. Do not
double-premultiply. No clip requires additive blending or bloom; dark material shapes
and low-opacity clouds rely on source-over. Four-pixel transparent atlas gutters;
constant union crops per clip. Disable mipmaps unless proper alpha-aware extrusion and
per-mip padding are added. All full source canvases and editable per-frame SVGs remain.

REBUILD / BOUNDARIES
Python 3, Pillow, numpy and ffmpeg with libx264. Run python source/build_environment_motion.py.
Add --early for the first three examples. Package scripts create complementary ZIPs
with an exact union and CRC/SHA256 ledger. Source art, atlas extraction, loop seams and
review framing are checked independently of integration. No hero art, Unity, Codex,
three.js or game code was changed, and owner approval of candidates is not implied.
'''

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--early',action='store_true');ap.add_argument('--skip-preview',action='store_true');args=ap.parse_args();out=ROOT/('early_review' if args.early else 'environment_motion_v1');out.mkdir(exist_ok=True);clips=[]
 names=['hanging_banner','reeds_sway','loose_papers'] if args.early else list(SPECS)
 for n in names:print('Rendering',n,flush=True);clips.append(export_clip(n,out))
 camera={'projection':'orthographic','elevationDegrees':ELEVATION,'azimuthDegrees':AZIMUTH,'azimuthConvention':'from +Z toward +X','worldAxes':'right-handed XZ ground +Y vertical','sourcePixelsPerWorldMetre':DENSITY,'sourceCanvasPx':[W,H],'rootPivotPx':list(PIVOT),'imageOrigin':'top_left','screenRight':[math.sqrt(.5),0,-math.sqrt(.5)],'screenUp':[-1/math.sqrt(6),math.sqrt(2/3),-1/math.sqrt(6)],'matrixConvention':'basis row dot world; image y negates screen-up; multiply by density then add pivot'}
 manifest={'schema':'lantern.environment-motion.v1','status':'original motion candidates; no runtime approval','sourceFPS':30,'familyCount':len(clips),'clipCount':len(clips),'camera':camera,'gameplayAuthority':'none','clips':clips}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');report=qa(out,clips);print(json.dumps(report,indent=2),flush=True);frames=proofs(out,clips)
 if not args.skip_preview:movie(out,clips,frames)
 budget={'format':'RGBA8','mipmaps':False,'atlasBytes':sum(math.prod(c['atlasSizePx'])*4 for c in clips),'atlasCount':len(clips),'note':'Raw base-level allocation, not file size or measured runtime performance','clips':[{'id':c['id'],'atlasSizePx':c['atlasSizePx'],'bytes':math.prod(c['atlasSizePx'])*4} for c in clips]};(out/'texture_budget.json').write_text(json.dumps(budget,indent=2)+'\n')
 (out/'README.txt').write_text(README);(out/'source').mkdir(exist_ok=True)
 for n in ['build_environment_motion.py','vfx_core.py','package_environment_motion.py']:
  if (SOURCE/n).resolve()!=(out/'source'/n).resolve():shutil.copyfile(SOURCE/n,out/'source'/n)
 (out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(out).as_posix()+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts))
 if not report['passed']:raise SystemExit('QA failed')
 print('ENVIRONMENT MOTION COMPLETE',out)
if __name__=='__main__':main()
