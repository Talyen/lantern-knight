from build_pack import *
DESCS={
'lantern_cone_flare':'Compact gather, broad connected ignition mass, brief overshoot, four unequal tearing flame lobes and isolated ember clear. Rooted warm cone presentation only.',
'layered_flame_tongues':'Primary direction A. Compact gather becomes one broad asymmetric ignition mass, then tears into four unequal pieces and isolated embers. Flame topology changes across phases.',
'fractured_amber_panes':'Alternative B. Three unequal amber panes ignite, shear at different rates and detach into smaller fragments within the same nominal cone. Presentation alternative, not another ability.',
'curling_ember_ribbons':'Alternative C. Two ember sheets progressively unfurl along curved paths. Moving interval clipping removes tails, then separates tips and clear fragments; no intact symbol scaling.',
'dash_wake':'Three unequal curved ground wakes open behind the motion root, pinch away from origin and clear. No character afterimage or gameplay invulnerability authority.',
'stagger_shards':'Three unequal irregular amber slivers rotate and lift from the attachment point, with a staged clear; no repeated diamonds or status UI.',
'hanging_banner':'Fresh oxblood illustrated cloth master with authored deep folds, worn split hem and wooden rod. Fixed-top periodic inverse mesh delays the hem response. Illustrative2D cloth, not camera-calibrated3D.',
'loose_papers':'Two curved papers with a rolled edge, front/back value difference and three quiet script strokes; phase-offset projected skitter and invisible reset.',
'reeds_sway':'Seven uneven stems form overlapping natural clumps with individually delayed curved leaves. Roots remain fixed.',
'chimney_puff':'Three sparse puff schedules. Each continuous emission opens into up to three separate uneven smoke lobes during rise and clear. Projected centres with facing-camera outlines.',
'rolling_ground_mist':'Four quiet unequal interlocking fog banks, asymmetric contour, broken gaps and delayed drift. Low opacity preserves floor visibility; not spatially tileable.',
'autumn_leaf_gust':'Three curved asymmetrical leaf silhouettes rotate through near-edge-on poses during bounded skimming gusts. No star-shaped glyph leaves.'}
for pack in PACKS:
 out=ROOT/pack;m=json.load(open(out/'manifest.json'))
 for c in m['clips']:
  if c.get('revisionStatus')!='repaired':continue
  name=c.get('effect',c.get('treatment',c.get('family')));c['description']=DESCS[name]
  if name in ['lantern_cone_flare','layered_flame_tongues','fractured_amber_panes','curling_ember_ribbons']:
   c['visualPhases']=[{'name':'gather','frameRangeInclusive':[0,4]},{'name':'ignition and overshoot','frameRangeInclusive':[5,10]},{'name':'split and separation','frameRangeInclusive':[11,17]},{'name':'detached clear','frameRangeInclusive':[18,23]}]
   c['gameplayAuthority']='none; all phase timing and nominal envelope dimensions are illustrative. Keep functional attack telegraphs separate.'
  if name=='hanging_banner':c.update(axis='front-facing2D cloth plane, fixed top pixel region and delayed hem deformation',visibleElementBudget=1)
  if name=='reeds_sway':c['visibleElementBudget']=7
  if name=='chimney_puff':c['visibleElementBudget']='3 emission schedules, each opening into1-3 lobes'
  if name=='rolling_ground_mist':c['elementBudget']='4 unequal banks; no dense noise or screen-filling veil'
  if name=='layered_flame_tongues':c['shapeLanguage']='Connected ignition mass, hooked flame tears, small detached embers'
  if name=='fractured_amber_panes':c['shapeLanguage']='Three uneven shearing amber plates and smaller fracture slivers'
  if name=='curling_ember_ribbons':c['shapeLanguage']='Two evolving open curved ember sheets with clipped tails and separated tips'
  for k in ['atlasPageCount']:
   if 'atlases' in c:c[k]=len(c['atlases'])
 m['artReviewScope']='Main A flare and banner gated before final export. Phase/contact images and all-file QA provided; no engine integration or runtime frame-rate claim.'
 (out/'manifest.json').write_text(json.dumps(m,indent=2))
 shutil.copytree(ROOT/'source',out/'source'/'revision',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
