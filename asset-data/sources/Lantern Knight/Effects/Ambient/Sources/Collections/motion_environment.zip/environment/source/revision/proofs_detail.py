from build_pack import *
def details(pack,cid):
 out=ROOT/pack;ims=[Image.open(p).convert('RGBA') for p in sorted((out/'frames'/cid).glob('*.png'))];bb=[im.getbbox() for im in ims if im.getbbox()];b=[min(x[0] for x in bb)-8,min(x[1] for x in bb)-8,max(x[2] for x in bb)+8,max(x[3] for x in bb)+8];sel=[0,len(ims)//4,len(ims)//2,len(ims)*3//4,len(ims)-1];cw=b[2]-b[0];ch=b[3]-b[1];sheet=Image.new('RGB',(5*(cw*3+20),ch*3+45),(25,31,31));d=ImageDraw.Draw(sheet)
 for j,k in enumerate(sel):
  crop=ims[k].crop(b).resize((cw*3,ch*3),Image.Resampling.NEAREST);sheet.paste(crop,(j*(cw*3+20),35),crop);d.text((j*(cw*3+20),10),f'{cid} frame{k}; 3x nearest',fill=(220,195,142))
 sheet.save(out/'review'/f'{cid}_detail.png')
 if cid=='hanging_banner':
  regions=[np.array(im.crop((220,281,292,293))) for im in ims];fixed=all(np.array_equal(regions[0],r) for r in regions);(out/'BANNER_ANCHOR_QA.json').write_text(json.dumps({'poleTopRegionPx':[220,281,292,293],'identicalEveryFrame':fixed,'meshMaximumHemDisplacementSourcePx':6,'rootPivotPx':[256,286],'method':'Fresh master bound to inverse periodic cloth mesh, stationary rod region; no framewise regenerated art.','caveat':'Illustrative2D deformation, not real3D overlap reconstruction or exact perspective cloth simulation.'},indent=2))
for pack,cid in [('environment','hanging_banner'),('environment','reeds_sway'),('environment','loose_papers'),('environment','chimney_puff'),('weather','autumn_leaf_gust'),('weather','rolling_ground_mist')]:details(pack,cid)
