#!/usr/bin/env python3
"""Quiet original weather loops; deterministic geometry, no generated image frames."""
from pathlib import Path
import argparse,hashlib,json,math,random,shutil,subprocess
import numpy as np
from PIL import Image,ImageDraw
from vfx_core import Canvas,proj,font,clamp,smooth,C,W,H,PIVOT,DENSITY,ELEVATION,AZIMUTH
SOURCE=Path(__file__).resolve().parent;ROOT=SOURCE.parent
if ROOT.name in ('early_review','weather_atmosphere_v1'):ROOT=ROOT.parent
TAU=math.tau;SEED=260610
C.update({'ink':'#293332','rain':'#d5e1d1','rainedge':'#374f53','ash':'#959985','ashedge':'#434d48','ashlight':'#c4c1a9','mist':'#bec5b7','mistlight':'#e0e0cb','mistshade':'#596e67','leaf':'#b78b4b','leafshade':'#796344','leafrust':'#aa7658','leafrustshade':'#715445','leafpale':'#c9ab70'})
SPECS={
'sparse_rain':dict(label='Rain / small ground patch',frames=90,space='projected_world',pivotMeaning='Ground centre of a bounded rain patch at world (0,0,0)',description='Eight staggered slanting drops per three-second cycle; three drops leave a short two-prong splash rather than repeated ripple rings.',elementBudget='8 deterministic drop schedules; only a few simultaneously visible; 3 impact events per cycle',previewFrame=24,relatedPrior='Drip/ripple and droplet splash: related water theme, different patch weather behavior.'),
'wind_ash':dict(label='Ash / sideways screen drift',frames=90,space='screen_overlay',pivotMeaning='Screen patch anchor at PNG (256,286); no physical ground contact or depth',description='Six unequal charcoal flakes glide sideways in a small screen patch, with subdued warm rims and slow independent turning. No falling socket or glowing motes.',elementBudget='6 flakes maximum; no world-contact claims',previewFrame=34,relatedPrior='Dust fall: related particulate theme; prior effect descends from a world socket, this one is a horizontal screen overlay.'),
'rolling_ground_mist':dict(label='Mist / low rolling ribbons',frames=120,space='projected_world',pivotMeaning='Ground centre of a low bounded mist patch at world (0,0,0)',description='Three broad low ribbons translate and roll along the ground; restrained translucency and smooth designed edges replace noise or puff clouds.',elementBudget='3 broad ribbons maximum, each with one restrained inner plane',previewFrame=38,relatedPrior='Quiet smoke/chimney puff/poison mist: related atmosphere themes, but this is non-vertical, ground-projected rolling mist.'),
'autumn_leaf_gust':dict(label='Leaves / ground-skimming gust',frames=90,space='projected_world',pivotMeaning='Ground centre of a bounded leaf-gust region at world (0,0,0)',description='Three different lobed autumn leaves skate and lift in a repeating lateral gust; low clearance and variable drift distinguish them from the earlier single falling leaf.',elementBudget='3 separate lobed leaves maximum',previewFrame=38,relatedPrior='Tumbling leaf and scattered-leaf decals: related leaf theme, new low wind-gust loop; not an entirely new subject.'),
}
for name,s in SPECS.items():s.update(family=name,loop=True,seed=SEED,spatialTiling='Not spatially tileable; bounded patch with invisible emitter resets. Do not assume matching left/right/top/bottom edges.')

def edge(c,pts,width,col,a=1):
 left=[];right=[]
 for i,p in enumerate(pts):
  pp=pts[max(0,i-1)];qq=pts[min(len(pts)-1,i+1)];dx=qq[0]-pp[0];dy=qq[1]-pp[1];ln=max(math.hypot(dx,dy),1e-8);left.append((p[0]-dy/ln*width/2,p[1]+dx/ln*width/2));right.append((p[0]+dy/ln*width/2,p[1]-dx/ln*width/2))
 c.poly(left+right[::-1],col,a)

rng=random.Random(SEED)
RAIN_EVENTS=[{'phase':(i/8+rng.uniform(-.026,.026))%1,'x':rng.uniform(-1.08,1.08),'z':rng.uniform(-.65,.65),'height':rng.uniform(1.27,1.54),'impact':i in (0,3,6)} for i in range(8)]
ASH_EVENTS=[{'phase':i/6+rng.uniform(-.025,.025),'y':-133+i*28+rng.uniform(-8,8),'size':rng.uniform(3.6,5.6),'angle':rng.uniform(-.7,.7)} for i in range(6)]

def rain(c,t):
 t=t%1
 for event in RAIN_EVENTS:
  q=(t-event['phase'])%1;x=event['x'];z=event['z']
  if q<.17:
   u=q/.17;a=smooth(u/.12)*(1-smooth((u-.91)/.09))*.88;y=event['height']*(1-u);xx=x-.31*(1-u);zz=z-.08*(1-u);w=.035;L=.21
   pp=[(xx-w,y,zz),(xx+w,y,zz),(xx-.038+w,y+L,zz-.011),(xx-.038-w,y+L,zz-.011)]
   c.worldpoly(pp,'rainedge',a)
   mid=(xx-.019,y+L*.5,zz-.0055);c.worldpoly([tuple(mid[k]+(p[k]-mid[k])*.44 for k in range(3)) for p in pp],'rain',a)
  if event['impact'] and .17<=q<.27:
   u=(q-.17)/.10;a=math.sin(math.pi*u)**1.2*.79;r=.035+.13*u;h=.09*math.sin(math.pi*u)
   for side in [-1,1]:
    xx=x+side*r;pp=[(xx-.026,.009,z),(xx+.024,.009,z),(xx+side*.022,h+.014,z+.008)]
    c.worldpoly(pp,'rainedge',a*.85);c.worldpoly([(xx-.011,.012,z-.003),(xx+.012,.012,z-.003),(xx+side*.018,h+.010,z+.004)],'rain',a)
   c.worldpoly([(x-.075,.008,z),(x,.008,z-.025),(x+.090,.008,z),(x,.008,z+.027)],'rain',a*.46)

def ash(c,t):
 t=t%1
 for i,e in enumerate(ASH_EVENTS):
  q=(t+e['phase'])%1;a=smooth(q/.14)*(1-smooth((q-.79)/.21))*(.83 if i%2 else .89);x=PIVOT[0]-117+234*q;y=PIVOT[1]+e['y']+8*math.sin(TAU*q+i);theta=e['angle']+.73*math.sin(TAU*q+i*.7);s=e['size']
  shape=[(-s,-s*.33),(-s*.14,-s*.74),(s*.78,-s*.18),(s*.58,s*.58),(-s*.24,s*.39)]
  if i%3==1:shape=[(-s,-s*.19),(s*.39,-s*.66),(s,s*.18),(-s*.32,s*.53)]
  pts=[(x+u*math.cos(theta)-v*math.sin(theta),y+u*math.sin(theta)+v*math.cos(theta)) for u,v in shape]
  c.poly(pts,'ashedge',a);c.poly([(x+(xx-x)*.62,y+(yy-y)*.62) for xx,yy in pts],'ash',a)
  cap=[pts[0],pts[1],pts[2],(x,y)];c.poly([(x+(xx-x)*.61,y+(yy-y)*.61) for xx,yy in cap],'ashlight',a*.85)

def mist(c,t):
 t=t%1
 for i,(zbase,length,width) in enumerate([(-.49,2.16,.38),(.04,2.38,.46),(.56,1.94,.36)]):
  q=(t+i/3+.09)%1;a=smooth(q/.17)*(1-smooth((q-.75)/.25));centre=-.43+.86*q;left=[];right=[];innerleft=[];innerright=[];under=[]
  for j in range(65):
   u=j/64;taper=math.sin(math.pi*u)**.6;x=centre+(u-.5)*length;z=zbase+.13*math.sin(TAU*(u*.87-q*.62)+i*.8);y=.025+.067*(1+math.sin(TAU*(u-q)+i*.9))*math.sin(math.pi*u);w=width*taper*(.81+.19*math.sin(u*7-q*TAU+i))
   left.append((x,y,z-w/2));right.append((x,y,z+w/2));innerleft.append((x,y+.012,z-w*.18));innerright.append((x,y+.012,z+w*.14));under.append((x,.012,z+w*.62))
  # A quiet darker underside and broad translucent cap hold their form on both
  # floor values. These are lifted XZ ribbons, not vertical smoke billboards.
  c.worldpoly(left+under[::-1],'mistshade',a*.12)
  c.worldpoly(left+right[::-1],'mist',a*.28)
  c.worldpoly(innerleft+innerright[::-1],'mistlight',a*.22)

LEAF_SHAPES=[
 [(0,.20),(-.045,.09),(-.145,.115),(-.106,.025),(-.174,-.022),(-.082,-.066),(-.083,-.162),(0,-.115),(.108,-.15),(.083,-.055),(.169,-.001),(.098,.041),(.127,.115),(.038,.088)],
 [(0,.184),(-.047,.076),(-.126,.082),(-.096,.01),(-.145,-.081),(-.06,-.072),(-.061,-.17),(.005,-.117),(.107,-.155),(.084,-.055),(.162,-.035),(.094,.034),(.109,.10),(.033,.083)],
 [(0,.211),(-.040,.114),(-.102,.129),(-.083,.036),(-.16,.01),(-.089,-.056),(-.121,-.131),(-.030,-.117),(.06,-.171),(.071,-.067),(.156,-.075),(.111,.019),(.147,.088),(.050,.081)],
]
def leaf_rotate(p,tilt,yaw,roll):
 x,y,z=p;y,z=y*math.cos(tilt)-z*math.sin(tilt),y*math.sin(tilt)+z*math.cos(tilt);x,y=x*math.cos(roll)-y*math.sin(roll),x*math.sin(roll)+y*math.cos(roll);return x*math.cos(yaw)+z*math.sin(yaw),y,-x*math.sin(yaw)+z*math.cos(yaw)
def leaves(c,t):
 t=t%1
 for i,shape in enumerate(LEAF_SHAPES):
  q=(t+i/3+.12)%1;a=smooth(q/.13)*(1-smooth((q-.81)/.19));travel=q-.070*math.sin(TAU*q);x=-1.25+2.50*travel;z=[-.47,.05,.52][i]+.105*math.sin(TAU*q+i);gap=.013+.066*math.sin(2*math.pi*q)**2+.052*math.sin(math.pi*q)
  tilt=.34*math.sin(TAU*q+i);yaw=.33+i*.67+TAU*q*.58;roll=.22*math.sin(2*TAU*q+i*.6)
  def localv(u,v):return leaf_rotate((u,.048*abs(u)/.17,v),tilt,yaw,roll)
  local=[localv(u,v) for u,v in shape];low=min(v[1] for v in local)
  def vertex(u,v):p=localv(u,v);return (x+p[0],p[1]-low+gap,z+p[2])
  c.worldpoly([vertex(u,v) for u,v in shape],'ink',a*.94)
  c.worldpoly([vertex(u*.85,v*.90) for u,v in shape],'leafrust' if i==1 else ('leafpale' if i==2 else 'leaf'),a)
  half=[(0,.17)]+[(u*.85,v*.89) for u,v in shape if u<0]+[(0,-.111)]
  c.worldpoly([vertex(u,v) for u,v in half],'leafrustshade' if i==1 else 'leafshade',a*.76)
  # One short stem; no vein network, speckle texture or screen-space twinkle.
  c.worldpoly([vertex(-.012,-.105),vertex(.012,-.105),vertex(.014,-.203),vertex(-.004,-.207)],'leafshade',a)

FUNCS={'sparse_rain':rain,'wind_ash':ash,'rolling_ground_mist':mist,'autumn_leaf_gust':leaves}
def render(name,i):
 c=Canvas();FUNCS[name](c,i/SPECS[name]['frames']);return c

def export_clip(name,out):
 spec=SPECS[name];n=spec['frames'];folder=out/'frames'/name;folder.mkdir(parents=True,exist_ok=True);svgs=out/'vectors'/name;svgs.mkdir(parents=True,exist_ok=True);images=[];bounds=[]
 for i in range(n):
  c=render(name,i);im=c.export(folder/f'{i:03d}.png');images.append(im);(svgs/f'{i:03d}.svg').write_text(c.svg_text());bounds.append(im.getbbox())
 b=[x for x in bounds if x];union=[min(x[0] for x in b)-2,min(x[1] for x in b)-2,max(x[2] for x in b)+2,max(x[3] for x in b)+2];cw,ch=union[2]-union[0],union[3]-union[1];pad=4;cols=min(8,max(1,2048//(cw+2*pad)));rows=max(1,2048//(ch+2*pad));capacity=cols*rows;atlases=[];frames=[];(out/'atlases').mkdir(exist_ok=True)
 for page,start in enumerate(range(0,n,capacity)):
  count=min(capacity,n-start);pageRows=math.ceil(count/cols);atlas=Image.new('RGBA',(cols*(cw+2*pad),pageRows*(ch+2*pad)));path=f'atlases/{name}_{page:02d}.png'
  for local,i in enumerate(range(start,start+count)):
   x=pad+(local%cols)*(cw+2*pad);y=pad+(local//cols)*(ch+2*pad);atlas.paste(images[i].crop(union),(x,y));frames.append({'id':i,'file':f'frames/{name}/{i:03d}.png','svg':f'vectors/{name}/{i:03d}.svg','atlas':path,'atlasPage':page,'rectPx':[x,y,cw,ch],'sourceSizePx':[W,H],'trimOffsetPx':union[:2],'atlasSourceCropPx':union,'pivotPx':list(PIVOT),'atlasPivotPx':[PIVOT[0]-union[0],PIVOT[1]-union[1]],'durationRational':[1,30],'durationSeconds':1/30,'alphaBoundsPx':list(bounds[i]) if bounds[i] else None})
  atlas.save(out/path,optimize=True);atlases.append({'file':path,'sizePx':list(atlas.size),'frameRangeInclusive':[start,start+count-1]})
 return {'id':name,**spec,'frames':frames,'frameCount':n,'sourceFPS':30,'durationRational':[n,30],'durationSeconds':n/30,'atlases':atlases,'atlasPageCount':len(atlases),'atlasPaddingPx':pad,'atlasCropPolicy':'one fixed union crop over whole clip; pages split at <=2048 px; full loose PNG canvases','finishBehavior':'wrap directly, no duplicated endpoint','blend':{'pngAlpha':'straight/unassociated','premultipliedAlpha':False,'recommended':'normal source-over','sourceFactor':'SRC_ALPHA','destinationFactor':'ONE_MINUS_SRC_ALPHA','textureColorSpace':'sRGB','alphaIsLinear':True,'additiveRequired':False},'gameplayAuthority':'none; illustrative weather art only'}

def qa(out,clips):
 report={'passed':True,'issues':[],'warnings':[],'clipCount':len(clips),'familyCount':len(clips),'frameCount':sum(c['frameCount'] for c in clips),'atlasPageCount':sum(c['atlasPageCount'] for c in clips),'minimumMarginPx':999,'loopSeams':{},'sourceUniqueness':{},'alphaAtlasChecksPassed':True,'transparentGuttersPassed':True,'analyticEndpointsExact':{},'reviewBoundsPassed':True}
 for clip in clips:
  atlases={a['file']:Image.open(out/a['file']).convert('RGBA') for a in clip['atlases']};first=None;prev=None;deltas=[];hashes=set()
  for f in clip['frames']:
   im=Image.open(out/f['file']).convert('RGBA');arr=np.array(im);hashes.add(hashlib.sha256(arr.tobytes()).hexdigest());b=im.getbbox()
   if np.any(arr[arr[:,:,3]==0,:3]):report['issues'].append('Hidden RGB '+f['file']);report['alphaAtlasChecksPassed']=False
   x,y,w,h=f['rectPx'];atlas=atlases[f['atlas']]
   if atlas.crop((x,y,x+w,y+h)).tobytes()!=im.crop(f['atlasSourceCropPx']).tobytes():report['issues'].append('Atlas mismatch '+f['file']);report['alphaAtlasChecksPassed']=False
   for box in [(x-4,y-4,x+w+4,y),(x-4,y+h,x+w+4,y+h+4),(x-4,y,x,y+h),(x+w,y,x+w+4,y+h)]:
    if atlas.crop(box).getchannel('A').getextrema()[1]!=0:report['issues'].append('Nontransparent atlas gutter '+f['file']);report['transparentGuttersPassed']=False
   if b:
    report['minimumMarginPx']=min(report['minimumMarginPx'],b[0],b[1],W-b[2],H-b[3])
    for scale in [1440/13/DENSITY,1080/16/DENSITY]:
     rr=[250+(b[0]-PIVOT[0])*scale,275+(b[1]-PIVOT[1])*scale,250+(b[2]-PIVOT[0])*scale,275+(b[3]-PIVOT[1])*scale]
     if rr[0]<8 or rr[1]<42 or rr[2]>490 or rr[3]>412:report['reviewBoundsPassed']=False;report['issues'].append('Review framing '+f['file'])
   aa=arr.astype(np.float32)/255;pm=np.concatenate([aa[:,:,:3]*aa[:,:,3,None],aa[:,:,3,None]],axis=2)
   if first is None:first=pm
   if prev is not None:deltas.append(float(np.abs(pm-prev).mean()))
   prev=pm
  seam=float(np.abs(first-prev).mean());ratio=seam/max(max(deltas),1e-8);report['loopSeams'][clip['id']]={'lastToFirstPremultipliedRGBADifference':seam,'maxOrdinaryAdjacentDifference':max(deltas),'seamToMaxAdjacentRatio':ratio,'passed':ratio<=1.25,'sampleConvention':f"phase=i/{clip['frameCount']}; no duplicate endpoint"}
  if ratio>1.25:report['issues'].append('Loop seam outlier '+clip['id'])
  report['sourceUniqueness'][clip['id']]={'uniquePixelFrames':len(hashes),'sourceFrameCount':clip['frameCount'],'note':'Repeated states are descriptive, not automatically a failed loop.'}
  same=render(clip['id'],0).svg_text()==render(clip['id'],clip['frameCount']).svg_text();report['analyticEndpointsExact'][clip['id']]=same
  if not same:report['issues'].append('Analytic endpoint mismatch '+clip['id'])
  if any(max(a.size)>2048 for a in atlases.values()):report['issues'].append('Atlas above 2048 '+clip['id'])
 report['worldGeometryBoundsMetres']={};report['groundClearancePassed']=True;report['excludedFromWorldBounds']=[c['id'] for c in clips if c['space']=='screen_overlay']
 import vfx_core
 original=vfx_core.proj
 for clip in clips:
  if clip['space']!='projected_world':continue
  points=[]
  def capture(p):points.append(p);return original(p)
  try:
   vfx_core.proj=capture
   for i in range(clip['frameCount']):render(clip['id'],i)
  finally:vfx_core.proj=original
  mins=[min(p[k] for p in points) for k in range(3)];maxs=[max(p[k] for p in points) for k in range(3)];report['worldGeometryBoundsMetres'][clip['id']]={'minimum':mins,'maximum':maxs,'framesSampled':clip['frameCount']}
  if mins[1]<-1e-8:report['issues'].append('Geometry below ground '+clip['id']);report['groundClearancePassed']=False
 if report['minimumMarginPx']<6:report['issues'].append('Canvas margin under 6 px')
 report['passed']=not report['issues'];(out/'qa_report.json').write_text(json.dumps(report,indent=2)+'\n');return report

FLOOR_CACHE={}
def floor(light,size,scale,root):
 key=(light,size,scale,root)
 if key in FLOOR_CACHE:return FLOOR_CACHE[key].copy()
 dep=SOURCE.parent/'review_dependencies';filename='09_pale_crypt_marble.png' if light else '06_dark_earth.png';tex=np.array(Image.open(dep/filename).convert('RGB'));ss=2
 py,px=np.mgrid[0:size[1]*ss,0:size[0]*ss];dx=(px/ss-root[0])/(DENSITY*scale);dy=(py/ss-root[1])/(DENSITY*scale);xx=(math.sqrt(2)*dx+math.sqrt(6)*dy)/2;zz=(math.sqrt(6)*dy-math.sqrt(2)*dx)/2
 uu=(xx%4)/4*tex.shape[1];vv=(zz%4)/4*tex.shape[0];x0=np.floor(uu).astype(int)%tex.shape[1];y0=np.floor(vv).astype(int)%tex.shape[0];x1=(x0+1)%tex.shape[1];y1=(y0+1)%tex.shape[0];fx=uu%1;fy=vv%1
 arr=tex[y0,x0]*(1-fx[:,:,None])*(1-fy[:,:,None])+tex[y0,x1]*fx[:,:,None]*(1-fy[:,:,None])+tex[y1,x0]*(1-fx[:,:,None])*fy[:,:,None]+tex[y1,x1]*fx[:,:,None]*fy[:,:,None]
 im=Image.fromarray(arr.astype(np.uint8)).resize(size,Image.Resampling.LANCZOS);FLOOR_CACHE[key]=im;return im.copy()

def card(frame,light,size=(560,450),scale=1440/13/DENSITY,label='',detail=''):
 root=(250,275);im=floor(light,size,scale,root)
 if frame:
  fr=frame.resize((round(W*scale),round(H*scale)),Image.Resampling.LANCZOS);im.paste(fr,(round(root[0]-PIVOT[0]*scale),round(root[1]-PIVOT[1]*scale)),fr)
 d=ImageDraw.Draw(im);tx=(43,53,48) if light else (229,230,211);d.text((16,13),label,font=font(14,True),fill=tx);d.text((16,size[1]-27),detail,font=font(11),fill=tx)
 rx=528;ry=333;ht=1.8*math.sqrt(2/3)*DENSITY*scale;d.line((rx,ry,rx,round(ry-ht)),fill=tx,width=2);d.line((rx-4,ry,rx+4,ry),fill=tx,width=2);d.line((rx-4,round(ry-ht),rx+4,round(ry-ht)),fill=tx,width=2);d.text((rx-45,ry+8),'1.8 m',font=font(10),fill=tx)
 return im

def proofs(out,clips):
 review=out/'review';review.mkdir(exist_ok=True);allfr={c['id']:[Image.open(out/f['file']).convert('RGBA') for f in c['frames']] for c in clips}
 for j,c in enumerate(clips):
  page=Image.new('RGB',(1120,982),(25,31,32));d=ImageDraw.Draw(page);d.text((22,15),c['label'],font=font(23,True),fill=(237,232,216));d.text((22,49),f"{c['frameCount']} source drawings / 30 fps / {c['durationSeconds']:g}-second cycle / "+c['space'].replace('_',' '),font=font(13),fill=(177,190,178))
  for row,(scale,desc) in enumerate([(1440/13/DENSITY,'1440 px / 13 m reference'),(1080/16/DENSITY,'1080 px / 16 m stress reference')]):
   for col in range(2):
    label=('PALE MARBLE' if col else 'DARK EARTH')+' / frame '+str(c['previewFrame']);ca=card(allfr[c['id']][c['previewFrame']],col==1,scale=scale,label=label,detail=desc+' | normal alpha');page.paste(ca,(col*560,82+row*450))
  page.save(review/f"proof_{j+1:02d}_{c['id']}.jpg",quality=95)
  indices=[c['frameCount']-1,0,1,c['frameCount']//4,c['frameCount']//2,3*c['frameCount']//4];sheet=Image.new('RGB',(1680,900),(25,31,32))
  for k,idx in enumerate(indices):
   ca=card(allfr[c['id']][idx],k%2==1,label=f'{idx:03d} / '+c['label'],detail=('SEAM: final, first, next' if k<3 else 'CYCLE PHASE')+' | '+c['space'].replace('_',' '));sheet.paste(ca,((k%3)*560,(k//3)*450))
  sheet.save(review/f"phases_{c['id']}.jpg",quality=94)
 overview=Image.new('RGB',(1120,80+450*math.ceil(len(clips)/2)),(25,31,32));d=ImageDraw.Draw(overview);d.text((22,15),'LANTERN / QUIET WEATHER STUDIES',font=font(25,True),fill=(237,232,214));d.text((22,48),f'{len(clips)} studies | source 30 fps | actual reference density | earlier floor art is a review dependency',font=font(14),fill=(178,192,180))
 for j,c in enumerate(clips):overview.paste(card(allfr[c['id']][c['previewFrame']],j%2==1,label=c['label'],detail=f"{c['durationSeconds']:g}-second loop | "+c['space'].replace('_',' ')),((j%2)*560,80+(j//2)*450))
 overview.save(review/'Weather_Atmosphere_Overview.jpg',quality=95);return allfr

def movie(out,clips,allfr):
 # Three complete cycles per clip, except the paired 3 s leaf loop repeats four
 # times beside 4 s mist. Each source drawing is held exactly two 60 Hz ticks.
 pages=[clips[j:j+2] for j in range(0,len(clips),2)];ticks=[int(math.lcm(*[c['frameCount'] for c in page])*2*(3 if len(page)==1 or page[0]['frameCount']==page[-1]['frameCount'] else 1)) for page in pages]
 proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1120x1020','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(out/'review'/'Weather_Atmosphere_60Hz.mp4')],stdin=subprocess.PIPE)
 for page,nt in zip(pages,ticks):
  cache={(c['id'],col):[card(fr,col==1,label=c['label'],detail=f"frame {i:03d}/{c['frameCount']} | {c['space'].replace('_',' ')}") for i,fr in enumerate(allfr[c['id']])] for c in page for col in range(2)}
  for tick in range(nt):
   im=Image.new('RGB',(1120,1020),(24,31,31));d=ImageDraw.Draw(im);d.text((22,15),'LANTERN / WEATHER AND ATMOSPHERE',font=font(24,True),fill=(236,232,214));d.text((22,49),'30 fps source / exact 2:1 holds at 60 Hz / bounded patches, no spatial tiling claim',font=font(13),fill=(178,192,181))
   for row,c in enumerate(page):
    fi=(tick//2)%c['frameCount']
    for col in range(2):im.paste(cache[c['id'],col][fi],(col*560,82+row*450))
   d=ImageDraw.Draw(im);d.text((22,995),'Ground textures: existing 4 m raw tiles projected once for review. Ash is a screen overlay; other studies use world geometry.',font=font(11),fill=(164,179,169));proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('ffmpeg failed')
 return sum(ticks)/60

README='''LANTERN / QUIET WEATHER AND ATMOSPHERE / v1.0
Four original motion studies using deterministic authored geometry, no AI frame series.
Rain: 90 frames, 30 fps, 3 s; eight drop schedules, three small ground splashes per cycle.
Ash: 90 frames, 30 fps, 3 s; six sideways drifting SCREEN-OVERLAY flakes maximum.
Ground mist: 120 frames, 30 fps, 4 s; three broad low world-space ribbons maximum.
Its coverage is limited to stylized ribbon shapes; volumetric fog is not represented.
Autumn leaves: 90 frames, 30 fps, 3 s; three lobed leaves in a ground-skimming gust.
390 transparent PNG frames and 390 editable SVG frames. Atlas pages are capped at
2048 pixels per axis and mapped individually in manifest.json. No still-state variants.

RELATED EARLIER DESIGNS
Earlier packs already contain a tumbling leaf, localized falling dust, drip/ripple,
smoke curl, chimney puff and poison mist. These are related themes, not four entirely
new subjects. This pack adds sparse patch weather with longer seamless cycles and
distinct placement/movement. Existing dark earth and pale marble PNGs are named
review-only dependencies, copied unchanged; do not count them as new weather art.

SPACE / CAMERA / PATCH BOUNDARIES
Right-handed XZ ground, +Y up; locked orthographic elevation 35.264389682754654 degrees,
azimuth 45 degrees from +Z toward +X. Canvas 512 x 448, ground/reference pivot (256,286),
112 source pixels/metre for world geometry. Rain and splashes, mist and leaves are
actual projected geometry. Ash is deliberately screen-space: its anchor is a pixel
placement datum, without world depth, physical footprint or ground-contact claim.
Screen ink accents on the world art are decorative widths, not collision boundaries.
Every patch is BOUNDED AND NOT SPATIALLY TILEABLE. Edge pixels are transparent;
opposite edges are not designed to match. All emitter resets happen while invisible.
Temporal wrap is checked, including exact analytic phase 0 == phase 1. No camera
scrolling, repeated-tile boundary test, depth occlusion or engine scene was implemented.

TIMING / RANDOMNESS
All samples use phase=i/N and omit a duplicate endpoint. Each drawing lasts 1/30 s.
Random seed 260610 is used only once when building event parameters. There is no
per-frame random noise. Those parameters, trajectories and phase offsets are editable.
The full 21-second review repeats complete cycles: rain/ash three times in 9 seconds;
mist three times and leaves four times in 12 seconds. Each 30 fps drawing is held
twice at 60 Hz. This does not claim 60 unique source frames per second.

REVIEW FIXTURE
The original Lantern dark-earth and pale-crypt-marble tiles are opaque raw top-down
1024 x 1024 PNGs, each covering 4 x 4 metres. The review projects them once with the
same exact camera; they are included only to reproduce the proof fixture. Thumbnails
are local unzoomed crops at 1440 px / 13 m reference density and 1080 px / 16 m stress
density. These are art comparisons, not game screenshots. The same scale is applied
to the ash screen patch for comparison, not as a claim of physical ash dimensions.

ALPHA / LIMITATIONS
Straight/unassociated alpha; zero RGB under alpha=0. RGB sRGB, linear alpha. Normal
source-over SRC_ALPHA / ONE_MINUS_SRC_ALPHA. No additive pass, bloom or texture grain.
If a later pipeline premultiplies once, use ONE / ONE_MINUS_SRC_ALPHA consistently.
Four transparent gutter pixels. No mipmaps in the RGBA8 base-level allocation estimate;
mipmapped use needs alpha-aware extrusion and per-level padding. File size and sparse
appearance are not runtime-cost claims. Weather, collision, sorting and scene import
remain untested. No game engineering, new mechanics, hero edits or source replacement.

REBUILD
Python 3, Pillow, numpy and ffmpeg with libx264. Run python source/build_weather.py;
--early builds rain/ash only. Run python source/package_weather.py for complementary
ZIPs. Keep review_dependencies/ for exact proof reconstruction. Source frames, SVGs,
atlas rectangles, pivots, rational durations, alpha notes, QA and hashes are included.
'''

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--early',action='store_true');ap.add_argument('--skip-preview',action='store_true');args=ap.parse_args();out=ROOT/('early_review' if args.early else 'weather_atmosphere_v1');out.mkdir(exist_ok=True);clips=[]
 names=['sparse_rain','wind_ash'] if args.early else list(SPECS)
 for n in names:print('Rendering',n,flush=True);clips.append(export_clip(n,out))
 camera={'projection':'orthographic','elevationDegrees':ELEVATION,'azimuthDegrees':AZIMUTH,'worldAxes':'right-handed XZ ground +Y up','sourcePixelsPerWorldMetre':DENSITY,'canvasPx':[W,H],'rootPivotPx':list(PIVOT),'screenRight':[math.sqrt(.5),0,-math.sqrt(.5)],'screenUp':[-1/math.sqrt(6),math.sqrt(2/3),-1/math.sqrt(6)],'imageOrigin':'top_left'}
 deps=[];(out/'review_dependencies').mkdir(exist_ok=True)
 for name in ['06_dark_earth.png','09_pale_crypt_marble.png']:
  p=SOURCE.parent/'review_dependencies'/name;target=out/'review_dependencies'/name
  if p.resolve()!=target.resolve():shutil.copyfile(p,target)
  deps.append({'file':'review_dependencies/'+name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sourcePack':'lantern_ground_surfaces_01','nativePx':[1024,1024],'rawWorldFootprintMetres':[4,4],'newWeatherAsset':False,'use':'existing floor tile, proof reproduction only'})
 manifest={'schema':'lantern.weather-atmosphere.v1','status':'original motion studies; related existing themes; no engine validation','familyCount':len(clips),'clipCount':len(clips),'frameCount':sum(c['frameCount'] for c in clips),'sourceFPS':30,'deterministicSeed':SEED,'eventSchedules':{'rain':RAIN_EVENTS,'ash':ASH_EVENTS,'rainMaximumScheduledConcurrency':{'streaks':2,'impacts':1,'totalEvents':3},'note':'Mist and leaves use explicit authored phases; no per-frame randomness.'},'camera':camera,'reviewDependencies':deps,'screenOverlayClips':['wind_ash'],'spatiallyTileable':False,'fullScreenWeatherCoverageTested':False,'clips':clips};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');report=qa(out,clips);print(json.dumps(report,indent=2),flush=True);frames=proofs(out,clips)
 if not args.skip_preview:movie(out,clips,frames)
 budget={'format':'RGBA8','mipmaps':False,'atlasPageCount':sum(c['atlasPageCount'] for c in clips),'atlasBytes':sum(math.prod(a['sizePx'])*4 for c in clips for a in c['atlases']),'note':'Raw base-level atlas allocation only; not file size or runtime measurement','clips':[{'id':c['id'],'pages':c['atlases'],'bytes':sum(math.prod(a['sizePx'])*4 for a in c['atlases'])} for c in clips]};(out/'texture_budget.json').write_text(json.dumps(budget,indent=2)+'\n');(out/'README.txt').write_text(README);(out/'source').mkdir(exist_ok=True)
 for name in ['build_weather.py','vfx_core.py','package_weather.py']:
  if (SOURCE/name).resolve()!=(out/'source'/name).resolve():shutil.copyfile(SOURCE/name,out/'source'/name)
 (out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(out).as_posix()+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts))
 if not report['passed']:raise SystemExit('QA failed')
 print('WEATHER COMPLETE',out)
if __name__=='__main__':main()
