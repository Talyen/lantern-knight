#!/usr/bin/env python3
"""Original medium-weight world-space interaction cue studies; no game integration."""
from pathlib import Path
import argparse,hashlib,json,math,shutil,subprocess,zipfile
import numpy as np
from PIL import Image,ImageDraw
from vfx_core import Canvas,proj,font,clamp,smooth,C,W,H,PIVOT,DENSITY,ELEVATION,AZIMUTH
SOURCE=Path(__file__).resolve().parent;ROOT=SOURCE.parent
if ROOT.name in ('early_review','interaction_pack_v1'):ROOT=ROOT.parent
TAU=math.tau
C.update({'ink':'#242b2e','danger':'#b66f62','dangerlight':'#e0c1a1','pale':'#f0ecd7','teal':'#9abbb2','stone':'#7a8e86','recovery':'#a3a59b'})
SPECS={
'enemy_cone':dict(family='enemy_cone',label='Enemy cone / anticipation to clear',frames=30,loop=False,space='projected_world',axis='world +Z',description='Medium-weight fan boundary and calm tinted footprint; then one clean strike sweep and a draining rim.',visualStages=[{'stage':'anticipation','frameRangeInclusive':[0,15]},{'stage':'impact','frameRangeInclusive':[16,20]},{'stage':'recovery','frameRangeInclusive':[21,29]}]),
'enemy_line':dict(family='enemy_line',label='Enemy line / anticipation to clear',frames=30,loop=False,space='projected_world',axis='world +X',description='A blunt-ended lane with two medium-weight rails; a short travelling strike slab clears into two broken ends.',visualStages=[{'stage':'anticipation','frameRangeInclusive':[0,15]},{'stage':'impact','frameRangeInclusive':[16,20]},{'stage':'recovery','frameRangeInclusive':[21,29]}]),
'loot_appearance':dict(family='loot',label='Loot appearance',frames=30,loop=False,space='projected_world',axis='vertical +Y over XZ',description='A compact ground halo unfolds into three tall clean light vanes. It marks a candidate loot arrival, not an item icon.',visualStages=[{'stage':'gather','frameRangeInclusive':[0,7]},{'stage':'appear','frameRangeInclusive':[8,19]},{'stage':'settle','frameRangeInclusive':[20,29]}]),
'loot_pickup':dict(family='loot',label='Loot pickup',frames=30,loop=False,space='projected_world',axis='vertical +Y over XZ',description='Three separated vanes pull inward and upward from a compact ground ring, then clear completely.',visualStages=[{'stage':'gather','frameRangeInclusive':[0,9]},{'stage':'lift','frameRangeInclusive':[10,21]},{'stage':'clear','frameRangeInclusive':[22,29]}]),
}


SPECS.update({
'enemy_arc':dict(family='enemy_arc',label='Enemy arc / anticipation to clear',frames=30,loop=False,space='projected_world',axis='world angular sweep -64 to +70 degrees',description='A bounded crescent lane forecasts a lateral sweep; the impact is a filled moving blade, then opposite short edges drain.',visualStages=[{'stage':'anticipation','frameRangeInclusive':[0,15]},{'stage':'impact','frameRangeInclusive':[16,20]},{'stage':'recovery','frameRangeInclusive':[21,29]}]),
'enemy_ring':dict(family='enemy_ring',label='Enemy ring / anticipation to clear',frames=30,loop=False,space='projected_world',axis='radial on XZ',description='A nominal annular footprint with heavy inside/outside rims; one thick annular impact crosses it, then four open remnants fade.',visualStages=[{'stage':'anticipation','frameRangeInclusive':[0,15]},{'stage':'impact','frameRangeInclusive':[16,20]},{'stage':'recovery','frameRangeInclusive':[21,29]}]),
'shrine_activation':dict(family='shrine',label='Shrine activation',frames=30,loop=False,space='projected_world',axis='vertical XY face at Z=0',description='Two broad stepped light wipes climb a shrine face and meet at a raised cap; a single inner band ascends. No ground halo.',visualStages=[{'stage':'wake','frameRangeInclusive':[0,8]},{'stage':'climb and cap','frameRangeInclusive':[9,20]},{'stage':'settle','frameRangeInclusive':[21,29]}]),
'door_seal_dissolve':dict(family='door_seal',label='Door seal dissolve',frames=30,loop=False,space='projected_world',axis='vertical XY face at Z=0',description='An initially visible arched seal opens down its centre; broad outer flaps peel apart and leave a clear passage. No noisy particles.',firstFrameTransparent=False,visualStages=[{'stage':'sealed','frameRangeInclusive':[0,3]},{'stage':'open and peel','frameRangeInclusive':[4,21]},{'stage':'clear','frameRangeInclusive':[22,29]}]),
'checkpoint_return':dict(family='checkpoint',label='Checkpoint return',frames=30,loop=False,space='projected_world',axis='vertical +Y above XZ',description='Four folded ground strokes converge as two broad descending veils close into a narrow arrival seam. No decorative ring.',visualStages=[{'stage':'arrive','frameRangeInclusive':[0,8]},{'stage':'descend and close','frameRangeInclusive':[9,21]},{'stage':'clear','frameRangeInclusive':[22,29]}]),
})
SPECS['enemy_cone']['visualFootprint']={'shape':'annular_sector','innerRadiusMetres':.27,'outerRadiusMetres':1.53,'angleRangeDegrees':[-36,36],'headingConvention':'0 is +Z, positive toward +X'}
SPECS['enemy_line']['visualFootprint']={'shape':'rectangle','xRangeMetres':[.26,2.30],'zRangeMetres':[-.30,.30]}
SPECS['enemy_arc']['visualFootprint']={'shape':'annular_sector','innerRadiusMetres':.91,'outerRadiusMetres':1.60,'angleRangeDegrees':[-64,70],'headingConvention':'0 is +Z, positive toward +X'}
SPECS['enemy_ring']['visualFootprint']={'shape':'annulus','innerRadiusMetres':.80,'outerRadiusMetres':1.32}
for _n in ['enemy_cone','enemy_line','enemy_arc','enemy_ring']:
 SPECS[_n]['visualFootprint']['meaning']='Nominal intended visual warning area; boundary stroke centered on it. No implemented or tested collision.'

def bez(p0,p1,p2,p3,n=20):
 out=[]
 for j in range(n+1):
  t=j/n;s=1-t;out.append(tuple(s*s*s*p0[k]+3*s*s*t*p1[k]+3*s*t*t*p2[k]+t*t*t*p3[k] for k in range(len(p0))))
 return out

def world_line(c,points,width,col,alpha=1,taper=False):
 # Width is in real XZ metres, so both path AND brush footprint obey the camera.
 if len(points)<2 or alpha<=0:return
 left=[];right=[]
 for i,(x,y,z) in enumerate(points):
  p=points[max(0,i-1)];q=points[min(len(points)-1,i+1)];dx=q[0]-p[0];dz=q[2]-p[2];ln=max(math.hypot(dx,dz),.000001);scale=math.sin(math.pi*i/(len(points)-1))**.5 if taper else 1;w=(width(i/(len(points)-1)) if callable(width) else width)*scale
  left.append((x-dz/ln*w/2,y,z+dx/ln*w/2));right.append((x+dz/ln*w/2,y,z-dx/ln*w/2))
 c.worldpoly(left+right[::-1],col,alpha)

def polar(r,a,y=.012):a=math.radians(a);return (math.sin(a)*r,y,math.cos(a)*r)
def arc(c,r,w,start,end,col,a=1):
 if a<=0 or end<=start:return
 outer=[];inner=[]
 for j in range(65):
  aa=start+(end-start)*j/64;outer.append(polar(r+w/2,aa));inner.append(polar(max(0,r-w/2),aa))
 c.worldpoly(outer+inner[::-1],col,a)

def ring_edge(c,r,start,end,a=1,col='dangerlight',width=.155):
 arc(c,r,width,start,end,'ink',a);arc(c,r,width*.55,start,end,col,a)

def outlined_line(c,pts,a=1,col='dangerlight',width=.155):
 world_line(c,pts,width,'ink',a);world_line(c,[(x,y+.002,z) for x,y,z in pts],width*.54,col,a)

def fill_sector(c,r,inner,start,end,col,a):
 pts=[polar(r,start+(end-start)*j/64) for j in range(65)]
 pts+=[polar(inner,end-(end-start)*j/64) for j in range(65)]
 c.worldpoly(pts,col,a)

def alpha(t,on=.08,off=.72):return smooth(t/on)*(1-smooth((t-off)/(1-off)))
def cue_envelopes(t):
 if not 0<t<1:return (0,0,0)
 anticipation=smooth(t/.10)*(1-smooth((t-.515)/.045))
 impact=smooth((t-.51)/.055)*(1-smooth((t-.63)/.09))
 recovery=smooth((t-.67)/.06)*(1-smooth((t-.78)/.22))
 return anticipation,impact,recovery

def cone(c,t):
 if not 0<t<1:return
 ant,hit,rec=cue_envelopes(t);r=1.53;inner=.27;start=-36;end=36
 if ant>0:
  fill_sector(c,r,inner,start,end,'danger',.14*ant)
  # Rails and outer strike limit remain broad; the short moving inset stroke carries charge.
  ring_edge(c,r,start,end,ant)
  for deg in [start,end]:outlined_line(c,[polar(inner,deg),polar(r,deg)],ant)
  ring_edge(c,inner,start,end,ant*.85,width=.13)
  q=smooth(t/.51);rr=inner+(r-inner)*q
  arc(c,rr,.07,start+5,end-5,'dangerlight',ant*.52)
 if hit>0:
  q=smooth((t-.515)/.155);rr=.35+1.18*q
  fill_sector(c,r,inner,start,end,'dangerlight',hit*.20)
  ring_edge(c,rr,start-2,end+2,hit,'pale',.28)
  for deg in [start,end]:outlined_line(c,[polar(inner,deg),polar(r,deg)],hit*.68,'dangerlight',.14)
 if rec>0:
  for aa,bb in [(start,-10),(10,end)]:ring_edge(c,r+.045,aa,bb,rec*.78,'recovery',.115)

def line(c,t):
 if not 0<t<1:return
 ant,hit,rec=cue_envelopes(t);x0=.26;x1=2.30;z=.30
 if ant>0:
  c.worldpoly([(x0,.01,-z),(x1,.01,-z),(x1,.01,z),(x0,.01,z)],'danger',ant*.14)
  for zz in [-z,z]:outlined_line(c,[(x0,.012,zz),(x1,.012,zz)],ant,width=.15)
  outlined_line(c,[(x1,.012,-z),(x1,.012,z)],ant,width=.16)
  # Two steady rails carry a moving crossbar; no chevrons, text or UI iconography.
  xx=x0+(x1-x0)*smooth(t/.52);outlined_line(c,[(xx,.016,-z*.76),(xx,.016,z*.76)],ant*.64,width=.08)
 if hit>0:
  q=smooth((t-.51)/.18);xx=x0+(x1-x0)*q;half=.17
  c.worldpoly([(xx-half,.02,-z*.80),(xx+half,.02,-z*.80),(xx+half,.02,z*.80),(xx-half,.02,z*.80)],'ink',hit)
  c.worldpoly([(xx-half*.54,.023,-z*.68),(xx+half*.54,.023,-z*.68),(xx+half*.54,.023,z*.68),(xx-half*.54,.023,z*.68)],'pale',hit)
  for zz in [-z,z]:outlined_line(c,[(max(x0,xx-.50),.013,zz),(xx,.013,zz)],hit*.9,'dangerlight',.17)
 if rec>0:
  for zz in [-z,z]:outlined_line(c,[(x1-.32,.013,zz),(x1+.06,.013,zz)],rec,'recovery',.13)


def vane(c,x,z,height,width,lean,col,a):
 # A pointed quadrilateral on a real vertical world plane with a bent shoulder.
 p=[(x-width/2,0,z),(x+width/2,0,z),(x+lean*.35,height*.64,z),(x+lean,height,z),(x+lean*.10-width*.15,height*.55,z)]
 c.worldpoly(p,'ink',a)
 center=(x,height*.34,z-.003)
 inner=[tuple(center[k]+(v[k]-center[k])*.73 for k in range(3)) for v in p]
 c.worldpoly(inner,col,a)

def loot_appear(c,t):
 if not 0<t<1:return
 a=alpha(t,.085,.72);grow=smooth(t/.36);r=.15+.30*grow+.18*t
 ring_edge(c,r,10,156,a,'pale',.16);ring_edge(c,r,196,344,a,'teal',.16)
 for i,(x,z,h,lean) in enumerate([(-.24,-.10,.58,-.12),(.20,-.12,.75,.09),(-.01,.18,.98,-.03)]):
  g=smooth((t-i*.035)/.36)*(1-smooth((t-.63)/.37));vane(c,x*g,z*g,h*g,.135,.7*lean,'pale' if i==2 else 'teal',a)

def loot_pickup(c,t):
 if not 0<t<1:return
 a=alpha(t,.07,.71);q=smooth(t/.81);r=.57*(1-q)+.08
 for st,en in [(15,127),(187,317)]:ring_edge(c,r,st,en,a*.9,'teal',.145)
 # Three world-space swept ribbons converge to a raised point, preserving a visible socket.
 for i,deg in enumerate([15,137,252]):
  an=math.radians(deg);rr=.53*(1-q);y=.85*q;dx=math.sin(an);dz=math.cos(an);w=.10*(1-.4*q)
  p=[(dx*(rr+w),y,dz*(rr+w)),(dx*rr,y+.36*(1-q)+.12,dz*rr),(dx*(rr-w),y,dz*(rr-w)),(dx*rr,y-.13*(1-q),dz*rr)]
  c.worldpoly(p,'ink',a)
  mid=(dx*rr,y+.06,dz*rr);c.worldpoly([tuple(mid[k]+(v[k]-mid[k])*.68 for k in range(3)) for v in p],'pale' if i==1 else 'teal',a)

def enemy_arc(c,t):
 if not 0<t<1:return
 ant,hit,rec=cue_envelopes(t);inner=.91;outer=1.60;start=-64;end=70
 if ant>0:
  fill_sector(c,outer,inner,start,end,'danger',ant*.14)
  ring_edge(c,outer,start,end,ant);ring_edge(c,inner,start,end,ant,width=.15)
  for deg in [start,end]:outlined_line(c,[polar(inner,deg),polar(outer,deg)],ant,width=.145)
  q=smooth(t/.52);deg=start+(end-start)*q
  outlined_line(c,[polar(inner+.08,deg),polar(outer-.08,deg)],ant*.72,width=.10)
 if hit>0:
  q=smooth((t-.51)/.18);deg=start+(end-start)*q
  aa=max(start,deg-40);bb=min(end,deg+5)
  fill_sector(c,outer+.015,inner-.015,aa,bb,'ink',hit)
  fill_sector(c,outer-.06,inner+.06,aa+3,bb,'dangerlight',hit)
  outlined_line(c,[polar(inner+.03,deg),polar(outer-.03,deg)],hit,'pale',.17)
 if rec>0:
  ring_edge(c,outer,start,start+34,rec*.85,'recovery',.125)
  ring_edge(c,inner,end-35,end,rec*.85,'recovery',.12)

def enemy_ring(c,t):
 if not 0<t<1:return
 ant,hit,rec=cue_envelopes(t);inner=.80;outer=1.32
 if ant>0:
  fill_sector(c,outer,inner,0,360,'danger',ant*.14)
  ring_edge(c,outer,0,360,ant);ring_edge(c,inner,0,360,ant,width=.15)
  q=smooth(t/.52);arc(c,inner+(outer-inner)*q,.085,0,360,'dangerlight',ant*.58)
 if hit>0:
  q=smooth((t-.51)/.18);r=inner+(outer-inner)*q
  fill_sector(c,outer,inner,0,360,'dangerlight',hit*.35)
  ring_edge(c,r,0,360,hit,'pale',.255)
 if rec>0:
  for k in range(4):ring_edge(c,outer,k*90+8,k*90+60,rec,'recovery',.12)

def vertical_brush(c,pts,width,col,a=1):
 # Real brush polygon in the vertical X/Y plane at a fixed authored Z.
 left=[];right=[]
 for i,(x,y,z) in enumerate(pts):
  p=pts[max(0,i-1)];q=pts[min(len(pts)-1,i+1)];dx=q[0]-p[0];dy=q[1]-p[1];ln=max(math.hypot(dx,dy),.000001);w=width(i/(len(pts)-1)) if callable(width) else width
  left.append((x-dy/ln*w/2,y+dx/ln*w/2,z));right.append((x+dy/ln*w/2,y-dx/ln*w/2,z))
 c.worldpoly(left+right[::-1],col,a)

def shrine(c,t):
 if not 0<t<1:return
 a=alpha(t,.09,.71);g=smooth(t/.53);h=.13+1.33*g
 # Two broad stepped light wipes climb a shrine face; no ground halo or rune icon.
 for side in [-1,1]:
  x=side*.47
  pts=[(x-side*.095,.08,0),(x+side*.095,.08,0),(x+side*.075,h*.65,0),(x+side*.17,h*.73,0),(x+side*.085,h,0),(x-side*.065,h*.87,0)]
  c.worldpoly(pts,'ink',a)
  mid=(x,h*.43,-.008);c.worldpoly([tuple(mid[k]+(v[k]-mid[k])*.77 for k in range(3)) for v in pts],'teal',a)
  vertical_brush(c,[(x,.10,-.016),(x,h*.58,-.016),(x+side*.045,h*.85,-.016)],.043,'pale',a)
 if t>.21:
  q=smooth((t-.21)/.36);aa=a*q
  # The cap draws from both sides toward a short raised center, as a shrine waking.
  for side in [-1,1]:
   pts=[(side*.47,1.34,0),(side*.21*(1-q),1.49,0),(0,1.56,0)]
   vertical_brush(c,pts,.14,'ink',aa);vertical_brush(c,[(x,y,z-.005) for x,y,z in pts],.070,'pale',aa)
 # A single broad rising central inset replaces ornamental circles.
 q=smooth((t-.07)/.62);yy=.13+.90*q
 c.worldpoly([(-.115,yy,0),(.115,yy,0),(.075,yy+.16,0),(-.075,yy+.16,0)],'pale',a*.67)

def door_seal(c,t):
 if t>=1:return
 # Starts as an existing visible seal, opens from the centre, then leaves no pixels.
 a=1-smooth((t-.62)/.38);gap=.007+.593*smooth(t/.89);top=lambda x:1.69-.30*(x/.61)**2
 for side in [-1,1]:
  xs=[side*(gap+(.61-gap)*j/24) for j in range(25)]
  pts=[(xs[0],.04,0),(xs[-1],.04,0)]+[(x,top(x),0) for x in xs[::-1]]
  c.worldpoly(pts,'teal',a*.24)
  # Outer silhouette and peeled inner edge are geometry, with an open central gap.
  outer=[(side*.61,.04,-.002),(side*.61,top(.61),-.002)]+[(x,top(x),-.002) for x in xs[::-1]]
  vertical_brush(c,outer,.10,'ink',a*.82)
  vertical_brush(c,[(x,y,z-.003) for x,y,z in outer],.046,'teal',a)
  inner=[(side*gap,.06,-.01),(side*(gap+.012),top(gap)*.66,-.01),(side*gap,top(gap),-.01)]
  vertical_brush(c,inner,.14,'ink',a);vertical_brush(c,[(x,y,z-.005) for x,y,z in inner],.075,'pale',a)
  # One wide peeled flap separates outward, instead of noisy pixel disintegration.
  q=smooth((t-.19)/.56);xx=side*(.31+.50*q);yy=.82+.12*math.sin(math.pi*q);aa=a*math.sin(math.pi*q)
  pp=[(xx-side*.075,yy-.35,0),(xx+side*.10,yy-.18,0),(xx+side*.14,yy+.23,0),(xx-side*.018,yy+.34,0)]
  c.worldpoly(pp,'ink',aa);mid=(xx,yy,-.003);c.worldpoly([tuple(mid[k]+(v[k]-mid[k])*.70 for k in range(3)) for v in pp],'teal',aa)

def checkpoint(c,t):
 if not 0<t<1:return
 a=alpha(t,.08,.73);q=smooth(t/.74);lift=.74*(1-q)
 # Four folded ground strokes draw in toward the arrival point. No continuous ring.
 r=.83*(1-q)+.17
 for deg in [18,108,198,288]:
  p0=polar(r+.10,deg-13);p1=polar(r,deg);p2=polar(r+.10,deg+13)
  outlined_line(c,[p0,p1,p2],a,'teal',.18)
 # Two large descending veils close into a narrow vertical seam over that point.
 for side in [-1,1]:
  xx=side*(.29*(1-q)+.06)
  pts=[(xx-side*.12,.02+lift*.55,0),(xx+side*.08,.14+lift*.60,0),(xx+side*.27,.89+lift*.62,0),(xx+side*.055,1.20+lift*.32,0),(xx-side*.04,.71+lift*.40,0)]
  c.worldpoly(pts,'ink',a)
  mid=(xx,.55+lift*.4,-.004);c.worldpoly([tuple(mid[k]+(v[k]-mid[k])*.79 for k in range(3)) for v in pts],'teal' if side<0 else 'pale',a)

FUNCS={'enemy_cone':cone,'enemy_line':line,'loot_appearance':loot_appear,'loot_pickup':loot_pickup,'enemy_arc':enemy_arc,'enemy_ring':enemy_ring,'shrine_activation':shrine,'door_seal_dissolve':door_seal,'checkpoint_return':checkpoint}

def render(name,i):
 s=SPECS[name];c=Canvas();t=i/s['frames'] if s['loop'] else i/(s['frames']-1);FUNCS[name](c,t);return c

def export_clip(name,out):
 spec=SPECS[name];n=spec['frames'];fd=out/'frames'/name;vd=out/'vectors'/name;fd.mkdir(parents=True,exist_ok=True);vd.mkdir(parents=True,exist_ok=True);ims=[];bs=[];frames=[]
 for i in range(n):
  c=render(name,i);im=c.export(fd/f'{i:03d}.png');ims.append(im);bs.append(im.getbbox());(vd/f'{i:03d}.svg').write_text(c.svg_text())
 boxes=[b for b in bs if b];u=[min(b[0] for b in boxes)-2,min(b[1] for b in boxes)-2,max(b[2] for b in boxes)+2,max(b[3] for b in boxes)+2];cw,ch=u[2]-u[0],u[3]-u[1];pad=4;cols=min(6,2048//(cw+pad*2));rows=math.ceil(n/cols);atlas=Image.new('RGBA',(cols*(cw+pad*2),rows*(ch+pad*2)))
 for i,im in enumerate(ims):
  x=pad+(i%cols)*(cw+pad*2);y=pad+(i//cols)*(ch+pad*2);atlas.paste(im.crop(u),(x,y));frames.append({'id':i,'file':f'frames/{name}/{i:03d}.png','svg':f'vectors/{name}/{i:03d}.svg','rectPx':[x,y,cw,ch],'sourceSizePx':[W,H],'trimOffsetPx':u[:2],'atlasSourceCropPx':u,'pivotPx':list(PIVOT),'atlasPivotPx':[PIVOT[0]-u[0],PIVOT[1]-u[1]],'durationRational':[1,30],'durationSeconds':1/30,'alphaBoundsPx':list(bs[i]) if bs[i] else None})
 (out/'atlases').mkdir(exist_ok=True);atlas.save(out/'atlases'/f'{name}.png',optimize=True)
 return {'id':name,**spec,'frameCount':n,'sourceFPS':30,'durationRational':[n,30],'durationSeconds':n/30,'sourcePixelsPerWorldMetre':DENSITY,'frames':frames,'atlas':f'atlases/{name}.png','atlasSizePx':list(atlas.size),'atlasPaddingPx':pad,'pivotMeaning':'XZ ground emitter at world y=0','blend':{'pngAlpha':'straight/unassociated','premultipliedAlpha':False,'recommended':'normal source-over','sourceFactor':'SRC_ALPHA','destinationFactor':'ONE_MINUS_SRC_ALPHA','textureColorSpace':'sRGB','alphaIsLinear':True,'additiveRequired':False},'gameplayAuthority':'none; phase boundaries are illustrative visual timing, not attack/collision timing'}

def qa(out,clips):
 report={'passed':True,'issues':[],'familyCount':len(set(c['family'] for c in clips)),'clipCount':len(clips),'frameCount':sum(c['frameCount'] for c in clips),'minimumCanvasMarginPx':999,'exactAtlasCrops':True,'uniqueNonEndpointFrames':True,'normalAlphaOnly':True}
 for c in clips:
  hashes=set();atlas=Image.open(out/c['atlas']).convert('RGBA')
  for f in c['frames']:
   im=Image.open(out/f['file']).convert('RGBA');ar=np.asarray(im);hashes.add(hashlib.sha256(im.tobytes()).hexdigest());bb=im.getbbox()
   if bb:report['minimumCanvasMarginPx']=min(report['minimumCanvasMarginPx'],bb[0],bb[1],W-bb[2],H-bb[3])
   if np.any(ar[ar[:,:,3]==0,:3]):report['issues'].append('Hidden RGB '+f['file'])
   x,y,w,h=f['rectPx']
   if atlas.crop((x,y,x+w,y+h)).tobytes()!=im.crop(f['atlasSourceCropPx']).tobytes():report['exactAtlasCrops']=False;report['issues'].append('Atlas mismatch '+f['file'])
   if (f['id']==c['frameCount']-1 or (f['id']==0 and c.get('firstFrameTransparent',True))) and ar[:,:,3].max():report['issues'].append('Opaque endpoint '+f['file'])
  if len(hashes)!=c['frameCount']-(1 if c.get('firstFrameTransparent',True) else 0):report['uniqueNonEndpointFrames']=False;report['issues'].append('Repeated interior drawing '+c['id'])
  if max(c['atlasSizePx'])>2048:report['issues'].append('Oversize atlas '+c['id'])
 if report['minimumCanvasMarginPx']<6:report['issues'].append('Canvas edge risk')
 report['passed']=not report['issues'];(out/'qa_report.json').write_text(json.dumps(report,indent=2)+'\n');return report

def floor(light,size,scale,root):
 bg=(202,201,185) if light else (35,43,43);ln=(183,184,169) if light else (46,54,53);im=Image.new('RGB',size,bg);d=ImageDraw.Draw(im)
 # Quiet projected XZ guide grid, with no borrowed floor texture.
 for i in range(-4,8):
  a=(i*.9,0,-3.5);b=(i*.9,0,3.5);p=proj(a);q=proj(b);d.line([(root[0]+(p[0]-PIVOT[0])*scale,root[1]+(p[1]-PIVOT[1])*scale),(root[0]+(q[0]-PIVOT[0])*scale,root[1]+(q[1]-PIVOT[1])*scale)],fill=ln)
  a=(-3.5,0,i*.9);b=(3.5,0,i*.9);p=proj(a);q=proj(b);d.line([(root[0]+(p[0]-PIVOT[0])*scale,root[1]+(p[1]-PIVOT[1])*scale),(root[0]+(q[0]-PIVOT[0])*scale,root[1]+(q[1]-PIVOT[1])*scale)],fill=ln)
 return im

def card(frame,light,size=(560,338),scale=1440/13/DENSITY,label='',detail=''):
 root=(size[0]//2-30,176);im=floor(light,size,scale,root);d=ImageDraw.Draw(im);tx=(46,55,48) if light else (231,229,211)
 if frame:
  fr=frame.resize((round(W*scale),round(H*scale)),Image.Resampling.LANCZOS);im.paste(fr,(round(root[0]-PIVOT[0]*scale),round(root[1]-PIVOT[1]*scale)),fr)
 d=ImageDraw.Draw(im);d.text((16,13),label,font=font(14,True),fill=tx);d.text((16,size[1]-26),detail,font=font(11),fill=tx)
 # 1.8 m vertical ruler is a calibration reference only, not a hero proxy or UI asset.
 ry=230;rx=size[0]-32;ht=1.8*math.sqrt(2/3)*DENSITY*scale;d.line((rx,ry,rx,round(ry-ht)),fill=tx,width=2);d.line((rx-4,ry,rx+4,ry),fill=tx,width=2);d.line((rx-4,round(ry-ht),rx+4,round(ry-ht)),fill=tx,width=2);d.text((rx-47,ry+8),'1.8 m',font=font(10),fill=tx)
 return im

def proofs(out,clips):
 review=out/'review';review.mkdir(exist_ok=True);allfr={c['id']:[Image.open(out/f['file']).convert('RGBA') for f in c['frames']] for c in clips}
 for j,c in enumerate(clips):
  page=Image.new('RGB',(1120,766),(25,31,32));d=ImageDraw.Draw(page);d.text((22,15),c['label'],font=font(23,True),fill=(237,232,216));d.text((22,49),'Actual pixel-scale crops, not full viewports. The ruler shows projected 1.8 m height.',font=font(14),fill=(177,190,178))
  idx=12 if c['family'].startswith('enemy') else 13
  for row,(scale,desc) in enumerate([(1440/13/DENSITY,'1440 px buffer / 13 m vertical view'),(1080/16/DENSITY,'1080 px buffer / 16 m stress view')]):
   for col in range(2):
    detail=desc+' | frame '+str(idx)+' | world geometry';ca=card(allfr[c['id']][idx],col==1,scale=scale,label=('LIGHT' if col else 'DARK')+' / normal alpha',detail=detail);page.paste(ca,(col*560,82+row*342))
  page.save(review/f"proof_{j+1:02d}_{c['id']}.jpg",quality=95)
 # Explicit phase proofs, enlarged by neither resampling nor zoom.
 for c in clips:
  indices=[5,12,17,20,25,29];sheet=Image.new('RGB',(1680,668),(25,31,32))
  for j,i in enumerate(indices):
   stage=next(v['stage'] for v in c['visualStages'] if v['frameRangeInclusive'][0]<=i<=v['frameRangeInclusive'][1]);ca=card(allfr[c['id']][i],j%2==1,label=f'{i:02d} / {stage}',detail=c['label']);sheet.paste(ca,((j%3)*560,(j//3)*334))
  sheet.save(review/f"phases_{c['id']}.jpg",quality=94)
 families=[];seen=set()
 for c in clips:
  if c['family'] not in seen:families.append(c);seen.add(c['family'])
 overview=Image.new('RGB',(1120,80+338*math.ceil(len(families)/2)),(25,31,32));dd=ImageDraw.Draw(overview);dd.text((22,15),'LANTERN / INTERACTION CUE FAMILIES',font=font(25,True),fill=(237,232,214));dd.text((22,48),f'{len(families)} families | actual 1440 px / 13 m density | presentation candidates, no tested collision',font=font(14),fill=(179,191,178))
 for j,c in enumerate(families):
  idx=12;ca=card(allfr[c['id']][idx],j%2==1,label=c['label'],detail=c['axis']);overview.paste(ca,((j%2)*560,80+(j//2)*338))
 overview.save(review/'Interaction_Cue_Families_Overview.jpg',quality=95)
 return allfr

def movie(out,clips,allfr):
 pages=math.ceil(len(clips)/2);ticks=240;proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1120x800','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(out/'review'/'Interaction_Cues_60Hz.mp4')],stdin=subprocess.PIPE)
 # Pre-render ordinary source cards at exact 1440/13 projection density.
 cache={}
 for c in clips:
  for col in range(2):
   arr=[]
   for i in range(c['frameCount']+1):
    stage='cleared' if i==c['frameCount'] else next(v['stage'] for v in c['visualStages'] if v['frameRangeInclusive'][0]<=i<=v['frameRangeInclusive'][1]);fr=None if i==c['frameCount'] else allfr[c['id']][i];arr.append(card(fr,col==1,label=c['label'],detail=f"{stage} / {'light' if col else 'dark'} / exact 1440 px, 13 m scale"))
   cache[(c['id'],col)]=arr
 for tick in range(pages*ticks):
  p=tick//ticks;tt=tick%ticks;fi=(tt%120)//2;im=Image.new('RGB',(1120,800),(24,31,31));d=ImageDraw.Draw(im);d.text((22,15),'LANTERN / INTERACTION CUE PROOF',font=font(24,True),fill=(236,232,214));d.text((22,49),'30 fps source / exact 2:1 holds at 60 Hz / candidate visual timings only',font=font(14),fill=(178,192,181))
  for row,c in enumerate(clips[p*2:p*2+2]):
   for col in range(2):im.paste(cache[(c['id'],col)][min(fi,c['frameCount'])],(col*560,82+row*344))
  d=ImageDraw.Draw(im);d.text((22,778),'Ground and brush widths both use the exact 35.264389682754654° / 45° projection. No UI or gameplay implementation.',font=font(11),fill=(162,179,166));proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('ffmpeg failed')

README='''LANTERN / MEDIUM-WEIGHT INTERACTION CUE STUDIES
Original world-space vector effects. These are presentation candidates, not UI icons,
player mechanics, hitboxes or approved gameplay timings. No engine/game code changed.

Full set: four enemy warning/strike families (cone, line, arc, ring), loot appearance
and pickup, shrine activation, door seal dissolve and checkpoint return. Eight distinct
families, nine clips, 270 source PNGs and matching SVGs.
All clips use 30 genuine source frames at 30 fps. All final frames are transparent.
Door seal dissolve deliberately starts with a VISIBLE seal; all others start clear. Enemy
clips contain explicit illustrative anticipation, impact and recovery frame ranges.
The 60 Hz MP4 holds each source drawing exactly twice, then leaves a clear interval.

CAMERA AND READABILITY
Right-handed XZ ground, +Y vertical. Orthographic elevation 35.264389682754654°;
azimuth 45° from +Z toward +X. Source 512 x 448 at 112 px/m, ground pivot (256,286).
Every effect and every ground brush width is world geometry projected by that camera.
Warning boundaries trace the intended nominal geometric footprint. The dark outline
is centered on that boundary and has visual thickness outside it; the stroke is not
a measured hitbox. Collision, actual attack reach and gameplay synchronization have
not been implemented or tested. Anticipation uses a quiet footprint plus travelling
charge edge; impact uses a thicker moving filled strike; recovery breaks and drains.
The medium-weight outline is typically 0.15–0.16 m across on the ground, with a light
inner band, avoiding the hairline cues that vanish in wide views. Source-over blending,
clean silhouettes, no grain, no bloom, few intentional planes and restrained colours.

Review panels are unzoomed CROPS from gameplay pixel density, not resized full screens:
1440-pixel buffer / 13 m view = 110.769 px/m, scale 0.98901099 of source;
1080-pixel buffer / 16 m stress view = 67.5 px/m, scale 0.60267857 of source.
The projected 1.8 m ruler is a calibration aid, not a hero proxy or exported UI element.
Orthographic distance does not shrink an asset; buffer size and view span do.

ALPHA AND TIMING
Straight/unassociated PNG alpha, sRGB RGB, linear alpha, transparent RGB zero.
Normal source-over SRC_ALPHA / ONE_MINUS_SRC_ALPHA. No additive blending or bloom
needed. If uploads explicitly premultiply once, match ONE / ONE_MINUS_SRC_ALPHA.
Four-pixel transparent atlas gutters; fixed union crop per clip. Full source canvases,
per-frame SVG, rational durations, trim offsets and pivots are in manifest.json.
Disable atlas mipmaps unless alpha-aware extrusion/per-level padding is added.

REBUILD
Python 3, Pillow, numpy and ffmpeg with libx264. Run python source/build_cues.py. Add --early for the original three-family gate.
All shapes are original code/SVG artwork, with no copied input images or generated
image variations. QA checks alpha, unique interior frames, endpoints, atlas mapping,
texture sizes and clipping margins. Visual phase timing never controls gameplay.
'''

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--skip-preview',action='store_true');ap.add_argument('--early',action='store_true');a=ap.parse_args();out=ROOT/('early_review' if a.early else 'interaction_pack_v1');out.mkdir(exist_ok=True);clips=[]
 names=['enemy_cone','enemy_line','loot_appearance','loot_pickup'] if a.early else ['enemy_cone','enemy_line','enemy_arc','enemy_ring','loot_appearance','loot_pickup','shrine_activation','door_seal_dissolve','checkpoint_return']
 for n in names:print('Rendering',n,flush=True);clips.append(export_clip(n,out))
 manifest={'schema':'lantern.interaction-cues.v1','status':'candidate art proof; no gameplay approval','familyCount':len(set(c['family'] for c in clips)),'clipCount':len(clips),'camera':{'projection':'orthographic','elevationDegrees':ELEVATION,'azimuthDegrees':AZIMUTH,'azimuthConvention':'from +Z toward +X','worldAxes':'right-handed XZ ground +Y vertical','sourcePixelsPerWorldMetre':DENSITY,'sourceCanvasPx':[W,H],'rootPivotPx':list(PIVOT),'imageOrigin':'top_left','screenRight':[math.sqrt(.5),0,-math.sqrt(.5)],'screenUp':[-1/math.sqrt(6),math.sqrt(2/3),-1/math.sqrt(6)],'matrixConvention':'basis row dot world; image y negates screen-up; multiply by density then add pivot'},'gameplayAuthority':'none','clips':clips}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');report=qa(out,clips);print(json.dumps(report,indent=2));frames=proofs(out,clips)
 if not a.skip_preview:movie(out,clips,frames)
 budget={'format':'RGBA8','mipmaps':False,'atlasBytes':sum(math.prod(c['atlasSizePx'])*4 for c in clips),'atlasCount':len(clips),'note':'Raw base-level allocation, not file size or measured runtime performance','clips':[{'id':c['id'],'atlasSizePx':c['atlasSizePx'],'bytes':math.prod(c['atlasSizePx'])*4} for c in clips]}
 (out/'texture_budget.json').write_text(json.dumps(budget,indent=2)+'\n')
 (out/'README.txt').write_text(README);(out/'source').mkdir(exist_ok=True)
 for n in ['build_cues.py','vfx_core.py','package_interaction.py']:
  if (SOURCE/n).resolve()!=(out/'source'/n).resolve():shutil.copyfile(SOURCE/n,out/'source'/n)
 (out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(out).as_posix()+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts))
 if not report['passed']:raise SystemExit('QA failed')
 print('CUE PACK COMPLETE',out)
if __name__=='__main__':main()
