Rust Crescent
One broad crescent ground target open toward viewer. Cels1-14 rusty dust gradually traces a crescent seam which slowly lifts and tensions. Cel15 seam snaps open. Cel16 ONE curved jagged rust-colored wall bursts upward exactly along crescent footprint. Cels17-23 wall peels outward into broad flakes and crumbles to dust.
Transparent experimental VFX. Enemy anticipation 980ms, one hit at 1015ms. Fixed canvas. Source cels preserved. Final cel clear. No engine or collision integration performed.
