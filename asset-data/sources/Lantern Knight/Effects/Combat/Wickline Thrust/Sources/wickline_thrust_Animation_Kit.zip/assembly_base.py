#!/usr/bin/env python3
"""Assemble image-generated 6x4 cel sheets, without creating or interpolating art.

Example:
  python assemble.py --config assembly_config.json --attacks ivory_blade
  python assemble.py --config assembly_config.json --comparison

All changes of crop boundaries retain the configured virtual source grid origin.
A single global source_scale and padding is used for every attack. Crops never
change a cel's scale, pivot, or registration. Source/prompts/provenance are kept.
"""
from __future__ import annotations
import argparse
import bisect
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

SIZE = 512
COLS, ROWS = 6, 4
FPS, TICK_MS, CYCLES = 200, 5, 3
DEFAULT_ROOT = Path(__file__).resolve().parent
SLUGS = ('ivory_blade', 'root_eruption', 'rust_chain', 'ash_palm', 'stone_crescent', 'cinder_cone')
BG = (66, 72, 68, 255)
INK = (236, 234, 215)
MUTED = (184, 193, 181)
ACCENT = (229, 190, 100)
FONT_PATH = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
PHASES = ['FORMATION / WINDUP'] * 14 + ['STRIKE', 'CONTACT'] + ['RECOVERY'] * 7 + ['CLEAR / HOLD']
ENEMY_INDICES = list(range(24))
ENEMY_DURATIONS = [60] * 14 + [40, 90] + [50] * 7 + [350]
HERO_INDICES = [0, 5, 9, 13, 14, 15] + list(range(16, 24))
HERO_DURATIONS = [30] * 4 + [40, 90] + [50] * 7 + [350]
ZIP_LIMIT = 20_000_000


def font(size):
    return ImageFont.truetype(FONT_PATH, size)


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def alpha_stats(im, threshold=16):
    a = np.asarray(im)[:, :, 3]
    yy, xx = np.where(a > threshold)
    bbox = None if not len(xx) else [int(xx.min()), int(yy.min()), int(xx.max() + 1), int(yy.max() + 1)]
    return {'alpha_bbox': bbox, 'visible_alpha_pixels': int((a > threshold).sum()),
            'nonzero_alpha_pixels': int((a > 0).sum())}


def boundaries(values, expected, limit, what):
    if len(values) != expected:
        raise ValueError(f'{what}: expected {expected} values, got {len(values)}')
    result = [int(x) for x in values]
    if any(float(x) != y for x, y in zip(values, result)):
        raise ValueError(f'{what}: crop boundaries must be integers')
    if result[0] < 0 or result[-1] > limit or any(b <= a for a, b in zip(result, result[1:])):
        raise ValueError(f'{what}: boundaries must be strictly increasing within [0,{limit}]')
    return result


def crop_boxes(c, w, h):
    if 'boxes' in c:
        if len(c['boxes']) != 24:
            raise ValueError('boxes must contain exactly 24 [left,top,right,bottom] rectangles')
        result = []
        for b in c['boxes']:
            if len(b) != 4 or any(int(v) != v for v in b):
                raise ValueError(f'Invalid crop rectangle {b}')
            b = list(map(int, b))
            if not (0 <= b[0] < b[2] <= w and 0 <= b[1] < b[3] <= h):
                raise ValueError(f'Crop rectangle outside source: {b}')
            result.append(b)
        return result
    # A separate set of column boundaries may be supplied for each source row.
    # These are extraction masks, never new local origins.
    ys = boundaries(c.get('ys', [round(i * h / ROWS) for i in range(ROWS + 1)]), 5, h, 'ys')
    xs = c.get('xs', [[round(i * w / COLS) for i in range(COLS + 1)]] * ROWS)
    if len(xs) == 7 and isinstance(xs[0], (int, float)):
        xs = [xs] * ROWS
    if len(xs) != 4:
        raise ValueError('xs must contain 4 rows of 7 boundaries')
    xs = [boundaries(row, 7, w, f'xs row {r}') for r, row in enumerate(xs)]
    return [[xs[r][col], ys[r], xs[r][col + 1], ys[r + 1]] for r in range(ROWS) for col in range(COLS)]


def get_guides(c, scale, padding):
    space = c.get('guide_coordinates', 'output_pixels')
    if space not in ('output_pixels', 'source_cell_pixels'):
        raise ValueError('guide_coordinates must be output_pixels or source_cell_pixels')
    def transform(p):
        if len(p) != 2:
            raise ValueError('A guide point must have two coordinates')
        return [round(float(p[i]) if space == 'output_pixels' else padding[i] + float(p[i]) * scale, 3) for i in range(2)]
    pivot = c.get('pivot', c.get('origin'))
    target = c.get('target')
    footprint = c.get('footprint')
    if pivot is None or target is None or footprint is None or len(footprint) < 3:
        raise ValueError('Provide pivot, target, and a footprint polygon of at least 3 points')
    return {'pivot_pixels': transform(pivot), 'target_pixels': transform(target),
            'intended_attack_footprint_pixels': [transform(p) for p in footprint]}


def timeline(mode):
    indices, durations = (ENEMY_INDICES, ENEMY_DURATIONS) if mode == 'enemy' else (HERO_INDICES, HERO_DURATIONS)
    t, entries = 0, []
    for j, (source, duration) in enumerate(zip(indices, durations)):
        entries.append({'sequence_index': j, 'source_index': source, 'source_cel': source + 1,
                        'file': f'frames/{source:02d}.png', 'phase': PHASES[source],
                        'start_ms': t, 'end_ms': t + duration, 'duration_ms': duration,
                        'damage_event': source == 15})
        t += duration
    return {'cycle_ms': t, 'formation_ms': 840 if mode == 'enemy' else 120,
            'strike_ms': 40, 'contact_ms': 90, 'recovery_ms': 350, 'clear_pause_ms': 350,
            'contact_event': {'source_index': 15, 'source_cel': 16,
                              'sequence_index': indices.index(15),
                              'time_ms': sum(durations[:indices.index(15)])},
            'frame_count': len(indices), 'entries': entries}


def probe_video(path):
    result = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                             '-show_entries', 'stream=width,height,r_frame_rate,nb_frames,duration',
                             '-of', 'json', str(path)], capture_output=True, check=True, text=True)
    return json.loads(result.stdout)['streams'][0]


def encode_video(path, width, height, segments, crf=20):
    """Each segment is (RGB PIL image, integer ms), quantized exactly at 5 ms."""
    command = ['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pixel_format', 'rgb24',
               '-video_size', f'{width}x{height}', '-framerate', str(FPS), '-i', '-', '-an',
               '-c:v', 'libx264', '-preset', 'fast', '-crf', str(crf), '-pix_fmt', 'yuv420p',
               '-movflags', '+faststart', str(path)]
    expected_frames = 0
    # Keep stderr in a file: a full error pipe must never deadlock rawvideo writes.
    log_path = path.with_suffix('.ffmpeg.log')
    with log_path.open('wb') as log:
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stderr=log)
        try:
            for im, duration in segments:
                if duration <= 0 or duration % TICK_MS:
                    raise ValueError(f'Nonpositive or non-5ms duration: {duration}')
                if im.size != (width, height):
                    raise ValueError('Incorrect preview canvas size')
                raw = im.convert('RGB').tobytes()
                count = duration // TICK_MS
                expected_frames += count
                for _ in range(count):
                    process.stdin.write(raw)
            process.stdin.close()
            code = process.wait()
        except Exception:
            if process.stdin and not process.stdin.closed:
                process.stdin.close()
            process.wait()
            raise
    if code:
        raise RuntimeError(f'ffmpeg failed for {path}: {log_path.read_text()}')
    log_path.unlink(missing_ok=True)
    probe = probe_video(path)
    if int(probe['nb_frames']) != expected_frames or probe['r_frame_rate'] != '200/1':
        raise RuntimeError(f'Video frame-rate/count mismatch: {probe}; expected {expected_frames}')
    expected_seconds = expected_frames / FPS
    if abs(float(probe['duration']) - expected_seconds) > 0.00001:
        raise RuntimeError(f'Video duration mismatch: {probe}; expected {expected_seconds}')
    return {'path': path.name, 'fps': FPS, 'frames': expected_frames,
            'duration_ms': round(float(probe['duration']) * 1000),
            'width': width, 'height': height, 'cycles': CYCLES}


def make_preview_frame(frame, title, mode, entry, total):
    im = Image.new('RGB', (SIZE, SIZE + 72), BG[:3])
    field = Image.new('RGBA', (SIZE, SIZE), BG)
    field.alpha_composite(frame)
    im.paste(field.convert('RGB'), (0, 72))
    d = ImageDraw.Draw(im)
    d.text((12, 7), f'{title}  |  {mode.upper()}', font=font(19), fill=INK)
    d.text((12, 32), f'NATIVE 1x  |  {entry["phase"]}  |  CEL {entry["source_cel"]:02d}', font=font(15), fill=ACCENT)
    d.text((12, 51), f'{entry["start_ms"]:04d}–{entry["end_ms"]:04d} ms / {total} ms', font=font(13), fill=MUTED)
    return im


def make_apng(path, frames, tl):
    images = [frames[e['source_index']] for e in tl['entries']]
    durations = [e['duration_ms'] for e in tl['entries']]
    images[0].save(path, save_all=True, append_images=images[1:], duration=durations,
                   loop=1, disposal=0, blend=0, optimize=True)
    check = Image.open(path)
    observed = []
    for i in range(check.n_frames):
        check.seek(i)
        observed.append(round(check.info.get('duration', 0)))
    if observed != durations:
        raise RuntimeError(f'APNG duration/frame mismatch: {path}: {observed} != {durations}')
    return {'path': path.name, 'frames': check.n_frames, 'durations_ms': observed,
            'duration_ms': sum(observed), 'play_count': 1, 'loop_forever': False}


def make_contact(path, title, frames):
    tile, head, footer = 256, 44, 57
    result = Image.new('RGB', (COLS * tile, head + ROWS * (tile + footer)), BG[:3])
    d = ImageDraw.Draw(result)
    d.text((14, 10), f'{title} — 24 SOURCE CELS / ENEMY AND HERO TIMING', font=font(20), fill=INK)
    hero_lookup = {e['source_index']: e for e in timeline('hero')['entries']}
    for i, frame in enumerate(frames):
        x, y = i % COLS * tile, head + i // COLS * (tile + footer)
        f = Image.new('RGBA', (tile, tile), BG)
        f.alpha_composite(frame.resize((tile, tile), Image.Resampling.LANCZOS))
        result.paste(f.convert('RGB'), (x, y))
        d.text((x + 8, y + tile + 3), f'{i + 1:02d}  {PHASES[i]}', font=font(13), fill=INK)
        h = hero_lookup.get(i)
        duration = f'hero {h["duration_ms"]} ms' if h else 'hero skipped'
        d.text((x + 8, y + tile + 22), f'enemy {ENEMY_DURATIONS[i]} ms | {duration}', font=font(12), fill=MUTED)
        if i == 15:
            d.text((x + 8, y + tile + 39), 'SINGLE CONTACT EVENT', font=font(11), fill=ACCENT)
    result.save(path, quality=93, subsampling=0)


def copy_source_if_needed(source, destination):
    if source.resolve() == destination.resolve():
        return
    if destination.exists():
        if sha256(source) != sha256(destination):
            raise ValueError(f'Refusing to overwrite existing source asset {destination}')
    else:
        shutil.copy2(source, destination)


def assemble(root, global_config, slug, c):
    if slug not in SLUGS:
        raise ValueError(f'Unrecognized attack slug: {slug}')
    if c.get('crops_reviewed') is not True:
        raise ValueError(f'{slug}: crops_reviewed must be true after visual crop review')
    out = root / slug
    out.mkdir(parents=True, exist_ok=True)
    source = Path(c.get('source', out / 'source_sheet.png'))
    if not source.is_absolute():
        source = root / source
    if not source.is_file():
        raise FileNotFoundError(source)
    copy_source_if_needed(source, out / 'source_sheet.png')
    source = out / 'source_sheet.png'
    # Required original evidence stays byte-identical. Never generate stand-in provenance.
    prompts = sorted(out.glob('*prompt*.txt'))
    provenance = sorted(out.glob('*provenance*.json'))
    if not prompts or not provenance:
        raise ValueError(f'{slug}: original prompt text and generation provenance JSON must be present')
    protected = {str(p.relative_to(out)): sha256(p) for p in [source] + prompts + provenance}
    image = Image.open(source).convert('RGBA')
    w, h = image.size
    if c.get('source_size') and list(image.size) != list(c['source_size']):
        raise ValueError(f'{slug}: source_size does not match actual image dimensions {image.size}')
    scale = float(global_config.get('source_scale', 1.5))
    padding = [float(x) for x in global_config.get('padding', [64, 64])]
    if scale <= 0 or len(padding) != 2:
        raise ValueError('source_scale must be positive and padding must contain two values')
    pitch = [float(x) for x in c.get('grid_pitch', [w / COLS, h / ROWS])]
    origin = [float(x) for x in c.get('grid_origin', [0, 0])]
    if len(pitch) != 2 or min(pitch) <= 0 or len(origin) != 2:
        raise ValueError('grid_pitch and grid_origin must have two coordinates')
    guides = get_guides(c, scale, padding)
    boxes = crop_boxes(c, w, h)
    (out / 'frames').mkdir(exist_ok=True)
    frames, records = [], []
    for i, box in enumerate(boxes):
        row, col = divmod(i, COLS)
        virtual_origin = [origin[0] + col * pitch[0], origin[1] + row * pitch[1]]
        crop = image.crop(box)
        source_alpha = np.asarray(crop)[:, :, 3]
        edge_alpha = np.concatenate([source_alpha[0], source_alpha[-1], source_alpha[:, 0], source_alpha[:, -1]])
        scaled = crop.resize((round(crop.width * scale), round(crop.height * scale)), Image.Resampling.LANCZOS)
        paste = [round(padding[0] + (box[0] - virtual_origin[0]) * scale),
                 round(padding[1] + (box[1] - virtual_origin[1]) * scale)]
        frame = Image.new('RGBA', (SIZE, SIZE))
        frame.alpha_composite(scaled, tuple(paste))
        full_alpha = np.asarray(scaled)[:, :, 3]
        inside = np.zeros(full_alpha.shape, dtype=bool)
        left, top = max(0, -paste[0]), max(0, -paste[1])
        right, bottom = min(scaled.width, SIZE - paste[0]), min(scaled.height, SIZE - paste[1])
        if right > left and bottom > top:
            inside[top:bottom, left:right] = True
        clipped = int(((full_alpha > 16) & ~inside).sum())
        if i == 23:
            # A true all-zero terminal frame, even if the generator left residue.
            frame = Image.new('RGBA', (SIZE, SIZE))
        frame.save(out / 'frames' / f'{i:02d}.png', optimize=True)
        frames.append(frame)
        records.append({'index': i, 'cel': i + 1, 'file': f'frames/{i:02d}.png',
                        'phase': PHASES[i], 'source_crop': box,
                        'source_grid_origin': virtual_origin, 'paste_xy': paste,
                        'scaled_crop_size': list(scaled.size), 'source_scale': scale,
                        'source_boundary_alpha_pixels': int((edge_alpha > 16).sum()),
                        'source_nonzero_alpha_pixels': int((source_alpha > 0).sum()),
                        'output_clipped_alpha_pixels': clipped,
                        'terminal_forced_empty': i == 23, **alpha_stats(frame)})
    atlas = Image.new('RGBA', (COLS * SIZE, ROWS * SIZE))
    for i, frame in enumerate(frames):
        atlas.alpha_composite(frame, (i % COLS * SIZE, i // COLS * SIZE))
    atlas.save(out / 'spritesheet_rgba.png', optimize=True)
    title = c.get('title', slug.replace('_', ' ').upper())
    make_contact(out / 'action_contact.jpg', title, frames)
    timelines, apng_qa, video_qa = {}, {}, {}
    for mode in ('enemy', 'hero'):
        tl = timeline(mode)
        timelines[mode] = tl
        apng_qa[mode] = make_apng(out / f'{mode}_rgba.apng', frames, tl)
        previews = [make_preview_frame(frames[e['source_index']], title, mode, e, tl['cycle_ms']) for e in tl['entries']]
        segments = [(previews[i], e['duration_ms']) for _ in range(CYCLES) for i, e in enumerate(tl['entries'])]
        video_qa[mode] = encode_video(out / f'{mode}_preview.mp4', SIZE, SIZE + 72, segments,
                                      crf=int(global_config.get('mp4_crf', 20)))
    source_array = np.asarray(image)
    margins = [min(r['alpha_bbox'][0], r['alpha_bbox'][1], SIZE - r['alpha_bbox'][2], SIZE - r['alpha_bbox'][3])
               for r in records if r['alpha_bbox']]
    unique = len({hashlib.sha256(f.tobytes()).hexdigest() for f in frames[:-1]})
    qa = {'all_frames_512_rgba': all(f.mode == 'RGBA' and f.size == (SIZE, SIZE) for f in frames),
          'frame_count': len(frames), 'terminal_fully_clear': records[-1]['nonzero_alpha_pixels'] == 0,
          'nonempty_drawn_frame_count': sum(bool(r['nonzero_alpha_pixels']) for r in records[:-1]),
          'unique_drawn_frame_count': unique, 'expected_drawn_frames': 23,
          'source_has_transparent_pixels': bool((source_array[:, :, 3] == 0).any()),
          'source_cut_alpha_pixels': sum(r['source_boundary_alpha_pixels'] for r in records[:-1]),
          'output_clipped_alpha_pixels': sum(r['output_clipped_alpha_pixels'] for r in records[:-1]),
          'minimum_output_margin_pixels': min(margins) if margins else None,
          'one_contact_event_per_timeline': all(sum(e['damage_event'] for e in tl['entries']) == 1 for tl in timelines.values()),
          'shared_contact_source_index': 15, 'no_per_frame_bbox_recentering': True,
          'apng': apng_qa, 'mp4': video_qa,
          'original_source_prompt_provenance_unchanged': all(sha256(out / name) == value for name, value in protected.items())}
    qa['critical_pass'] = (qa['all_frames_512_rgba'] and qa['terminal_fully_clear'] and
                           qa['nonempty_drawn_frame_count'] == 23 and unique == 23 and
                           qa['source_has_transparent_pixels'] and qa['output_clipped_alpha_pixels'] == 0 and
                           qa['one_contact_event_per_timeline'] and qa['original_source_prompt_provenance_unchanged'])
    qa['warnings'] = []
    if qa['source_cut_alpha_pixels']:
        qa['warnings'].append('Visible alpha touches extraction boundaries; inspect contact sheet/source for cut shapes or adjacent-cel contamination.')
    if margins and min(margins) < 16:
        qa['warnings'].append('Visible art approaches within 16 output pixels of the canvas edge.')
    manifest = {'title': title, 'slug': slug, 'canvas': [SIZE, SIZE], 'pixel_format': 'straight RGBA',
                'source_sheet': 'source_sheet.png', 'source_size': [w, h],
                'source_grid': [COLS, ROWS], 'source_grid_pitch': pitch, 'source_grid_origin': origin,
                'source_scale': scale, 'source_padding': padding,
                'registration': 'Fixed virtual source grid; crop offsets compensate for uneven extraction boundaries. No silhouette bounding-box recentering.',
                'source_registration_note': c.get('source_registration_note', 'Use the unchanged generated nominal grid.'),
                'atlas': 'spritesheet_rgba.png', 'atlas_grid': [COLS, ROWS],
                'frame_count': 24, 'unique_drawn_cels': 23, 'fully_clear_terminal_cels': 1,
                'loop': False, 'apng_play_count': 1, 'mp4_preview_cycles': CYCLES,
                'mp4_fps': FPS, 'mp4_time_basis_ms': TICK_MS,
                'formation_comparison': {'enemy_ms': 840, 'hero_ms': 120, 'ratio': 7.0,
                                          'hero_formation_source_cels': [1, 6, 10, 14]},
                'coordinate_guide_note': 'Art-direction guides only; no engine collision or gameplay implementation. Cosmetic recovery debris does not create extra damage events.',
                **guides, 'timelines': timelines, 'frames': records,
                'assembly_method': 'Crop, common uniform scale, fixed-coordinate paste, all-zero final hold, atlas/timeline packaging. No art synthesis, opacity fading, interpolation, morphing, or per-frame recentering.',
                'protected_source_sha256': protected}
    write_json(out / 'timing_manifest.json', manifest)
    write_json(out / 'qa.json', qa)
    write_json(out / 'assembly_config.json', {'global': global_config, 'attacks': {slug: c},
                                             'resolved_source_size': [w, h], 'resolved_grid_pitch': pitch,
                                             'resolved_grid_origin': origin, 'resolved_boxes': boxes})
    shutil.copy2(Path(__file__), out / 'assembly_script.py')
    (out / 'README.txt').write_text(f'''{title} — telegraphed single-contact formation kit

23 image-generated drawn cels plus one fully transparent terminal cel.
24 separate 512 × 512 straight-RGBA PNGs; 6 × 4 atlas, 3072 × 2048.
Source image, original generation prompt(s), and provenance are included unchanged.

ENEMY: formation/windup 840 ms (cels 1–14 at 60 ms), strike 40 ms,
contact 90 ms, recovery 350 ms (cels 17–23 at 50 ms), clear hold 350 ms.
Total one-shot duration: 1670 ms. One contact at 880 ms (source index 15 / cel 16).

HERO: formation 120 ms (cels 1, 6, 10, 14 at 30 ms), then the same
40 ms strike, 90 ms contact, 350 ms recovery, and 350 ms clear hold.
Total one-shot duration: 950 ms. One contact at 160 ms (source index 15 / cel 16).

The enemy and hero use exactly the same drawn cels. Only timing and formation
cel selection differ. APNGs play once and end clear. MP4s repeat 3 isolated
native-speed cycles at 200 fps, preserving all durations on a 5 ms basis.
MP4 labels show phase, source cel, and the active cel's time interval.

Fixed virtual grid; shared source scale {scale:g}; shared padding {padding}.
Per-row/individual extraction boundaries only exclude neighboring cels.
Crop offset compensation preserves nominal registration. No per-frame bbox
recentering, procedural VFX, generated in-betweens, morphs, or opacity fades.
Only the terminal cel is deliberately replaced with fully transparent pixels.

See timing_manifest.json for both timelines, exact crops, atlas mapping,
pivot, target, footprint, and the single damage-event suggestion.
These coordinates are art-direction guides, not engine collision code.
See qa.json and action_contact.jpg before importing into an engine.

To reproduce from inside this kit directory, with Pillow, NumPy and ffmpeg:
python assembly_script.py --config assembly_config.json --root .. --attacks {slug}
''')
    zip_path, zip_bytes = package_kit(root, slug)
    result = {'slug': slug, 'zip': str(zip_path), 'zip_bytes': zip_bytes,
              'critical_pass': qa['critical_pass'], 'warnings': qa['warnings'],
              'minimum_margin': qa['minimum_output_margin_pixels'],
              'source_cut_alpha_pixels': qa['source_cut_alpha_pixels']}
    print(json.dumps(result), flush=True)
    return result


def package_kit(root, slug):
    out = root / slug
    zip_path = root / f'{slug}_Formation_Impact_Kit.zip'
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in sorted(out.rglob('*')):
            rel = p.relative_to(out)
            final_names = {'source_sheet.png', 'source_on_gray.jpg', 'spritesheet_rgba.png',
                           'action_contact.jpg', 'enemy_rgba.apng', 'hero_rgba.apng',
                           'enemy_preview.mp4', 'hero_preview.mp4', 'timing_manifest.json',
                           'qa.json', 'assembly_config.json', 'assembly_script.py', 'README.txt',
                           'source_assessment.json', 'source_config.json', 'source_notes.txt', 'source_qa.json'}
            keep = (rel.as_posix() in final_names or
                    (rel.parent.as_posix() == 'frames' and p.suffix == '.png') or
                    (rel.parent.as_posix() == '.' and ('prompt' in p.name and p.suffix == '.txt')) or
                    (rel.parent.as_posix() == '.' and ('provenance' in p.name and p.suffix == '.json')))
            if p.is_file() and keep:
                archive.write(p, str(Path(slug) / rel))
    zip_bytes = zip_path.stat().st_size
    if zip_bytes >= ZIP_LIMIT:
        raise RuntimeError(f'{slug}: ZIP {zip_bytes / 1e6:.2f} MB exceeds strict 20 MB limit')
    with zipfile.ZipFile(zip_path) as check:
        if check.testzip() is not None:
            raise RuntimeError(f'{slug}: ZIP CRC failed')
    return zip_path, zip_bytes


def active_entry(tl, time_ms):
    if time_ms >= tl['cycle_ms']:
        return {'source_index': 23, 'source_cel': 24, 'phase': 'WAIT FOR NEXT CYCLE',
                'start_ms': tl['cycle_ms'], 'end_ms': timeline('enemy')['cycle_ms']}
    return tl['entries'][bisect.bisect_right([e['start_ms'] for e in tl['entries']], time_ms) - 1]


def comparison(root, global_config, attack_configs, slugs):
    if len(slugs) != 6:
        raise ValueError('Combined comparison requires exactly six assembled attacks')
    enemy, hero = timeline('enemy'), timeline('hero')
    cycle_ms = enemy['cycle_ms']
    # All modes start simultaneously; hero stays truly empty after its shorter cycle.
    split_points = sorted({0, cycle_ms, hero['cycle_ms']} |
                          {e['start_ms'] for e in enemy['entries']} |
                          {e['start_ms'] for e in hero['entries']})
    thumb, panel_w, panel_h = 256, 512, 342
    width, height = 3 * panel_w, 2 * panel_h
    all_frames = {s: [Image.open(root / s / 'frames' / f'{i:02d}.png').convert('RGBA').resize((thumb, thumb), Image.Resampling.LANCZOS)
                      for i in range(24)] for s in slugs}
    segments, records = [], []
    for start, end in zip(split_points, split_points[1:]):
        if start >= cycle_ms:
            continue
        ee, he = active_entry(enemy, start), active_entry(hero, start)
        im = Image.new('RGB', (width, height), BG[:3])
        d = ImageDraw.Draw(im)
        for i, slug in enumerate(slugs):
            x, y = i % 3 * panel_w, i // 3 * panel_h
            title = attack_configs[slug].get('title', slug.replace('_', ' ').upper())
            d.text((x + 10, y + 6), title, font=font(18), fill=INK)
            d.text((x + 10, y + 29), f'NATIVE 1x | shared cycle {start:04d}–{end:04d} / {cycle_ms} ms', font=font(12), fill=MUTED)
            for side, mode, entry in ((0, 'ENEMY', ee), (1, 'HERO', he)):
                sx = x + side * thumb
                d.text((sx + 10, y + 49), mode, font=font(15), fill=ACCENT)
                d.text((sx + 10, y + 69), f'{entry["phase"]} · cel {entry["source_cel"]:02d}', font=font(10), fill=INK)
                field = Image.new('RGBA', (thumb, thumb), BG)
                field.alpha_composite(all_frames[slug][entry['source_index']])
                im.paste(field.convert('RGB'), (sx, y + 86))
            d.line((x + thumb, y + 43, x + thumb, y + panel_h - 1), fill=(101, 106, 98))
            d.line((x, y + panel_h - 1, x + panel_w, y + panel_h - 1), fill=(120, 126, 115))
        segments.append((im, end - start))
        records.append({'start_ms': start, 'end_ms': end,
                        'enemy_source_index': ee['source_index'], 'hero_source_index': he['source_index'],
                        'enemy_phase': ee['phase'], 'hero_phase': he['phase']})
    path = root / 'six_attacks_enemy_hero_comparison.mp4'
    result = encode_video(path, width, height, segments * CYCLES, crf=int(global_config.get('comparison_crf', 21)))
    write_json(root / 'comparison_manifest.json', {'layout': '3 columns × 2 rows; enemy left, hero right in each panel',
               'attack_order': slugs, 'shared_cycle_ms': cycle_ms,
               'simultaneous_triggers': True, 'hero_extra_empty_hold_ms': cycle_ms - hero['cycle_ms'],
               'preview': result, 'segments': records})
    print(json.dumps({'comparison': str(path), **result}), flush=True)
    return result


def overview(root, attack_configs, slugs):
    if len(slugs) != 6:
        raise ValueError('Overview requires exactly six assembled attacks')
    tile, panel_w, panel_h, header = 224, 672, 294, 70
    result = Image.new('RGB', (panel_w * 2, header + panel_h * 3), BG[:3])
    d = ImageDraw.Draw(result)
    d.text((16, 9), 'SIX TELEGRAPHED ATTACKS — FORMATION / CONTACT / RECOVERY', font=font(22), fill=INK)
    d.text((16, 40), 'Enemy formation 840 ms · Hero formation 120 ms · Shared strike 40 ms / contact 90 ms / recovery 350 ms', font=font(15), fill=MUTED)
    stages = [('FORMED · CEL 14', 13), ('SINGLE CONTACT · CEL 16', 15), ('BREAKUP · CEL 20', 19)]
    for i, slug in enumerate(slugs):
        x, y = i % 2 * panel_w, header + i // 2 * panel_h
        title = attack_configs[slug].get('title', slug.replace('_', ' ').upper())
        d.text((x + 12, y + 8), title, font=font(20), fill=INK)
        for j, (label, source) in enumerate(stages):
            sx = x + j * tile
            d.text((sx + 10, y + 36), label, font=font(12), fill=ACCENT)
            f = Image.open(root / slug / 'frames' / f'{source:02d}.png').convert('RGBA')
            field = Image.new('RGBA', (tile, tile), BG)
            field.alpha_composite(f.resize((tile, tile), Image.Resampling.LANCZOS))
            result.paste(field.convert('RGB'), (sx, y + 57))
        d.line((x + 6, y + panel_h - 2, x + panel_w - 6, y + panel_h - 2), fill=(115, 120, 109))
    path = root / 'six_attacks_overview.jpg'
    result.save(path, quality=94, subsampling=0)
    print(json.dumps({'overview': str(path), 'size': list(result.size)}), flush=True)
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--attacks', nargs='+', choices=SLUGS)
    parser.add_argument('--comparison', action='store_true', help='Also make synchronized six-panel comparison')
    parser.add_argument('--comparison-only', action='store_true', help='Use existing assembled PNG frames')
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    global_config, attacks = config.get('global', {}), config['attacks']
    slugs = args.attacks or [s for s in SLUGS if s in attacks]
    if not slugs:
        parser.error('No attacks selected')
    results = []
    if not args.comparison_only:
        for slug in slugs:
            results.append(assemble(args.root, global_config, slug, attacks[slug]))
    if args.comparison or args.comparison_only:
        comparison(args.root, global_config, attacks, slugs)
        overview(args.root, attacks, slugs)
    if results:
        write_json(args.root / 'assembly_run_summary.json', results)
        if not all(r['critical_pass'] for r in results):
            print('One or more kits failed critical QA. Inspect qa.json before delivery.', file=sys.stderr)
            return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
