import sys,json,hashlib,zipfile,importlib.util
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location('base',str(root/'assembly_base.py'));base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
BG=(66,72,68,255)
specs=json.loads((root/'specs.json').read_text())
for s in specs:
 slug=s['slug'];p=root/slug;src=Image.open(p/'source_sheet.png').convert('RGBA'); a=np.asarray(src)[:,:,3];frames=[];boxes=[];edgecounts=[]
 # Only crop boundaries change to avoid isolated overflow into empty gutter. Nominal grid stays fixed.
 for i in range(24):
  row,col=divmod(i,6);x=col*256;y=row*256;box=[x,y,x+256,y+256]
  if False:
   ys=[0,256,542,784,1024];box=[x,ys[row],x+256,ys[row+1]]
  if slug=='caged_ember':
   ys=[0,239,512,768,1024];box=[x,ys[row],x+256,ys[row+1]]
  if slug=='lanternfall':
   ys=[0,256,525,768,1024];box=[x,ys[row],x+256,ys[row+1]]
  crop=src.crop(box);ca=np.asarray(crop)[:,:,3];edge=np.r_[ca[0],ca[-1],ca[:,0],ca[:,-1]];edgecounts.append(int((edge>16).sum()))
  frame=Image.new('RGBA',(384,384)); frame.alpha_composite(crop,(64+box[0]-x,64+box[1]-y))
  if i==23: frame=Image.new('RGBA',(384,384))
  frames.append(frame);boxes.append(box)
 (p/'frames').mkdir(exist_ok=True)
 for i,f in enumerate(frames):f.save(p/'frames'/f'{i:02d}.png',optimize=True)
 atlas=Image.new('RGBA',(384*6,384*4))
 for i,f in enumerate(frames):atlas.alpha_composite(f,(i%6*384,i//6*384))
 atlas.save(p/'spritesheet_rgba.png',optimize=True)
 utility=slug in ['hearthskin_ward','mothlight_recall'];impact=9 if slug=='caged_ember' else 10
 indices=[0,2,5,8]+list(range(9,24)); durations=[30]*4+[40,90]+[45]*12+[350]
 if utility:durations=[45]*4+[70,100]+[65]*12+[350]
 if slug=='caged_ember':indices=[0,2,5,7,8,9]+list(range(10,24));durations=[30]*4+[40,90]+[45]*13+[350]
 t=0;entries=[]
 for idx,d in zip(indices,durations):
  phase='FORMATION' if idx<9 else ('CONTACT' if idx==impact else 'STRIKE' if idx<impact else 'RECOVERY')
  if idx==23:phase='CLEAR'
  entries.append({'source_index':idx,'duration_ms':d,'start_ms':t,'end_ms':t+d,'phase':phase,'damage_event':idx==impact and not utility,'utility_event':idx==impact and utility});t+=d
 selected=[frames[i] for i in indices]
 selected[0].save(p/'animation_rgba.apng',save_all=True,append_images=selected[1:],duration=durations,loop=1,disposal=2,blend=0)
 segments=[]
 for e in entries:
  canvas=Image.new('RGBA',(384,456),BG);canvas.alpha_composite(frames[e['source_index']],(0,72));d=ImageDraw.Draw(canvas);d.text((12,9),s['title'],font=base.font(21),fill=(235,230,214));d.text((12,39),f"{'UTILITY' if utility else 'HERO'} | {e['phase']} | {e['start_ms']} ms",font=base.font(14),fill=(210,197,157));segments.append((canvas.convert('RGB'),e['duration_ms']))
 video=base.encode_video(p/'preview.mp4',384,456,segments*3)
 contact=Image.new('RGB',(6*192,4*220),BG[:3]);d=ImageDraw.Draw(contact)
 for i,f in enumerate(frames):
  tile=Image.new('RGBA',(192,192),BG);tile.alpha_composite(f.resize((192,192),Image.Resampling.LANCZOS));x=i%6*192;y=i//6*220;contact.paste(tile.convert('RGB'),(x,y+25));d.text((x+8,y+5),str(i+1),font=base.font(15),fill=(235,230,214))
 contact.save(p/'action_contact.jpg',quality=93)
 manifest={'title':s['title'],'slug':slug,'category':'utility' if utility else 'hero_attack','canvas':[384,384],'source_grid':[6,4],'registration':'Fixed nominal256px source grid with64px padding; no per-frame recentring, transformation or opacity fade. Only crop boundaries adjust to avoid adjacent cel contamination.','crops':boxes,'source_scale':1,'pivot_pixels':[192,264],'target_guide_note':'Experimental visual guide. Confirm gameplay collision footprint separately; aftermath particles cosmetic.','action_description':s['action'],'contact_source_index':impact,'formation_ms':180 if utility else 120,'entries':entries,'cycle_ms':t,'loop':False,'clear_final_frame':True,'source_art':'Image-generated evolving cels; original alpha preserved. Final cel forced all-zero.'}
 if (p/'footprint.json').exists(): manifest.update(json.loads((p/'footprint.json').read_text()))
 (p/'timing_manifest.json').write_text(json.dumps(manifest,indent=2))
 qa={'frame_count':24,'unique_drawn_frames':len(set(hashlib.sha256(f.tobytes()).hexdigest() for f in frames[:-1])),'clear_final':frames[-1].getbbox() is None,'all_edges_clear':all(not np.any(np.r_[np.array(f)[:,:,3][0],np.array(f)[:,:,3][-1],np.array(f)[:,:,3][:,0],np.array(f)[:,:,3][:,-1]]) for f in frames),'source_crop_boundary_visible_pixels':edgecounts,'mp4':video,'one_attack_contact':sum(e['damage_event'] for e in entries)==(0 if utility else 1)}
 (p/'qa.json').write_text(json.dumps(qa,indent=2))
 (p/'README.txt').write_text(s['title']+'\n\n'+s['action']+'\n\nExperimental Lantern hero VFX. 24 RGBA384px frames,6x4 atlas. Fast formation then one hit, continuous physical aftermath. Utility effects instead have one protective/restorative pulse. APNG one-shot ends transparent; preview repeats3 cycles. Timing/footprint data are artistic guides, not engine implementation. Original generated source and actual prompts included. No procedural drawn art or synthetic fades.\n')
 print(slug,edgecounts,flush=True)
