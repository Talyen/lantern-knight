from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,shutil,subprocess,zipfile,hashlib
R=Path('/workspace/shared/ephemeral_tests');S=512;K=1.2;P=56;BG=(78,84,78,255)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
D=[50,50,50,50,80,25,25,90,40,50,50,50,50,40,30,340]
PH=['SPARSE','GATHER','FORM','TELEGRAPH','LOAD','COMMIT','STRIKE','CONTACT','RECOIL','BREAKUP','SCATTER','DISSIPATE','REMNANTS','LAST FLECKS','CLEARING','CLEAR']
CFG={
'ivory_rake':dict(title='IVORY RAKE',xs=[[0,314,627,940,1254]]*4,ys=[0,314,627,940,1254],origin=[180,292],target=[355,270],footprint=[[175,300],[355,235],[395,280],[190,325]]),
'oil_whip':dict(title='OIL WHIP',xs=[[0,340,650,970,1254],[0,360,670,980,1254],[0,370,650,965,1254],[0,340,650,970,1254]],ys=[0,350,680,960,1254],origin=[185,395],target=[350,360],footprint=[[170,380],[350,335],[382,370],[175,410]]),
'veil_shear':dict(title='VEIL SHEAR',xs=[[0,320,630,950,1254],[0,340,650,970,1254],[0,330,640,950,1254],[0,330,640,950,1254]],ys=[0,335,650,950,1254],origin=[180,300],target=[350,300],footprint=[[175,280],[370,280],[370,320],[175,320]])}
for slug,c in CFG.items():
 c['origin']=[round(56+(v-44)/1.35*1.2) for v in c['origin']];c['target']=[round(56+(v-44)/1.35*1.2) for v in c['target']];c['footprint']=[[round(56+(v-44)/1.35*1.2) for v in point] for point in c['footprint']]
 o=R/slug;(o/'frames').mkdir(exist_ok=True);src=Image.open(o/'source_sheet.png').convert('RGBA');frames=[];records=[]
 for i in range(16):
  row,col=divmod(i,4);box=(c['xs'][row][col],c['ys'][row],c['xs'][row][col+1],c['ys'][row+1]);cel=src.crop(box)
  # Preserve nominal source grid coordinates; varying extraction boundaries only remove neighboring cels.
  dx=round(P+(box[0]-col*313.5)*K);dy=round(P+(box[1]-row*313.5)*K)
  cel=cel.resize((round(cel.width*K),round(cel.height*K)),Image.Resampling.LANCZOS)
  frame=Image.new('RGBA',(S,S));frame.alpha_composite(cel,(dx,dy));frame=Image.new('RGBA',(S,S)) if i==15 else frame;frame.save(o/'frames'/f'{i:02d}.png',optimize=True);frames.append(frame)
  a=np.asarray(frame)[:,:,3];ys,xs=np.where(a>16);bb=None if not len(xs) else [int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]
  sa=np.asarray(src.crop(box))[:,:,3];border=int(np.count_nonzero(np.concatenate([sa[0],sa[-1],sa[:,0],sa[:,-1]])>16))
  records.append(dict(index=i,file=f'frames/{i:02d}.png',phase=PH[i],duration_ms=D[i],source_crop=list(box),source_grid_origin=[col*313.5,row*313.5],paste_xy=[dx,dy],alpha_bbox=bb,source_boundary_alpha_pixels=border,damage_event=i==7))
 frames[0].save(o/'animation_rgba.apng',save_all=True,append_images=frames[1:],duration=D,loop=1,disposal=0,blend=0,optimize=True)
 atlas=Image.new('RGBA',(2048,2048))
 for i,f in enumerate(frames):atlas.alpha_composite(f,((i%4)*512,(i//4)*512))
 atlas.save(o/'spritesheet_rgba.png',optimize=True)
 contact=Image.new('RGB',(1280,1440),BG[:3]);draw=ImageDraw.Draw(contact);font=ImageFont.truetype(FONT,16)
 for i,f in enumerate(frames):
  thumb=Image.new('RGBA',(320,320),BG);thumb.alpha_composite(f.resize((320,320),Image.Resampling.LANCZOS));x=i%4*320;y=i//4*360;contact.paste(thumb.convert('RGB'),(x,y));draw.text((x+10,y+325),f'{i+1:02} {PH[i]} / {D[i]}ms',font=font,fill='white')
 contact.save(o/'action_contact.jpg',quality=94)
 data=[]
 for f in frames:
  bg=Image.new('RGBA',(S,S),BG);bg.alpha_composite(f);data.append(bg.convert('RGB').tobytes())
 p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pixel_format','rgb24','-video_size','512x512','-framerate','200','-i','-','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(o/'preview.mp4')],stdin=subprocess.PIPE)
 for _ in range(3):
  for j,b in enumerate(data):
   for _ in range(D[j]//5):p.stdin.write(b)
 p.stdin.close();assert p.wait()==0
 m=dict(title=c['title'],experimental_feedback_test=True,canvas=[512,512],atlas_grid=[4,4],frame_count=16,unique_drawn_cels=15,fully_clear_terminal_cels=1,cycle_ms=sum(D),formation_ms=200,load_ms=80,strike_ms=50,single_contact_ms=90,recovery_ms=310,clear_pause_ms=340,loop=False,preview_cycles=3,source_scale=K,source_padding=[P,P],registration='Fixed virtual 313.5px source grid; no per-frame silhouette recentering.',pivot_pixels=c['origin'],target_pixels=c['target'],intended_attack_footprint_pixels=c['footprint'],target_note='Art-direction placement guide, not engine collision implementation. One target lane/endpoint. Debris is cosmetic recovery.',damage_events=[dict(frame=7,time_ms=sum(D[:7]),target_pixels=c['target'])],frames=records)
 (o/'timing_manifest.json').write_text(json.dumps(m,indent=2))
 qa=dict(all_frames_512_rgba=all(f.size==(512,512) and f.mode=='RGBA' for f in frames),terminal_fully_clear=not np.asarray(frames[-1])[:,:,3].any(),unique_nonempty_frames=len(set(hashlib.sha256(f.tobytes()).hexdigest() for f in frames[:-1]))==15,source_cut_alpha_pixels=sum(r['source_boundary_alpha_pixels'] for r in records),minimum_output_margin=min(min(r['alpha_bbox'][:2]+[512-r['alpha_bbox'][2],512-r['alpha_bbox'][3]]) for r in records if r['alpha_bbox']))
 (o/'qa.json').write_text(json.dumps(qa,indent=2))
 for suffix in ['prompt','revision_prompt']:shutil.copy2(R/(slug+'_'+suffix+'.txt'),o/(suffix+'.txt'))
 (o/'README.txt').write_text(c['title']+' — small telegraphed single-impact test\n\n15 newly image-generated painted cels plus an empty terminal cel. 512px straight RGBA. Playback is one shot; MP4 repeats three isolated cycles for review.\nFormation 200ms, load 80ms, strike 50ms, one contact 90ms, recovery 310ms, clear pause340ms.\nSource and complete generation/revision prompts included. Imagegen created the artwork. Code only crops cels, applies one common scale/coordinate transform, preserves alpha, and assembles timelines/atlas/previews. No procedural VFX, per-frame bbox centering, opacity fades, morphs or interpolated frames.\nRead timing_manifest.json for source crops, pivot, intended target lane, and single damage-event suggestion. Coordinates are design guides; no engine changes made.\n')
 zpath=R/(slug+'_Formation_Impact_Kit.zip')
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,6) as z:
  for f in sorted(o.rglob('*')):
   if f.is_file():z.write(f,str(Path(slug)/f.relative_to(o)))
 print(slug,qa,'zip_MB',zpath.stat().st_size/1e6,flush=True)
