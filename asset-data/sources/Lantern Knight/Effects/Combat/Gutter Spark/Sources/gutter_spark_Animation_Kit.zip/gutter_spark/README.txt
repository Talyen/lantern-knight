Gutter Spark

A dull brass ember gathers inside a coiled ash filament at left, uncoils along a single hooked trajectory to a fixed small target at lower right, and strikes ONCE in a sharp flattened spark-splash. The hooked ash ribbon whips onward and unravels after contact. No bounce, no multiple target or second hit.

Experimental Lantern hero VFX. 24 RGBA384px frames,6x4 atlas. Fast formation then one hit, continuous physical aftermath. Utility effects instead have one protective/restorative pulse. APNG one-shot ends transparent; preview repeats3 cycles. Timing/footprint data are artistic guides, not engine implementation. Original generated source and actual prompts included. No procedural drawn art or synthetic fades.
