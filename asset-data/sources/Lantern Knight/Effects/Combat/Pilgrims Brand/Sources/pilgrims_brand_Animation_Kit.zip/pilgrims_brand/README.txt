Pilgrim's Brand

Four dark charcoal strokes crawl together across the ground to form one squat cross-shaped footprint, thin copper seams fill from the center, then the entire cross erupts upward ONCE as four fused low curtains of ember and soot. Curtains buckle outward into torn flakes then drift away. One bounded cross-shaped hit, no sequential explosions.

Experimental Lantern hero VFX. 24 RGBA384px frames,6x4 atlas. Fast formation then one hit, continuous physical aftermath. Utility effects instead have one protective/restorative pulse. APNG one-shot ends transparent; preview repeats3 cycles. Timing/footprint data are artistic guides, not engine implementation. Original generated source and actual prompts included. No procedural drawn art or synthetic fades.
