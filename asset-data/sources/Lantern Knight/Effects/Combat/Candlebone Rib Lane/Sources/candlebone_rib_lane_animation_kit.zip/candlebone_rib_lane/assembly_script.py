from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,hashlib,subprocess,zipfile,shutil,sys
ROOT=Path(__file__).parent;BG=(64,70,68,255);W,H=512,384;FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
DUR=[70]*14+[40,90]+[60]*7+[350]
def run(slug):
 p=ROOT/slug;im=Image.open(p/'source_sheet.png').convert('RGBA');sw,sh=im.size;pitch=(sw/4,sh/6);scale=min(384/pitch[0],240/pitch[1]);pad=((W-pitch[0]*scale)/2,(H-pitch[1]*scale)/2)
 frames=[];rec=[];(p/'frames').mkdir(exist_ok=True)
 for i in range(24):
  c,r=i%4,i//4; box=[round(c*pitch[0]),round(r*pitch[1]),round((c+1)*pitch[0]),round((r+1)*pitch[1])]
  ys={'umbral_beak':[0,187,424,656,871,1084,1254],'verdigris_shear':[0,167,411,636,868,1060,1254],'censer_chain_lash':[0,186,411,654,879,1047,1254],'candlebone_rib_lane':[0,181,392,605,846,1043,1254]}.get(slug)
  if ys:box[1],box[3]=ys[r],ys[r+1]
  if slug=='funeral_streamer':
   xs=[(0,292),(323,612),(642,932),(962,1254)];ys=[(0,196),(215,408),(426,619),(636,830),(847,1039),(1056,1254)];box=[xs[c][0]+4,ys[r][0]+4,xs[c][1]-4,ys[r][1]-4]
  cr=im.crop(box);a=np.array(cr)[:,:,3];edge=int(np.count_nonzero(np.r_[a[0],a[-1],a[:,0],a[:,-1]]>16));f=Image.new('RGBA',(W,H));res=cr.resize((round(cr.width*scale),round(cr.height*scale)),Image.Resampling.LANCZOS);xy=(round(pad[0]+(box[0]-c*pitch[0])*scale),round(pad[1]+(box[1]-r*pitch[1])*scale));f.alpha_composite(res,xy)
  if i==23:f=Image.new('RGBA',(W,H))
  f.save(p/'frames'/f'{i:02}.png');frames.append(f);rec.append({'cel':i+1,'source_box':box,'source_boundary_alpha_pixels':edge,'paste':xy,'duration_ms':DUR[i],'phase':'telegraph' if i<14 else 'strike' if i==14 else 'impact' if i==15 else 'recovery' if i<23 else 'clear','damage_event':i==15})
 atlas=Image.new('RGBA',(W*4,H*6))
 for i,f in enumerate(frames):atlas.alpha_composite(f,(i%4*W,i//4*H))
 atlas.save(p/'spritesheet_rgba.png');frames[0].save(p/'enemy_rgba.apng',save_all=True,append_images=frames[1:],duration=DUR,loop=1,disposal=0,blend=0)
 co=Image.new('RGB',(1024,6*215),BG[:3]);d=ImageDraw.Draw(co)
 for i,f in enumerate(frames):
  x=i%4*256;y=i//4*215;b=Image.new('RGBA',(256,192),BG);b.alpha_composite(f.resize((256,192),Image.Resampling.LANCZOS));co.paste(b.convert('RGB'),(x,y));d.text((x+5,y+193),f'{i+1:02} {rec[i]["phase"]} {DUR[i]}ms',font=FONT,fill='white')
 co.save(p/'action_contact.jpg',quality=92)
 proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','512x432','-r','100','-i','-','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p',str(p/'enemy_preview.mp4')],stdin=subprocess.PIPE)
 for cycle in range(3):
  for i,f in enumerate(frames):
   b=Image.new('RGBA',(W,H),BG);b.alpha_composite(f);v=Image.new('RGB',(512,432),BG[:3]);v.paste(b.convert('RGB'),(0,48));dr=ImageDraw.Draw(v);dr.text((10,5),slug.replace('_',' ').title(),font=FONT,fill='white');dr.text((10,27),f'ENEMY | {rec[i]["phase"]} | cel {i+1:02}',font=FONT,fill=(219,192,149));raw=v.tobytes()
   for _ in range(DUR[i]//10):proc.stdin.write(raw)
 proc.stdin.close();assert proc.wait()==0
 meta={'name':slug,'role':'enemy','grid':[4,6],'canvas':[W,H],'source_size':[sw,sh],'source_scale':scale,'source_padding':pad,'telegraph_ms':sum(DUR[:14]),'strike_ms':40,'impact_start_ms':sum(DUR[:15]),'contact_ms':90,'recovery_ms':420,'clear_hold_ms':350,'duration_ms':sum(DUR),'frames':rec,'registration':'Fixed nominal 4x6 source grid; crop offsets compensated, no per-frame recentering.','assembly':'Only crops, one uniform scale, fixed placement; no synthetic motion, morphing or fade. Final all-zero cel.','coordinates_note':'Art direction only, not engine collision integration','preview_cycles':3,'source_sha256':hashlib.sha256((p/'source_sheet.png').read_bytes()).hexdigest()}
 guide={'saltwire_lash':{'pivot':[.18,.60],'target':[.78,.60],'footprint':'thin horizontal lane'},'umbral_beak':{'pivot':[.53,.76],'target':[.53,.76],'footprint':'small ellipse'},'funeral_streamer':{'pivot':[.15,.58],'target':[.80,.58],'footprint':'thin horizontal lane'},'verdigris_shear':{'pivot':[.20,.62],'target':[.80,.62],'footprint':'narrow triangular wedge'},'censer_chain_lash':{'pivot':[.15,.62],'target':[.78,.62],'footprint':'long horizontal lane and endpoint ellipse','enemy_reference':'Censer Keeper, original Drive 1aOROXR-El7nor2Nc7d1sLhAWOvh2kxxu'},'candlebone_rib_lane':{'pivot':[.18,.72],'target':[.80,.42],'footprint':'long thin diagonal lane','enemy_reference':'Candlebone Oracle, original Drive 1Df_2l6PKRRnegnsIwwlXd2gPd7pvoOBS'}}.get(slug,{})
 meta['art_direction_guide_normalized_source_cell']=guide
 (p/'timing_manifest.json').write_text(json.dumps(meta,indent=2));qa={'alpha_empty_final':not frames[-1].getbbox(),'unique_drawn_cels':len({hashlib.sha256(f.tobytes()).hexdigest() for f in frames[:-1]}),'source_edge_pixels':[r['source_boundary_alpha_pixels'] for r in rec],'output_clear_edges':all(not any(np.array(f)[:,:,3][0]) and not any(np.array(f)[:,:,3][-1]) and not any(np.array(f)[:,:,3][:,0]) and not any(np.array(f)[:,:,3][:,-1]) for f in frames)};(p/'qa.json').write_text(json.dumps(qa,indent=2));shutil.copy(__file__,p/'assembly_script.py')
 (p/'README.txt').write_text(f'{slug.replace("_"," ").title()}\nExperimental enemy attack. 23 image-generated cels plus clear terminal. 980ms evolving telegraph,40ms strike,one90ms contact,420ms outward recovery. 512x384 transparent frames and4x6atlas. MP4 shows3cycles. No engine changes. See timing_manifest for source crop registration and timing. Generated source,prompt,andprovenance retained.\n')
 z=ROOT/(slug+'_animation_kit.zip')
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,9) as out:
  for f in sorted(p.rglob('*')):
   if f.is_file():out.write(f,str(Path(slug)/f.relative_to(p)))
 print(slug,z.stat().st_size,qa,flush=True)
if __name__=='__main__':
 for s in sys.argv[1:]:run(s)
