#!/usr/bin/env python3
"""Original deterministic Clean Ink effect geometry. No image inputs or AI frame generation.
Python 3 + Pillow + numpy; ffmpeg is used only for 60 Hz review movies.
"""
from pathlib import Path
import argparse, hashlib, json, math, subprocess, zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
if ROOT.name in ('combat_pack_v1','early_review'): ROOT = ROOT.parent
W,H=512,448
PIVOT=(256,286)
DENSITY=112.0
SS=3
FPS=30
ELEVATION=35.264389682754654
AZIMUTH=45.0
C={'ink':'#272b2b','charcoal':'#454947','bone':'#f5edda','ivory':'#fff8e7','amber':'#e8aa49','ochre':'#b87634','dust':'#a79b80','lightdust':'#d0c5aa'}
SPECS={
 'sword_arc_01':(12,'Opening cut','projected_world','Sword action 1 visual trail; rightward sweep in local aim space.'),
 'sword_arc_02':(12,'Returning cut','projected_world','Sword action 2 visual trail; reverse sweep, narrow split tail.'),
 'sword_finisher_03':(16,'Heavy finisher','projected_world','Sword action 3 visual trail; broad crescent with a brief second edge.'),
 'lantern_cone_flare':(18,'Lantern cone','projected_world','Short cone rooted at lantern socket; no traveling projectile.'),
 'amber_impact':(12,'Amber impact','screen_overlay','Small contained hit accent; anchor at impact point.'),
 'footstep_dust':(18,'Footstep dust','projected_world','Muted ground-rooted dust for visual footstep notifications.'),
 'dash_wake':(12,'Dash wake','projected_world','Tapered wake behind motion; no body afterimage or invulnerability authority.'),
 'stagger_shards':(24,'Stagger shards','screen_overlay','Three irregular hovering amber shards; no status UI ring or stars.'),
}
DIRECTIONAL={'sword_arc_01','sword_arc_02','sword_finisher_03','lantern_cone_flare','dash_wake'}

def clamp(t,a=0,b=1): return max(a,min(b,t))
def smooth(t): t=clamp(t); return t*t*(3-2*t)
def rgba(color, alpha):
 color=C.get(color,color).lstrip('#')
 return tuple(int(color[i:i+2],16) for i in (0,2,4))+(round(clamp(alpha)*255),)
def local(x,y,z,yaw=0):
 a=math.radians(yaw)
 return (x*math.cos(a)+z*math.sin(a),y,-x*math.sin(a)+z*math.cos(a))
def proj(p):
 x,y,z=p;a=math.radians(AZIMUTH);e=math.radians(ELEVATION)
 return (PIVOT[0]+DENSITY*(math.cos(a)*x-math.sin(a)*z),PIVOT[1]-DENSITY*(-math.sin(e)*math.sin(a)*x+math.cos(e)*y-math.sin(e)*math.cos(a)*z))

class Canvas:
 def __init__(self):
  self.image=Image.new('RGBA',(W*SS,H*SS));self.svg=[]
 def poly(self,pts,col,alpha=1):
  if alpha<=0 or len(pts)<3:return
  color=rgba(col,alpha)
  layer=Image.new('RGBA',self.image.size)
  ImageDraw.Draw(layer).polygon([(round(x*SS),round(y*SS)) for x,y in pts],fill=color)
  self.image=Image.alpha_composite(self.image,layer)
  v=' '.join(f'{x:.3f},{y:.3f}' for x,y in pts)
  self.svg.append(f'<polygon points="{v}" fill="{C.get(col,col)}" fill-opacity="{clamp(alpha):.5f}"/>')
 def worldpoly(self,pts,col,alpha=1,yaw=0):self.poly([proj(local(*p,yaw)) for p in pts],col,alpha)
 def export(self,path):
  im=self.image.resize((W,H),Image.Resampling.LANCZOS)
  a=np.array(im); a[a[:,:,3]==0,:3]=0
  im=Image.fromarray(a);im.save(path,optimize=True)
  return im
 def svg_text(self):return '<svg xmlns="http://www.w3.org/2000/svg" width="512" height="448" viewBox="0 0 512 448">\n'+ '\n'.join(self.svg)+'\n</svg>\n'

def arc_pts(start,end,radius,width,height,yaw,shift=(0,0,0),tipbias=0):
 # The tapered silhouette is a single coherent ribbon, sampled from one source curve.
 outer=[];inner=[]
 for j in range(37):
  q=j/36;a=math.radians(start+(end-start)*q)
  taper=(math.sin(math.pi*q)**0.72)*(0.40+0.60*q)
  w=width*taper
  for dest,r in ((outer,radius+w*.35),(inner,radius-w*.65)):
   p=(math.sin(a)*r+shift[0],height+shift[1]+.055*math.sin(math.pi*q),math.cos(a)*r+shift[2])
   dest.append(proj(local(*p,yaw)))
 return outer+inner[::-1]

def shard(c,x,y,sx,sy,col,alpha=1,angle=0):
 a=math.radians(angle)
 pts=[]
 for px,py in [(0,-sy),(.31*sx,-.13*sy),(sx,.16*sy),(.20*sx,.34*sy),(-.14*sx,sy),(-.32*sx,.12*sy),(-sx,-.13*sy),(-.19*sx,-.30*sy)]:
  pts.append((x+px*math.cos(a)-py*math.sin(a),y+px*math.sin(a)+py*math.cos(a)))
 c.poly(pts,col,alpha)

def sword(c,t,yaw,kind):
 if t<=0 or t>=1:return
 heavy=kind==3;rev=kind==2
 alpha=smooth(t/.10)*(1-smooth((t-.63)/.37))
 sweep=smooth(t/.70)
 head=(-91+185*sweep) * (-1 if rev else 1)
 length=(110 if heavy else 87)*(math.sin(math.pi*clamp(t/.94))**.30)
 tail=head-length*(-1 if rev else 1)
 r=1.38 if heavy else (1.21 if rev else 1.30)
 width=(.31 if heavy else .18)*(.7+.3*math.sin(math.pi*t))
 height=1.00 if heavy else 1.07
 c.poly(arc_pts(tail,head,r,width*1.38,height,yaw),'ink',alpha*.88)
 c.poly(arc_pts(tail+5*(-1 if rev else 1),head,r+.016,width,height+.017,yaw),'bone',alpha)
 c.poly(arc_pts(tail+length*.22*(-1 if rev else 1),head-4*(-1 if rev else 1),r+.042,width*.24,height+.025,yaw),'ivory',alpha)
 # Short gold lower edge connects the effects palette to the carried lantern.
 c.poly(arc_pts(tail+length*.39*(-1 if rev else 1),head-8*(-1 if rev else 1),r-.12,.052,height-.01,yaw),'amber',alpha*.85)
 c.poly(arc_pts(tail-17*(-1 if rev else 1),head-35*(-1 if rev else 1),r-.29,.055,height-.027,yaw),'charcoal',alpha*.60)
 if heavy:
  c.poly(arc_pts(tail+9,head-21,r+.17,.077,height+.024,yaw),'bone',alpha*.78)
  if .22<t<.83:
   for i in range(3):
    a=math.radians(head+6+i*14);rr=r+.1+i*.09
    p=proj(local(math.sin(a)*rr,height+.05,math.cos(a)*rr,yaw))
    shard(c,*p,3.6-i*.5,8.2-i*1.2,'amber',alpha*.80,head+40)
 if rev:c.poly(arc_pts(tail-13,head+27,r+.12,.055,height+.08,yaw),'bone',alpha*.53)

def flare(c,t,yaw):
 if t<=0 or t>=1:return
 grow=smooth(t/.26);fade=1-smooth((t-.45)/.55);alpha=smooth(t/.11)*fade
 reach=(.45+1.62*grow)*(1+.012*math.sin(2*math.pi*t))
 # Constant root and angular bounds. Only the fan's envelope opens and collapses.
 w=.14+.77*grow
 z0=.05;y=.86
 pts=[(-.055,y,z0),(-w*.53,y+.03,reach*.52),(-w,y,reach*.83),(-w*.65,y+.02,reach*.86),(-w*.41,y,reach),(-w*.20,y+.04,reach*.86),(0,y,reach*1.045),(w*.23,y-.03,reach*.89),(w*.50,y,reach*.965),(w*.61,y-.02,reach*.76),(w,y,reach*.79),(w*.44,y-.03,reach*.44),(.055,y,z0)]
 c.worldpoly(pts,'ink',alpha*.35,yaw)
 c.worldpoly([(x*.97,yy+.016,z*.98) for x,yy,z in pts],'ochre',alpha*.60,yaw)
 core=[(-.045,y+.023,.04),(-w*.22,y+.028,reach*.45),(-w*.53,y+.028,reach*.80),(-w*.30,y+.028,reach*.76),(-w*.18,y+.028,reach*.93),(.04,y+.028,reach*.78),(w*.31,y+.028,reach*.88),(w*.27,y+.028,reach*.63),(w*.50,y+.028,reach*.74),(w*.23,y+.028,reach*.40),(.045,y+.023,.04)]
 c.worldpoly(core,'amber',alpha*.96,yaw)
 inside=[(-.025,y+.046,.035),(-w*.08,y+.046,reach*.33),(-w*.16,y+.046,reach*.58),(-w*.03,y+.046,reach*.51),(w*.02,y+.046,reach*.76),(w*.16,y+.046,reach*.48),(w*.09,y+.046,reach*.26),(.026,y+.046,.035)]
 c.worldpoly(inside,'bone',alpha,yaw)
 # Three deliberate detached tongues stay inside the original cone envelope.
 for i,(x,z) in enumerate([(-.62,.70),(.50,.58),(.13,.90)]):
  if t>.16:
   s=.07*fade
   c.worldpoly([(x*w,y+.035,z*reach),(x*w-s,y+.035,z*reach-.11),(x*w+s*.6,y+.035,z*reach-.07)],'amber',alpha*.8,yaw)

def impact(c,t,yaw):
 if t<=0 or t>=1:return
 a=smooth(t/.10)*(1-smooth((t-.30)/.70));x,y=PIVOT
 r=13+50*smooth(t);contract=(1-t)**.65
 # One asymmetric four-corner center, five curated radial splinters.
 shard(c,x,y,22*contract,32*contract,'ink',a,18)
 shard(c,x,y,17*contract,28*contract,'amber',a,18)
 shard(c,x,y,8*contract,16*contract,'bone',a,18)
 for i,deg in enumerate([-101,-35,23,102,168]):
  ang=math.radians(deg);xx=x+math.cos(ang)*r*(.84+.07*(i%3));yy=y+math.sin(ang)*r*.83
  shard(c,xx,yy,2.7*contract,12*contract*(.7+i*.05),'amber' if i%2 else 'bone',a,deg-90)

def dust(c,t,yaw):
 if t<=0 or t>=1:return
 a=smooth(t/.13)*(1-smooth((t-.36)/.64))*.64
 # Broad low sheets. No noise particles or smoke texture; all fixed trajectories.
 for i,(x,z,s) in enumerate([(-.19,.03,.29),(.10,.14,.33),(.30,-.09,.23)]):
  q=smooth(t);xx=x*(1+q*1.5);zz=z*(1+q);h=.04+.15*q;sz=s*(.65+.75*q)
  pts=[(xx-sz,h,zz),(xx-sz*.62,h+.07,zz+sz*.46),(xx-sz*.13,h+.12,zz+sz*.47),(xx+sz*.30,h+.09,zz+sz*.64),(xx+sz,h,zz+sz*.21),(xx+sz*.52,h-.03,zz-sz*.26),(xx-sz*.50,h-.02,zz-sz*.26)]
  c.worldpoly(pts,'dust',a*(1-.13*i),0)
  c.worldpoly([(px*.98,py+.014,pz*.97) for px,py,pz in pts[:5]]+[(xx,h,zz)],'lightdust',a*.35,0)

def dash(c,t,yaw):
 if t<=0 or t>=1:return
 a=smooth(t/.1)*(1-smooth((t-.48)/.52))
 length=.7+1.21*smooth(t/.76)
 for i,(x,h,wide) in enumerate([(-.18,.20,.17),(.13,.61,.13),(-.12,1.05,.085)]):
  z=-.10-.08*i
  pts=[(x-wide,h,z),(x-wide*.38,h+.035,z-length*.25),(x+wide*.34,h+.018,z-length),(x+wide*.55,h-.02,z-length*.42),(x+wide,h-.02,z-.16)]
  c.worldpoly(pts,'ink',a*.82,yaw)
  inner=[(x-wide*.67,h+.02,z-.025),(x-wide*.12,h+.045,z-length*.25),(x+wide*.34,h+.026,z-length*.94),(x+wide*.40,h,z-length*.42),(x+wide*.62,h,z-.19)]
  c.worldpoly(inner,'bone' if i<2 else 'charcoal',a*(.77 if i<2 else .6),yaw)
 if t>.2:
  c.worldpoly([(-.34,.07,-.12),(-.50,.07,-length*.56),(-.34,.07,-length*.74),(-.23,.07,-.29)],'dust',a*.34,yaw)

def stagger(c,t,yaw):
 if t<=0 or t>=1:return
 a=smooth(t/.16)*(1-smooth((t-.72)/.28));x,y=PIVOT
 for i in range(3):
  angle=math.radians(-155+i*68+19*math.sin(t*math.pi*2+i*.7))
  xx=x+39*math.cos(angle); yy=y-11+13*math.sin(angle)-4*math.sin(t*math.pi*2+i)
  w=[5.5,4.4,5.0][i];h=[10,8,9][i]
  pts=[(xx-w,yy+2),(xx-w*.28,yy-h),(xx+w*.59,yy-h*.52),(xx+w,yy+h*.26),(xx+w*.17,yy+h)]
  c.poly(pts,'ink',a*.82)
  c.poly([(xx+(px-xx)*.65,yy+(py-yy)*.68) for px,py in pts],'amber',a)
  c.poly([(xx-w*.13,yy-h*.55),(xx+w*.4,yy-h*.36),(xx+w*.14,yy+1)],'bone',a*.7)

def render(name,i,n,yaw):
 c=Canvas();t=i/(n-1)
 if name.startswith('sword'):sword(c,t,yaw,3 if 'finisher' in name else int(name[-2:]))
 else:{'lantern_cone_flare':flare,'amber_impact':impact,'footstep_dust':dust,'dash_wake':dash,'stagger_shards':stagger}[name](c,t,yaw)
 return c

def clip_build(name,yaw,out):
 n,label,space,description=SPECS[name]
 suffix=f'd{yaw:03d}' if name in DIRECTIONAL else 'unoriented'
 clipid=f'{name}__{suffix}'
 folder=out/'frames'/clipid;folder.mkdir(parents=True,exist_ok=True)
 svgdir=out/'vectors'/clipid;svgdir.mkdir(parents=True,exist_ok=True)
 atlasdir=out/'atlases';atlasdir.mkdir(exist_ok=True)
 pad=3
 frames=[];bounds=[];images=[]
 for i in range(n):
  c=render(name,i,n,yaw);filename=f'{i:03d}.png';im=c.export(folder/filename);images.append(im)
  (svgdir/f'{i:03d}.svg').write_text(c.svg_text())
  bbox=im.getbbox();bounds.append(bbox)
  frames.append({'id':i,'file':str((folder/filename).relative_to(out)),'svg':str((svgdir/f'{i:03d}.svg').relative_to(out)), 'durationSeconds':1/FPS,'durationRational':[1,FPS],'sourceSizePx':[W,H],'pivotPx':list(PIVOT),'alphaBoundsPx':list(bbox) if bbox else None})
 visible=[b for b in bounds if b]
 union=[max(0,min(b[0] for b in visible)-2),max(0,min(b[1] for b in visible)-2),min(W,max(b[2] for b in visible)+2),min(H,max(b[3] for b in visible)+2)]
 cw=union[2]-union[0];ch=union[3]-union[1];cellw=cw+pad*2;cellh=ch+pad*2
 cols=min(4,2048//cellw)
 while math.ceil(n/cols)*cellh>2048 and cols<2048//cellw:cols+=1
 rows=math.ceil(n/cols)
 if cols*cellw>2048 or rows*cellh>2048:raise ValueError('Atlas exceeds 2048')
 atlas=Image.new('RGBA',(cols*cellw,rows*cellh))
 for i,(im,frame) in enumerate(zip(images,frames)):
  x=pad+(i%cols)*cellw;y=pad+(i//cols)*cellh
  atlas.paste(im.crop(union),(x,y))
  frame.update({'rectPx':[x,y,cw,ch],'trimOffsetPx':union[:2],'atlasPivotPx':[PIVOT[0]-union[0],PIVOT[1]-union[1]],'atlasSourceCropPx':union})
 atlasname=f'atlases/{clipid}.png';atlas.save(out/atlasname,optimize=True)
 clip={'id':clipid,'effect':name,'label':label,'description':description,'space':space,'headingDegrees':yaw if name in DIRECTIONAL else None,'headingMeaning':'0=+Z; positive toward +X; d045 toward camera' if name in DIRECTIONAL else None,'frameCount':n,'sourceFPS':FPS,'durationSeconds':n/FPS,'durationRational':[n,FPS],'loop':False,'finishBehavior':'remove effect after final transparent frame','frames':frames,'atlas':atlasname,'atlasSizePx':list(atlas.size),'atlasPaddingPx':pad,'atlasCropPolicy':'one constant union crop for the complete clip; loose PNG and SVG retain untrimmed canvas','emitterLocalPositionMetres':[0,.86,.05] if name=='lantern_cone_flare' else None,'placementRule':'Place the source foot-root pivot at the actor effect-root; geometry already includes emitter height. To attach at a lantern socket, subtract the projected emitter offset before placing the root. Never apply emitter height twice.' if name=='lantern_cone_flare' else 'Attach root at documented effect origin; do not apply frame trim to world position.','pivotMeaning':'world effect root / foot level at local (0,0,0)' if space=='projected_world' else 'effect attachment point (impact point or head socket)','blend':{'pngAlpha':'straight (unassociated)','premultipliedAlpha':False,'recommended':'normal source-over','sourceFactor':'SRC_ALPHA','destinationFactor':'ONE_MINUS_SRC_ALPHA','textureColorSpace':'sRGB','blendColorSpace':'linear preferred','alphaIsLinear':True,'additiveRequired':False},'visualEvents':[{'frame':1,'name':'effect_visible','authority':'presentation_only'}]}
 return clip

def font(size,bold=False):
 name='DejaVuSans'+('-Bold' if bold else '')+'.ttf'
 for candidate in ['/usr/share/fonts/truetype/dejavu/'+name,name]:
  try:return ImageFont.truetype(candidate,size)
  except OSError:pass
 return ImageFont.load_default(size=size)


def panel(bg,width=640,height=315):
 im=Image.new('RGB',(width,height),bg);d=ImageDraw.Draw(im)
 light=sum(bg)>400;floor=(199,195,181) if light else (42,47,47);line=(175,172,161) if light else (49,55,54)
 d.polygon([(0,103),(width,47),(width,height),(0,height)],fill=floor)
 # Quiet flat isometric slabs. No texture or borrowed assets.
 for j in range(-3,7):
  xx=j*146
  d.line([(xx,105),(xx+430,height)],fill=line,width=1)
  d.line([(xx,105),(xx-430,height)],fill=line,width=1)
 # Neutral silhouette for visual scale, explicitly not the locked hero art.
 x,y=320,259;body=(73,75,70) if light else (103,100,86);shade=(52,56,53) if light else (77,82,75)
 d.ellipse([x-24,y-5,x+23,y+5],fill=(170,168,156) if light else (32,37,36))
 d.polygon([(x-12,y),(x-13,y-33),(x-19,y-78),(x-11,y-100),(x+9,y-100),(x+16,y-74),(x+11,y-32),(x+14,y),(x+3,y),(x,y-35),(x-3,y)],fill=shade)
 d.polygon([(x-11,y-99),(x-8,y-76),(x+8,y-72),(x+9,y-99)],fill=body)
 d.ellipse([x-10,y-119,x+10,y-100],fill=body)
 return im

def composite_frame(base,fr,pos,scale):
 if fr is None:return base
 fw,fh=round(W*scale),round(H*scale);im=fr.resize((fw,fh),Image.Resampling.LANCZOS)
 base.paste(im,(round(pos[0]-PIVOT[0]*scale),round(pos[1]-PIVOT[1]*scale)),im)
 return base

def make_review(out,clips,filename='effects_review_60hz.mp4'):
 chosen=[]
 for name in dict.fromkeys(c['effect'] for c in clips):
  cs=[c for c in clips if c['effect']==name];chosen.append(next((c for c in cs if c['headingDegrees']==90),cs[0]))
 while len(chosen)%2:chosen.append(chosen[-1])
 arrays={c['id']:[Image.open(out/f['file']).convert('RGBA') for f in c['frames']] for c in chosen}
 review=out/'review';review.mkdir(exist_ok=True)
 # 3.6 seconds per two-effect page, 60 genuine video samples/second, 30 source drawings/second.
 total=len(chosen)//2*216
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1280x800','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','21','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(review/filename)]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 screenshot=None
 for tick in range(total):
  page=tick//216;localtick=tick%216;pair=chosen[page*2:page*2+2]
  image=Image.new('RGB',(1280,800),(24,29,29));d=ImageDraw.Draw(image)
  d.text((30,19),'LANTERN  /  CLEAN INK EFFECTS',font=font(23,True),fill=(244,236,217))
  d.text((30,53),'Controlled vectors  ·  30 authored fps  ·  60 Hz review  ·  original art',font=font(15),fill=(174,179,169))
  for row,clip in enumerate(pair):
   # Repeat each 1.8 s; no interpolation or generated video frames.
   time=(localtick%108)/60;fi=math.floor(time*FPS)
   visible=fi<clip['frameCount'];fr=arrays[clip['id']][fi] if visible else None
   for col,bg in enumerate([(32,38,38),(212,208,194)]):
    card=panel(bg);cd=ImageDraw.Draw(card);light=col==1;text=(43,48,46) if light else (235,228,209)
    cd.text((25,14),clip['label'],font=font(18,True),fill=text)
    cd.text((25,40),('Light' if light else 'Dark')+' ground  |  '+('d090' if clip['headingDegrees']!=None else ('ground effect' if clip['space']=='projected_world' else 'socket overlay')),font=font(12),fill=text)
    pos=(320,259)
    if clip['effect']=='amber_impact':pos=(354,186)
    if clip['effect']=='stagger_shards':pos=(320,124)
    card=composite_frame(card,fr,pos,.742)
    cd=ImageDraw.Draw(card)
    cd.text((25,289),f"{clip['frameCount']} frames / {clip['durationSeconds']:.3f} s  ·  "+(f'frame {fi+1:02d}' if visible else 'cleared'),font=font(12),fill=text)
    image.paste(card,(col*640,91+row*321))
  d=ImageDraw.Draw(image)
  d.text((30,746),'Neutral scale proxy, not hero art.  Geometry: 35.2643897° elevation / 45° azimuth.',font=font(14),fill=(185,187,176))
  d.text((30,771),'All effects are visual-only.  Damage, cone range, invulnerability and stagger timing remain gameplay-owned.',font=font(12),fill=(141,149,141))
  if localtick==10:
   image.save(review/f'proof_page_{page+1:02d}.jpg',quality=94)
  proc.stdin.write(image.tobytes())
 proc.stdin.close();code=proc.wait()
 if code:raise RuntimeError('ffmpeg failed')
 # Contact sheet: six actual samples per chosen clip, on alternating grounds.
 tw,th=256,258;sheet=Image.new('RGB',(tw*6,th*len(chosen)),(30,35,35));sd=ImageDraw.Draw(sheet)
 for row,clip in enumerate(chosen):
  for j in range(6):
   idx=round((j+1)*(clip['frameCount']-2)/7);fr=arrays[clip['id']][idx]
   cell=Image.new('RGB',(tw,th),(206,203,188) if j%2 else (43,49,48));cd=ImageDraw.Draw(cell);tx=(50,56,52) if j%2 else (238,231,209)
   scaled=fr.resize((256,224),Image.Resampling.LANCZOS);cell.paste(scaled,(0,18),scaled)
   cd.text((10,5),clip['label'],font=font(12,True),fill=tx)
   cd.text((10,240),f'frame {idx:02d} / {clip["frameCount"]}  •  t={idx/FPS:.3f}s',font=font(10),fill=tx)
   sheet.paste(cell,(j*tw,row*th))
 sheet.save(review/'source_frame_contact.jpg',quality=94)


def qa(out,clips):
 result={'passed':True,'issues':[],'clips':len(clips),'frames':sum(c['frameCount'] for c in clips),'uniqueSourceFrames':0,'atlasFramesExact':True,'alphaZeroRGBZero':True,'edgeMarginMinimumPx':None,'sourceFPS':FPS,'reviewFPS':60,'checks':[]}
 allhash=set();margins=[]
 for clip in clips:
  atlas=Image.open(out/clip['atlas']).convert('RGBA');hashes=set()
  for frame in clip['frames']:
   im=Image.open(out/frame['file']).convert('RGBA');arr=np.array(im)
   h=hashlib.sha256(arr.tobytes()).hexdigest();hashes.add(h);allhash.add(h)
   if np.any(arr[arr[:,:,3]==0,:3]):result['alphaZeroRGBZero']=False;result['issues'].append('RGB under alpha=0: '+frame['file'])
   x,y,w,h=frame['rectPx'];crop=atlas.crop((x,y,x+w,y+h))
   if crop.tobytes()!=im.crop(frame['atlasSourceCropPx']).tobytes():result['atlasFramesExact']=False;result['issues'].append('Atlas mismatch '+frame['file'])
   bbox=im.getbbox()
   if bbox:
    margin=min(bbox[0],bbox[1],W-bbox[2],H-bbox[3]);margins.append(margin)
    if margin<4:result['issues'].append('Clipping risk '+frame['file'])
  if len(hashes)<clip['frameCount']-1:result['issues'].append('Unexpected duplicate source frames '+clip['id'])
  if np.array(Image.open(out/clip['frames'][0]['file']))[:,:,3].max()!=0 or np.array(Image.open(out/clip['frames'][-1]['file']))[:,:,3].max()!=0:result['issues'].append('Clip endpoints not transparent '+clip['id'])
 result['edgeMarginMinimumPx']=min(margins);result['uniqueSourceFrames']=len(allhash);result['passed']=not result['issues']
 result['checks']=['PNG mode RGBA','alpha=0 implies RGB=0','atlas frame crops byte-identical to documented loose-frame union crops','each non-empty silhouette at least 4 px from canvas boundary','all clips have transparent first and last frames','constant loose-frame canvas and pivot; fixed clip union atlas crop','no undocumented duplicate frames beyond shared transparent endpoints','normal alpha blending; premultiplied flag false']
 (out/'qa_report.json').write_text(json.dumps(result,indent=2)+'\n')
 return result

def write_readme(out,clips):
 text=f'''LANTERN — CLEAN INK EFFECTS / v1.0
Original, code-authored game art. Not an engine integration or approved gameplay tuning.

WHAT IS HERE
{len(set(c['effect'] for c in clips))} effect designs, {len(clips)} clips, {sum(c['frameCount'] for c in clips)} transparent PNG source frames.
Directional effects are authored in 3D world coordinates and freshly projected for each
heading. These are not rotated copies of one baked sprite. Each clip has 12–24 drawings
at 30 fps. Every frame also has editable vector SVG. Atlas cells use 3 px transparent
padding on every side and retain the complete 512 × 448 source canvas in loose frames. Atlas cells use a fixed
per-clip union crop with exact source offsets and atlas-local pivot metadata. Each
atlas is at most 2048 px on either axis.

DESIGN
Opening sword cut, returning cut, heavy finisher, short lantern cone, contained amber
impact, muted foot dust, directional dash wake, and three irregular stagger shards.
Clean silhouette edges, a handful of purposeful flat regions, bone / amber / charcoal.
No grain, noise, fluid-brush restyling, full-screen washes, hero edits or generated
video. The lantern fan stays attached to its root throughout its life. It is not a
projectile. Dash wake contains no character afterimage. Stagger is an authored
presentation accent, not a proposed new status system.

CAMERA / SCALE
Right-handed coordinates. XZ ground, +Y vertical. Heading 0 = +Z; positive toward +X.
Orthographic elevation 35.264389682754654 degrees, azimuth 45 degrees from +Z to +X.
Source density: {DENSITY} pixels per world metre before projection. World root projects
to ({PIVOT[0]}, {PIVOT[1]}) px in the 512 × 448 top-left-origin loose canvas. Atlas-only fixed union trim.
At a 1440 px buffer and 13 m vertical span, use uniform scale (1440/13)/112 = 0.98901.
At 1080 px and 13 m span the scale is 0.74176. The review uses 0.742.
The lantern emitter is local (0, 0.86, 0.05) m relative to the source root.
Its vertical offset is already baked. When attaching to an actual lantern socket,
subtract its projected emitter offset from that socket to locate the source root.
Do not add another 0.86 m height to an already socket-anchored effect.
Source geometry is artistic; its metres do not establish approved collision or reach.
Bone impact and stagger are explicitly SCREEN OVERLAYS, not camera-calibrated 3D.
Their pivot is the impact point or attachment socket. Do not scale these as ground
meshes unless you intentionally choose a matching presentation size.

TIMING / AUTHORITY
All durations are explicit rational 1/30 s per source frame. Review video is true
constant 60 Hz, displaying each authored drawing twice. It does not contain 60 new
drawings per second. No optical-flow interpolation. No looped non-empty endpoint.
Every clip is one-shot with transparent first and last frames and is removed at its
end. Visual events are presentation-only. Never derive damage, target checks,
invulnerability, movement, cone range, cooldown or stagger duration from these files.
Gameplay owns those values, and controls start, cancel and playback synchronization.
Footstep dust may be triggered per authored footstep; stagger may be retriggered only
when gameplay says so. Nothing here schedules gameplay actions.

ALPHA / COLOUR / FILTERING
PNG files are RGBA, sRGB RGB, STRAIGHT / UNASSOCIATED alpha. Transparent RGB is zero.
Do not mark these bytes premultiplied. Use normal source-over (SRC_ALPHA,
ONE_MINUS_SRC_ALPHA) with a linear colour blending pipeline where supported. If the
engine premultiplies on upload, change its blend factors consistently to ONE,
ONE_MINUS_SRC_ALPHA; do not premultiply twice. Additive blending is not required.
RGB colour is authored in sRGB; alpha is linear. Export has no matte background.
Borders are antialiased. Three-pixel empty atlas gutters protect bilinear sampling
at native resolution. These are not mip-safe atlases: disable mipmaps or repack with
appropriate alpha-aware edge extrusion and per-mip padding before mipmapped use.
Do not rotate projected directional frames in screen space to invent other world
headings. Re-export the geometry with another yaw if continuous aimed art is needed.

FILES
manifest.json          Exact paths, frame rectangles, rational durations and pivots
frames/                Lossless RGBA PNGs, authoritative exported drawings
vectors/               Corresponding editable SVG for every source frame
atlases/               One ordered union-cropped atlas per clip (each axis at most 2048 px)
review/                60 Hz H.264 MP4, dark/light mockup proof stills, contact sheet
qa_report.json         Intrinsic alpha, clipping, bounds, duplicate and atlas checks
source/build_effects.py Deterministic geometry, export, review and QA source

REBUILD
Python 3, Pillow, numpy; ffmpeg with libx264 for review video.
Run: python source/build_effects.py --full
Use --early for the opening-cut and lantern-cone review gate only.
The output is deterministic from the committed constants; no random seed, outside
images, AI generations, credentials, internet or engine tools are required.

LIMITS
This is an art handoff. It has not been imported or performance-tested in Lantern.
No Unity, Codex or three.js implementation was changed. Review silhouette is a plain
height/placement marker, not a hero redesign or approved character. Values and
attachment placement require the owner's runtime validation. Every heading retains
identical geometry and dimensions; apparent shape changes are projection changes.
Generated 6 October 2026 against Lantern Project Design Document v0.1.
'''
 (out/'README.txt').write_text(text)

def finalize_pack(out,clips):
 # Every heading shown from its own freshly projected source geometry.
 directed=[name for name in SPECS if name in DIRECTIONAL]
 sheet=Image.new('RGB',(1920,256*len(directed)),(28,33,33))
 for row,name in enumerate(directed):
  for j,yaw in enumerate(range(0,360,45)):
   clip=next(c for c in clips if c['effect']==name and c['headingDegrees']==yaw)
   frame=clip['frames'][max(1,round(clip['frameCount']*.38))]
   im=Image.open(out/frame['file']).convert('RGBA').resize((240,210),Image.Resampling.LANCZOS)
   bg=(204,201,187) if j%2 else (42,48,47);tx=(45,51,48) if j%2 else (239,231,212)
   cell=Image.new('RGB',(240,256),bg);cell.paste(im,(0,26),im);d=ImageDraw.Draw(cell)
   d.text((10,8),clip['label'],font=font(12,True),fill=tx)
   d.text((10,237),f'd{yaw:03d}  |  exact camera projection',font=font(10),fill=tx)
   sheet.paste(cell,(j*240,row*256))
 (out/'review').mkdir(exist_ok=True);sheet.save(out/'review/eight_heading_contact.jpg',quality=93)
 sizes=[Image.open(out/c['atlas']).size for c in clips]
 atlas_bytes=sum(x*y*4 for x,y in sizes)
 summary={'clipCount':len(clips),'effectCount':len(set(c['effect'] for c in clips)),'sourceFrameFiles':sum(c['frameCount'] for c in clips),'directionalEffectCount':len(directed),'headingsPerDirectionalEffect':8,'atlasMaximumWidthPx':max(x for x,y in sizes),'atlasMaximumHeightPx':max(y for x,y in sizes),'allAtlasBaseRGBA8Bytes':atlas_bytes,'allAtlasBaseRGBA8MiB':round(atlas_bytes/1024**2,3),'allLooseFramesDecodedRGBA8Bytes':sum(c['frameCount'] for c in clips)*W*H*4,'mipmapsIncluded':False,'runtimePerformanceTested':False,'notes':'Estimates are raw RGBA8 texture allocation only, not PNG file size or measured GPU use. Load the atlases you need; do not upload both loose frames and atlases. No mipmaps or engine integration are included.'}
 (out/'texture_budget.json').write_text(json.dumps(summary,indent=2)+'\n')
 readme=out/'README.txt'
 text=readme.read_text()
 if 'ORDINARY ZIP VOLUMES' not in text:
  text+='\nORDINARY ZIP VOLUMES\nExtract both ordinary ZIPs into the same directory to assemble this one pack.\nAssets contains PNG frames, atlases, manifest, QA, budget and the generator.\nSource_and_Preview contains editable per-frame SVG and the 60 Hz review evidence.\nThese are independent standard ZIP files, not binary split archives.\n'
  readme.write_text(text)
 (out/'source/build_effects.py').write_text(Path(__file__).read_text())
 hash_lines=[]
 for f in sorted(out.rglob('*')):
  if f.is_file() and f.name!='SHA256SUMS.txt':
   hash_lines.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(out).as_posix())
 (out/'SHA256SUMS.txt').write_text('\n'.join(hash_lines)+'\n')
 for group in ['Assets','Source_and_Preview']:
  zp=ROOT/f'Lantern_Combat_Effects_v1_{group}.zip'
  with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
   for f in sorted(out.rglob('*')):
    if not f.is_file():continue
    rel=f.relative_to(out)
    common=rel.parts[0] not in ['frames','atlases','vectors','review']
    include=common or (rel.parts[0] in (['frames','atlases'] if group=='Assets' else ['vectors','review']))
    if include:z.write(f,f.relative_to(out.parent))
  if zp.stat().st_size>12_000_000:raise ValueError('Volume larger than 12 MB: '+str(zp))
  print('ZIP',zp,zp.stat().st_size,flush=True)
 old=ROOT/'Lantern_Clean_Ink_Combat_Effects_v1.zip'
 if old.exists():old.unlink()

def main():
 p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--early',action='store_true');p.add_argument('--no-preview',action='store_true');args=p.parse_args()
 out=ROOT/('combat_pack_v1' if args.full else 'early_review');out.mkdir(parents=True,exist_ok=True)
 names=list(SPECS) if args.full else ['sword_arc_01','lantern_cone_flare']
 clips=[]
 for name in names:
  headings=list(range(0,360,45)) if args.full and name in DIRECTIONAL else ([90] if name in DIRECTIONAL else [0])
  for yaw in headings:
   print('Building',name,yaw,flush=True);clips.append(clip_build(name,yaw,out))
 manifest={'schema':'lantern.controlled-vfx.v1','version':'1.0.0','status':'original art candidate; engine integration and owner approval not implied','authoring':'deterministic vector geometry; no image inputs; no AI frame synthesis','camera':{'projection':'orthographic','elevationDegrees':ELEVATION,'azimuthDegrees':AZIMUTH,'azimuthConvention':'from +Z toward +X','worldAxes':'right-handed XZ ground +Y vertical','sourcePixelsPerWorldMetre':DENSITY,'referenceVerticalSpanMetres':13,'imageOrigin':'top_left','sourceCanvasPx':[W,H],'rootPivotPx':list(PIVOT),'screenRight':[math.sqrt(.5),0,-math.sqrt(.5)],'screenUp':[-1/math.sqrt(6),math.sqrt(2/3),-1/math.sqrt(6)],'matrixConvention':'basis row dot world position; screen y negates screen-up; multiply by density then add pivot'},'license':'Original artwork authored for the Lantern project; no external art assets included.','gameplayAuthority':'none; all events and dimensions presentation-only','clips':clips}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');write_readme(out,clips)
 src=out/'source';src.mkdir(exist_ok=True);(src/'build_effects.py').write_text(Path(__file__).read_text())
 result=qa(out,clips);print(json.dumps(result,indent=2),flush=True)
 if not args.no_preview:make_review(out,clips)
 if result['passed'] and args.full:finalize_pack(out,clips)
 if not result['passed']:raise SystemExit(2)
if __name__=='__main__':main()
