#!/usr/bin/env python3
"""Complementary ZIPs with exact-union, CRC and SHA256 verification. No uploads."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
if ROOT.name=='flare_treatments_v1':ROOT=ROOT.parent
PACK=ROOT/'flare_treatments_v1'
LIMIT=12_000_000

def digest(data):return hashlib.sha256(data).hexdigest()
def main():
 files=sorted(p for p in PACK.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 groups=[('Assets',[p for p in files if p.relative_to(PACK).parts[0] in ['frames','atlases']]),('Source_and_Review',[p for p in files if p.relative_to(PACK).parts[0] not in ['frames','atlases']])]
 paths=[];records=[];seen=set()
 for label,subset in groups:
  if not subset:continue
  # Measure actual compressed membership so well-compressing SVGs do not create
  # needless extra volumes. Final archives still receive an independent size check.
  trial=ROOT/f'.trial_{label}.zip'
  with zipfile.ZipFile(trial,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
   for p in subset:z.write(p,arcname='flare_treatments_v1/'+p.relative_to(PACK).as_posix())
  with zipfile.ZipFile(trial) as z:
   compressed={inf.filename.removeprefix('flare_treatments_v1/'):inf.compress_size for inf in z.infolist()}
  if trial.stat().st_size<=LIMIT:
   parts=[subset]
  else:
   parts=[];part=[];size=0
   for p in subset:
    n=compressed[p.relative_to(PACK).as_posix()]+300
    if n+2000>LIMIT:raise RuntimeError('Individual compressed file too large: '+str(p))
    if part and size+n>LIMIT-100000:parts.append(part);part=[];size=0
    part.append(p);size+=n
   if part:parts.append(part)
  trial.unlink()
  for j,part in enumerate(parts):
   suffix=f'_{j+1:02d}' if len(parts)>1 else ''
   zp=ROOT/f'Lantern_Flare_Treatments_v1_{label}{suffix}.zip'
   with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in part:z.write(p,arcname='flare_treatments_v1/'+p.relative_to(PACK).as_posix())
   if zp.stat().st_size>LIMIT:raise RuntimeError('Archive size exceeds 12 MB')
   paths.append(zp)
   with zipfile.ZipFile(zp) as z:
    bad=z.testzip()
    if bad:raise RuntimeError('CRC failed: '+bad)
    members=[]
    for inf in z.infolist():
     rel=inf.filename.removeprefix('flare_treatments_v1/')
     if rel in seen:raise RuntimeError('Duplicate delivery member: '+rel)
     seen.add(rel);data=z.read(inf.filename)
     if digest(data)!=digest((PACK/rel).read_bytes()):raise RuntimeError('Archive hash mismatch: '+rel)
     members.append({'path':rel,'bytes':len(data),'crc32':f'{inf.CRC:08x}','sha256':digest(data)})
   records.append({'archive':zp.name,'bytes':zp.stat().st_size,'sha256':digest(zp.read_bytes()),'crcTestPassed':True,'memberCount':len(members),'members':members})
 expected={p.relative_to(PACK).as_posix() for p in files}
 if seen!=expected:raise RuntimeError('Union mismatch')
 ledger={'schema':'lantern.delivery-ledger.v1','pack':'flare_treatments_v1','limitBytesPerArchive':LIMIT,'archiveCount':len(records),'memberCount':len(seen),'exactUnion':True,'noDuplicateMembers':True,'allCRCChecksPassed':True,'allSourceHashesMatched':True,'archives':records}
 (ROOT/'DELIVERY_LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n')
 (ROOT/'DELIVERY_INDEX.txt').write_text('LANTERN / LANTERN FLARE TREATMENTS v1\n\nExtract ALL complementary volumes into one directory. There is no overlap; their\nexact union reconstructs flare_treatments_v1/. Every archive is under 12,000,000 bytes.\n\n'+''.join(f"{r['archive']}\n  {r['bytes']:,} bytes | {r['memberCount']} files\n  SHA256 {r['sha256']}\n" for r in records)+'\nDELIVERY_LEDGER.json contains CRC and SHA256 for every member.\nNo upload or engine integration performed.\n')
 print(json.dumps({k:v for k,v in ledger.items() if k!='archives'},indent=2));print('\n'.join(str(p) for p in paths))
if __name__=='__main__':main()
