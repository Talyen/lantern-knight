#!/usr/bin/env python3
"""Three original treatments of one short lantern flare; no gameplay authority."""
from pathlib import Path
import argparse,hashlib,json,math,shutil,subprocess
import numpy as np
from PIL import Image,ImageDraw
from vfx_core import Canvas,proj,local,font,clamp,smooth,C,W,H,PIVOT,DENSITY,ELEVATION,AZIMUTH
SOURCE=Path(__file__).resolve().parent;ROOT=SOURCE.parent
if ROOT.name in ('early_review','flare_treatments_v1'):ROOT=ROOT.parent
TAU=math.tau;HEADING=135;ACTIVE_HEADING=HEADING;FRAME_COUNT=18;EMITTER=(0,.86,.05);RADIUS=2.10;HALFANGLE=28.0
C.update({'ink':'#303432','warmedge':'#795333','burnt':'#ba7537','amber':'#e9aa4b','light':'#f6cf78','core':'#fff0c5','pane':'#d6933f','paneshade':'#ab6832'})
SPECS={
'layered_flame_tongues':dict(label='A / Layered flame tongues',description='Three curved interlocking flame tongues open from the socket, with broad gold planes and a brief pale centre. Their shoulders fold inward as they clear.',shapeLanguage='Curved pointed lobes, overlapping broad folds, restrained three-value flame mass.'),
'fractured_amber_panes':dict(label='B / Fractured amber panes',description='Five broad asymmetric panes hinge open as a connected fan of amber light. Pale cut planes and clear angular gaps replace the old zigzag flame fan.',shapeLanguage='Large angular light planes, five uneven facets, broad fracture edges; no glass projectile fragments.'),
'curling_ember_ribbons':dict(label='C / Curling ember ribbons',description='Three broad ember ribbons unfurl and curl back inside the same short cone. Open negative spaces and rolled ends distinguish this from a filled flame fan.',shapeLanguage='Broad S and hook curves with pale inner tracks; all ribbons remain rooted, no particle stream.'),
}

def bez(points,n=24):
 p0,p1,p2,p3=points;out=[]
 for i in range(n+1):
  t=i/n;s=1-t;out.append(tuple(s*s*s*p0[k]+3*s*s*t*p1[k]+3*s*t*t*p2[k]+t*t*t*p3[k] for k in range(len(p0))))
 return out
def outline(c,pts,width=1.55,col='ink',a=1):
 left=[];right=[]
 for i,p in enumerate(pts):
  p0=pts[max(0,i-1)];p1=pts[min(len(pts)-1,i+1)];dx=p1[0]-p0[0];dy=p1[1]-p0[1];ln=max(math.hypot(dx,dy),1e-8);left.append((p[0]-dy/ln*width/2,p[1]+dx/ln*width/2));right.append((p[0]+dy/ln*width/2,p[1]-dx/ln*width/2))
 c.poly(left+right[::-1],col,a)
def envelopes(t):
 if t<=0 or t>=1:return 0,0,0
 grow=smooth(t/.245);fade=1-smooth((t-.48)/.52);a=smooth(t/.10)*fade;retract=1-.21*smooth((t-.62)/.38);impact=smooth((t-.12)/.09)*(1-smooth((t-.35)/.20))
 return grow*retract,a,impact
def point(ang,r,height,g):
 theta=math.radians(HALFANGLE*clamp(ang,-1,1));rr=RADIUS*clamp(r)*g;return local(rr*math.sin(theta),EMITTER[1]+height,EMITTER[2]+rr*math.cos(theta),ACTIVE_HEADING)
def patch(c,params,g,col,a,loft=0,edge=True):
 pts=[point(ang,r,loft*math.sin(math.pi*clamp(r)),g) for ang,r in params];pp=[proj(p) for p in pts];c.poly(pp,col,a)
 if edge:outline(c,pp+[pp[0]],1.55,'ink',a*.85)

def flame(c,t):
 g,a,hit=envelopes(t)
 if a<=0:return
 # All tongues originate at the same socket. Their tips breathe and fold but
 # never leave the shared illustrative sector or become travelling bolts.
 for index,(centre,span,reach,loft) in enumerate([(.55,.36,.92,.045),(-.54,.37,.91,.018),(0,.40,1.0,.145)]):
  flutter=.055*math.sin(t*TAU*1.2+index*1.7)*(1-.5*t);tip=centre+flutter;rr=reach*(1-.035*math.sin(t*TAU+index))
  root=(0,0);left=(centre-span*.45,.79);tippt=(tip,rr);shoulder=(centre+span*.88,.46)
  params=bez([root,(centre-span*.64,.23),(centre-span*.93,.57),left],26)
  params+=bez([left,(centre-span*.27,.86),(tip-.07,.86),tippt],18)[1:]
  params+=bez([tippt,(centre+span*.22,.76),(centre+span*.91,.63),shoulder],24)[1:]
  params+=bez([shoulder,(centre+span*.54,.24),(centre+.035,.11),root],24)[1:]
  patch(c,params,g,'burnt' if index<2 else 'amber',a,loft)
  # Broad inner plane follows the tongue, keeping a clear dark/warm outer edge.
  inner=[(centre+(u-centre)*.66,v*.93) for u,v in params]
  patch(c,inner,g,'amber' if index<2 else 'light',a*.94,loft+.009,False)
  if index==2:
   pale=[(u*.40,v*.80) for u,v in params];patch(c,pale,g,'core',a*(.42+.54*hit),loft+.017,False)

def panes(c,t):
 g,a,hit=envelopes(t)
 if a<=0:return
 boundaries=[-1,-.63,-.20,.21,.63,1];ends=[.84,.975,.91,1.0,.85]
 for i in [4,3,2,1,0]:
  left=boundaries[i]+.026;right=boundaries[i+1]-.026;mid=(left+right)/2;reach=ends[i];hinge=.025*math.sin(t*TAU+i*.65);loft=(.042+.018*(i%2))*math.sin(math.pi*clamp(t/.73))
  pp=[(0,0),(left,.53),(left+.026,reach*.84),(mid+hinge,reach),(right,reach*.88),(right,.43)]
  patch(c,pp,g,'pane' if i%2 else 'amber',a,loft)
  # One large pale cut face per pane, not little repeating facets or flecks.
  cut=[(left+.055,reach*.76),(mid+hinge,reach*.93),(right-.045,reach*.84),(mid,.54)]
  patch(c,cut,g,'light',a*(.47+.30*hit),loft+.013,False)
  shadow=[(mid*.09,.035),(left+.017,.51),(left+.039,reach*.75),(mid,.54)]
  patch(c,shadow,g,'paneshade',a*.66,loft+.004,False)
 core=[(0,0),(-.26,.30),(0,.56),(.25,.30)]
 patch(c,core,g,'core',a*(.46+.48*hit),.057,False)

RIBBON_PATHS=[
 [[(0,.015),(-.38,.24),(-.99,.67),(-.40,.94)],[(-.40,.94),(.17,.99),(.04,.65),(-.40,.67)]],
 [[(0,.018),(.26,.22),(.90,.43),(.69,.83)],[(.69,.83),(.37,1.0),(.06,.82),(.37,.73)]],
 [[(0,.018),(-.11,.28),(.29,.48),(.08,.78)],[(.08,.78),(-.16,.96),(-.62,.76),(-.14,.54)]],
]
def constrain_local(x,z):
 rr=min(RADIUS,math.hypot(x,z));aa=clamp(math.atan2(x,z),-math.radians(HALFANGLE),math.radians(HALFANGLE));return rr*math.sin(aa),rr*math.cos(aa)
def ribbon_shape(c,path,g,a,col,width,loft,phase,inner=False):
 params=[]
 for section in path:params+=bez(section,30)[bool(params):]
 centre=[]
 for i,(an,rr) in enumerate(params):
  theta=math.radians(HALFANGLE*an);r=RADIUS*rr;centre.append((r*math.sin(theta),r*math.cos(theta),rr))
 left=[];right=[]
 for i,(x,z,rr) in enumerate(centre):
  p=centre[max(0,i-1)];q=centre[min(len(centre)-1,i+1)];dx=q[0]-p[0];dz=q[1]-p[1];ln=max(math.hypot(dx,dz),1e-8);u=i/(len(centre)-1);ww=width*(math.sin(math.pi*u)**.44)*(.82+.18*math.sin(phase+u*4));y=EMITTER[1]+loft*math.sin(math.pi*rr)
  for sign,arr in [(-1,left),(1,right)]:
   xx,zz=constrain_local(x-sign*dz/ln*ww/2,z+sign*dx/ln*ww/2);arr.append(local(xx*g,y,EMITTER[2]+zz*g,ACTIVE_HEADING))
 pts=[proj(p) for p in left+right[::-1]];c.poly(pts,col,a)
 if not inner:outline(c,pts+[pts[0]],1.7,'ink',a*.88)
def ribbons(c,t):
 g,a,hit=envelopes(t)
 if a<=0:return
 for i in [1,0,2]:
  # The rolled ends tighten during recovery while remaining inside the envelope.
  tuck=smooth((t-.43)/.57);path=[[(an*(1-.11*tuck),r*(1-.10*tuck*(j/3))) for j,(an,r) in enumerate(section)] for section in RIBBON_PATHS[i]]
  ribbon_shape(c,path,g,a,'burnt' if i==1 else 'amber',.25 if i<2 else .205,.04+i*.045,t*TAU+i)
  ribbon_shape(c,path,g,a*.96,'light' if i<2 else 'core',.112 if i<2 else .077,.047+i*.045,t*TAU+i,True)
 # Compact socket heat ties the separated curves to one source for every frame.
 patch(c,[(0,0),(-.26,.18),(0,.28),(.27,.18)],g,'core',a*(.47+.43*hit),.025,False)

FUNCS={'layered_flame_tongues':flame,'fractured_amber_panes':panes,'curling_ember_ribbons':ribbons}
def render(name,i,heading=HEADING):
 global ACTIVE_HEADING
 previous=ACTIVE_HEADING;ACTIVE_HEADING=heading
 try:c=Canvas();FUNCS[name](c,i/(FRAME_COUNT-1));return c
 finally:ACTIVE_HEADING=previous

def export_clip(name,out,heading=HEADING):
 spec=SPECS[name];n=FRAME_COUNT;clipid=f'{name}__d{heading:03d}';folder=out/'frames'/clipid;folder.mkdir(parents=True,exist_ok=True);svgs=out/'vectors'/clipid;svgs.mkdir(parents=True,exist_ok=True);images=[];frames=[];bounds=[]
 for i in range(n):
  c=render(name,i,heading);im=c.export(folder/f'{i:03d}.png');images.append(im);(svgs/f'{i:03d}.svg').write_text(c.svg_text());bounds.append(im.getbbox())
 b=[x for x in bounds if x];union=[min(x[0] for x in b)-2,min(x[1] for x in b)-2,max(x[2] for x in b)+2,max(x[3] for x in b)+2];cw,ch=union[2]-union[0],union[3]-union[1];pad=4;cols=6;rows=math.ceil(n/cols);atlas=Image.new('RGBA',(cols*(cw+2*pad),rows*(ch+2*pad)))
 for i,im in enumerate(images):
  x=pad+(i%cols)*(cw+2*pad);y=pad+(i//cols)*(ch+2*pad);atlas.paste(im.crop(union),(x,y));frames.append({'id':i,'file':f'frames/{clipid}/{i:03d}.png','svg':f'vectors/{clipid}/{i:03d}.svg','rectPx':[x,y,cw,ch],'sourceSizePx':[W,H],'trimOffsetPx':union[:2],'atlasSourceCropPx':union,'pivotPx':list(PIVOT),'atlasPivotPx':[PIVOT[0]-union[0],PIVOT[1]-union[1]],'durationRational':[1,30],'durationSeconds':1/30,'alphaBoundsPx':list(bounds[i]) if bounds[i] else None})
 (out/'atlases').mkdir(exist_ok=True);atlasname=f'atlases/{clipid}.png';atlas.save(out/atlasname,optimize=True)
 return {'id':clipid,'treatment':name,'family':'lantern_cone_flare','role':'alternative treatment of the same existing flare, not a new ability',**spec,'headingDegrees':heading,'headingConvention':'0=+Z; positive toward +X; 45 points toward camera','directionMethod':'rotate original local world geometry around +Y before exact camera projection; never rotate the rendered sprite','space':'projected_world','frameCount':n,'sourceFPS':30,'durationRational':[n,30],'durationSeconds':n/30,'loop':False,'frames':frames,'atlas':atlasname,'atlasSizePx':list(atlas.size),'atlasPaddingPx':pad,'atlasCropPolicy':'fixed union crop per treatment and heading; untrimmed source PNG/SVG','rootPivotPx':list(PIVOT),'pivotMeaning':'foot-level effect root at local world (0,0,0)','emitterLocalPositionMetres':list(EMITTER),'emitterProjectedPixelPosition':list(proj(local(*EMITTER,heading))),'placementRule':'Root the image at the actor effect-root. Height is already baked. For an actual lantern socket, subtract the projected emitter offset from the socket to locate the foot-root pivot. No actor socket has been calibrated here.','finishBehavior':'remove after transparent final drawing','blend':{'pngAlpha':'straight/unassociated','premultipliedAlpha':False,'recommended':'normal source-over','sourceFactor':'SRC_ALPHA','destinationFactor':'ONE_MINUS_SRC_ALPHA','textureColorSpace':'sRGB','alphaIsLinear':True,'additiveRequired':False},'visualPhases':[{'name':'gather/open','frameRangeInclusive':[0,3]},{'name':'brief visual impact','frameRangeInclusive':[4,7]},{'name':'fold and clear','frameRangeInclusive':[8,17]}],'gameplayAuthority':'none; all visual timings and dimensions are illustrative'}

def qa(out,clips):
 report={'passed':True,'issues':[],'abilityFamilyCount':1,'treatmentCount':len(set(c['treatment'] for c in clips)),'headingCount':len(set(c['headingDegrees'] for c in clips)),'clipCount':len(clips),'newSourceFrameCount':sum(c['frameCount'] for c in clips),'minimumMarginPx':999,'transparentEndpoints':True,'atlasCropsMatch':True,'transparentGutters':True,'zeroRGBUnderZeroAlpha':True,'reviewBoundsPass':True,'uniqueness':{},'sharedEnvelopeChecks':{}}
 for clip in clips:
  atlas=Image.open(out/clip['atlas']).convert('RGBA');hashes=set()
  for f in clip['frames']:
   im=Image.open(out/f['file']).convert('RGBA');arr=np.array(im);hashes.add(hashlib.sha256(arr.tobytes()).hexdigest());b=im.getbbox();x,y,w,h=f['rectPx']
   if np.any(arr[arr[:,:,3]==0,:3]):report['issues'].append('Hidden RGB '+f['file']);report['zeroRGBUnderZeroAlpha']=False
   if atlas.crop((x,y,x+w,y+h)).tobytes()!=im.crop(f['atlasSourceCropPx']).tobytes():report['issues'].append('Atlas crop mismatch '+f['file']);report['atlasCropsMatch']=False
   for box in [(x-4,y-4,x+w+4,y),(x-4,y+h,x+w+4,y+h+4),(x-4,y,x,y+h),(x+w,y,x+w+4,y+h)]:
    if atlas.crop(box).getchannel('A').getextrema()[1]:report['issues'].append('Atlas gutter '+f['file']);report['transparentGutters']=False
   if f['id'] in (0,FRAME_COUNT-1) and b:report['issues'].append('Non-clear endpoint '+f['file']);report['transparentEndpoints']=False
   if b:
    report['minimumMarginPx']=min(report['minimumMarginPx'],b[0],b[1],W-b[2],H-b[3])
    for scale in [1440/13/DENSITY,1080/16/DENSITY]:
     rr=[300+(b[0]-PIVOT[0])*scale,280+(b[1]-PIVOT[1])*scale,300+(b[2]-PIVOT[0])*scale,280+(b[3]-PIVOT[1])*scale]
     if rr[0]<8 or rr[1]<40 or rr[2]>554 or rr[3]>398:report['issues'].append('Direction review clipping '+f['file']);report['reviewBoundsPass']=False
     if clip['headingDegrees']==135:
      rr=[95+(b[0]-PIVOT[0])*scale,250+(b[1]-PIVOT[1])*scale,95+(b[2]-PIVOT[0])*scale,250+(b[3]-PIVOT[1])*scale]
      if rr[0]<8 or rr[1]<40 or rr[2]>408 or rr[3]>305:report['issues'].append('Side-by-side review clipping '+f['file']);report['reviewBoundsPass']=False
  report['uniqueness'][clip['id']]={'uniquePixelFrames':len(hashes),'sourceFrames':FRAME_COUNT,'expectedSharedEmptyEndpoints':True}
  if max(atlas.size)>2048:report['issues'].append('Oversize atlas '+clip['id'])
 # Capture the actual projected vertices, then reverse the authored yaw to
 # verify every treatment against the SAME nominal XZ sector and emitter.
 global proj
 old=proj
 for clip in clips:
  angle=math.radians(-clip['headingDegrees'])
  points=[]
  def capture(p):points.append(p);return old(p)
  try:
   proj=capture
   for i in range(1,FRAME_COUNT-1):render(clip['treatment'],i,clip['headingDegrees'])
  finally:proj=old
  radii=[];angles=[]
  for p in points:
   x=p[0]*math.cos(angle)+p[2]*math.sin(angle);z=-p[0]*math.sin(angle)+p[2]*math.cos(angle)-EMITTER[2];r=math.hypot(x,z);radii.append(r)
   if r>1e-7:angles.append(abs(math.degrees(math.atan2(x,z))))
  record={'maximumRadiusMetres':max(radii),'maximumAbsoluteHalfAngleDegrees':max(angles),'minimumHeightMetres':min(p[1] for p in points),'maximumHeightMetres':max(p[1] for p in points),'passed':max(radii)<=RADIUS+1e-7 and max(angles)<=HALFANGLE+1e-7};report['sharedEnvelopeChecks'][clip['id']]=record
  if not record['passed']:report['issues'].append('Shared envelope exceeded '+clip['id'])
 if report['minimumMarginPx']<6:report['issues'].append('Low canvas margin')
 report['passed']=not report['issues'];(out/'qa_report.json').write_text(json.dumps(report,indent=2)+'\n');return report

FLOOR_CACHE={}
def floor(light,size,scale,root):
 key=(light,size,scale,root)
 if key in FLOOR_CACHE:return FLOOR_CACHE[key].copy()
 dep=SOURCE.parent/'review_dependencies';filename='09_pale_crypt_marble.png' if light else '06_dark_earth.png';tex=np.array(Image.open(dep/filename).convert('RGB'));ss=2
 py,px=np.mgrid[0:size[1]*ss,0:size[0]*ss];dx=(px/ss-root[0])/(DENSITY*scale);dy=(py/ss-root[1])/(DENSITY*scale);xx=(math.sqrt(2)*dx+math.sqrt(6)*dy)/2;zz=(math.sqrt(6)*dy-math.sqrt(2)*dx)/2
 uu=(xx%4)/4*tex.shape[1];vv=(zz%4)/4*tex.shape[0];x0=np.floor(uu).astype(int)%tex.shape[1];y0=np.floor(vv).astype(int)%tex.shape[0];x1=(x0+1)%tex.shape[1];y1=(y0+1)%tex.shape[0];fx=uu%1;fy=vv%1
 arr=tex[y0,x0]*(1-fx[:,:,None])*(1-fy[:,:,None])+tex[y0,x1]*fx[:,:,None]*(1-fy[:,:,None])+tex[y1,x0]*(1-fx[:,:,None])*fy[:,:,None]+tex[y1,x1]*fx[:,:,None]*fy[:,:,None]
 im=Image.fromarray(arr.astype(np.uint8)).resize(size,Image.Resampling.LANCZOS);FLOOR_CACHE[key]=im;return im.copy()

def card(frame,light,size=(480,340),scale=1440/13/DENSITY,label='',detail='',anchors=False):
 root=(95 if size[0]>=480 else 65,250);im=floor(light,size,scale,root)
 if frame:
  fr=frame.resize((round(W*scale),round(H*scale)),Image.Resampling.LANCZOS);im.paste(fr,(round(root[0]-PIVOT[0]*scale),round(root[1]-PIVOT[1]*scale)),fr)
 d=ImageDraw.Draw(im);tx=(42,52,48) if light else (234,230,213);d.text((14,12),label,font=font(13,True),fill=tx);d.text((14,size[1]-26),detail,font=font(10),fill=tx)
 rx=size[0]-28;ry=277;ht=1.8*math.sqrt(2/3)*DENSITY*scale;d.line((rx,ry,rx,round(ry-ht)),fill=tx,width=2);d.line((rx-4,ry,rx+4,ry),fill=tx,width=2);d.line((rx-4,round(ry-ht),rx+4,round(ry-ht)),fill=tx,width=2);d.text((rx-44,ry+7),'1.8 m',font=font(10),fill=tx)
 if anchors:
  ex,ey=proj(local(*EMITTER,HEADING));socket=(root[0]+(ex-PIVOT[0])*scale,root[1]+(ey-PIVOT[1])*scale)
  for p in [root,socket]:d.line((p[0]-5,p[1],p[0]+5,p[1]),fill=tx);d.line((p[0],p[1]-5,p[0],p[1]+5),fill=tx)
  d.text((root[0]-31,root[1]+10),'foot root',font=font(10),fill=tx);d.text((socket[0]-65,socket[1]-20),'socket datum',font=font(10),fill=tx)
 return im

def proofs(out,clips):
 review=out/'review';review.mkdir(exist_ok=True);allfr={c['treatment']:[Image.open(out/f['file']).convert('RGBA') for f in c['frames']] for c in clips}
 for scale,label,filename in [(1440/13/DENSITY,'1440 px / 13 m / actual gameplay reference','Flare_Treatments_Overview.jpg'),(1080/16/DENSITY,'1080 px / 16 m / stress reference','Flare_Treatments_Stress.jpg')]:
  im=Image.new('RGB',(1440,762),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),'ONE LANTERN FLARE / THREE VISUAL ALTERNATIVES',font=font(26,True),fill=(239,233,216));d.text((22,49),label+' | heading 135 degrees | common 0.6-second illustrative timing',font=font(14),fill=(176,190,176))
  for col,c in enumerate(clips):
   for row in range(2):im.paste(card(allfr[c['treatment']][5],row==1,scale=scale,label=c['label'],detail='frame 05 / normal alpha / shared root and art envelope'),(col*480,82+row*340))
  im.save(review/filename,quality=95)
 for c in clips:
  im=Image.new('RGB',(1440,762),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),c['label']+' / open, impact, clear',font=font(24,True),fill=(239,233,216));d.text((22,49),'18 frames / 30 fps / 0.6 seconds / gameplay size / fixed actor-effect root',font=font(14),fill=(176,190,176))
  for k,idx in enumerate([1,3,5,8,12,17]):im.paste(card(allfr[c['treatment']][idx],k%2==1,label=f'frame {idx:02d} / '+('gather' if idx<4 else 'impact' if idx<8 else 'clear'),detail=c['shapeLanguage'][:69]),((k%3)*480,82+(k//3)*340))
  im.save(review/f"phases_{c['treatment']}.jpg",quality=94)
 original=[Image.open(SOURCE.parent/'review_dependencies'/'combat_lantern_cone_flare__d135'/f'{i:03d}.png').convert('RGBA') for i in range(FRAME_COUNT)]
 im=Image.new('RGB',(1600,762),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),'EXISTING COMBAT FLARE / NEW VISUAL ALTERNATIVES',font=font(25,True),fill=(239,233,216));d.text((22,49),'Same heading, source density, 18-frame duration and emitter convention. Existing reference is not a new design.',font=font(14),fill=(176,190,176))
 for j,(label,fr) in enumerate([('Existing / zigzag fan',original[5])]+[(c['label'],allfr[c['treatment']][5]) for c in clips]):
  for row in range(2):im.paste(card(fr,row==1,size=(400,340),label=label,detail='frame 05 | 1440 px / 13 m | normal alpha'),(j*400,82+row*340))
 im.save(review/'Existing_Flare_Comparison.jpg',quality=95)
 im=Image.new('RGB',(1440,422),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),'SHARED FOOT ROOT AND ILLUSTRATIVE SOCKET DATUM',font=font(25,True),fill=(239,233,216));d.text((22,49),'Emitter local (0, 0.86, 0.05) m, rotated by 135 degrees. Crosses are review-only; no hero socket has been calibrated.',font=font(13),fill=(176,190,176))
 for j,c in enumerate(clips):im.paste(card(allfr[c['treatment']][5],j%2==1,label=c['label'],detail='Foot root and raised socket use the same placement in every frame.',anchors=True),(j*480,82))
 im.save(review/'Shared_Anchor_Proof.jpg',quality=95);return allfr,original

def movie(out,clips,allfr,original):
 proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1440x800','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(out/'review'/'Flare_Treatments_Side_by_Side_60Hz.mp4')],stdin=subprocess.PIPE)
 for scale,label in [(1440/13/DENSITY,'1440 px / 13 m gameplay reference'),(1080/16/DENSITY,'1080 px / 16 m stress reference')]:
  cache={(c['treatment'],row):[card(fr,row==1,scale=scale,label=c['label'],detail=f"source frame {i:02d} / 18 | 30 fps | normal alpha") for i,fr in enumerate(allfr[c['treatment']]+[None])] for c in clips for row in range(2)}
  for tick in range(360):
   fi=min((tick%72)//2,18);im=Image.new('RGB',(1440,800),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),'ONE LANTERN FLARE / THREE VISUAL ALTERNATIVES',font=font(25,True),fill=(239,233,216));d.text((22,49),label+' | 30 fps source held 2:1 at 60 Hz | same 0.6-second flare, then clear interval',font=font(14),fill=(176,190,176))
   for col,c in enumerate(clips):
    for row in range(2):im.paste(cache[c['treatment'],row][fi],(col*480,82+row*340))
   d=ImageDraw.Draw(im);d.text((22,779),'135-degree comparison. Shared illustrative envelope and anchor; damage, cooldown, dimensions and action timing remain gameplay-owned.',font=font(12),fill=(170,182,169));proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('ffmpeg failed')
 # A separate synchronized old/new comparison preserves the reference's own
 # unchanged native frames while keeping all four columns at native density.
 proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1600x800','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(out/'review'/'Existing_vs_Treatments_60Hz.mp4')],stdin=subprocess.PIPE)
 items=[('existing','Existing / zigzag fan',original)]+[(c['treatment'],c['label'],allfr[c['treatment']]) for c in clips];cache={(name,row):[card(fr,row==1,size=(400,340),label=label,detail='1440 px / 13 m | source 30 fps | normal alpha') for fr in frames+[None]] for name,label,frames in items for row in range(2)}
 for tick in range(360):
  fi=min((tick%72)//2,18);im=Image.new('RGB',(1600,800),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),'EXISTING FLARE / THREE NEW TREATMENTS OF THE SAME FLARE',font=font(25,True),fill=(239,233,216));d.text((22,49),'Synchronized 18-frame / 0.6-second clips at the same native density, heading and emitter convention.',font=font(14),fill=(176,190,176))
  for col,(name,_,__) in enumerate(items):
   for row in range(2):im.paste(cache[name,row][fi],(col*400,82+row*340))
  d=ImageDraw.Draw(im);d.text((22,779),'Existing combat frames are unchanged review references and excluded from new source-frame counts.',font=font(12),fill=(170,182,169));proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('reference ffmpeg failed')

def direction_card(frame,light,label,detail,scale=1440/13/DENSITY):
 size=(600,430);root=(300,280);im=floor(light,size,scale,root);fr=frame.resize((round(W*scale),round(H*scale)),Image.Resampling.LANCZOS) if frame else None
 if fr:im.paste(fr,(round(root[0]-PIVOT[0]*scale),round(root[1]-PIVOT[1]*scale)),fr)
 d=ImageDraw.Draw(im);tx=(42,52,48) if light else (234,230,213);d.text((16,12),label,font=font(15,True),fill=tx);d.text((16,405),detail,font=font(11),fill=tx);rx=572;ry=340;ht=1.8*math.sqrt(2/3)*DENSITY*scale;d.line((rx,ry,rx,round(ry-ht)),fill=tx,width=2);d.line((rx-4,ry,rx+4,ry),fill=tx,width=2);d.line((rx-4,round(ry-ht),rx+4,round(ry-ht)),fill=tx,width=2);d.text((rx-44,ry+7),'1.8 m',font=font(10),fill=tx)
 return im

def direction_proofs(out,clips):
 review=out/'review'
 for name,spec in SPECS.items():
  group=sorted([c for c in clips if c['treatment']==name],key=lambda c:c['headingDegrees'])
  for scale,tag in [(1440/13/DENSITY,'Native'),(1080/16/DENSITY,'Stress')]:
   im=Image.new('RGB',(2400,80+430*math.ceil(len(group)/4)),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),spec['label']+' / eight world-rotated headings',font=font(27,True),fill=(239,233,216));d.text((22,49),'0 = +Z, positive toward +X; 45 points toward camera. Source geometry rotates before projection. '+tag+' density; frame 05.',font=font(15),fill=(176,190,176))
   for j,c in enumerate(group):
    fr=Image.open(out/c['frames'][5]['file']).convert('RGBA');ca=direction_card(fr,j%2==1,f"d{c['headingDegrees']:03d} / {c['label']}",('1440 px / 13 m' if tag=='Native' else '1080 px / 16 m')+' | normal alpha | same illustrative socket',scale);im.paste(ca,((j%4)*600,80+(j//4)*430))
   im.save(review/f"Headings_{tag}_{name}.jpg",quality=94)

def direction_movie(out,clips):
 headings=sorted(set(c['headingDegrees'] for c in clips));proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1800x980','-r','60','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-r','60','-movflags','+faststart',str(out/'review'/'Eight_Heading_Treatments_60Hz.mp4')],stdin=subprocess.PIPE)
 for heading in headings:
  group=[next(c for c in clips if c['treatment']==name and c['headingDegrees']==heading) for name in SPECS];cache={}
  for c in group:
   frames=[Image.open(out/f['file']).convert('RGBA') for f in c['frames']]+[None]
   for row in range(2):cache[c['treatment'],row]=[direction_card(fr,row==1,c['label'],f'd{heading:03d} | source 30 fps | 1440 px / 13 m | normal alpha') for fr in frames]
  for tick in range(144):
   fi=min((tick%72)//2,18);im=Image.new('RGB',(1800,980),(24,31,31));d=ImageDraw.Draw(im);d.text((22,14),f'ONE LANTERN FLARE / THREE TREATMENTS / HEADING {heading:03d}',font=font(26,True),fill=(239,233,216));d.text((22,49),'8 headings from world geometry; 0 = +Z, positive toward +X, 45 toward camera. Source drawings held twice at 60 Hz.',font=font(15),fill=(176,190,176))
   for col,c in enumerate(group):
    for row in range(2):im.paste(cache[c['treatment'],row][fi],(col*600,82+row*430))
   d=ImageDraw.Draw(im);d.text((22,959),'Three visual treatments, one ability family. Eight headings are variants, not new designs. The original combat flare is unchanged.',font=font(12),fill=(170,182,169));proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('direction ffmpeg failed')

README='''LANTERN / THREE TREATMENTS OF ONE SHORT LANTERN CONE / v1.0
One existing ability family, three alternative visual treatments, eight authored headings,
24 clips. These are not new abilities or approved replacements; headings are variants.
A: three layered curved flame tongues with folding shoulders and a pale centre.
B: five broad fractured amber light panes with clear angular gaps and cut faces.
C: three broad curling ember ribbons with open spaces and rolled ends.
All remain connected to the same illustrative lantern socket; none is a projectile.
432 original PNG frames, 432 matching editable SVGs and 24 atlases. A is recommended
for the first visual/import test because its broad organic shapes read most clearly as
lantern flame. B is a sharper magical alternative; C is an exploratory decorative curl.
No treatment selection is locked. The original combat flare pack remains unchanged.

FAIR COMPARISON / SHARED CONVENTIONS
All three use 18 genuine source frames at 30 fps, lasting 0.6 seconds, just as the old
combat flare. Source samples are i/17; frames 0 and 17 are clear. Each lasts 1/30 s.
Illustrative phases: gather/open 0-3, brief impact 4-7, fold/clear 8-17. These visual
phases do not approve gameplay windup, active windows, damage, cooldown or stagger.
The shared ART ENVELOPE is a 2.10 m radius sector, +/-28 degrees around each
per-clip heading, measured in XZ from the emitter. It bounds projected geometry only; stroke
ink adds decorative pixel thickness. It is not an implemented or approved hitbox.
The existing combat flare is a flatter zigzag fan. New treatments change contours,
plane structure and recovery motion rather than only recolouring that drawing.

CAMERA / ROOT / EMITTER
Right-handed XZ ground, +Y up. Exact orthographic elevation 35.264389682754654 degrees,
azimuth 45 degrees from +Z toward +X. Source 512 x 448 at 112 px/m; foot-root pivot
(256,286), top-left image origin. Heading 0 is +Z; positive heading turns toward +X.
The headings are 0,45,90,135,180,225,270,315 degrees; 45 points toward the camera.
Each clip rotates original local world geometry around +Y BEFORE camera projection.
No projected sprite is screen-rotated to manufacture a direction. The existing
illustrative emitter convention is retained: local (0,0.86,0.05) m,
rotated with the heading before projection. Height is already present in the image.
Place the foot-root at the actor effect-root; for an actual lantern socket, subtract
the projected emitter offset from that socket to find the image root. Do not apply
the emitter height a second time. This emitter has NOT been calibrated to a hero pose.
The foot-level pivot can sit outside the trimmed painted crop; its atlas offset is
recorded explicitly. Loose source PNGs retain the full canvas and shared root.
No hero, sword, lantern model, source rig or locked C / RUST art was edited or drawn.
Every new flare plane is actual world-projected geometry. No billboard exception.

REVIEWS / EXISTING DEPENDENCIES
The side-by-side MP4 is 12 s at 60 Hz: six seconds at 1440 px / 13 m reference density,
then six at 1080 px / 16 m stress density. Each source drawing is held exactly twice;
every 0.6-second flare is followed by a 0.6-second clear interval. Five plays per scale.
Existing_vs_Treatments_60Hz.mp4 is a six-second synchronized old/new comparison.
Eight_Heading_Treatments_60Hz.mp4 is 19.2 seconds: two complete plays per heading,
all three treatments together on light/dark floors at actual 1440 px / 13 m density.
18 unchanged old combat PNG frames and two existing 4 m raw floor tiles are included
only for review reproduction. They are excluded from the new 432-frame/three-treatment
counts. The floor is projected once; these are local-density art crops, not game shots.
No composition, collision, runtime cost, body occlusion or final socket fit was tested.

ALPHA / SOURCE
Straight/unassociated alpha; zero RGB under alpha=0. RGB sRGB, linear alpha.
Normal source-over SRC_ALPHA / ONE_MINUS_SRC_ALPHA. Ink edges and warm dark planes
require source-over. No additive blend, bloom pass, grain or particle flood.
For a later pipeline that premultiplies once, use ONE / ONE_MINUS_SRC_ALPHA consistently.
Four transparent gutter pixels and fixed union crops. Mipmaps are excluded from the
RGBA8 base-level estimate; mipmapped use needs alpha-aware extrusion and mip padding.
Python 3, Pillow, numpy and ffmpeg/libx264 rebuild the pack. Run
python source/build_flare_treatments.py; --early builds only the 135-degree review gate.
Then run python source/package_flare_treatments.py to create complementary ZIPs.
Keep review_dependencies/ to reproduce the unchanged comparison references.
'''

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--early',action='store_true');ap.add_argument('--skip-preview',action='store_true');args=ap.parse_args();out=ROOT/('early_review' if args.early else 'flare_treatments_v1');out.mkdir(exist_ok=True);clips=[];headings=[135] if args.early else list(range(0,360,45))
 for name in SPECS:
  for heading in headings:print('Rendering',name,heading,flush=True);clips.append(export_clip(name,out,heading))
 dependencies=[];(out/'review_dependencies').mkdir(exist_ok=True)
 for p in sorted((SOURCE.parent/'review_dependencies').rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(SOURCE.parent);target=out/rel;target.parent.mkdir(exist_ok=True,parents=True)
  if p.resolve()!=target.resolve():shutil.copyfile(p,target)
  dependencies.append({'file':rel.as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'newArt':False,'role':'unchanged prior combat frame' if 'combat_' in rel.as_posix() else 'unchanged existing 4 m raw floor tile'})
 camera={'projection':'orthographic','elevationDegrees':ELEVATION,'azimuthDegrees':AZIMUTH,'worldAxes':'right-handed XZ ground +Y up','sourcePixelsPerWorldMetre':DENSITY,'sourceCanvasPx':[W,H],'rootPivotPx':list(PIVOT),'screenRight':[math.sqrt(.5),0,-math.sqrt(.5)],'screenUp':[-1/math.sqrt(6),math.sqrt(2/3),-1/math.sqrt(6)],'imageOrigin':'top_left'}
 manifest={'schema':'lantern.flare-treatments.v1','status':'visual alternatives for the same existing short lantern flare; no treatment selected','familyCount':1,'family':'lantern_cone_flare','visualTreatmentCount':3,'recommendedFirstTestTreatment':'layered_flame_tongues','exploratoryTreatment':'curling_ember_ribbons','headingCount':len(headings),'headingsDegrees':headings,'headingConvention':'0=+Z; positive toward +X; 45 points toward camera','directionMethod':'rotate source geometry, never screen-rotate a projected sprite','clipCount':len(clips),'newSourceFrameCount':sum(c['frameCount'] for c in clips),'sourceFPS':30,'camera':camera,'sharedIllustrativeEnvelope':{'shape':'XZ sector at raised emitter','radiusMetres':RADIUS,'halfAngleDegrees':HALFANGLE,'heading':'per clip, using the documented common convention','emitterLocalPositionMetres':list(EMITTER),'authority':'art only; not approved gameplay dimensions or collision'},'unchangedReviewDependencies':dependencies,'unchangedReferenceFrameCount':18,'unchangedFloorTextureCount':2,'billboardExceptions':[],'gameplayAuthority':'none','clips':clips};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');report=qa(out,clips);print(json.dumps(report,indent=2),flush=True);featured=[c for c in clips if c['headingDegrees']==135];frames,original=proofs(out,featured)
 if not args.early:direction_proofs(out,clips)
 if not args.skip_preview:
  movie(out,featured,frames,original)
  if not args.early:direction_movie(out,clips)
 budget={'format':'RGBA8','mipmaps':False,'atlasCount':len(clips),'atlasBytes':sum(math.prod(c['atlasSizePx'])*4 for c in clips),'note':'New treatment atlases only; raw base-level allocation, not a runtime measurement','clips':[{'id':c['id'],'atlasSizePx':c['atlasSizePx'],'bytes':math.prod(c['atlasSizePx'])*4} for c in clips]};(out/'texture_budget.json').write_text(json.dumps(budget,indent=2)+'\n');(out/'README.txt').write_text(README);(out/'source').mkdir(exist_ok=True)
 for name in ['build_flare_treatments.py','vfx_core.py','package_flare_treatments.py']:
  if (SOURCE/name).resolve()!=(out/'source'/name).resolve():shutil.copyfile(SOURCE/name,out/'source'/name)
 (out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(out).as_posix()+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts))
 if not report['passed']:raise SystemExit('QA failed')
 print('FLARE TREATMENTS COMPLETE',out)
if __name__=='__main__':main()
